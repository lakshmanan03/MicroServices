/**
 * 
 */
package com.bfa.insurance.core;

/**
 * @author pradheep.p
 *
 */
public class CRMResponse {
	
	private int customerId;
	
	private String entity_id;
	
	private String entity_type;
	
	private String agent_id;
	
	private Integer hubspotReference;

	public String getEntity_id() {
		return entity_id;
	}

	public void setEntity_id(String entity_id) {
		this.entity_id = entity_id;
	}

	public String getEntity_type() {
		return entity_type;
	}

	public void setEntity_type(String entity_type) {
		this.entity_type = entity_type;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAgent_id() {
		return agent_id;
	}

	public void setAgent_id(String agent_id) {
		this.agent_id = agent_id;
	}

	public Integer getHubspotReference() {
		return hubspotReference;
	}

	public void setHubspotReference(Integer hubspotReference) {
		this.hubspotReference = hubspotReference;
	}
	
}

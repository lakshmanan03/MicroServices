/**
 * 
 */
package com.bfa.insurance;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.bfa.application.core.CustomerAndPrevilegeV2;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.PrevilageMaster;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.request.entity.CustomerCreationDTO;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.util.ErrorCodes;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This test is to check the features of new signup - Version 2.
 * 
 * BFA-1343
 * 
 * @author pradheep.p
 *
 */
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure = false)
@ContextConfiguration
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
//@Sql(scripts = { "classpath:signupv2/TestScript.sql" })
public class SignupTest {

	// 1. Test the signup controller //
//	@Mock
	private MockMvc mockMvc;

	private String signup_api = "/api/signupV2";

	private String mobileNumber = "98901122";

	private String sessionId = "51c3f8b5-feb0-4e2f-b98b-45cffceae575";

	private String emailAddress = "testemail@gmail.com";

	private String captchaStr = "11111";

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private AccountsDao accountsDao;

	String authHeader = "";
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	@Autowired
	private Environment environment;

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	public void init() {
		System.out.println("-- Initializing the signup tests -- ");
		authHeader = getAuthToken();
		saveSessionDetails();
		cleanupCustomerDB();
		// loadMasterPrevileges();
	}

	/**
	 * Loads the captcha required for testing.
	 */
	private void saveSessionDetails() {
		String hql = "delete from SessionDetails";
		accountsDao.executeUpdate(hql);
		// -----------------------------------------//
		SessionDetails sessionDetails = new SessionDetails();
		sessionDetails.setBrowser("None");
		sessionDetails.setCaptcha(captchaStr);
		sessionDetails.setDevice("None");
		sessionDetails.setSessionId(sessionId);
		accountsDao.saveOrUpdateObject(sessionDetails);
	}

	/**
	 * Delete the existing customer previleges if any.
	 */
	private void cleanupCustomerDB() {
		cleanupCustomerPrevilage();
		System.out.println("-- Cleaning customers if any -- ");
		String hql = "delete from Customer";
		System.out.println("Number of rows affected :" + accountsDao.executeUpdate(hql));
		System.out.println("-- Cleaning previlege master -- ");
		hql = "delete from PrevilageMaster";
		System.out.println("Number of rows affected :" + accountsDao.executeUpdate(hql));
	}

	private void cleanupCustomerPrevilage() {
		System.out.println("-- Clean the existing customer previleges -- ");
		String hql = "delete from CustomerPrevilege";
		System.out.println("Number of rows affected :" + accountsDao.executeUpdate(hql));
	}

	private void loadMasterPrevileges() {
		System.out.println("-- creating the master previleges --");
		PrevilageMaster pm = new PrevilageMaster();
		pm.setDescription("Role user");
		pm.setPrevilegeId(1);
		pm.setPrvilegeName("ROLE_USER");
		accountsDao.saveObject(pm);
		PrevilageMaster pm1 = new PrevilageMaster();
		pm1.setDescription("Role signed user");
		pm1.setPrevilegeId(2);
		pm1.setPrvilegeName("ROLE_SIGNED_USER");
		accountsDao.saveObject(pm1);

		String hql = "from PrevilageMaster";
		List<PrevilageMaster> previlageMasterList = accountsDao.getObjectByHql(hql);
		Iterator<PrevilageMaster> iter = previlageMasterList.iterator();

		while (iter.hasNext()) {
			PrevilageMaster pmaster = iter.next();
			System.out.println("Role" + pmaster.getPrvilegeName() + "," + pmaster.getPrevilegeId());
		}
	}

	/**
	 * Create a signup request for testing.
	 * 
	 * @return
	 */
	private CustomerCreationPostRequestV2 getCustomerCreationPostRequest() {
		CustomerCreationPostRequestV2 obj = new CustomerCreationPostRequestV2();
		Random ran = new Random();
		obj.setEnquiryId(ran.nextInt(450000));
		obj.setJourneyType("insurance-guided");
		obj.setSessionId(sessionId);
		obj.setCaptcha(captchaStr);
		CustomerCreationDTO customer = new CustomerCreationDTO();
		customer.setCountryCode("65");

		customer.setEmailAddress(emailAddress);
		customer.setFirstName("insurance-user");
		customer.setLastName("test");
		customer.setMobileNumber(mobileNumber);
		customer.setAcceptMarketingNotifications(false);
		customer.setPassword(
				"U2FsdGVkX19hTyHhuCaNc51ilH4wFWfxPCPaCEanH4pJufcik7d0+pHBvNvJXllYk3C29JX9zsfrTZWWdwIPUf7h/FFWnFdDSVjCrFFeIweNnctxJLE/n95LbgXbbi9D4VfjOMsPcie/RHAcS10ts9qa/EBBPWiJd4R2BlmY8jctygL6UEUUd9kenIGR0LxT1CatYv7jO4dG1wJ41dNg6A==");
		obj.setCustomer(customer);
		return obj;
	}

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_USER");
		BFAGrandtedAuthority grantedAuthority2 = new BFAGrandtedAuthority("ROLE_SIGNED_USER");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		authorities.add(grantedAuthority2);
		return tokenProvider.getTokenString("-1", authorities);
	}

	/**
	 * Basic Test of signup API V2. Method name in alphabetical order.
	 */
	@Test
	public void signupB() {
		System.out.println("Teting signup API");
		init();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		try {
			System.out.println("Auth Token:" + authHeader);
			mockMvc.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization", authHeader))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method name in alphabetical order for execution. Tests the new customer
	 * after signup.
	 */
	@Test
	public void signupC() {
		System.out.println("-- Testing for the customer : " + emailAddress + "--");
		Customer customerObj = accountsDao.getCustomerDetails(emailAddress);
		Assert.assertNull(customerObj);
	}

	/**
	 * Negative test case 1. Same email address but different mobile number
	 * signup request test of signup API V2. Method name in alphabetical order.
	 */
	@Test
	public void signupD() {
		printDelimiter();
		System.out.println("-- Testing signup with same email address and diff mobile number --");
		printDelimiter();
		cleanupCustomerPrevilage();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		signupRequestObject.getCustomer().setMobileNumber("89772211");
		try {
			saveSessionDetails();
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization", authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test for mobile already verified.
	 */
	@Test
//	@Sql(scripts = { "classpath:signupv2/signup_mobile_already_verified.sql" })
	public void signupE() {
		printDelimiter();
		System.out.println("-- Testing signup with same mobile number and diff email address--");
		printDelimiter();
		cleanupCustomerPrevilage();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		signupRequestObject.getCustomer().setEmailAddress("testagain@yahoo.com");
		try {
			saveSessionDetails();
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization", authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test for email already verified.
	 */
	@Test
//	@Sql(scripts = { "classpath:signupv2/signup_email_already_verified.sql" })
	public void signupF() {
		printDelimiter();
		System.out.println("-- Testing signup with same mobile number and email address--");
		printDelimiter();
		cleanupCustomerPrevilage();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		try {
			saveSessionDetails();
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization", authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Duplicate signup test.
	 */
	@Test
//	@Sql(scripts = { "classpath:signupv2/signup_duplicate_entry_test.sql" })
	public void signupG() {
		printDelimiter();
		System.out.println("-- Testing signup with same mobile number and email address--");
		printDelimiter();
		cleanupCustomerPrevilage();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			saveSessionDetails();
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "6008").exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	@Sql(scripts = { "classpath:signupv2/signup_email_already_verified.sql" })
	public void signupH() {
		System.out.println("Testing the signup v2");
		String email = null;		
		String mobile = "98901122";
		Random ran = new Random();
		Customer customer = new Customer();
		customer.setId(ran.nextInt(250000));
		customer.setEmail(email);
		customer.setMobileNumber(mobile);
		customer.setVerificationEnquiryId(-2);
		try {			
			saveSessionDetails();			
			customer.setId(ran.nextInt(250000));
			CustomerAndPrevilegeV2 custAndPrev2 =  accountsDao.signupV2(customer);
			Assert.assertNotNull(custAndPrev2);			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Sql(scripts = { "classpath:signupv2/signup_email_already_verified.sql" })
	public void signupI() {
		System.out.println("Testing the signup v2");
		String email = "testagain@yahoo.com";		
		String mobile = null;
		Random ran = new Random();
		Customer customer = new Customer();
		customer.setId(ran.nextInt(250000));
		customer.setEmail(email);
		customer.setMobileNumber(mobile);
		customer.setVerificationEnquiryId(100);
		try {			
			saveSessionDetails();			
			customer.setId(ran.nextInt(250000));
			CustomerAndPrevilegeV2 custAndPrev2 =  accountsDao.signupV2(customer);
			Assert.assertNotNull(custAndPrev2);			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* Test for captcha enable by property during signup */	
	@Test
	@Sql(scripts = { "classpath:signupv2/signup_duplicate_entry_test.sql" })
	public void signupJ() {		
		printDelimiter();
		System.out.println("-- Testing signup with same mobile number and email address--");
		printDelimiter();
		cleanupCustomerPrevilage();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		signupRequestObject.setCaptcha("acbnm");
		System.setProperty("disable.captcha.while.creating.account", "false");
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			saveSessionDetails();
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_CAPTCHA).exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* Test for captcha disable by property during signup */	
	@Test
	@Sql(scripts = { "classpath:signupv2/signup_duplicate_entry_test.sql" })
	public void signupK() {		
		printDelimiter();
		System.out.println("-- Testing the disable captcha by property --");
		printDelimiter();
		cleanupCustomerPrevilage();
		CustomerCreationPostRequestV2 signupRequestObject = getCustomerCreationPostRequest();
		signupRequestObject.setCaptcha("acbnm");
		System.setProperty("disable.captcha.while.creating.account", "true");
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			saveSessionDetails();
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(signup_api).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(signupRequestObject)).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.ACCOUNT_ALREADY_EXISTS).exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private void printDelimiter() {
		System.out.println("---------------------------------------------------------------");
	}

	private void printEndTest() {
		System.out.println("--------------------- Test End ---------------------------------");
	}
}

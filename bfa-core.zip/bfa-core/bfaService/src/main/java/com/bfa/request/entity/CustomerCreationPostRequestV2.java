/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep.p
 *
 */
public class CustomerCreationPostRequestV2 {

	private CustomerCreationDTO customer;

	private String sessionId;

	private String captcha;

	private String journeyType;	
	
	private Integer enquiryId;	

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public String getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public CustomerCreationDTO getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerCreationDTO customer) {
		this.customer = customer;
	}	
}

/**
 * 
 */
package com.bfa.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.bfa.application.core.EnquiryByEmail;
import com.bfa.exception.InvalidSessionIdException;

import com.bfa.request.entity.ads.RetirementPlanningModel;
import com.bfa.service.RetirementLeadService;
import com.bfa.service.EnquiryService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessageList;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * *
 * 
 * @author pradheep
 * 
 */
@RestController
@Api(value = "/api")
public class MiscFunctionsController extends BaseController {

	@Autowired
	private EnquiryService enquiryService;
	
	@Autowired
	private RetirementLeadService adServices;

	/**
	 * This function was introduced to register the enquiry by email address
	 * only.
	 * 
	 * @see https://ntuclink.atlassian.net/browse/BFA-1578
	 * 
	 * @param requestObj
	 * @param httpServletRequest
	 * @return
	 */
	@PostMapping(API_ENQUIRY_BY_EMAIL_ONLY)
	@Produces({ "application/xml", "application/json" })
	@Path(API_ENQUIRY_BY_EMAIL_ONLY)
	@ApiOperation(value = "Registeres the enquiry by email address", notes = "Registers the enquiry by email address.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList saveEnquiryByEmail(@Valid @RequestBody EnquiryByEmail requestObj,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("----- Registering the enquiry by email address : " + new Date() + ": Request"
				+ requestObj.toString() + "------");
		ResponseMessageList responseMessageList = getDefaultMessageList();
		try {
			String result = enquiryService.updateSelectedProductsByEmail(requestObj.getValidateCaptchaBean(),
					requestObj);
			if(result.equals(EnquiryService.INVALID_EMAIL_ADDRESS)){
				responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
				responseMessageList.getResponseMessage().setResponseDescription("Invalid email address");
				return responseMessageList;
			}
			if (result.equals(EnquiryService.INVALID_CAPTCHA)) {
				responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CAPTCHA);
				responseMessageList.getResponseMessage().setResponseDescription("Invalid captcha");
				return responseMessageList;
			}
			return responseMessageList;
		} catch (InvalidSessionIdException exp) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
			responseMessageList.getResponseMessage().setResponseDescription("Invalid Session ID");
			return responseMessageList;
		} catch (Exception err) {
			getLogger(this.getClass()).error("Error while handling the enquiry", err);
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			return responseMessageList;
		}
	}
	
	/**
	 * BFA-1232 Get the details of the dependents.
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/api/admin/getDependentDetails", method = RequestMethod.GET)
	@GET
	@Path("/api/customer/getDependentDetails")
	@ApiOperation(value = "Get the dependent details", notes = "Get the dependent details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList getDependentDetails(HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Get the dependent details of the ");
		ResponseMessageList responseMessageList = getDefaultMessageList();
		try {
			String enquiryId = httpServletRequest.getParameter("enqId");
			String appKey = "IMXYlDmP4f4=";
			PublicUtility utility = PublicUtility.getInstance(appKey);
			String enId = utility.DecryptText(enquiryId);
			Integer enquiry_ID = Integer.parseInt(enId);
			
			List dependentMappingList = enquiryService.getDependentDetails(enquiry_ID);
			responseMessageList.setObjectList(dependentMappingList);
			return responseMessageList;
		} catch (Exception err) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			return responseMessageList;
		}
	}
	
	/**
	 * This is to register the retirement planning.
	 * 
	 * @param RetirementPlanningModel
	 * @param HttpServletRequest
	 * @return ResponseMessageList
	 * @since Release 4.0
	 * 
	 */
	@PostMapping(APIConstants.POST_RETIREMENT_PLANNING)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.POST_RETIREMENT_PLANNING)
	@ApiOperation(value = "Registeres the retirement planning data given by ads.", notes = "Registeres the retirement planning data given by ads.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList postRetirementPlanningData(
			@Valid @RequestBody RetirementPlanningModel requestObj, HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("----- Registering the retirement planning data : " + new Date() + ": Request"
				+ requestObj.toString() + "------");
		ResponseMessageList responseMessageList = getDefaultMessageList();
		try {
			adServices.updateRetirementPlanningData(requestObj);
			return responseMessageList;
		}catch (Exception err) {
			getLogger(this.getClass()).error("Error while handling the enquiry", err);
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			return responseMessageList;
		}
	}
	

}

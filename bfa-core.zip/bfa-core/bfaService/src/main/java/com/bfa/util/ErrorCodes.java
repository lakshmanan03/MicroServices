/**
 * 
 */
package com.bfa.util;

/**
 * @author pradheep.p
 *
 */
public class ErrorCodes {
	
	public static int HTTP_SUCCESS_CODE = 200;
	
	// Internal Server Error
	public static final int INTERNAL_SERVER_ERROR = 5000;
	
	// Communication failure error.
	public static final int DB_COMMUNICATION_FAILURE = 5001;
	
	// Session timeout error.
	public static final int SESSION_TIME_OUT_ERROR = 5002;
	
	// Invalid user input.
	public static final int INVALID_INPUT_FIELD = 5003;
	
	public static final int NO_SUCH_USER = 5004;
	
	public static final int INVALID_SECRET_KEY = 5005;
	
	public static final int VALIDATION_ERROR = 5006;
	
	public static final int OTP_VALIDATION_FAILED = 5007;
	
	public static final int OTP_VALIDATION_ALREADY_DONE = 5008;
	
	public static final int OTP_EXPIRED = 5009;
	
	public static final int EMAIL_VERIFICATION_FAILED = 5010;

	public static final int INVALID_CREDENTIALS = 5011;
	
	public static final int EMAIL_UNVERIFIED = 5012;
	
	public static final int MOBILE_UNVERIFIED = 5013;
	
	public static final int EMAIL_AND_MOBILE_UNVERIFIED = 5014;

	public static final int INVALID_SESSION_ID = 5015;
	
	public static final int INVALID_CAPTCHA = 5016;
	
	public static final int INVALID_PROMO_CODE = 5017;
	
	public static final int AML_VERIFICATION_REJECTED = 5018;
	
	public static final int AML_VERIFICATION_FAILED = 5019;
	
	public static final int INVALID_TOKEN = 5020; 

	public static final int PASSWORD_USED_FOR_5_TIMES = 5021;
	
	public static final int EMAIL_LINK_EXPIRED = 5022;
	
	public static final int COMPREHENSIVE_ERROR_CODE = 5024;
	
	public static final int EMAIL_LINK_ALREADY_VERIFIED = 5023;
	
		//IFAST Error constants
	public static final int INVALID_API_KEY = 5101;
	
	public static final int INVALID_PARTNER_ID = 5102;
	
	public static final int INVALID_API_KEY_OR_PARTNER_ID = 5103;
	
	public static final int INVALID_REQUEST = 5104;
	
	public static final int UNABLE_TO_PROCESS_REQUEST = 5105;
	
	public static final int PASSWORD_ALREADY_RESET = 5106;
	
	public static final int PASSWORD_RESET_LINK_EXPIRED = 5107;
	
	public static final int USER_CREDENTIALS_INVALID = 5108;
	
	public static final int INVALID_TOKEN_DETAILS = 5109;
	
	public static final int NEW_PASSWORD_CANNOT_BE_SAME_AS_OLD = 5110;
	
	public static final int PASSWORD_RESET_FAILED = 5111;
	
	public static final int PASSWORD_LINK_EXPIRED = 5112;
	
	public static final int PASSWORD_LINK_ALREADY_USED = 5113;
	
	public static final int EMAIL_VERIFICATION_REQUEST_FAILED = 5114;

	public static final int IFAST_DOWN = 5115;
	
	public static final int ACTION_NOT_PERMITTED = 5116;
	
	public static final int RSP_TIMING_COULD_NOT_NE_UPDATED = 5118;	
	
	// Successful response
	public static final int PORTFOLIO_ALREADY_ACCEPTED = 5119;
	
	public static final int PORTFOLIO_NAME_ALREADY_EXITS = 5120;
	
	public static final int WELCOME_EMAIL_FAILED_COMPRE = 5121;
	
	public static final int INVALID_ACCESS_CODE = 5122;	
	
	public static final int TWO_FACTOR_AUTHENTICATION_FAILED = 5123;
	
	public static final int TWO_FACTOR_AUTH_TIME_EXCEEDED = 5124;
	
	// Successful response
	public static final int SUCCESSFUL_RESPONSE = 6000;
	
	public static final int USER_CREATED_SUCCESSFULLY = 6001;
	
	public static final int CRM_UPDATE_SUCCESSFUL = 6002;
	
	public static final int OPT_VERIFICATION_SUCCESSFUL = 6003;
	
	public static final int NO_MATCHING_RECORDS_FOUND = 6004;
	
	public static final int PROMO_CODE_VERIFICATION_SUCCESSFUL = 6005;
	
	public static final int PASSWORD_LINK_VALID = 6006;
	
	public static final int EMAIL_VERIFICATION_REQUEST_SUCCESS = 6007;
	
	public static final int ACCOUNT_ALREADY_EXISTS = 6008;
	
	public static final int NO_DATA_FOUND = 6009;
		
	public static final int WELCOME_EMAIL_SUCCESS_COMPRE = 6010;
	
	public static final int TWO_FACTOR_AUTH_SUCCESS = 6011;
	
}

package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.CustomerLiabilitiesDetail;

public interface CustomerLiabilityRepository extends CrudRepository<CustomerLiabilitiesDetail, String> {
	
	Optional<CustomerLiabilitiesDetail>  findFirstByCustomerId(Integer customerId);
	
	
	Optional<CustomerLiabilitiesDetail> findTopByCustomerIdOrderByEnquiryIdDesc(Integer customerId);

}

/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.core.Customer;
import com.bfa.insurance.product.ProductList;

/**
 * @author pradheep.p
 *
 */
public class CRMCustomerUpdateRequest {

	private Customer customer;
	
	private int enquiryId;
	
	private List<ProductList> selectedProducts;
	
	private boolean isNewCustomer;

	public boolean isNewCustomer() {
		return isNewCustomer;
	}

	public void setNewCustomer(boolean isNewCustomer) {
		this.isNewCustomer = isNewCustomer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}
}

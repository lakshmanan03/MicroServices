/**
 * 
 */
package com.bfa.monthlystatements;

import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;

/**
 * @author HCL
 *
 * CheckSumUtil.java Created on Dec 11, 2018, 5:46:02 PM by Vimala Shan
 */
public class CheckSumUtil {

	private CheckSumUtil(){
		// created constructor
	}
	public static byte[] getChecksum(InputStream stream, MessageDigest md) throws IOException {

		try (DigestInputStream dis = new DigestInputStream(stream, md)) {
			while (dis.read() != -1)
				; // empty loop to clear the data
			md = dis.getMessageDigest();
		}
		return md.digest();
	}

	public static String bytesToHex(byte[] hashInBytes) {

		StringBuilder sb = new StringBuilder();
		for (byte b : hashInBytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();

	}
}

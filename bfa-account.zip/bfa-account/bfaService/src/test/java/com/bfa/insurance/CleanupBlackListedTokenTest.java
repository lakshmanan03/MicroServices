/**
 * 
 */
package com.bfa.insurance;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.serviceimpl.CleanupBlackListedTokens;

/**
 * @author pradheep.p
 *
 */

@RunWith(SpringRunner.class)
public class CleanupBlackListedTokenTest {	

	@InjectMocks
	private CleanupBlackListedTokens cleanupBlackListedTokens;
	
	@Mock
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Mock
	private Logger mLogger;

	@Test
	public void testCleanBlacklistedTokens() {		
		mLogger.info("-- Cleanup blacklisted tokens --");
		Thread d = new Thread(cleanupBlackListedTokens);
		d.start();
	}	
}

package com.bfa.service;

import java.util.List;

import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveHouseHoldDTO;
import com.bfa.common.dto.ComprehensiveResult;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;
import com.bfa.comprehensive.dto.InsuranceAgentCallback;
import com.bfa.insurance.core.ComprehensiveDependentMapping;
import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;
import com.bfa.investment.account.dto.ComprehensivePricingDTO;
import com.bfa.request.entity.ValidatePromoCodeRequest;

public interface ComprehensiveService {

	public void updateCustomerBasicDetails(UpdateCustomerBasicInfo custmerBasicInfo, Integer customerId);
	
	public ComprehensiveResult requestPromoCodeDetails(Integer customerId, String category);
	
	public boolean validatePromoCodeByUser(ValidatePromoCodeRequest validatePromoCodeRequest,Integer customerId);

	public BaseProfileDTO getCustomerBasicDetails(Integer customerId,String journeyType);

	public void saveDependents(List<ComprehensiveDependentMapping> dependents, Integer customerId,
			boolean hasDependents) throws DatabaseAccessException;

	List<DependentDTO> getDependentDetailList(Integer customerId,Integer enquiryId) throws DatabaseAccessException;

	void saveChildEndowmentPlanDetails(List<ComprehensiveEndowmentPlanMapping> childEndowmentPlan, String hasEndowments, Integer customerId);

	void deleteChildEndowmentPlans(Integer cutomerId, String hasEndowments, Integer customerId) throws DatabaseAccessException;

	List<DependentEducationPreferencesDTO> getDependentEducationPreferences(Integer enquiryId, Integer customerId)
			throws DatabaseAccessException;
	
	public void updateDependentsForInsuranceNeed(List<ComprehensiveEndowmentPlanMapping> childEndowmentPlanning, Integer customerId,Integer enquiryId, String hasEndowments) throws DatabaseAccessException;
	
	public InsuranceAgentCallback generateCustomerToken(Integer customerId) throws DatabaseAccessException;
	
	public void saveComprehensiveHouseHold(ComprehensiveHouseHoldDTO houseHoldDTO,Integer enquiryId) throws DatabaseAccessException;
	
	public ComprehensiveHouseHoldDTO getComprehensiveHouseHold(Integer customerId,Integer enquiryId) throws DatabaseAccessException;

	public ComprehensivePricingDTO getComprehensiveProductPricing(String productType, String promotion);
}

package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "portfolio_transaction_fundmapping")
public class PortfolioFundInvestmentMapping {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private Integer id;
	
	@OneToOne
	@JoinColumn(name = "portfolio_transaction_id")
	private PortfolioTransaction portfolioTransaction;
	
	@OneToOne
	@JoinColumn(name = "fund_investment_splitup_id")
	private FundInvestmentSplit fundInvestmentSplit;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public PortfolioTransaction getPortfolioTransaction() {
		return portfolioTransaction;
	}

	public void setPortfolioTransaction(PortfolioTransaction portfolioTransaction) {
		this.portfolioTransaction = portfolioTransaction;
	}

	public FundInvestmentSplit getFundInvestmentSplit() {
		return fundInvestmentSplit;
	}

	public void setFundInvestmentSplit(FundInvestmentSplit fundInvestmentSplit) {
		this.fundInvestmentSplit = fundInvestmentSplit;
	}
	
	
	
}

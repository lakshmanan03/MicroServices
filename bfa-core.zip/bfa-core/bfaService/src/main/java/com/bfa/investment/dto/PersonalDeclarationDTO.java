package com.bfa.investment.dto;

public class PersonalDeclarationDTO {
	private Integer investmentSourceId;
	private Boolean beneficialOwner;
	private Boolean politicallyExposed;
	private Boolean connectedToInvestmentFirm;
	private PEPAdditionalDeclarationDTO pepDeclaration;
	
	
	
	public Boolean isConnectedToInvestmentFirm() {
		return connectedToInvestmentFirm;
	}
	
	public void setConnectedToInvestmentFirm(Boolean connectedToInvestmentFirm) {
		this.connectedToInvestmentFirm = connectedToInvestmentFirm;
	}
	public Integer getInvestmentSourceId() {
		return investmentSourceId;
	}
	public void setInvestmentSourceId(Integer investmentSourceId) {
		this.investmentSourceId = investmentSourceId;
	}
	public Boolean isBeneficialOwner() {
		return beneficialOwner;
	}
	public void setBeneficialOwner(Boolean beneficialOwner) {
		this.beneficialOwner = beneficialOwner;
	}
	public Boolean isPoliticallyExposed() {
		return politicallyExposed;
	}
	public void setPoliticallyExposed(Boolean politicallyExposed) {
		this.politicallyExposed = politicallyExposed;
	}
	public PEPAdditionalDeclarationDTO getPepDeclaration() {
		return pepDeclaration;
	}
	public void setPepDeclaration(PEPAdditionalDeclarationDTO pepDeclaration) {
		this.pepDeclaration = pepDeclaration;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PersonalDeclarationDTO [investmentSourceId=");
		builder.append(investmentSourceId);
		builder.append(", beneficialOwner=");
		builder.append(beneficialOwner);
		builder.append(", politicallyExposed=");
		builder.append(politicallyExposed);
		builder.append(", connectedToInvestmentFirm=");
		builder.append(connectedToInvestmentFirm);
		builder.append(", pepDeclaration=");
		builder.append(pepDeclaration);
		builder.append("]");
		return builder.toString();
	}
	
	
}

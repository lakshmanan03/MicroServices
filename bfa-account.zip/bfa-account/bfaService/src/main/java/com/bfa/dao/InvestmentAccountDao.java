package com.bfa.dao;

import java.util.List;

import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerLiabilitiesDetail;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.common.entity.OptionItem;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.Expenses;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;
import com.bfa.investment.entity.CustomerPortfolio;
import com.bfa.util.DAOResponse;

public interface InvestmentAccountDao {
	CustomerIFastAccount getCustomerIFastAccountDetails(Integer customerId);

	List<CustomerIFastAccount> customerSearch(AdminSearchRequestDTO searchRequest);

	Customer getCustomer(int customerId);

	Income getCustomerIncomeDetails(int customerId);
	
	List<Income> getCustomerIncomeDetailsList(int customerId);

	Assets getCustomerAssetDetails(int customerId);

	CustomerInvestmentObjective getCustomerInvestmentObjective(int customerId);

	CustomerDocumentDetails getCustomerDocumentDetails(int customerId, String docType);

	List<CustomerDocumentDetails> getCustomerDocumentDetails(int customerId);

	CustomerAdditionalDetails getCustomerAdditionalDetails(int customerId);

	CustomerIdentityDetails getCustomerIdentityDetails(int customerId);

	CustomerPEPDetails getCustomerPEPDetails(int customerId);

	Country getCountry(int countryId);

	Country getNationality(String nationalityCode);

	List<CustomerTaxDetails> getCustomerTaxDetails(int customerId);

	Enquiry getCustomerEnquiryDetails(int customerId);

	Liabilities getCustomerLiabilitiesDetails(int customerId);

	CustomerEmploymentInformation getCustomerEmploymentInformation(int customerId);

	void updateCustomer(Customer customer);

	void saveOrUpdateAddress(Address address);

	void saveOrUpdateDetails(Object details);

	Integer insertDetails(String query);

	DAOResponse mapCustomerToEnquiry(int customerId, int enquiryId);

	OptionItem getCustomerEmploymentStatus(Integer employmentStatusId);
	
	List<Customer> getCustomerByAdvisor(int adviserId);

	Expenses getCustomerExpenses(Integer id);

	CustomerLiabilitiesDetail getCustomerLiabilityDetailByEnquiryId(Integer customerId);

	Income getCustomerIncomeByEnquiryId(int enquiryId);


	CustomerInvestmentObjective getCustomerInvestmentObjective(Integer customerId, Integer enquiryId);
	
	CustomerSrsAccount getCustomerSrsBankbyId(Integer customerId);
	
	

}

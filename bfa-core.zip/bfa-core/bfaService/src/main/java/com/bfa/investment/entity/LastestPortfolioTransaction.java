package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// vw_portfolio_transaction_by_transaction_date_desc
@Entity
@Table(name = "vw_portfolio_transaction_by_transaction_date_desc")
public class LastestPortfolioTransaction {
	
	@Column
	@Id
	private Integer id;
	
	@Column
	private Integer customerId;
	
	@Column
	private Integer portfolioId;
	
	@Column
	private Date transactionDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
}

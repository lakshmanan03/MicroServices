/**
 * 
 */
package com.bfa.application.core;

/**
 * @author pradheep.p
 *
 */
public class AccountStatus {

	private boolean isMobileVerified = false;

	private boolean isEmailVerified = false;

	private boolean isAccountAlreadyCreated = false;

	public boolean isMobileVerified() {
		return isMobileVerified;
	}

	public void setMobileVerified(boolean isMobileVerified) {
		this.isMobileVerified = isMobileVerified;
	}

	public boolean isEmailVerified() {
		return isEmailVerified;
	}

	public void setEmailVerified(boolean isEmailVerified) {
		this.isEmailVerified = isEmailVerified;
	}

	public boolean isAccountAlreadyCreated() {
		return isAccountAlreadyCreated;
	}

	public void setAccountAlreadyCreated(boolean isAccountAlreadyCreated) {
		this.isAccountAlreadyCreated = isAccountAlreadyCreated;
	}

}

package com.bfa.servicehelper;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.bfa.admin.dto.AdminCustomerSummary;
import com.bfa.application.discovery.DiscoveryService;
import com.bfa.common.dto.CustomerBankInfoDTO;
import com.bfa.common.dto.FinancialDTO;
import com.bfa.common.dto.OptionsSearchResultDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.OptionItem;
import com.bfa.ifast.exception.IFastException;
import com.bfa.investment.account.dto.InvestmentAccountStatusDTO;
import com.bfa.investment.dto.CustomerInvestmentObjectiveDTO;
import com.bfa.investment.dto.HolidaysDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.OptionsSearchFilterDTO;
import com.bfa.investment.dto.RSPRunDTO;
import com.bfa.investment.dto.UpdateFundingTypeRequest;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.ifast.dto.DPMSHoldingsSummary;
import com.bfa.investment.ifast.dto.DPMSTransactionResponse;
import com.bfa.investment.ifast.dto.IFastAccountUpdateResponse;
import com.bfa.investment.ifast.dto.IFastResponse;
import com.bfa.investment.ifast.notification.dto.IFastCashAccountTransactionDTO;
import com.bfa.investment.ifast.notification.dto.IFastCustomerTransactionDTO;
import com.bfa.util.APIResponse;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class MOInvestmentService extends MOServiceHelper {
	

	@Autowired
	private DiscoveryService discoveryService;
	
	/** Logger available to subclasses */
	protected final Log logger = LogFactory.getLog(getClass());

	public OptionsSearchResultDTO searchOptions(OptionsSearchFilterDTO filter) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		OptionsSearchResultDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		if (filter == null)
			return null;
		request.setUrl(URLDirectory.InvestmentService.optionsSearch(filter.getCountryCode(),
				filter.getNationalityCode(), filter.getSsoc(), filter.getSsic(), filter.getHouseHoldRange()));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<OptionsSearchResultDTO>> typeToken = new TypeToken<APIResponse<OptionsSearchResultDTO>>() {
			};
			APIResponse<OptionsSearchResultDTO> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}

	public Boolean mapEnquiryToCustomer(Integer customerId, Integer enquiryId) {

		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateMapCustomerEnquiry());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		Map<String, Integer> mapEnquiryMap = new HashMap<>();
		mapEnquiryMap.put("customerId", customerId);
		mapEnquiryMap.put("enquiryId", enquiryId);
		request.setRequestBody(mapEnquiryMap);
		
		logger.info("Printing the request Object"+request);
		
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}

		}

		return updateStatus;

	}

	public Boolean updateInvestmentAccountStatus(String counterPartyAccountNumber, String investmentAccountStatus,
			Date accountCreatedDate) {
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateInvestmentAccountStatus());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		Map<String, Object> ifastAccountInput = new HashMap<>();
		ifastAccountInput.put("counterPartyAccountNumber", counterPartyAccountNumber);
		ifastAccountInput.put("investmentAccountStatus", investmentAccountStatus);
		ifastAccountInput.put("accountCreatedDate", PublicUtility.dateToString(accountCreatedDate, "yyyy-MM-dd"));
		request.setRequestBody(ifastAccountInput);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}
		}
		return updateStatus;
	}
	
	public OptionItem fetchingOptionItemById(Integer id) {
		String authorizationToken = discoveryService.preAuthorize();
		OptionItem optionItem = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.fetchOptionItemById(id));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		// Create CustomerIFastAccount instance and set appropriate values
		Map<String, Object> optionIteminput = new HashMap<>();
		 optionIteminput.put("id", id);
		 //request.setRequestBody(optionIteminput);
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<OptionItem>> typeToken = new TypeToken<APIResponse<OptionItem>>() {
			};
			APIResponse<OptionItem> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					optionItem = apiResponse.getObjectList();
				}
			}
		}
		return optionItem;
	}
	
	public Boolean updatetheSrsfundingTypeStatus(Integer customerId, Integer customerPortfolioId,Integer fundingType)
			 {
		// DiscoveryServiceImpl discoveryServiceImpl = new DiscoveryServiceImpl();
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateInvestmentAccountStatus());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		Map<String, Object> ifastAccountInput = new HashMap<>();
		ifastAccountInput.put("customerPortfolioId", customerPortfolioId);
		ifastAccountInput.put("customerId", customerPortfolioId);
		ifastAccountInput.put("fundingType", fundingType);
		request.setRequestBody(ifastAccountInput);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					updateStatus = apiResponse.getObjectList();
				}
			}
		}
		return updateStatus;
	}
	
	 // updateTrustId
	public Boolean updateTrustId(String counterPartyAccountNumber, String ifastStatus, String trustId,
			Date updatedDate) {
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateTrustId());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		Map<String, Object> ifastAccountInput = new HashMap<>();
		ifastAccountInput.put("counterPartyAccountNumber", counterPartyAccountNumber);
		ifastAccountInput.put("ifastStatus", ifastStatus);
		ifastAccountInput.put("trustId", trustId);
		request.setRequestBody(ifastAccountInput);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}
		}
		return updateStatus;
	}

	public void notifyInvestmentAccountSetup(ProfileSummaryDTO profileSummary) {
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.notifyInvestmentAccountSetup());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		request.setRequestBody(profileSummary);
		MOServiceResponse response = post(request);
	}

	// save cash transaction details
	public Boolean saveCashTransaction(IFastCustomerTransactionDTO<IFastCashAccountTransactionDTO> dto) {
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.saveCashTransaction());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		String requestBody = serializeTransaction(dto);
		request.setSerializedRequestBody(requestBody);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}
		}
		return updateStatus;
	}

	private String serializeTransaction(Object notificationObject) {
		try {
			JsonSerializer<Date> ser = new JsonSerializer<Date>() {

				@Override
				public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext context) {
					return src == null ? null : new JsonPrimitive(src.getTime());
				}
			};

			Gson gson = new GsonBuilder().registerTypeAdapter(Date.class, ser).create();
			return gson.toJson(notificationObject);
		} catch (Exception ex) {

		}

		return "";
	}
	
	// save cash transaction details
	public Boolean savePortfolioTransaction(IFastCustomerTransactionDTO<DPMSTransactionResponse> dto) {
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.savePortfolioTransaction());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		String requestBody = serializeTransaction(dto);
		request.setSerializedRequestBody(requestBody);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}
		}
		return updateStatus;
	}
	
	public Boolean savePortfolioTransaction(IFastCustomerTransactionDTO<DPMSTransactionResponse> dto, Logger logger) {
		String authorizationToken = discoveryService.preAuthorize();
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		logger.info("Inside savePortfolioTransaction: URL: " + URLDirectory.InvestmentService.savePortfolioTransaction());
		request.setUrl(URLDirectory.InvestmentService.savePortfolioTransaction());
		logger.info("Inside savePortfolioTransaction: authorizationToken: " + authorizationToken);
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		// Create CustomerIFastAccount instance and set appropriate values
		String requestBody = serializeTransaction(dto);
		logger.info("Inside savePortfolioTransaction: requestBody: " + requestBody);
		request.setSerializedRequestBody(requestBody);
		MOServiceResponse response = post(request);
		if (response != null) {
			logger.info("Inside savePortfolioTransaction: response.getResponseBody(): " + response.getResponseBody());
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}
		}
		return updateStatus;
	}

	public Boolean updateInvestmentAccountStatus(String status) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateInvestmentAccountStatus());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		HashMap<String, String> statusObj = new HashMap<>();
		statusObj.put("investmentAccountStatus", status);
		request.setRequestBody(statusObj);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}
		}
		return updateStatus;
	}
	
	public Boolean updateInvestmentAccountStatus_debug(String status, Map<String,Object> debugInfo) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateInvestmentAccountStatus());
		debugInfo.put("Status Update URL", URLDirectory.InvestmentService.updateInvestmentAccountStatus());
		request.addHeader("Authorization", authorizationToken);
		debugInfo.put("Authorization value", authorizationToken);
		request.setMethodName("POST");
		HashMap<String, String> statusObj = new HashMap<>();
		statusObj.put("investmentAccountStatus", status);
		request.setRequestBody(statusObj);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
			debugInfo.put("MOServiceResponse", response);
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
				debugInfo.put("updateStatus value", updateStatus);
			}
		}
		return updateStatus;
	}

	public InvestementDashboardStatusDTO customerInvestmentProfile() {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		InvestementDashboardStatusDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getInvestmentProfile());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<InvestementDashboardStatusDTO>> typeToken = new TypeToken<APIResponse<InvestementDashboardStatusDTO>>() {
			};
			APIResponse<InvestementDashboardStatusDTO> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}

	
	
	public HolidaysDTO checkHoliday(String authToken) {
		HolidaysDTO holidaysDTO =null;
		Date currentdate = PublicUtility.getCurrentUTC();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String curDate = dateFormat.format(currentdate);
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getRspHolidayList(curDate));
		request.addHeader("Authorization", authToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response.isSuccess()) {
			TypeToken<APIResponse<HolidaysDTO>> typeToken = new TypeToken<APIResponse<HolidaysDTO>>() {
			};
			APIResponse<HolidaysDTO> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
					holidaysDTO = apiResponse.getObjectList();
			}
		}
		
		return holidaysDTO;
	}
	
	public String getAuthorizationToken() {
		return discoveryService.preAuthorize();
	}
	
	public List<RSPRunDTO> getRSPBatchList(String authToken){
		List<RSPRunDTO> batchList = null;
		MOServiceRequest request = new MOServiceRequest();
		Integer currentMonthYear =  PublicUtility.getCurrentMonthYear();
		request.setUrl(URLDirectory.InvestmentService.getRspBatchTimings(currentMonthYear));
		request.addHeader("Authorization", authToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<List<RSPRunDTO>>> typeToken = new TypeToken<APIResponse<List<RSPRunDTO>>>() {
			};
			APIResponse<List<RSPRunDTO>> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
					batchList = apiResponse.getObjectList();
					logger.info("getRSPBatchList: " + batchList);
			}else {
				logger.info("getRSPBatchList is null: " + batchList);
			}
			
		}
		return batchList;
	}
	
	
	public InvestementDashboardStatusDTO customerInvestmentProfile(Integer customerId) {
		String authorizationToken = discoveryService.preAuthorizeV2(customerId);
		InvestementDashboardStatusDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getInvestmentProfile(customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeReference<APIResponse<InvestementDashboardStatusDTO>> typeReference = new TypeReference<APIResponse<InvestementDashboardStatusDTO>>() {
			};
			ObjectMapper mapper = new ObjectMapper();
            mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			APIResponse<InvestementDashboardStatusDTO> apiResponse = null;
			try {
				apiResponse = mapper.readValue(response.getResponseBody(), typeReference);
			} catch (IOException e) {
				e.printStackTrace();
			}
					//response.parseAbstractResponse(typeToken)
			if (apiResponse != null) {
				if(apiResponse.getResponseMessage().getResponseCode() == ErrorCodes.IFAST_DOWN) {
					throw new IFastException(ApplicationConstants.IFAST_SERVICE_DOWN);
				}
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}
		return dto;
	}
	
	public InvestmentAccountStatusDTO customerInvestmentAccountActions(Integer customerId) {
		String authorizationToken = discoveryService.preAuthorizeV2(customerId);
		InvestmentAccountStatusDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getInvestmentAccountActions());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<InvestmentAccountStatusDTO>> typeToken = new TypeToken<APIResponse<InvestmentAccountStatusDTO>>() {
			};
			APIResponse<InvestmentAccountStatusDTO> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}
		return dto;
	}

	public String fetchCustomerId(String counterPartyAccountNo) {
		String authorizationToken = discoveryService.preAuthorize();
		String custId = "";
		InvestementDashboardStatusDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.fetchCustomerId(counterPartyAccountNo));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			custId = response.getResponseBody();
		}
		return custId;
	}
	
	public String fetchCustIdForStatements(String ifastRefno) {
		String authorizationToken = discoveryService.preAuthorize();
		String custId = "";
		InvestementDashboardStatusDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.fetchCustIdForStatements(ifastRefno));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			custId = response.getResponseBody();
		}
		return custId;
	}

	public Boolean updateRSPStatus(String status, String errorDetails, String authToken) {
		Boolean rspStatus = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.saveRspBatchTimings());
		request.addHeader("Authorization", getAuthorizationToken());
		request.setMethodName("POST");
		HashMap<String, Object> statusParams = new HashMap<>();
		statusParams.put("status", status);
		statusParams.put("errorDetails", errorDetails);
		statusParams.put("month",PublicUtility.getCurrentMonthYear());
		request.setRequestBody(statusParams);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					rspStatus = apiResponse.getObjectList();
				}
			}
		}
		return rspStatus;
	}
	
	
//	public Boolean updateCustomerPortfolioStatus(String portfolioId, Double investmentAmount, String payMonthly,
//			Integer customerId) {
//		// String authorizationToken =
//		// getCurrentHttpRequest().getHeader("Authorization");
//		String authorizationToken = discoveryService.preAuthorizeScheduler();
//		logger.info("reached updateCustomerPortfolioStatus");
//		//String authorizationToken = discoveryService.preAuthorize();
//		Boolean updateStatus = false;
//		try {
//		logger.info("authorizationToken"+authorizationToken);
//		MOServiceRequest request = new MOServiceRequest();
//		request.setUrl(URLDirectory.InvestmentService.updateCustomerPortfolioPurchasedStatus());
//		//harcoded URL - to be modified
//		//request.setUrl("https://bfa-uat2.ntucbfa.com/invest/investment-microservice/portfolio/scheduledBuy");
//		request.addHeader("Authorization", authorizationToken);
//		request.setMethodName("POST");
//		HashMap<String, Object> statusObj = new HashMap<>();
//		statusObj.put("portfolioId", portfolioId);
//		statusObj.put("investmentAmount", investmentAmount);
//		statusObj.put("payMonthly", payMonthly);
//		statusObj.put("customerId", customerId.toString());
//		request.setRequestBody(statusObj);
//		logger.info("request url"+request.getUrl());
//		MOServiceResponse response = post(request);
//		logger.info("authorizationToken"+authorizationToken);
//		if (response != null) {
//			TypeToken<APIResponse<IFastResponse<DPMSTransactionResponse>>> typeToken = new TypeToken<APIResponse<IFastResponse<DPMSTransactionResponse>>>() {
//			};
//			APIResponse<IFastResponse<DPMSTransactionResponse>> apiResponse = response.parseAbstractResponse(typeToken);
//			if (apiResponse != null) {
//				if (apiResponse.getObjectList() != null) {
//					updateStatus = apiResponse.getResponseMessage().getResponseCode() == ErrorCodes.SUCCESSFUL_RESPONSE;
//				}
//			}
//		}
//		}catch(Exception e) {
//			logger.error("Exception at updateCustomerPortfolioStatus",e);
//		}
//		return updateStatus;
//	}
	
	public void updateRSPCustomer(Integer customerPortfolioId, String portfolioId, Double investmentAmount,
			String payMonthly, Integer customerId, Integer portfolioTransId, Boolean notifyInsufficientFund) {
		logger.info("reached updateRSPCustomer for customer portfolioid: " + customerPortfolioId);
		try {
			MOServiceRequest request = new MOServiceRequest();
			request.setUrl(URLDirectory.InvestmentService.updateCustomerPortfolioPurchasedStatus(customerPortfolioId));
			String authToken = discoveryService.preAuthorizeV2(customerId);
			request.addHeader("Authorization", authToken);
			request.setMethodName("POST");
			HashMap<String, Object> statusObj = new HashMap<>();
			statusObj.put("portfolioId", portfolioId);
			statusObj.put("investmentAmount", investmentAmount);
			statusObj.put("payMonthly", payMonthly);
			statusObj.put("customerId", customerId);
			statusObj.put("transactionId", portfolioTransId);
			statusObj.put("notifyInsufficientFund", notifyInsufficientFund);
			request.setRequestBody(statusObj);
			logger.info("request url" + request.getUrl());
			MOServiceResponse response = post(request);
			if (response != null) {
				TypeToken<APIResponse<IFastResponse<DPMSTransactionResponse>>> typeToken = new TypeToken<APIResponse<IFastResponse<DPMSTransactionResponse>>>() {

					/**
					 * 
					 */
					private static final long serialVersionUID = 1L;
				};
				APIResponse<IFastResponse<DPMSTransactionResponse>> apiResponse = response
						.parseAbstractResponse(typeToken);
				if (apiResponse != null && apiResponse.getObjectList() != null) {
					logger.info("Updated RSP customers: " + apiResponse.getResponseMessage() + "for Customer : "
							+ customerId);

				}
			}
		} catch (Exception e) {
			logger.error("Exception at updateRSPCustomer: ", e);
			throw e;
		}
	}

	
	public Boolean updateInsufficientFundJob() {
		logger.info("reached updateInsufficientFundJob");
		Boolean updateStatus = false;
		try {
		String authorizationToken = discoveryService.preAuthorize();
		logger.info("authorizationToken: "+ authorizationToken);
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateInsufficientFundStatus());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		logger.info("updateInsufficientFundJob response:: "+ response);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
					updateStatus = apiResponse.getObjectList();
			}
		}
		}catch(Exception e) {
			logger.error("Exception at updateInsufficientFundJob",e);
		}
		return updateStatus;
	}
	
	public Boolean getPortfolioNavList() {
		logger.info("reached getPortfolioNavList");
		Boolean updateStatus = false;
		try {
			Date currentdate = PublicUtility.getCurrentUTC();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String curDate = dateFormat.format(currentdate);
		String authorizationToken = discoveryService.preAuthorize();
		logger.info("authorizationToken: "+ authorizationToken);
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.savePortfolioNavList(curDate));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		logger.info("getPortfolioNavList response:: "+ response);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					updateStatus = apiResponse.getObjectList();
				}
			}
		}
		}catch(Exception e) {
			logger.error("Exception at getPortfolioNavList",e);
		}
		return updateStatus;
	}
	
	public DPMSHoldingsSummary getDPMSHoldings(Integer customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		DPMSHoldingsSummary dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.fetchHoldingDetails(customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<DPMSHoldingsSummary>> typeToken = new TypeToken<APIResponse<DPMSHoldingsSummary>>() {
			};
			String responseBody = response.getResponseBody();

			APIResponse<DPMSHoldingsSummary> apiResponse = new GsonBuilder().create().fromJson(responseBody,
					typeToken.getType());
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
	
	public AdminCustomerSummary fetchCustomerInvestmentObjectiveForAdmin(String customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		AdminCustomerSummary dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getInvetmentObjectiveForAdmin(customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);

		if (response != null) {
			TypeToken<APIResponse<AdminCustomerSummary>> typeToken = new TypeToken<APIResponse<AdminCustomerSummary>>() {
			};
			String responseBody = response.getResponseBody();

			APIResponse<AdminCustomerSummary> apiResponse = new GsonBuilder()
					.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {

						@Override
						public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
							Date parsedDate = PublicUtility.tryParseDate(json.getAsString());
							if (parsedDate == null)
								parsedDate = new Date();

							return parsedDate;
						}
					}).create().fromJson(responseBody, typeToken.getType());
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
	
	public boolean sendMonthlyStatementMailer(int customerId, String customerPortfolioId, String month, String year) {
		boolean dto = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.monthlyStatementMailer(customerPortfolioId, month, year));
		String authorizationToken = discoveryService.preAuthorizeV2(customerId);
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
	
	public boolean sendRSPReminderMail(int customerId,int customerPortfolioId) {
		boolean dto = true;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.rspReminderMailer(customerPortfolioId));
		String authorizationToken = discoveryService.preAuthorizeV2(customerId); 
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}
		return dto;
	}

	//Get financial details call
	
	public FinancialDTO getFinacialDetailsByCustomerId(){
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		FinancialDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.FinanceService.getFinacialDetailsByCustomerId());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<FinancialDTO>> typeToken = new TypeToken<APIResponse<FinancialDTO>>() {
			};
			APIResponse<FinancialDTO> apiResponse = APIResponse
					.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
		
	public CustomerIFastAccount getCustomerIfastDetails(String counterPartyAccNumber) {
		String authorizationToken = discoveryService.preAuthorize();
		CustomerIFastAccount custIfastAcc = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getCustomerIfastAccount(counterPartyAccNumber));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		logger.info("getCustomerIfastAccount response:: "+ response);	
		
		
		if (response != null) {
			TypeToken<APIResponse<CustomerIFastAccount>> typeToken = new TypeToken<APIResponse<CustomerIFastAccount>>() {
			};
			String responseBody = response.getResponseBody();

			APIResponse<CustomerIFastAccount> apiResponse = new GsonBuilder()
					.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {

						@Override
						public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
							Date parsedDate = PublicUtility.tryParseDate(json.getAsString());
							if (parsedDate == null)
								parsedDate = new Date();

							return parsedDate;
						}
					}).create().fromJson(responseBody, typeToken.getType());
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				custIfastAcc = apiResponse.getObjectList();
			}
		}
		logger.info("ResponseBody from investment service call: " + response.getResponseBody());
		return custIfastAcc;
	
	}

	public Boolean updatetheSrsfundingType(UpdateFundingTypeRequest fundingRequest) {
// DiscoveryServiceImpl discoveryServiceImpl = new DiscoveryServiceImpl();
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		Boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.updateCustomerInvfundType());
		request.addHeader("Authorization", authorizationToken);
		request.setRequestBody(fundingRequest);
		 request.setMethodName("POST");
// Create CustomerIFastAccount instance and set appropriate values
		
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					updateStatus = apiResponse.getObjectList();
				}
			}
		}
		return updateStatus;
	}
	
	public boolean saveCustomerSRStoIfast(CustomerBankInfoDTO customerBankInfoDTO) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.saveSRSIntoIfast());
		request.addHeader("Authorization", authorizationToken);
		request.setRequestBody(customerBankInfoDTO);
		request.setMethodName("POST");
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<IFastResponse<IFastAccountUpdateResponse>>> typeToken = new TypeToken<APIResponse<IFastResponse<IFastAccountUpdateResponse>>>() {
			};
			APIResponse<IFastResponse<IFastAccountUpdateResponse>> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && !ObjectUtils.isEmpty(apiResponse.getObjectList()) && !StringUtils.isEmpty(apiResponse.getObjectList().getServerStatus())
					&& !StringUtils.isEmpty(apiResponse.getObjectList().getServerStatus().getStatus())
					&& apiResponse.getObjectList().getServerStatus().getStatus().equalsIgnoreCase("OK")) {
				updateStatus = true;
	    }
		}
		return updateStatus;
	}
	
	
	public Map<String, String> postCustomerInvestmentObjective(CustomerInvestmentObjectiveDTO custInvestObj,int customerId) {

		String authorizationToken = discoveryService.preAuthorizeV2(customerId);
		Map<String, String> updateStatus = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.postCustomerInvestmentObjective());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		request.setRequestBody(custInvestObj);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Map<String, String>>> typeToken = new TypeToken<APIResponse<Map<String, String>>>() {
			};
			APIResponse<Map<String, String>> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				updateStatus = apiResponse.getObjectList();
			}

		}

		return updateStatus;

	}
	
	public String sendNotifiation(String notification) {
		String notificationStatus = null;
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.NotificationService.sendNotification());
		request.setRequestBody(notification);
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		MOServiceResponse response = post(request);
		if(response != null) {
			notificationStatus = response.getResponseBody();
		}
		return notificationStatus;
		
	}
	
	public ArrayList<OptionItem> fetchingOptionListCollection(int customerId) {
		String authorizationToken = discoveryService.preAuthorizeV2(customerId);
		ArrayList<OptionItem> optionItem = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.fetchOptionsCollectionMaster(ApplicationConstants.PORTFOLIO_FUNDING_METHOD));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<Map<String, ArrayList<OptionItem>>>> typeToken = new TypeToken<APIResponse<Map<String, ArrayList<OptionItem>>>>() {
			};
			APIResponse<Map<String, ArrayList<OptionItem>>> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					optionItem = apiResponse.getObjectList().get(ApplicationConstants.PORTFOLIO_FUNDING_METHOD);
				}
			}
		}
		return optionItem;
	}

	public AdminCustomerSummary fetchDeletePortfolioSummary(String customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		AdminCustomerSummary dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.getDeletedPortfolioDetailsForAdmin(customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		
		if (response != null) {
			TypeToken<APIResponse<AdminCustomerSummary>> typeToken = new TypeToken<APIResponse<AdminCustomerSummary>>() {
			};
			String responseBody = response.getResponseBody();

			APIResponse<AdminCustomerSummary> apiResponse = new GsonBuilder()
					.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {

						@Override
						public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
							Date parsedDate = PublicUtility.tryParseDate(json.getAsString());
							if (parsedDate == null)
								parsedDate = new Date();

							return parsedDate;
						}
					}).create().fromJson(responseBody, typeToken.getType());
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}

	public Boolean updateAddressToIfast(String customerId, String sessionId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		try {
			MOServiceRequest request = new MOServiceRequest();
			request.setUrl(URLDirectory.InvestmentService.saveAddressToIfast(customerId));
			request.addHeader("Authorization", authorizationToken);
			Map<String,String> requestBody = new HashMap<>();
			requestBody.put("sessionId",sessionId);
			request.setRequestBody(requestBody);
			request.setMethodName("POST");
			MOServiceResponse response = post(request);
			if (response != null) {
				TypeToken<APIResponse<IFastResponse<IFastAccountUpdateResponse>>> typeToken = new TypeToken<APIResponse<IFastResponse<IFastAccountUpdateResponse>>>() {

					/**
					 * 
					 */
					private static final long serialVersionUID = 1L;
				};
				APIResponse<IFastResponse<IFastAccountUpdateResponse>> apiResponse = response
						.parseAbstractResponse(typeToken);

				if (apiResponse != null && apiResponse.getResponseMessage() != null
						&& apiResponse.getResponseMessage().getResponseCode() == ErrorCodes.SUCCESSFUL_RESPONSE) {
					logger.info("Updated Address in iFAST" + apiResponse.getResponseMessage() + "for Customer : "
							+ customerId);
					return true;
				}
			}
		} catch (Exception e) {
			logger.error("Exception while updating address in iFAST: ", e);
		}
		return false;
	}
	
	/**
	 * Save customer bank info to IFAST
	 * @param customerBankInfoDTO
	 * @return
	 */
	public boolean saveCustomerBankToIfast(CustomerBankDetail customerBankDetail) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		boolean updateStatus = false;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.InvestmentService.saveBankIntoIfast());
		request.addHeader("Authorization", authorizationToken);
		request.setRequestBody(customerBankDetail);
		request.setMethodName("POST");
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<IFastResponse<List<IFastAccountUpdateResponse>>>> typeToken = new TypeToken<APIResponse<IFastResponse<List<IFastAccountUpdateResponse>>>>() {
			};
			APIResponse<IFastResponse<List<IFastAccountUpdateResponse>>> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && !ObjectUtils.isEmpty(apiResponse.getObjectList()) && !StringUtils.isEmpty(apiResponse.getObjectList().getServerStatus())
						&& !StringUtils.isEmpty(apiResponse.getObjectList().getServerStatus().getStatus())
						&& apiResponse.getObjectList().getServerStatus().getStatus().equalsIgnoreCase("OK")) {
					updateStatus = true;
		    }
		}
		return updateStatus;
	}
}

package com.bfa.serviceimpl;

import static org.mockito.Mockito.when;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.ComprehensiveDao;
import com.bfa.insurance.core.Customer;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;

@Configuration
@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@PrepareForTest({ComprehensiveServiceImpl.class, LogManager.class})
@PowerMockIgnore({"javax.crypto.*",  "javax.management.*", "javax.net.ssl.*"})
public class ComprehensiveServiceImplPowerMockTest {
	
	@InjectMocks
	ComprehensiveServiceImpl compServiceImpl;
	
	@Mock
	private ComprehensiveDao mComprehensiveDAO;
	
	@Mock
	ComprehensiveEnquiryPreferencesHelper mComprehensiveEnquiryPreferencesHelper;
	
	private ComprehensiveServiceImpl powerMockComprehensiveServiceImpl;
	
	private DefaultServiceImpl defaultServiceImpl;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Before
    public void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
		
		powerMockComprehensiveServiceImpl = PowerMockito.spy(new ComprehensiveServiceImpl());
		
		defaultServiceImpl = PowerMockito.spy(new DefaultServiceImpl());
        
        PowerMockito.mock(LogManager.class);
		
        when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
    }
	
	@Test
	public void updateCustomerBasicDetailsTest() throws Exception {
		
		ComprehensiveServiceImpl spiedCompService = PowerMockito.spy(compServiceImpl);
		
		UpdateCustomerBasicInfo updateCustomerBasicInfo = new UpdateCustomerBasicInfo();
		updateCustomerBasicInfo.setCustomerId(1);
		updateCustomerBasicInfo.setGender("male");
		updateCustomerBasicInfo.setDateOfBirth("10-09-1999");
		updateCustomerBasicInfo.setNationalityStatus("Singapoorean");
		
		Customer customer = new Customer();
		customer.setId(1);
		
		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		comprehensiveEnquiryDTO.setCustomerId(1);
		comprehensiveEnquiryDTO.setReportStatus("Submitted");
		
		PowerMockito.doReturn(customer).when(spiedCompService, "getCustomer", ArgumentMatchers.anyInt());
		
		ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = new ComprehensiveEnquiryPostResponse();
		comprehensiveEnquiryPostResponse.setComprehensiveEnquiry(comprehensiveEnquiryDTO);
		
	
		ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();

		comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);

		
		when(mComprehensiveEnquiryPreferencesHelper.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest)).thenReturn(comprehensiveEnquiryPostResponse);

		
		PowerMockito.doReturn(comprehensiveEnquiryDTO).when(spiedCompService, "getComprehensiveEnquiry", ArgumentMatchers.anyInt(), ArgumentMatchers.anyInt());
		
		spiedCompService.updateCustomerBasicDetails(updateCustomerBasicInfo, 1);
	}

}

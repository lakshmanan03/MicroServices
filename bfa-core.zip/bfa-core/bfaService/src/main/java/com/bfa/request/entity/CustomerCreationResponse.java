/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep.p
 *
 */
public class CustomerCreationResponse {	
	
	private String customerRef;
	
	private int enquiryId;
	
	private String securityToken;

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getSecurityToken() {
		return securityToken;
	}

	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}	
}

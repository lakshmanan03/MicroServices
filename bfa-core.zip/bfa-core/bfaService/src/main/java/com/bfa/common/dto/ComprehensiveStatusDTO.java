package com.bfa.common.dto;

import java.util.Date;

/**
 * 
 * @author GajendraK
 *
 */

public class ComprehensiveStatusDTO {

	private Integer enquiryId;
	
	private Boolean dobPopUpEnable;
	
	private String type;
	
	private Boolean isDobUpdated;
	
	private Boolean isLocked;
	
	private String reportStatus;
	
	private Date reportSubmittedTimeStamp;
	
	private Integer stepCompleted;
	
	private Boolean isValidatedPromoCode;
	
	private String nationalityStatus;
	
	private Integer reportId;
	

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Boolean getDobPopUpEnable() {
		return dobPopUpEnable;
	}

	public void setDobPopUpEnable(Boolean dobPopUpEnable) {
		this.dobPopUpEnable = dobPopUpEnable;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Boolean getIsDobUpdated() {
		return isDobUpdated;
	}

	public void setIsDobUpdated(Boolean isDobUpdated) {
		this.isDobUpdated = isDobUpdated;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public String getReportStatus() {
		return reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}

	public Date getReportSubmittedTimeStamp() {
		return reportSubmittedTimeStamp;
	}

	public void setReportSubmittedTimeStamp(Date reportSubmittedTimeStamp) {
		this.reportSubmittedTimeStamp = reportSubmittedTimeStamp;
	}

	public Integer getStepCompleted() {
		return stepCompleted;
	}

	public void setStepCompleted(Integer stepCompleted) {
		this.stepCompleted = stepCompleted;
	}

	public Boolean getIsValidatedPromoCode() {
		return isValidatedPromoCode;
	}

	public void setIsValidatedPromoCode(Boolean isValidatedPromoCode) {
		this.isValidatedPromoCode = isValidatedPromoCode;
	}

	public String getNationalityStatus() {
		return nationalityStatus;
	}

	public void setNationalityStatus(String nationalityStatus) {
		this.nationalityStatus = nationalityStatus;
	}

	public Integer getReportId() {
		return reportId;
	}

	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}
	
}

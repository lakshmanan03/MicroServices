package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCodeRequest;
@RunWith(SpringJUnit4ClassRunner.class)
public class PromoCodeServiceImplTest {

	@InjectMocks
	private PromoCodeServiceImpl mPromoCodeServiceImpl;

	@Mock
	private PromoCodeRequest mPromoCodeRequest;

	@Mock
	private DelegateHandler mDelegateHandler;

	@Mock
	private EnquiryServiceUpdater mEnquiryServiceUpdater;

	@Mock
	private EnquiryResponseMessage mEnquiryResponseMessage;

	@Test
	public void testGetEnquiryReference() {
		when(mDelegateHandler.getEnquiryServiceUpdater()).thenReturn(mEnquiryServiceUpdater);
		when(mEnquiryServiceUpdater.createEnquiry(mPromoCodeRequest)).thenReturn(mEnquiryResponseMessage);
		EnquiryResponseMessage response = mPromoCodeServiceImpl.getEnquiryReference(mPromoCodeRequest);
		assertNotNull(response);
	}

}

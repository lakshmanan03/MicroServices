SET FOREIGN_KEY_CHECKS=0;
drop table customer_previlege if exists;
CREATE TABLE if not exists customer_previlege (customer_id int(11) NOT NULL, previlege_id int(11) NOT NULL);
delete from customers;
insert into customers (email,mobile_number,otp_verified,email_verified,accept_market_emails,is_smoker,is_identity_verified,by_phone,by_email) values ('testagain@yahoo.com','98901122','No','Yes',0,0,1,0,0);
commit;
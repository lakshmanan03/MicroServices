package com.bfa.util;

import java.io.InputStream;

public class BFAHTTPFile {
	private String fileName;
	private InputStream stream;
	private String fileKey;
	
	public BFAHTTPFile(String fileName,InputStream stream,String fileKey) {
		this.fileKey = fileKey;
		this.fileName = fileName;
		this.stream = stream;
	}
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public InputStream getStream() {
		return stream;
	}
	public void setStream(InputStream stream) {
		this.stream = stream;
	}
	public String getFileKey() {
		return fileKey;
	}
	public void setFileKey(String fileKey) {
		this.fileKey = fileKey;
	}
	
	
}

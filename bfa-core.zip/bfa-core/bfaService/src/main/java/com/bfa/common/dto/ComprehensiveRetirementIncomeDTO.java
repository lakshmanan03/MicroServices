/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveRetirementIncomeDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonIgnore
	private Integer customerId;
	
	private Integer enquiryId;	
	
	private Integer monthlyPayout;	
	
	private Integer payoutStartAge;	
	
	private String payoutDuration;
	

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getMonthlyPayout() {
		return monthlyPayout;
	}

	public void setMonthlyPayout(Integer monthlyPayout) {
		this.monthlyPayout = monthlyPayout;
	}

	public Integer getPayoutStartAge() {
		return payoutStartAge;
	}

	public void setPayoutStartAge(Integer payoutStartAge) {
		this.payoutStartAge = payoutStartAge;
	}

	public String getPayoutDuration() {
		return payoutDuration;
	}

	public void setPayoutDuration(String payoutDuration) {
		this.payoutDuration = payoutDuration;
	}
}

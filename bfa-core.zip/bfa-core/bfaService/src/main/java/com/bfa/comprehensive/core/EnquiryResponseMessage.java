
package com.bfa.comprehensive.core;

import java.util.List;

import com.bfa.insurance.core.Enquiry;

public class EnquiryResponseMessage {


	private List<Enquiry> objectList;

	public List<Enquiry> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<Enquiry> objectList) {
		this.objectList = objectList;
	}


}

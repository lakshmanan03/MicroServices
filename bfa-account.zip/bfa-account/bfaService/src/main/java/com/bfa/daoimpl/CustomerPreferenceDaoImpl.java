package com.bfa.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.core.CustomerPreference;
import com.bfa.application.core.CustomerSrsPopStatus;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.CustomerPreferenceDao;
import com.bfa.util.PublicUtility;

@Transactional
@Repository
public class CustomerPreferenceDaoImpl extends BaseDaoImpl implements CustomerPreferenceDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private ApplicationLoggerBean loggerBean;
	
	protected Logger getLogger() {
		return loggerBean.getLogBean(this.getClass());
	}

	@Autowired
	private SecurityConstants securityConstants;

	private String appKey = "IMXYlDmP4f4=";

	private PublicUtility utility = PublicUtility.getInstance(appKey);

	@Override
	public Object saveOrUpdateObject(Object obj) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();			
			Transaction transaction = session.beginTransaction();
			session.saveOrUpdate(obj);
			session.flush();
			transaction.commit();
			return obj;
		} catch (Exception err) {
			getLogger().error("Error while saving the entity", err);
			throw new DatabaseAccessException();
		}
		finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}
	
	@Override
	public CustomerPreference getCustomerPreference(Integer customerId, String trackCode) {
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("customerId", String.valueOf(customerId));
		parameters.put("trackCode", trackCode);
		List<CustomerPreference> customerPreferences = getList("FROM CustomerPreference where customer_id = :customerId AND track_code = :trackCode", parameters);
		if(customerPreferences != null && customerPreferences.size() > 0) {
			return customerPreferences.get(0);
		}
		return null;
	}
	
	@Override
	public List<CustomerPreference> getCustomerPreferences(Integer customerId) {
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("customerId", String.valueOf(customerId));
		List<CustomerPreference> customerPreferences = getList("FROM CustomerPreference where customer_id = :customerId", parameters);
		if(customerPreferences != null) {
			return customerPreferences;
		}
		return null;
	}
}

/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveDownOnLuckDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private Integer customerId;

	private Integer enquiryId;

	private Double badMoodMonthlyAmount;

	private Integer hospitalPlanId;
	
	private String hospitalPlanName;

	public String getHospitalPlanName() {
		return hospitalPlanName;
	}

	public void setHospitalPlanName(String hospitalPlanName) {
		this.hospitalPlanName = hospitalPlanName;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getBadMoodMonthlyAmount() {
		return badMoodMonthlyAmount;
	}

	public void setBadMoodMonthlyAmount(Double badMoodMonthlyAmount) {
		this.badMoodMonthlyAmount = badMoodMonthlyAmount;
	}

	public Integer getHospitalPlanId() {
		return hospitalPlanId;
	}

	public void setHospitalPlanId(Integer hospitalPlanId) {
		this.hospitalPlanId = hospitalPlanId;
	}

}

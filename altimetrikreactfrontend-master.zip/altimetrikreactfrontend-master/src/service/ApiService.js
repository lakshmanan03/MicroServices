import axios from 'axios';

const Food_API_BASE_URL = 'http://localhost:8080/api/v1/food';

class ApiService {

    fetchFood() {
        return axios.get(Food_API_BASE_URL);
    }

    fetchBudget() {
        return axios.get(Food_API_BASE_URL + '/' + 'price');
    }

    fetchRated()
    {
        return axios.get(Food_API_BASE_URL + '/' + 'rated');
    }

    deleteUser(userId) {
        return axios.delete(Food_API_BASE_URL + '/' + userId);
    }

    addUser(user) {
        return axios.post(""+Food_API_BASE_URL, user);
    }

    editUser(user) {
        return axios.put(Food_API_BASE_URL + '/' + user.id, user);
    }

}

export default new ApiService();
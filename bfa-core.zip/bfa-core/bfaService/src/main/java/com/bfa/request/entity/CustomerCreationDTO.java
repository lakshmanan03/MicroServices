/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep.p
 *
 */
public class CustomerCreationDTO {
	
	private String countryCode;
	
	private String mobileNumber;
	
	private String firstName;
	
	private String lastName;
	
	private String fullName;
	
	private String emailAddress;
	
	private String password;
	
	private boolean acceptMarketingNotifications;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAcceptMarketingNotifications() {
		return acceptMarketingNotifications;
	}

	public void setAcceptMarketingNotifications(boolean acceptMarketingNotifications) {
		this.acceptMarketingNotifications = acceptMarketingNotifications;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	
}

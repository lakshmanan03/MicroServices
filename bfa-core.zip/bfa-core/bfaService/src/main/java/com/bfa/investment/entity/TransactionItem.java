package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// Added for combining Portfolio and Cash Transactions 
@Entity
@Table(name = "vw_transaction_history")
public class TransactionItem {

	@Column
	@Id
	private String id;
	
	@Column
	private String transactionId;
	
	@Column
	private Double amount;
	
	@Column
	private String portfolioName;
	
	@Column
	private String transactionType;
	
	@Column
	private String fundName;
	
	@Column
	private Double fundUnit;
	
	@Column
	private Double fundUnitPrice;
	
	@Column
	private Integer customerId;
	
	@Column
	private Date createdDate;
	
	@Column
	private Integer customerPortfolioId;
	
	@Column
	private String contractNo;

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	
	
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public Double getFundUnit() {
		return fundUnit;
	}

	public void setFundUnit(Double fundUnit) {
		this.fundUnit = fundUnit;
	}

	public Double getFundUnitPrice() {
		return fundUnitPrice;
	}

	public void setFundUnitPrice(Double fundUnitPrice) {
		this.fundUnitPrice = fundUnitPrice;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	
}

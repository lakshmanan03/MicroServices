package com.bfa.exception;

/**
 * @author Vimala Shan
 *
 */
public class ComprehensiveException extends BfaException {

	/**
	 * The serializable class ComprehensiveException declared a static final
	 * serialVersionUID field of type long
	 */
	private static final long serialVersionUID = -5687368227645851769L;

	/**
	 * @param exceptionMessage
	 */
	public ComprehensiveException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
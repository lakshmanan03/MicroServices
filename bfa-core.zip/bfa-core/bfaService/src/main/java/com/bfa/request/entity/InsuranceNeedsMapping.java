/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.core.CriticalIllnessNeeds;
import com.bfa.insurance.core.EnquiryProtectionType;
import com.bfa.insurance.core.ExistingInsurance;
import com.bfa.insurance.core.HospitalizationNeeds;
import com.bfa.insurance.core.LifeProtectionNeeds;
import com.bfa.insurance.core.LongTermCareNeeds;
import com.bfa.insurance.core.OccupationalDisabilityNeeds;
import com.bfa.insurance.core.RetirementIncomePlan;
import com.bfa.insurance.core.SRSApprovedPlans;

/**
 * @author sureshkumar_su
 *
 */
public class InsuranceNeedsMapping {

	private List<EnquiryProtectionType> enquiryProtectionType;

	private CriticalIllnessNeeds criticalIllnessNeeds;

	private LongTermCareNeeds longTermCareNeeds;

	private HospitalizationNeeds hospitalization;

	private LifeProtectionNeeds lifeprotectionNeeds;

	private OccupationalDisabilityNeeds occupationalDisabilityNeeds;

	private List<ExistingInsurance> existingInsurance;

	private SRSApprovedPlans srsApprovedPlans;

	private RetirementIncomePlan retirementIncomePlan;

	public CriticalIllnessNeeds getCriticalIllnessNeeds() {
		return criticalIllnessNeeds;
	}

	public void setCriticalIllnessNeeds(CriticalIllnessNeeds criticalIllnessNeeds) {
		this.criticalIllnessNeeds = criticalIllnessNeeds;
	}

	public LongTermCareNeeds getLongTermCareNeeds() {
		return longTermCareNeeds;
	}

	public void setLongTermCareNeeds(LongTermCareNeeds longTermCareNeeds) {
		this.longTermCareNeeds = longTermCareNeeds;
	}

	public HospitalizationNeeds getHospitalization() {
		return hospitalization;
	}

	public void setHospitalization(HospitalizationNeeds hospitalization) {
		this.hospitalization = hospitalization;
	}

	public LifeProtectionNeeds getLifeprotectionNeeds() {
		return lifeprotectionNeeds;
	}

	public void setLifeprotectionNeeds(LifeProtectionNeeds lifeprotectionNeeds) {
		this.lifeprotectionNeeds = lifeprotectionNeeds;
	}

	public OccupationalDisabilityNeeds getOccupationalDisabilityNeeds() {
		return occupationalDisabilityNeeds;
	}

	public void setOccupationalDisabilityNeeds(OccupationalDisabilityNeeds occupationalDisabilityNeeds) {
		this.occupationalDisabilityNeeds = occupationalDisabilityNeeds;
	}

	public List<ExistingInsurance> getExistingInsurance() {
		return existingInsurance;
	}

	public void setExistingInsurance(List<ExistingInsurance> existingInsurance) {
		this.existingInsurance = existingInsurance;
	}

	public List<EnquiryProtectionType> getEnquiryProtectionType() {
		return enquiryProtectionType;
	}

	public void setEnquiryProtectionType(List<EnquiryProtectionType> enquiryProtectionType) {
		this.enquiryProtectionType = enquiryProtectionType;
	}

	public SRSApprovedPlans getSrsApprovedPlans() {
		return srsApprovedPlans;
	}

	public void setSrsApprovedPlans(SRSApprovedPlans srsApprovedPlans) {
		this.srsApprovedPlans = srsApprovedPlans;
	}

	public RetirementIncomePlan getRetirementIncomePlan() {
		return retirementIncomePlan;
	}

	public void setRetirementIncomePlan(RetirementIncomePlan retirementIncomePlan) {
		this.retirementIncomePlan = retirementIncomePlan;
	}

	@Override
	public String toString() {
		return "InsuranceNeedsMapping [enquiryProtectionType=" + enquiryProtectionType + ", criticalIllnessNeeds="
				+ criticalIllnessNeeds + ", longTermCareNeeds=" + longTermCareNeeds + ", hospitalization="
				+ hospitalization + ", lifeprotectionNeeds=" + lifeprotectionNeeds + ", occupationalDisabilityNeeds="
				+ occupationalDisabilityNeeds + ", existingInsurance=" + existingInsurance + ", srsApprovedPlans="
				+ srsApprovedPlans + ", retirementIncomePlan=" + retirementIncomePlan + "]";
	}
}

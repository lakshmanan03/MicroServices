package com.bfa.common.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomerInvestmentDetails {
	
	@JsonInclude(Include.NON_NULL)
	private Integer custId;
	
	@JsonInclude(Include.NON_NULL)
	private double oneTimeInvestmentAmount;
	
	@JsonInclude(Include.NON_NULL)
	private double monthlyInvestmentAmount;
	
	@JsonInclude(Include.NON_NULL)
	private String investmentAccountReferenceCode;
	
	@JsonInclude(Include.NON_NULL)
	private String bankTransferRecipientName;
	
	@JsonInclude(Include.NON_NULL)
	private String bankName;
	
	@JsonInclude(Include.NON_NULL)
	private String bankAccountNo;
	
	@JsonInclude(Include.NON_NULL)
	private String paynowUniqueEntityNumber;
	
	@JsonInclude(Include.NON_NULL)
	private String paynowEntityName;
	
	@JsonInclude(Include.NON_NULL)
	private String portfolioName;
	
	
	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getInvestmentAccountReferenceCode() {
		return investmentAccountReferenceCode;
	}

	public void setInvestmentAccountReferenceCode(String investmentAccountReferenceCode) {
		this.investmentAccountReferenceCode = investmentAccountReferenceCode;
	}

	public String getBankTransferRecipientName() {
		return bankTransferRecipientName;
	}

	public void setBankTransferRecipientName(String bankTransferRecipientName) {
		this.bankTransferRecipientName = bankTransferRecipientName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public String getPaynowUniqueEntityNumber() {
		return paynowUniqueEntityNumber;
	}

	public void setPaynowUniqueEntityNumber(String paynowUniqueEntityNumber) {
		this.paynowUniqueEntityNumber = paynowUniqueEntityNumber;
	}

	public String getPaynowEntityName() {
		return paynowEntityName;
	}

	public void setPaynowEntityName(String paynowEntityName) {
		this.paynowEntityName = paynowEntityName;
	}

	public double getOneTimeInvestmentAmount() {
		return oneTimeInvestmentAmount;
	}

	public void setOneTimeInvestmentAmount(double oneTimeInvestmentAmount) {
		this.oneTimeInvestmentAmount = oneTimeInvestmentAmount;
	}

	public double getMonthlyInvestmentAmount() {
		return monthlyInvestmentAmount;
	}

	public void setMonthlyInvestmentAmount(double monthlyInvestmentAmount) {
		this.monthlyInvestmentAmount = monthlyInvestmentAmount;
	}

	/**
	 * @return the portfolioName
	 */
	public String getPortfolioName() {
		return portfolioName;
	}

	/**
	 * @param portfolioName the portfolioName to set
	 */
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	
	

}

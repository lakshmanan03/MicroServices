package com.bfa.util;

/*
 * @Author Vimala Shan
 */


public class EmailQueueHelperImpl {


}
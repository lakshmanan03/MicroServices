/**
 * 
 */
package com.bfa.application.corporate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bfa.application.core.MailChimpModel;
import com.google.gson.Gson;

/**
 * @author pradheep
 *
 */
public class CorporateLeadGenRequest extends MailChimpModel {

	
	@NotBlank(message = "First name cannot be blank")
	private String firstName;

	
	@NotBlank(message = "Last name cannot be blank")
	private String lastName;

	
	@NotBlank(message = "Job function cannot be blank")
	private String jobFunction;

	
	@NotBlank(message = "Company name cannot be blank")
	private String companyName;

	
	@NotBlank(message = "Company size cannot be blank")
	private String companySize;

	
	@NotBlank(message = "Email address cannot be blank")
	private String emailAddress;

	
	@NotBlank(message = "Phone number cannot be blank")
	private String phoneNumber;
	
	/* BFA-1840 */

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getJobFunction() {
		return jobFunction;
	}

	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanySize() {
		return companySize;
	}

	public void setCompanySize(String companySize) {
		this.companySize = companySize;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}	

	public String toString() {
		return "First Name:" + getFirstName() + " Last Name:" + getLastName() + "Email Address: " + getEmailAddress()
				+ " Company name:" + getCompanyName() + " Job function:" + getJobFunction() + " Company size:"
				+ getCompanySize() + " Phone Number:" + getPhoneNumber();
	}	

}

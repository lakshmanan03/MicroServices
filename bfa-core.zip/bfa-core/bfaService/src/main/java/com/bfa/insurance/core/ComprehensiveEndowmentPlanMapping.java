/**
 * 
 */
package com.bfa.insurance.core;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author gajendrak
 *
 */

public class ComprehensiveEndowmentPlanMapping {
	
	@JsonIgnore
	private int id;
	
	private int dependentId;
	
	private int enquiryId;
	
	private String location;

	private String educationCourse;

	private Double endowmentMaturityAmount;

	private int endowmentMaturityYears;
	
	private int educationSpendingShare;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDependentId() {
		return dependentId;
	}

	public void setDependentId(int dependentId) {
		this.dependentId = dependentId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEducationCourse() {
		return educationCourse;
	}

	public void setEducationCourse(String educationCourse) {
		this.educationCourse = educationCourse;
	}

	public Double getEndowmentMaturityAmount() {
		return endowmentMaturityAmount;
	}

	public void setEndowmentMaturityAmount(Double endowmentMaturityAmount) {
		this.endowmentMaturityAmount = endowmentMaturityAmount;
	}

	public int getEndowmentMaturityYears() {
		return endowmentMaturityYears;
	}

	public void setEndowmentMaturityYears(int endowmentMaturityYears) {
		this.endowmentMaturityYears = endowmentMaturityYears;
	}

	public int getEducationSpendingShare() {
		return educationSpendingShare;
	}

	public void setEducationSpendingShare(int educationSpendingShare) {
		this.educationSpendingShare = educationSpendingShare;
	}

	

}

package com.bfa.investment.ifast.dto;





import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bfa.investment.entity.RiskProfile;
import com.fasterxml.jackson.annotation.JsonFormat;

public class DPMSPortfolio {

	private String portfolioStatus;
    private String productName;
    private String productCode;
    private String paymentMethod;
    private String productType;
    private String currency;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private Date expiryDate;
    private Double currentValue;
    private Double investmentAmount;
    private Double profitAndLoss;
    private RiskProfile riskProfile;
    private Double profitAndLossPercentage;
    private Double totalReturns;
    private Double totalReturnsPercentage;
    private Double yearlyReturns;
    private Double totalInvested;
    private Double unrealisedGainOrLoss;
    private Double simpleReturns;
    private List<DPMSFund> dpmsDetailsDisplay = null;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Date getExpiryDate() {
  		return expiryDate;
  	}

  	public void setExpiryDate(Date expiryDate) {
  		this.expiryDate = expiryDate;
  	}
    
    
    public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public Double getTotalReturns() {
		return totalReturns;
	}

	public void setTotalReturns(Double totalReturns) {
		this.totalReturns = totalReturns;
	}

	public Double getTotalReturnsPercentage() {
		return totalReturnsPercentage;
	}

	public void setTotalReturnsPercentage(Double totalReturnsPercentage) {
		this.totalReturnsPercentage = totalReturnsPercentage;
	}

	public Double getYearlyReturns() {
		return yearlyReturns;
	}

	public void setYearlyReturns(Double yearlyReturns) {
		this.yearlyReturns = yearlyReturns;
	}

	public Double getTotalInvested() {
		return totalInvested;
	}

	public void setTotalInvested(Double totalInvested) {
		this.totalInvested = totalInvested;
	}

	public Double getUnrealisedGainOrLoss() {
		return unrealisedGainOrLoss;
	}

	public void setUnrealisedGainOrLoss(Double unrealisedGainOrLoss) {
		this.unrealisedGainOrLoss = unrealisedGainOrLoss;
	}

	public Double getSimpleReturns() {
		return simpleReturns;
	}

	public void setSimpleReturns(Double simpleReturns) {
		this.simpleReturns = simpleReturns;
	}

	public RiskProfile getRiskProfile() {
		return riskProfile;
	}

	public void setRiskProfile(RiskProfile riskProfile) {
		this.riskProfile = riskProfile;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(Double currentValue) {
        this.currentValue = currentValue;
    }

    public Double getInvestmentAmount() {
        return investmentAmount;
    }

    public void setInvestmentAmount(Double investmentAmount) {
        this.investmentAmount = investmentAmount;
    }

    public Double getProfitAndLoss() {
        return profitAndLoss;
    }

    public void setProfitAndLoss(Double profitAndLoss) {
        this.profitAndLoss = profitAndLoss;
    }

    public Double getProfitAndLossPercentage() {
        return profitAndLossPercentage;
    }

    public void setProfitAndLossPercentage(Double profitAndLossPercentage) {
        this.profitAndLossPercentage = profitAndLossPercentage;
    }

    public List<DPMSFund> getDpmsDetailsDisplay() {
        return dpmsDetailsDisplay;
    }

    public void setDpmsDetailsDisplay(List<DPMSFund> dpmsDetailsDisplay) {
        this.dpmsDetailsDisplay = dpmsDetailsDisplay;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DPMSPortfolio [portfolioStatus=");
		builder.append(portfolioStatus);
		builder.append(", productName=");
		builder.append(productName);
		builder.append(", productCode=");
		builder.append(productCode);
		builder.append(", paymentMethod=");
		builder.append(paymentMethod);
		builder.append(", productType=");
		builder.append(productType);
		builder.append(", currency=");
		builder.append(currency);
		builder.append(", expiryDate=");
		builder.append(expiryDate);
		builder.append(", currentValue=");
		builder.append(currentValue);
		builder.append(", investmentAmount=");
		builder.append(investmentAmount);
		builder.append(", profitAndLoss=");
		builder.append(profitAndLoss);
		builder.append(", riskProfile=");
		builder.append(riskProfile);
		builder.append(", profitAndLossPercentage=");
		builder.append(profitAndLossPercentage);
		builder.append(", totalReturns=");
		builder.append(totalReturns);
		builder.append(", totalReturnsPercentage=");
		builder.append(totalReturnsPercentage);
		builder.append(", yearlyReturns=");
		builder.append(yearlyReturns);
		builder.append(", totalInvested=");
		builder.append(totalInvested);
		builder.append(", dpmsDetailsDisplay=");
		builder.append(dpmsDetailsDisplay);
		builder.append(", additionalProperties=");
		builder.append(additionalProperties);
		builder.append("]");
		return builder.toString();
	}

}

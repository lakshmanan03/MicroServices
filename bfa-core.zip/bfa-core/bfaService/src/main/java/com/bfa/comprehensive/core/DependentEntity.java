/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This entity is to map the Dependents table for comprehensive journey.
 * 
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "dependents")
public class DependentEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name="dependent_name")
	private String name;

	@Column(name = "relationship")
	private String relationship;
	
	@Column(name = "gender")
	private String gender;

	@Column(name = "date_of_birth")
	private String dateOfBirth;
	
	@Column(name="nationality")
	private String nation;	
	
	@Column(name="status")
	private String status;
	
	@Column(name="insurance_needed")
	private Boolean isInsuranceNeeded;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Boolean getIsInsuranceNeeded() {
		return isInsuranceNeeded;
	}

	public void setIsInsuranceNeeded(Boolean isInsuranceNeeded) {
		this.isInsuranceNeeded = isInsuranceNeeded;
	}
	
}

/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "occupational_disability_needs")

public class OccupationalDisabilityNeeds implements Serializable{

	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;	
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "percentage_coverage")
	private double percentageCoverage;
	
	@Column(name = "coverage_duration")
	private String coverageDuration;
	
	@Column(name = "coverage_amount")
	private double coverageAmount;
	
	/*@Column(name = "user_type")
	private String userType*/
	
	@Column(name = "employment_status_id")
	private int employmentStatusId;
	
	@Column(name = "max_age")
	private int maxAge;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public double getPercentageCoverage() {
		return percentageCoverage;
	}

	public void setPercentageCoverage(double percentageCoverage) {
		this.percentageCoverage = percentageCoverage;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}


	public int getEmploymentStatusId() {
		return employmentStatusId;
	}

	public void setEmploymentStatusId(int employmentStatusId) {
		this.employmentStatusId = employmentStatusId;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}

	public String getCoverageDuration() {
		return coverageDuration;
	}

	public void setCoverageDuration(String coverageDuration) {
		this.coverageDuration = coverageDuration;
	}
}

/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.common.CRMDataTransformer;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.ProtectionTypeEnum;
import com.bfa.common.entity.BFAGrantedAuthority;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.promotion.model.PromotionBundleModel;
import com.bfa.request.entity.CRMNewEnquiryRequest;
import com.bfa.request.entity.NewEnquiryRequest;
import com.bfa.service.BundleService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.PublicUtility;
import com.bfa.util.ServiceNames;

/**
 * @author pradheep
 *
 */
public class CRMBundleUpdater extends CRMDataTransformer implements Runnable {

	@Autowired
	private ApplicationLoggerBean applicationLogger;

	private CRMNewEnquiryRequest crmNewEnquiryRequest;

	private PromotionBundleModel promotionBundleModel;

	@Autowired
	private Environment environment;

	private String commandName = "CRM-BUNDLE-DATA-UPDATE";

	private String API_NAME = APIConstants.CRM_API;

	private Logger getLogger() {
		return this.applicationLogger.getLogBean(this.getClass());
	}

	public CRMBundleUpdater() {
		crmNewEnquiryRequest = new CRMNewEnquiryRequest();
	}

	public void setPromotionBundleModel(PromotionBundleModel model) {
		this.promotionBundleModel = model;
	}

	private String init() {
		setEnvironment(environment);
		String targetURL = getBaseUrl(ServiceNames.CRM_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + API_NAME;
		return targetURL;
	}

	private void constructCRMData() {
		getLogger().info("Making a CRM call to register the bundle information.");
		crmNewEnquiryRequest.setCustomerId(0);
		crmNewEnquiryRequest.setEmailAddress(promotionBundleModel.getEmailAddress());
		crmNewEnquiryRequest.setFirstName(promotionBundleModel.getFirstName());

		if (promotionBundleModel.getEnquiryType().toLowerCase().equals(BundleService.CHILD_BUNDLE_PRO_TYPE_ENQ)) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Child_Protection_Bundle);
		} else if (promotionBundleModel.getEnquiryType().toLowerCase()
				.equals(BundleService.CHILD_BUNDLE_EDU_TYPE_ENQ)) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Child_Education_Bundle);
		} else if (promotionBundleModel.getEnquiryType().toLowerCase()
				.equals(BundleService.RETIREMENT_BUNDLE_TYPE_ENQ)) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Retirewise_Bundle);
		} else if (promotionBundleModel.getEnquiryType().toLowerCase().contains("adult")) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Young_Working_Adult_Bundle);
		}
		crmNewEnquiryRequest.setLastName(promotionBundleModel.getLastName());
		crmNewEnquiryRequest.setNewCustomer(true);
		crmNewEnquiryRequest.setNewEnquiryRequest(getNewEnquiryRequest());
		crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.None);
		crmNewEnquiryRequest.setRequestByEmail(false);
		crmNewEnquiryRequest.setSelectedProductList(Collections.emptyList());
	}

	/* Some of the values are populated by CRM - Microservice */
	private NewEnquiryRequest getNewEnquiryRequest() {
		NewEnquiryRequest newEnquiryRequest = new NewEnquiryRequest();
		newEnquiryRequest.setCategory("");
		newEnquiryRequest.setContact(promotionBundleModel.getContactNumber());
		newEnquiryRequest.setContactTime("NA");
		newEnquiryRequest.setDescription("");
		newEnquiryRequest.setDob(promotionBundleModel.getDateOfBirth());
		newEnquiryRequest.setEmail(promotionBundleModel.getEmailAddress());
		String emailDate = getCurrentDate();
		getLogger().info("Printing the email date : " + emailDate);		
		newEnquiryRequest.setEmail_date(emailDate);
		newEnquiryRequest.setEventPlan(updateEventPlan(promotionBundleModel.getEnquiryType()));
		newEnquiryRequest.setGender(promotionBundleModel.getGender());
		newEnquiryRequest.setLast_name(promotionBundleModel.getLastName());
		newEnquiryRequest.setName(promotionBundleModel.getFirstName());
		newEnquiryRequest.setSmoker("NA");
		newEnquiryRequest.setSubject(ApplicationConstants.CRM_REQUEST_SUBJECT);
		return newEnquiryRequest;
	}
	
	private String updateEventPlan(String eventPlan){
		eventPlan = eventPlan.replace("-", " ");
		eventPlan = eventPlan.toUpperCase();
		String[] arg = eventPlan.split(" ");
		StringBuffer buffer = new StringBuffer();
		for(int i=0;i<arg.length;i++){
			String x = arg[i];
			buffer.append(x.charAt(0));
			buffer.append(x.substring(1).toLowerCase());
			buffer.append(" ");
		}
		return buffer.toString();
	}

	private String getCurrentDate() {
		return PublicUtility.dateToString(new Date(), "yyyy-MM-dd");
	}

	@Override
	public void run() {
		constructCRMData();
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new BFAGrantedAuthority("ROLE_USER"));
		authorities.add(new BFAGrantedAuthority("ROLE_SERVICE_CALL"));
		loadSecurityHeader(securityConstants.TOKEN_NAME, authorities);
		String requestBody = "";
		// ---------------------------------------------------------------------//
		requestBody = gson.toJson(crmNewEnquiryRequest);
		String targetURL = init();
		getLogger().info("Printing the target URL :" + targetURL);
		getLogger().info("Updating the bundle details into crm microservice -" + "Request body :" + requestBody);
		addJobToQueue(targetURL, requestBody, commandName, 0);
	}
}

/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.insurance.core.Assets;

/**
 * @author pradheep.p
 *
 */
public interface AssetsRepository extends JpaRepository<Assets, Integer> {

}

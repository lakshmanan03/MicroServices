package com.bfa.investment.dto;

import java.util.Map;

import com.google.common.reflect.TypeToken;
import com.google.gson.GsonBuilder;

public class RiskProfileDTO {
	private int primaryRiskProfileId;
	
	private String primaryRiskProfileType;
	
	private int alternateRiskProfileId;
	
	private String alternateRiskProfileType;
	
	private int order;
	
	private String htmlDesc;
	

	public Map<String, Object> getHtmlDescObject() {
		Map<String, Object> descObj = null;
		try {
			TypeToken<Map<String, Object>> typeToken = new TypeToken<Map<String, Object>>() {
			};
			descObj = new GsonBuilder().create()
					.fromJson(htmlDesc, typeToken.getType());	
		}
		catch(Exception ex) {
			descObj = null;
		}
		return descObj;
	}


	public int getAlternateRiskProfileId() {
		return alternateRiskProfileId;
	}

	public void setAlternateRiskProfileId(int alternateRiskProfileId) {
		this.alternateRiskProfileId = alternateRiskProfileId;
	}

	public String getAlternateRiskProfileType() {
		return alternateRiskProfileType;
	}

	public void setAlternateRiskProfileType(String alternateRiskProfileType) {
		this.alternateRiskProfileType = alternateRiskProfileType;
	}

	public int getPrimaryRiskProfileId() {
		return primaryRiskProfileId;
	}

	public void setPrimaryRiskProfileId(int id) {
		this.primaryRiskProfileId = id;
	}

	public String getPrimaryRiskProfileType() {
		return primaryRiskProfileType;
	}

	public void setPrimaryRiskProfileType(String type) {
		this.primaryRiskProfileType = type;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public String getHtmlDesc() {
		return htmlDesc;
	}

	public void setHtmlDesc(String string) {
		this.htmlDesc = string;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RiskProfileDTO [primaryRiskProfileId=");
		builder.append(primaryRiskProfileId);
		builder.append(", primaryRiskProfileType=");
		builder.append(primaryRiskProfileType);
		builder.append(", alternateRiskProfileId=");
		builder.append(alternateRiskProfileId);
		builder.append(", alternateRiskProfileType=");
		builder.append(alternateRiskProfileType);
		builder.append(", order=");
		builder.append(order);
		builder.append(", htmlDesc=");
		builder.append(htmlDesc);
		builder.append("]");
		return builder.toString();
	}
}

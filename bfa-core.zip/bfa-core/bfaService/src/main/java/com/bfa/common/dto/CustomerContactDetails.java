package com.bfa.common.dto;

import com.bfa.investment.dto.CustomerAddressDTO;

public class CustomerContactDetails {
	
	private CustomerAddressDTO homeAddress;
	private CustomerAddressDTO mailingAddress;
	private String differentMailingAddressReason;
	private Integer differentMailingAddressReasonId;
	public CustomerAddressDTO getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(CustomerAddressDTO homeAddress) {
		this.homeAddress = homeAddress;
	}
	public CustomerAddressDTO getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(CustomerAddressDTO mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public String getDifferentMailingAddressReason() {
		return differentMailingAddressReason;
	}
	public void setDifferentMailingAddressReason(String differentMailingAddressReason) {
		this.differentMailingAddressReason = differentMailingAddressReason;
	}
	public Integer getDifferentMailingAddressReasonId() {
		return differentMailingAddressReasonId;
	}
	public void setDifferentMailingAddressReasonId(Integer differentMailingAddressReasonId) {
		this.differentMailingAddressReasonId = differentMailingAddressReasonId;
	}
	
	
	

}

/**
 * 
 */
package com.bfa.application.core;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.util.APIConstants;
import com.bfa.util.ServiceNames;

/**
 * @author pradheep.p
 *
 */
public class UpdateEnquiryIdInWills extends DiscoveryHelper implements Runnable {

	private Integer customerId;
	
	private Integer enquiryId;
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	private SecurityConstants securityConstants;
	
	@Autowired
	private Environment environment;
	
	
	private Logger getLogger(){
		return this.applicationLoggerBean.getLogBean(this.getClass());		
	}
	
	@Override
	public void run() {	
		getLogger().info("Trying to update the enquiry id for Wills");		
		this.loadSecurityHeaderForCustomer(securityConstants.TOKEN_NAME,this.customerId);
		String baseUrl = getBaseUrl("wills-microservice");		
		baseUrl = removePortNumbers(baseUrl);
		baseUrl = baseUrl + APIConstants.UPDATE_ENQUIRY_IN_WILLS;
		getLogger().info("Printing the base URL :" + baseUrl);
		String requestBody = "{\"enquiryId\":" + this.enquiryId + "}";
		String jobName = "wills-update-customer-id";
		int delay = 0;
		addJobToQueue(baseUrl, requestBody, jobName, delay);
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

}

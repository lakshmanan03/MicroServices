package com.bfa.application.core;
/**
 * 
 * @author weihao
 *
 */
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.bfa.application.core.CustomerPreference;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"customer_id",
"srs_pop_status"
})
public class CustomerSrsPopStatus {
	
	@JsonProperty("customer_id")
	private Integer customerId;
	
	@JsonProperty("srs_pop_status")
	private Boolean srsPopStatus;

	public CustomerSrsPopStatus() {}
	
	public CustomerSrsPopStatus(CustomerPreference preference) {
		customerId = preference.getCustomerId();
		//srsPopStatus = preference.getSrsPopStatus();
	}
	/**
	 * @return the customer_id
	 */
	@JsonProperty("customer_id")
	public Integer getCustomerId() {
		return customerId;
	}

	/**
	 * @param customer_id the customer_id to set
	 */
	@JsonProperty("customer_id")
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the srs_pop_status
	 */
	@JsonProperty("srs_pop_status")
	public Boolean getSrsPopStatus() {
		return srsPopStatus;
	}
	
	/**
	 * @param srs_pop_status the srs_pop_status to set
	 */
	@JsonProperty("srs_pop_status")
	public void setSrs_pop_status(Boolean srsPopStatus) {
		this.srsPopStatus = srsPopStatus;
	}

}

package com.bfa.admin.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class AdvisorCommentsRequestDTO {

	private Integer id;
	private String customerId;
	private Integer advisorId;
	private String advisorName;
	private String advisorComments;
	private Boolean isAddDeleteComments;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public Integer getAdvisorId() {
		return advisorId;
	}
	public void setAdvisorId(Integer advisorId) {
		this.advisorId = advisorId;
	}
	
	public String getAdvisorName() {
		return advisorName;
	}
	public void setAdvisorName(String advisorName) {
		this.advisorName = advisorName;
	}
	public String getAdvisorComments() {
		return advisorComments;
	}
	public void setAdvisorComments(String advisorComments) {
		this.advisorComments = advisorComments;
	}
	
	public Boolean getIsAddDeleteComments() {
		return isAddDeleteComments;
	}
	public void setIsAddDeleteComments(Boolean isAddDeleteComments) {
		this.isAddDeleteComments = isAddDeleteComments;
	}
	
}

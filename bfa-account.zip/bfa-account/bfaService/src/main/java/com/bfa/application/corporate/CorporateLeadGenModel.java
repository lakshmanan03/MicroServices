/**
 * 
 */
package com.bfa.application.corporate;

/**
 * @author pradheep
 *
 */
public class CorporateLeadGenModel {	
	
	private String email_address;	
	
	private String email_type;
	
	private String ip_signup;
	
	private CoporateLeadGenMergeFields merge_fields;	
	
	private String status;

	public String getEmail_address() {
		return email_address;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public String getEmail_type() {
		return email_type;
	}

	public void setEmail_type(String email_type) {
		this.email_type = email_type;
	}

	public String getIp_signup() {
		return ip_signup;
	}

	public void setIp_signup(String ip_signup) {
		this.ip_signup = ip_signup;
	}

	public CoporateLeadGenMergeFields getMerge_fields() {
		return merge_fields;
	}

	public void setMerge_fields(CoporateLeadGenMergeFields merge_fields) {
		this.merge_fields = merge_fields;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}

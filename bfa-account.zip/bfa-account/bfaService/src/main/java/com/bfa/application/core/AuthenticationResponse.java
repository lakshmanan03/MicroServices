/**
 * 
 */
package com.bfa.application.core;

import com.bfa.util.ResponseMessage;

/**
 * @author pradheep.p
 *
 */
public class AuthenticationResponse extends ResponseMessage{
	
	private String securityToken;

	public String getSecurityToken() {
		return securityToken;
	}

	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}
}

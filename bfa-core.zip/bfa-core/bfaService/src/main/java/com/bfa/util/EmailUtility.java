/**
 * 
 */
package com.bfa.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

/**
 * @author pradheep.p
 *
 */
public class EmailUtility {
	
	@Autowired
	private Environment environment;
	
	

}

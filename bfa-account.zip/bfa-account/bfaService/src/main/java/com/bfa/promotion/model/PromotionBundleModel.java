/**
 * 
 */
package com.bfa.promotion.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bfa.application.core.MailChimpModel;

/**
 * This is the model class introduced for BFA-1565 (Promotion bundle- Adult / Child)
 * 
 * Javax validations included.
 * 
 * @see
 * https://ntuclink.atlassian.net/browse/BFA-1565
 *
 * @author pradheep
 *
 */
public class PromotionBundleModel extends MailChimpModel {

	@NotNull(message = "First name cannot be null")
	@NotBlank(message = "First name cannot be ")
	private String firstName;

	@NotNull(message = "Last name cannot be null")
	@NotBlank(message = "Last name cannot be blank")
	private String lastName;

	@NotNull(message ="Email cannot be null")
	@NotBlank(message = "Email cannot be blank")
	@Email(message="Email should be valid")
	private String emailAddress;

	@NotNull(message = "Contact number cannot be null")
	@NotBlank(message = "Contact number cannot be blank")
	private String contactNumber;

	@NotNull(message = "Date of birth cannot be null")
	@NotBlank(message = "Date of birth cannot be blank")
	private String dateOfBirth;

	@NotNull(message = "Gender cannot be null")
	@NotBlank(message = "Gender cannot be blank")
	private String gender;	

	@NotNull(message = "receive marketing email field cannot be null")
	@NotBlank(message = "receive marketing email field cannot be blank")
	private String receiveMarketingEmails;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getReceiveMarketingEmails() {
		return receiveMarketingEmails;
	}

	public void setReceiveMarketingEmails(String receiveMarketingEmails) {
		this.receiveMarketingEmails = receiveMarketingEmails;
	}	

	public String toString() {
		return "Promotion Bundle " + getEnquiryType() + " ,First Name:" + getFirstName() + " ,Last Name:"
				+ getLastName() + " ,Gender:" + getGender() + " ,Email:" + getEmailAddress() + " ,Contact Number "
				+ getContactNumber() + " ,Accept Marketing Notifications :" + getReceiveMarketingEmails();
	}
}

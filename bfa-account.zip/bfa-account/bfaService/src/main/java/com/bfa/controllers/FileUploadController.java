package com.bfa.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Produces;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.service.CustomerDocumentDetailService;
import com.bfa.util.AmazonS3ClientService;
import com.bfa.util.ResponseMessageList;
import com.google.gson.Gson;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@CrossOrigin(origins = "*")
@RestController
public class FileUploadController {
	
    @Autowired
    AmazonS3ClientService amazonS3ClientService;
    
    @Autowired
    CustomerDocumentDetailService customerService;
    
	@Autowired
	private ApplicationLoggerBean logBean;
	
	private Logger getLog() {
		return this.logBean.getLogBean(this.getClass());
	}


    @PostMapping("/uploadFile")
	@Produces({ "application/xml", "application/json" })
	@ApiOperation(value = "Upload file to S3",notes="Upload file to S3",response = ResponseMessageList.class)
	@ApiResponses(value = { @ApiResponse(code = 5000, message = "Internal server error"),
	@ApiResponse(code = 5001, message = "Database communication failure")})
    public List<String> uploadFile(@RequestParam("customerId") int customerId, @RequestParam("status") String status, 
    		@RequestPart(name = "nricFront", required = false) MultipartFile nricFrontFile, @RequestPart(name = "nricBack", required = false) MultipartFile nricBackfile)
    {
    	List<String> fileList = new ArrayList<String>();
    	
    	return fileList;
    }
    
    @PostMapping("/uploadDocuments")
	@Produces({ "application/xml", "application/json" })
	@ApiOperation(value = "Upload file to S3",notes="Upload file to S3",response = ResponseMessageList.class)
	@ApiResponses(value = { @ApiResponse(code = 5000, message = "Internal server error"),
	@ApiResponse(code = 5001, message = "Database communication failure")})
    public List<String> uploadDocuments(@RequestParam("customerId") int customerId, @RequestParam("status") String status, 
    		@RequestPart(name = "nricFront", required = false) MultipartFile nricFrontFile, 
    		@RequestPart(name = "nricBack", required = false) MultipartFile nricBackfile, 
    		@RequestParam(name = "form", required = true) String details)
    {
    	List<String> fileList = new ArrayList<>();
    	return fileList;
    }
    
    @PostMapping("/deleteFile")
	@Produces({ "application/xml", "application/json" })
	@ApiOperation(value = "Upload file to S3",notes="Upload file to S3",response = ResponseMessageList.class)
	@ApiResponses(value = { @ApiResponse(code = 5000, message = "Internal server error"),
	@ApiResponse(code = 5001, message = "Database communication failure")})
	public String deleteFile(@RequestParam("customerId") int customerId) {
    	getLog().info("inside delete customer document");
		String response = customerService.deleteCustomerDocument(customerId);;
		return response;
	}

}

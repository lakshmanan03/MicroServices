package com.bfa.investment.dto;

import java.util.Date;

public class TransactionDetailsDTO {

	private Double amount;
	private String transactionStatus;
	private Date createdDate;
	private Date expiryDate;
	private String transactionFrequency;
	private String transactionType;
	private String paymentMode;
	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}
	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}
	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	/**
	 * @return the transactionFrequency
	 */
	public String getTransactionFrequency() {
		return transactionFrequency;
	}
	/**
	 * @param transactionFrequency the transactionFrequency to set
	 */
	public void setTransactionFrequency(String transactionFrequency) {
		this.transactionFrequency = transactionFrequency;
	}
	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}
	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}
	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransactionDetailsDTO [amount=");
		builder.append(amount);
		builder.append(", transactionStatus=");
		builder.append(transactionStatus);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", expiryDate=");
		builder.append(expiryDate);
		builder.append(", transactionFrequency=");
		builder.append(transactionFrequency);
		builder.append(", transactionType=");
		builder.append(transactionType);
		builder.append(", paymentMode=");
		builder.append(paymentMode);
		builder.append("]");
		return builder.toString();
	}
	
	
}


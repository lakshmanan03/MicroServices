/**
 * 
 */
package com.bfa.insurance.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "product")
public class Product {

	@Id
	@GenericGenerator(name = "bfa", strategy = "increment")
	@GeneratedValue(generator = "bfa")
	@Column(name = "prod_id")
	public String id;

	@JsonIgnore
	@Column(name = "rider_id")
	public Integer riderId;

	@JsonIgnore
	@Column(name = "insurer_id")
	public String insurerId;

	@Column(name = "prod_name")
	public String productName;

	@JsonIgnore
	@Column(name = "purpose_id")
	public Integer purposeId;

	@JsonIgnore
	@Column(name = "objective_id")
	public Integer objectiveId;

	@JsonIgnore
	@Column(name = "type_id")
	public Integer typeId;

	@JsonIgnore
	@Column(name = "promo_id")
	public Integer promoId;

	@JsonIgnore
	@Column(name = "search_count")
	public Integer searchCount;

	@Column(name = "whybuy")
	public String whyBuy;

	@Column(name = "payout")
	public String payOut;

	@Column(name = "underwriting")
	public String underWritting;

	@Column(name = "rebate")
	public String rebate;

	@Column(name = "cash_value")
	public String cashValue;

	@Column(name = "cash_payout_frequency")
	public String cashPayoutFrequency;

	@Column(name = "coverage_duration")
	public String coverageDuration;

	@Column(name = "premium_duration")
	public String premiumDuration;

	@Column(name = "features")
	public String features;

	@Column(name = "prod_desc")
	public String productDescription;

	@Column(name = "status")
	public String status;
	// added new column with brochure link
	@Column(name = "brochure_link")
	public String brochureLink;
	
	@Column(name = "brochure_link_size")
	public String brochureLinkSize;

	@Column(name = "authorised")
	public boolean isAuthorised;

	@JsonIgnore
	@Column(name = "last_update")
	public Date lastUpdated;

	@JsonIgnore
	@Column(name = "last_updated_by")
	public String lastUpdatedBy;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getRiderId() {
		return riderId;
	}

	public void setRiderId(Integer riderId) {
		this.riderId = riderId;
	}

	public String getInsurerId() {
		return insurerId;
	}

	public void setInsurerId(String insurerId) {
		this.insurerId = insurerId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getPurposeId() {
		return purposeId;
	}

	public void setPurposeId(Integer purposeId) {
		this.purposeId = purposeId;
	}

	public Integer getObjectiveId() {
		return objectiveId;
	}

	public void setObjectiveId(Integer objectiveId) {
		this.objectiveId = objectiveId;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public Integer getPromoId() {
		return promoId;
	}

	public void setPromoId(Integer promoId) {
		this.promoId = promoId;
	}

	public Integer getSearchCount() {
		return searchCount;
	}

	public void setSearchCount(Integer searchCount) {
		this.searchCount = searchCount;
	}

	public String getWhyBuy() {
		return whyBuy;
	}

	public void setWhyBuy(String whyBuy) {
		this.whyBuy = whyBuy;
	}

	public String getPayOut() {
		return payOut;
	}

	public void setPayOut(String payOut) {
		this.payOut = payOut;
	}

	public String getUnderWritting() {
		return underWritting;
	}

	public void setUnderWritting(String underWritting) {
		this.underWritting = underWritting;
	}

	public String getRebate() {
		return rebate;
	}

	public void setRebate(String rebate) {
		this.rebate = rebate;
	}

	public String getCashValue() {
		return cashValue;
	}

	public void setCashValue(String cashValue) {
		this.cashValue = cashValue;
	}

	public String getCashPayoutFrequency() {
		return cashPayoutFrequency;
	}

	public void setCashPayoutFrequency(String cashPayoutFrequency) {
		this.cashPayoutFrequency = cashPayoutFrequency;
	}

	public String getCoverageDuration() {
		return coverageDuration;
	}

	public void setCoverageDuration(String coverageDuration) {
		this.coverageDuration = coverageDuration;
	}

	public String getPremiumDuration() {
		return premiumDuration;
	}

	public void setPremiumDuration(String premiumDuration) {
		this.premiumDuration = premiumDuration;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isAuthorised() {
		return isAuthorised;
	}

	public String getBrochureLink() {
		return brochureLink;
	}

	public void setBrochureLink(String brochureLink) {
		this.brochureLink = brochureLink;
	}

	public void setAuthorised(boolean isAuthorised) {
		this.isAuthorised = isAuthorised;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getBrochureLinkSize() {
		return brochureLinkSize;
	}

	public void setBrochureLinkSize(String brochureLinkSize) {
		this.brochureLinkSize = brochureLinkSize;
	}

}

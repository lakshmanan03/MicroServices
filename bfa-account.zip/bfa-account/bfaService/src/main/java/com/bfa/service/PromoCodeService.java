/**
 * 
 */
package com.bfa.service;

import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCodeRequest;

/**
 * @author kianann
 *
 */
public interface PromoCodeService {

	EnquiryResponseMessage getEnquiryReference(PromoCodeRequest promoCodeRequest);
	
	EnquiryResponseMessage getComprehensiveEnquiryReference(PromoCodeRequest promoCodeRequest);
}

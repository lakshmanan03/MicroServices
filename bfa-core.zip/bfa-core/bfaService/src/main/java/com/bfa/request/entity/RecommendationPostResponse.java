/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.product.ProductProtectionType;

/**
 * @author pradheep.p
 *
 */
public class RecommendationPostResponse {
	
	private int enquiryId;	
	
	private List<ProductProtectionType> productProtectionTypeList;
	
	//private String securityToken

	/**
	 * @return the enquiryId
	 */
	public int getEnquiryId() {
		return enquiryId;
	}

	/**
	 * @param enquiryId the enquiryId to set
	 */
	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public List<ProductProtectionType> getProductProtectionTypeList() {
		return productProtectionTypeList;
	}

	public void setProductProtectionTypeList(List<ProductProtectionType> productProtectionTypeList) {
		this.productProtectionTypeList = productProtectionTypeList;
	}	

}

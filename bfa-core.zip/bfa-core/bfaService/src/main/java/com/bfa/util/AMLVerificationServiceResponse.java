package com.bfa.util;

import java.util.Map;

public class AMLVerificationServiceResponse {
	private AMLVerificationStatus status;
	private Map<String,Object> additionalDetails;
	private String referenceKey;
	
	public AMLVerificationStatus getStatus() {
		return status;
	}
	public void setStatus(AMLVerificationStatus status) {
		this.status = status;
	}
	public Map<String, Object> getAdditionalDetails() {
		return additionalDetails;
	}
	public void setAdditionalDetails(Map<String, Object> additionalDetails) {
		this.additionalDetails = additionalDetails;
	}
	public String getReferenceKey() {
		return referenceKey;
	}
	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}
	
	
}

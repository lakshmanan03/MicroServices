/**
 * 
 */
package com.bfa.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bfa.application.core.AuthenticationResponse;
import com.bfa.application.core.BlacklistToken;
import com.bfa.application.core.CustomerIssuedToken;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.dao.SecurityDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessage;

/**
 * @author pradheep.p
 *
 */
public class DefaultServiceImpl {
	
	protected String delimiter = ApplicationConstants.DELIMITER;

	protected String appKey = "IMXYlDmP4f4=";

	protected PublicUtility utility = PublicUtility.getInstance(appKey);

	@Autowired
	protected ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	protected AccountsDao accountsDao;
	
	@Autowired
	private SecurityDao securityDao;
	
	@Autowired
	@Qualifier("securityConstants")
	protected SecurityConstants constants;


	public AuthenticationResponse getDefaultAuthenticationResponse() {
		AuthenticationResponse authenticationResponse = new AuthenticationResponse();
		authenticationResponse.setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
		authenticationResponse.setResponseDescription(ApplicationConstants.SUCCESSFUL_RESPONSE);
		authenticationResponse.setSecurityToken("");
		return authenticationResponse;
	}

	protected Logger getLogger() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}

	public SessionDetails getSessionDetails(HttpServletRequest request) {
		SessionDetails sessionDetails = new SessionDetails();
		String ipAddress = getIPAddress(request);
		getLogger().info("Printing the IP address : " + ipAddress);
		sessionDetails.setIpAddress(getIPAddress(request));
		sessionDetails.setLastUpdated(new Date());
		String browserDetails = getBrowserAndOSDetails(request);
		sessionDetails.setBrowser(browserDetails);
		return sessionDetails;
	}

	public String getIPAddress(HttpServletRequest requestObj) {
		String ipAddress = requestObj.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			ipAddress = requestObj.getRemoteAddr();
		}
		return ipAddress;
	}

	public Object getDefaultResponseMessage(Class obj) {
		ResponseMessage responseMessage = null;
		try {
			responseMessage = (ResponseMessage) obj.newInstance();
			responseMessage.setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
			responseMessage.setResponseDescription(ApplicationConstants.SUCCESSFUL_RESPONSE);
			return responseMessage;
		} catch (InstantiationException e) {
			getLogger().error("Error while initiation of object" + e.getMessage(), e);
		} catch (IllegalAccessException e) {
			getLogger().error("Illegal access exception - getDefaultResponseMessage :" + e.getMessage(), e);
		}
		return null;
	}

	public String getBrowserAndOSDetails(HttpServletRequest request) {
		String browserDetails = request.getHeader("User-Agent");
		if(browserDetails == null){
			browserDetails = "unknown";
		}
		String userAgent = browserDetails;
		String user = userAgent.toLowerCase();
		
		String os = "";
		String browser = "";

		// =================OS=======================
		if (userAgent.toLowerCase().indexOf("windows") >= 0) {
			os = "Windows";
		} else if (userAgent.toLowerCase().indexOf("mac") >= 0) {
			os = "Mac";
		} else if (userAgent.toLowerCase().indexOf("x11") >= 0) {
			os = "Unix";
		} else if (userAgent.toLowerCase().indexOf("android") >= 0) {
			os = "Android";
		} else if (userAgent.toLowerCase().indexOf("iphone") >= 0) {
			os = "IPhone";
		} else {
			os = "UnKnown, More-Info: " + userAgent;
		}
		// ===============Browser===========================
		if (user.contains("msie")) {
			String substring = userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
			browser = substring.split(" ")[0].replace("MSIE", "IE") + "-" + substring.split(" ")[1];
		} else if (user.contains("safari") && user.contains("version")) {
			browser = (userAgent.substring(userAgent.indexOf("Safari")).split(" ")[0]).split("/")[0] + "-"
					+ (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
		} else if (user.contains("opr") || user.contains("opera")) {
			if (user.contains("opera"))
				browser = (userAgent.substring(userAgent.indexOf("Opera")).split(" ")[0]).split("/")[0] + "-"
						+ (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
			else if (user.contains("opr"))
				browser = ((userAgent.substring(userAgent.indexOf("OPR")).split(" ")[0]).replace("/", "-"))
						.replace("OPR", "Opera");
		} else if (user.contains("chrome")) {
			browser = (userAgent.substring(userAgent.indexOf("Chrome")).split(" ")[0]).replace("/", "-");
		} else if ((user.indexOf("mozilla/7.0") > -1) || (user.indexOf("netscape6") != -1)
				|| (user.indexOf("mozilla/4.7") != -1) || (user.indexOf("mozilla/4.78") != -1)
				|| (user.indexOf("mozilla/4.08") != -1) || (user.indexOf("mozilla/3") != -1)) {
			browser = "Netscape-?";

		} else if (user.contains("firefox")) {
			browser = (userAgent.substring(userAgent.indexOf("Firefox")).split(" ")[0]).replace("/", "-");
		} else if (user.contains("rv")) {
			browser = "IE-" + user.substring(user.indexOf("rv") + 3, user.indexOf(")"));
		} else {
			browser = "UnKnown, More-Info: " + userAgent;
		}
		return os + "-" + browser;
	}
	
	protected Customer getCustomerByReference(String customerReference) {
		String customerId = decryptUserResponseData(customerReference);
		getLogger().info("Obtaining the customer based on id: " + customerId);
		Integer id = Integer.parseInt(customerId);
		return getCustomerById(id);
	}
	
	protected Customer getCustomerByReferenceV1(String customerReference) {
		String customerId = utility.DecryptText(customerReference);
		getLogger().info("Obtaining the customer based on id: " + customerId);
		Integer id = Integer.parseInt(customerId);
		return getCustomerById(id);
	}
	
	protected CustomerContactVerification getNewVerificationrByReference(String customerReference) {
		String customerId = decryptUserResponseData(customerReference);
		getLogger().info("Obtaining the customer based on id: " + customerId);
		Integer id = Integer.parseInt(customerId);
		return getCustomerFromVerification(id);
	}
	
	
	
	protected Customer getCustomerById(int id) {
		List<Object> customerList = accountsDao.getObjectsById(Customer.class, "id", id);
		if (customerList == null || customerList.isEmpty()) {
			getLogger().error("No such user found for customer id :" + id);
			return null;
		}
		return (Customer) customerList.get(0);
	}
	
	protected CustomerContactVerification getCustomerFromVerification(int id) {
		String actionType = new String(ApplicationConstants.CUSTOMER_UPDATE_TYPE);
		return securityDao.getCustomerContactVerificationByCustomerIdAndType(id,actionType);		
	}
	
	public String decryptUserResponseData(String toBeDecrypted) {		
		String arg = utility.DecryptText(toBeDecrypted);
		String[] values = arg.split(delimiter);
		getLogger().info(values[1]);
		return values[1];
	}
	
	public void blackList(String token,String reason){
		getLogger().info("Black listing the token :" + token);
		int timeToLiveInSeconds = SecurityConstants.timeToLive;
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		int ejectPeriod = timeToLiveInSeconds + 300;
		calendar.add(GregorianCalendar.SECOND, ejectPeriod);
		Date ejectTime = calendar.getTime();
		
		BlacklistToken blackListedToken = new BlacklistToken();
		blackListedToken.setReason(reason);
		blackListedToken.setEjectTime(ejectTime);
		blackListedToken.setTokenValue(token);
		accountsDao.saveOrUpdateObject(blackListedToken);	
	}
	
	protected CustomerIssuedToken getCustomerIssuedToken(int customerId) {
		List<Object> customerIssuedTokenList = accountsDao.getObjectsById(CustomerIssuedToken.class, "customerId", customerId);
		if (customerIssuedTokenList == null || customerIssuedTokenList.isEmpty()) {
			getLogger().error("No such user found for customer id :" + customerId);
			return null;
		}
		return (CustomerIssuedToken) customerIssuedTokenList.get(0);
	}
	
	public boolean validateEmailAddress(String emailAddress) {
		boolean valid = EmailValidator.getInstance().isValid(emailAddress);
		return valid;
	}
	
	public String appendDateToOTP(String otp) {
		Date dateObj = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		String arg = otp + delimiter + sdf.format(dateObj);
		return utility.EncryptText(arg);
	}
	
	public String[] getParsedOtp(String encryptedArg){
		String arg = utility.DecryptText(encryptedArg);
		String[] splitData = arg.split(this.delimiter);
		return splitData;
	}
}

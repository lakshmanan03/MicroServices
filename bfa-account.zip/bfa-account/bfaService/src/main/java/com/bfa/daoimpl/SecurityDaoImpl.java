/**
 * 
 */
package com.bfa.daoimpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.SecurityDao;

/**
 * @author pradheep
 *
 */
public class SecurityDaoImpl implements SecurityDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private ApplicationLoggerBean loggerBean;

	private Logger getLogger() {
		return loggerBean.getLogBean(this.getClass());
	}

	@Override
	public CustomerContactVerification getCustomerContactVerificationBySessionAndType(String sessionId,
			String actionType) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			String hql = "FROM CustomerContactVerification where sessionId =:sessionId and actionType =:actionType";
			Query query = session.createQuery(hql);
			query.setParameter("sessionId", sessionId);
			query.setParameter("actionType", actionType);
			List<CustomerContactVerification> customerContactVerificationList = query.list();
			if (null != customerContactVerificationList && !customerContactVerificationList.isEmpty()) {
				return customerContactVerificationList.get(0);
			}
		} catch (Exception err) {
			getLogger().error("Error while obtaining the customer contact verification", err);
		} finally {
			if (null != session) {
				session.clear();
				session.close();
			}
		}
		return null;
	}

	@Override
	public CustomerContactVerification updateCustomerContactVerification(
			CustomerContactVerification customerContactVerification) {
		Session sessionObj = null;
		try {
			sessionObj = sessionFactory.openSession();
			Transaction transaction = sessionObj.beginTransaction();
			sessionObj.saveOrUpdate(customerContactVerification);
			transaction.commit();
			getLogger().info(
					"Updated the customer contact verification details [id]:" + customerContactVerification.getId());
		} catch (Exception err) {
			getLogger().error("Error while updating the customer contact verification details", err);
		} finally {
			if (null != sessionObj) {
				sessionObj.clear();
				sessionObj.close();
			}
		}
		return customerContactVerification;
	}

	@Override
	public CustomerContactVerification getCustomerContactVerificationByCustomerIdAndType(Integer customerId,
			String actionType) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			String hql = "FROM CustomerContactVerification where customer_id =:customerId and actionType =:actionType";
			Query query = session.createQuery(hql);
			query.setParameter("customerId", customerId);
			query.setParameter("actionType", actionType);
			List<CustomerContactVerification> customerContactVerificationList = query.list();
			if (null != customerContactVerificationList && !customerContactVerificationList.isEmpty()) {
				return customerContactVerificationList.get(0);
			}
		} catch (Exception err) {
			getLogger().error("Error while obtaining the customer contact verification", err);
		} finally {
			if (null != session) {
				session.clear();
				session.close();
			}
		}
		return null;
	}

}

/**
 * 
 */
package com.bfa.insurance;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.bfa.configuration.ApplicationLoggerBean;

/**
 * @author pradheep.p
 *
 */
@RunWith(SpringRunner.class)
public class AccountsServiceSecurityTest {
	

	@Mock
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Mock
	private Logger mLogger;

	@Test
	public void sampleTestAccountService() {
		mLogger.info("Testing sample test account service");
	}

	public static void main(String[] args) {

	}

}

package com.bfa.investment.account.dto;

import java.util.List;

import com.bfa.common.dto.AddressDTO;
import com.bfa.common.dto.CustomerTaxDetailsDTO;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.HouseholdDTO;
import com.bfa.investment.dto.FinancialDetailsDTO;
import com.bfa.investment.dto.PersonalDeclarationDTO;
import com.fasterxml.jackson.annotation.JsonProperty;


public class CustomerDetailsDTO {
	
	public static class AccountVerificationMode {
		private AccountVerificationMode(){
			// created constructor
		}
		public static final String MY_INFO = "MY-INFO";
		public static final String PASSPORT = "PASSPORT";
	}
	
	@JsonProperty(value = "isSingaporePR")
	private Boolean singaporePR;
	
	private Boolean myInfoVerified;
	private PersonalDetailsDTO personalInfo;
	private AddressDTO residentialAddress;
	private AddressDTO mailingAddress;
	private EmploymentDetailsDTO employmentDetails;
	private HouseholdDTO householdDetails;
	private FinancialDetailsDTO financialDetails;
	private List<CustomerTaxDetailsDTO> taxDetails;
	private PersonalDeclarationDTO personalDeclarations;
	private Boolean sameAsMailingAddress;
	
	

	public Boolean getSingaporePR() {
		return singaporePR;
	}
	
	@JsonProperty(value = "isSingaporePR")
	public void setSingaporePR(Boolean singaporePR) {
		this.singaporePR = singaporePR;
	}
	public Boolean getMyInfoVerified() {
		return myInfoVerified;
	}

	public Boolean isMyInfoVerified() {
		return myInfoVerified;
	}
	public void setMyInfoVerified(Boolean myInfoVerified) {
		this.myInfoVerified = myInfoVerified;
	}
	public PersonalDeclarationDTO getPersonalDeclarations() {
		return personalDeclarations;
	}
	public void setPersonalDeclarations(PersonalDeclarationDTO personalDeclarations) {
		this.personalDeclarations = personalDeclarations;
	}

	

	public FinancialDetailsDTO getFinancialDetails() {
		return financialDetails;
	}
	public void setFinancialDetails(FinancialDetailsDTO financialDetails) {
		this.financialDetails = financialDetails;
	}
	public HouseholdDTO getHouseholdDetails() {
		return householdDetails;
	}
	public void setHouseholdDetails(HouseholdDTO householdDetails) {
		this.householdDetails = householdDetails;
	}
	public AddressDTO getResidentialAddress() {
		return residentialAddress;
	}
	public void setResidentialAddress(AddressDTO residentialAddress) {
		this.residentialAddress = residentialAddress;
	}
	public AddressDTO getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(AddressDTO mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public PersonalDetailsDTO getPersonalInfo() {
		return personalInfo;
	}
	public void setPersonalInfo(PersonalDetailsDTO personalInfo) {
		this.personalInfo = personalInfo;
	}
	public EmploymentDetailsDTO getEmploymentDetails() {
		return employmentDetails;
	}
	public void setEmploymentDetails(EmploymentDetailsDTO employmentDetails) {
		this.employmentDetails = employmentDetails;
	}
	
	public Boolean getSameAsMailingAddress() {
		return sameAsMailingAddress;
	}

	public void setSameAsMailingAddress(Boolean sameAsMailingAddress) {
		this.sameAsMailingAddress = sameAsMailingAddress;
	}

	public List<CustomerTaxDetailsDTO> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(List<CustomerTaxDetailsDTO> taxDetails) {
		this.taxDetails = taxDetails;
	}

	
	
	
}


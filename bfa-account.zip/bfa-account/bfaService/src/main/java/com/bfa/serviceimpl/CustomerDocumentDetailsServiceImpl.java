package com.bfa.serviceimpl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.CustomerDocumentDAO;
import com.bfa.insurance.core.Customer;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.DocumentStatusMaster;
import com.bfa.investment.entity.DocumentStatusMaster.DocumentStatusTypes;
import com.bfa.service.CustomerDocumentDetailService;
import com.bfa.util.AmazonS3ClientService;
import com.bfa.util.PublicUtility;

@Service
public class CustomerDocumentDetailsServiceImpl implements CustomerDocumentDetailService{
	
	@Autowired
	private CustomerDocumentDAO customerDocDao;
	
	@Autowired
	private AmazonS3ClientService amazonS3Client;
	
	@Autowired
	ApplicationLoggerBean applicationLoggerBean;
	
	protected Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@Override
	public List<CustomerDocumentDetails> getAllDetails() {
		return customerDocDao.getAllDetails();
	}

	
	public void saveOrUpdateCustomerDocument(int customerId, String filePath, String docType) {
		getLogger().info("Reached saveOrUpdateCustomerDocument");
		try {
			CustomerDocumentDetails customerDocumentDetails = customerDocDao.getCustomerDocument(customerId, docType);
			if (customerDocumentDetails == null) {
				getLogger().info("creating new customerDocumentDetails object ");
				customerDocumentDetails = new CustomerDocumentDetails();
				customerDocumentDetails.setCreatedDate(PublicUtility.getCurrentUTC());
			}
			customerDocumentDetails.setLastUpdatedTimeStamp(PublicUtility.getCurrentUTC());
			Customer customer = new Customer();
			customer.setId(customerId);
			customerDocumentDetails.setCustomer(customer);
			customerDocumentDetails.setFileName(filePath);
			customerDocumentDetails.setDocType(docType);
			DocumentStatusMaster docStatus = customerDocDao.getDocumentStatus(DocumentStatusTypes.TO_BE_REVIEWED);
			customerDocumentDetails.setDocumentStatus(docStatus);
			customerDocumentDetails.setLastUpdatedTimeStamp(new Date());
			customerDocumentDetails.setReviewComments("Success");
			getLogger().info("customerDocumentDetails Id"+customerDocumentDetails.getId());
			customerDocDao.saveCustomerDocument(customerDocumentDetails);
		}catch(Exception e) {
			deleteCustomerDocument(filePath);
			getLogger().debug("exception caught in saveOrUpdateCustomerDocument"+e);
			getLogger().debug("exception message caught in saveOrUpdateCustomerDocument"+e.getMessage());
			throw e;
		}
	}
	
	public void saveCustomerDocument(int customerId, String filePath, CustomerDocumentDetails customerDocumentDetails, String status) {
		try {
			customerDocumentDetails.setCreatedDate(new Date());
			Customer customer = new Customer();
			customer.setId(customerId);
			customerDocumentDetails.setCustomer(customer);
			customerDocumentDetails.setFileName(filePath);
			customerDocumentDetails.setLastUpdatedTimeStamp(new Date());
			customerDocumentDetails.setReviewComments("Success");
			customerDocDao.saveCustomerDocument(customerDocumentDetails, status);
		}catch(Exception e) {
			e.getMessage();
			deleteCustomerDocument(filePath);
		}
	}

	@Override
	public String deleteCustomerDocument(int customerId) {
		String awsFileName = customerDocDao.getAwsFileName(customerId);
		getLogger().info("awsFileNameawsFileNameawsFileName" + awsFileName);
		amazonS3Client.deleteFileFromS3Bucket(awsFileName);
		return "awsFileName";
	}

	@Override
	public String deleteCustomerDocument(String awsFilePath) {
		return amazonS3Client.deleteFileFromS3Bucket(awsFilePath);
	}	
}

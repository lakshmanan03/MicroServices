/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "comprehensive_insurance_planning")
public class ComprehensiveInsurancePlanning {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "have_hospital_plan")
	private Boolean haveHospitalPlan;
	
	@Column(name="have_cpf_dependents_protection_scheme")
	private Integer haveCPFDependentsProtectionScheme;
	
	@Column(name="life_protection_amount")
	private Double life_protection_amount;
	
	@Column(name="is_default_life_protection_amount")
	private Boolean isDefaultLifeProtectionAmount;
	
	@Column(name="have_home_protection_scheme")
	private Integer have_HDB_Home_Protection_Scheme;
	
	@Column(name="home_protection_amount")
	private Double homeProtectionCoverageAmount;

	@Column(name="other_life_protection_amount")
	private Double other_life_protection_amount;
	
	@Column(name="critical_illness_coverage_amount")
	private Double criticalIllnessCoverageAmount;
	
	@Column(name="disability_income_coverage_amount")
	private Double disabilityIncomeCoverageAmount;
	
	@Column(name="have_long_term_elder_shield")
	private Integer haveLongTermElderShield;
	
	@Column(name="long_term_elder_shield_amount")
	private Integer longTermElderShieldAmount;
	
	@Column(name = "hospital_plan_with_rider")
	private Integer haveHospitalPlanWithRider;
	
	@Column(name="other_ltc_insurance_amt")
	private Double otherLongTermCareInsuranceAmount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Boolean getHaveHospitalPlan() {
		return haveHospitalPlan;
	}

	public void setHaveHospitalPlan(Boolean haveHospitalPlan) {
		this.haveHospitalPlan = haveHospitalPlan;
	}

	public Double getLife_protection_amount() {
		return life_protection_amount;
	}

	public void setLife_protection_amount(Double life_protection_amount) {
		this.life_protection_amount = life_protection_amount;
	}

	public Double getOther_life_protection_amount() {
		return other_life_protection_amount;
	}

	public void setOther_life_protection_amount(Double other_life_protection_amount) {
		this.other_life_protection_amount = other_life_protection_amount;
	}

	public Double getCriticalIllnessCoverageAmount() {
		return criticalIllnessCoverageAmount;
	}

	public void setCriticalIllnessCoverageAmount(Double criticalIllnessCoverageAmount) {
		this.criticalIllnessCoverageAmount = criticalIllnessCoverageAmount;
	}

	public Double getDisabilityIncomeCoverageAmount() {
		return disabilityIncomeCoverageAmount;
	}

	public void setDisabilityIncomeCoverageAmount(Double disabilityIncomeCoverageAmount) {
		this.disabilityIncomeCoverageAmount = disabilityIncomeCoverageAmount;
	}

	public Integer getHaveCPFDependentsProtectionScheme() {
		return haveCPFDependentsProtectionScheme;
	}

	public void setHaveCPFDependentsProtectionScheme(Integer haveCPFDependentsProtectionScheme) {
		this.haveCPFDependentsProtectionScheme = haveCPFDependentsProtectionScheme;
	}

	public Integer getHave_HDB_Home_Protection_Scheme() {
		return have_HDB_Home_Protection_Scheme;
	}

	public void setHave_HDB_Home_Protection_Scheme(Integer have_HDB_Home_Protection_Scheme) {
		this.have_HDB_Home_Protection_Scheme = have_HDB_Home_Protection_Scheme;
	}

	public Double getHomeProtectionCoverageAmount() {
		return homeProtectionCoverageAmount;
	}

	public void setHomeProtectionCoverageAmount(Double homeProtectionCoverageAmount) {
		this.homeProtectionCoverageAmount = homeProtectionCoverageAmount;
	}

	public Integer getHaveLongTermElderShield() {
		return haveLongTermElderShield;
	}

	public void setHaveLongTermElderShield(Integer haveLongTermElderShield) {
		this.haveLongTermElderShield = haveLongTermElderShield;
	}

	public Integer getLongTermElderShieldAmount() {
		return longTermElderShieldAmount;
	}

	public void setLongTermElderShieldAmount(Integer longTermElderShieldAmount) {
		this.longTermElderShieldAmount = longTermElderShieldAmount;
	}

	public Boolean getIsDefaultLifeProtectionAmount() {
		return isDefaultLifeProtectionAmount;
	}

	public void setIsDefaultLifeProtectionAmount(Boolean isDefaultLifeProtectionAmount) {
		this.isDefaultLifeProtectionAmount = isDefaultLifeProtectionAmount;
	}

	public Integer getHaveHospitalPlanWithRider() {
		return haveHospitalPlanWithRider;
	}

	public void setHaveHospitalPlanWithRider(Integer haveHospitalPlanWithRider) {
		this.haveHospitalPlanWithRider = haveHospitalPlanWithRider;
	}

	public Double getOtherLongTermCareInsuranceAmount() {
		return otherLongTermCareInsuranceAmount;
	}

	public void setOtherLongTermCareInsuranceAmount(Double otherLongTermCareInsuranceAmount) {
		this.otherLongTermCareInsuranceAmount = otherLongTermCareInsuranceAmount;
	}

	


}

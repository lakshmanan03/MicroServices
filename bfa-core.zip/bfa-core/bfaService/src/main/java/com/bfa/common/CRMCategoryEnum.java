/**
 * 
 */
package com.bfa.common;

import java.io.Serializable;

/**
 * BFA-1729
 * 
 * Used by CRM Microservice to decide the category of the lead.
 * 
 * @author pradheep
 * @since Release 3.0
 *
 */
public enum CRMCategoryEnum implements Serializable{
	
	Protection ("Protection"),
	Savings ("Savings"),
	Retirement_Income ("Retirement Income"),
	Comprehensive("Comprehensive"),
	Comprehensive_Lite("Comprehensive Lite"),
	Baby_Bundle("Baby Bundle"),
	Young_Working_Adult_Bundle("Young Working Adult Bundle"),
	Retirement_Bundle("Retirement Bundle");
	
	private String value;
	
	private CRMCategoryEnum(String value){
		this.value = value;
	}
	
	public String getValue(){
		return this.value;
	}

}

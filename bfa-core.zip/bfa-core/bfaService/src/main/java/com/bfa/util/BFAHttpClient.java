/**
 * 
 */
package com.bfa.util;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;

import brave.Tracing;
import brave.httpclient.TracingHttpClientBuilder;

/**
 * @author pradheep.p
 *
 */
public class BFAHttpClient {
//	private Tracing tracing = Tracing.newBuilder().build();
	
	private CloseableHttpClient httpclient = createAcceptSelfSignedCertificateClient(); 
//	private CloseableHttpClient httpclient = createAcceptSelfSignedCertificateClient(); // HttpClients.createDefault()
	
	public RequestConfig getRequestConfig(int TIMEOUT_MILLIS) {
		return RequestConfig.custom().setSocketTimeout(TIMEOUT_MILLIS)
				.setConnectTimeout(TIMEOUT_MILLIS).setConnectionRequestTimeout(TIMEOUT_MILLIS).build();
	}
	
//	public BFAHttpClient(Tracing tracing) {
//		this.httpclient = TracingHttpClientBuilder.create(tracing).build();
//	}
	
//	public void setTracing(Tracing tracing) {
//		try {
//			httpclient.close();
//			this.tracing = tracing; 
//			httpclient = TracingHttpClientBuilder.create(tracing).build();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	private static CloseableHttpClient createAcceptSelfSignedCertificateClient() {
		Tracing tracing = Tracing.newBuilder().build();
		try {
			SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(null, new TrustStrategy() {
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			}).build();

			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, null, null,
					new NoopHostnameVerifier());
			return TracingHttpClientBuilder.create(tracing).setSSLSocketFactory(sslsf).build();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return TracingHttpClientBuilder.create(tracing).build();

	}

	public void trustEveryone() {
		try {
			HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			});
			SSLContext context = SSLContext.getInstance("TLS");
			context.init(null, new X509TrustManager[] { new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					// checkClientTrusted
				}

				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					// checkServerTrusted
				}

				public X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}
			} }, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public BFAHttpResponse doFormPost(String URL, Map<String, String> headers, Map<String, Object> fields,
			List<BFAHTTPFile> files) throws IOException {

		BFAHttpResponse bfaResponse = new BFAHttpResponse();

		try {
			MultipartUtility multipartUtility = new MultipartUtility(URL, "UTF-8");
			multipartUtility.initializeWithHeaders(headers);
			// Add form fields
			if (fields != null) {
				for (String field : fields.keySet()) {
					if (fields.get(field) instanceof String) {
						multipartUtility.addFormField(field, fields.get(field).toString());
					} else {
						Gson gson = new Gson();
						multipartUtility.addJSONFormField(field, gson.toJson(fields.get(field)));
					}
				}
			}

			// Add files
			if (files != null) {
				for (BFAHTTPFile file : files) {
					multipartUtility.addFilePart(file.getFileKey(), file.getStream(), file.getFileName());				
				}
			}
			
			String response = multipartUtility.finish();
			if (response != null) {			
				bfaResponse.setResponseBody(response);
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}

		return bfaResponse;
	}

	public BFAHttpResponse doPostCall(String requestBody, String URL, Map<String, String> header,
			Map<String, String> cookies) {
		if (!isSensitiveUrl(URL)) {
			System.out.println("[doPostCall] Making a POST request : " + URL);
		}
		BFAHttpResponse bfaHttpResponse = new BFAHttpResponse();
		HttpPost httpPost = new HttpPost(URL);
		httpPost.setConfig(getRequestConfig(30000));
		
		httpPost.addHeader("Content-Type", "application/json");
		header.keySet().forEach(X -> httpPost.addHeader(X, header.get(X)));
		StringEntity postingString = null;
		try {
			postingString = new StringEntity(requestBody);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		httpPost.setEntity(postingString);
		CloseableHttpResponse responseObj = null;
		try {
			responseObj = httpclient.execute(httpPost);
			HttpEntity entity = responseObj.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			bfaHttpResponse.setAllHeaders(responseObj.getAllHeaders());
			bfaHttpResponse.setResponseBody(responseString);
			bfaHttpResponse.setResponseCode(responseObj.getStatusLine().getStatusCode());
			return bfaHttpResponse;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (Exception err) {
			err.printStackTrace();
			return null;
		} finally {
			try {
				if (responseObj != null) {
					responseObj.close();
					responseObj = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public BFAHttpResponse doPostCallBufferedReader(String requestBody, String URL, HashMap<String, String> header,
			HashMap<String, String> cookies) {
		if (!isSensitiveUrl(URL)) {
			System.out.println("[doPostCallBufferedReader] Making a POST request : " + URL);
		}
		BFAHttpResponse bfaHttpResponse = new BFAHttpResponse();
		HttpPost httpPost = new HttpPost(URL);
		httpPost.setConfig(getRequestConfig(30000));
		httpPost.addHeader("Content-Type", "application/json");
		header.keySet().forEach(X -> httpPost.addHeader(X, header.get(X)));
		StringEntity postingString = null;
		try {
			postingString = new StringEntity(requestBody);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		httpPost.setEntity(postingString);
		CloseableHttpResponse responseObj = null;
		try {
			responseObj = httpclient.execute(httpPost);
			HttpEntity entity = responseObj.getEntity();
			InputStream is = entity.getContent();
			DataInputStream dis = new DataInputStream(is);
			// Only stream the first 200 bytes
			System.out.println("-------------------------Buffered Read---------------------------");
			for (int i = 0; i < 400; i++) {
				System.out.print(((char) dis.readByte()));
			}

			String responseString = EntityUtils.toString(entity, "UTF-8");
			bfaHttpResponse.setAllHeaders(responseObj.getAllHeaders());
			bfaHttpResponse.setResponseBody(responseString);
			bfaHttpResponse.setResponseCode(responseObj.getStatusLine().getStatusCode());
			return bfaHttpResponse;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (Exception err) {
			err.printStackTrace();
			return null;
		} finally {
			try {
				if (responseObj != null) {
					responseObj.close();
				}
				responseObj = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public BFAHttpResponse doGetCall(String URL, Map<String, String> header, Map<String, String> cookies) {
		if (!isSensitiveUrl(URL)) {
			System.out.println("[doGetCall] Making a GET request : " + URL);
		}
		BFAHttpResponse bfaHttpResponse = new BFAHttpResponse();
		HttpGet httpGet = new HttpGet(URL);
		httpGet.setConfig(getRequestConfig(30000));
		httpGet.addHeader("Content-Type", "application/json");
		header.keySet().forEach(X -> httpGet.addHeader(X, header.get(X)));
		CloseableHttpResponse responseObj = null;
		try {
			responseObj = httpclient.execute(httpGet);
			HttpEntity entity = responseObj.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			bfaHttpResponse.setAllHeaders(responseObj.getAllHeaders());
			bfaHttpResponse.setResponseBody(responseString);
			bfaHttpResponse.setResponseCode(responseObj.getStatusLine().getStatusCode());
			return bfaHttpResponse;
		} catch (IOException e) {
			e.printStackTrace();
			bfaHttpResponse.setException(e);
			return bfaHttpResponse;
		} catch (Exception err) {
			err.printStackTrace();
			return null;
		} finally {
			try {
				if (responseObj != null) {
					responseObj.close();
					responseObj = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	
	public BFAHttpResponse doPutCall(String URL, Map<String, String> header, Map<String, String> cookies) {
		if (!isSensitiveUrl(URL)) {
			System.out.println("[doPutCall] Making a PUT request : " + URL);
		}
		BFAHttpResponse bfaHttpResponse = new BFAHttpResponse();
		HttpPut httpPut = new HttpPut(URL);
		httpPut.setConfig(getRequestConfig(60000));
		httpPut.addHeader("Content-Type", "application/json");
		header.keySet().forEach(X -> httpPut.addHeader(X, header.get(X)));
		CloseableHttpResponse responseObj = null;
		try {
			responseObj = httpclient.execute(httpPut);
			HttpEntity entity = responseObj.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			bfaHttpResponse.setAllHeaders(responseObj.getAllHeaders());
			bfaHttpResponse.setResponseBody(responseString);
			bfaHttpResponse.setResponseCode(responseObj.getStatusLine().getStatusCode());
			return bfaHttpResponse;
		} catch (IOException e) {
			e.printStackTrace();
			bfaHttpResponse.setException(e);
			return bfaHttpResponse;
		} catch (Exception err) {
			err.printStackTrace();
			return null;
		} finally {
			try {
				if (responseObj != null) {
					responseObj.close();
					responseObj = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	
	public BFAHttpResponse doGetCallWithoutSNI(String URL, HashMap<String, String> header,
			HashMap<String, String> cookies) {
		if (!isSensitiveUrl(URL)) {
			System.out.println("[doGetCallWithoutSNI] Making a GET request : " + URL);
		}
		System.setProperty("jsse.enableSNIExtension", "false");
		BFAHttpResponse bfaHttpResponse = new BFAHttpResponse();
		HttpGet httpGet = new HttpGet(URL);
		httpGet.setConfig(getRequestConfig(30000));
		httpGet.addHeader("Content-Type", "application/json");
		header.keySet().forEach(X -> httpGet.addHeader(X, header.get(X)));
		CloseableHttpResponse responseObj = null;
		try {
			responseObj = httpclient.execute(httpGet);
			HttpEntity entity = responseObj.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			bfaHttpResponse.setAllHeaders(responseObj.getAllHeaders());
			bfaHttpResponse.setResponseBody(responseString);
			bfaHttpResponse.setResponseCode(responseObj.getStatusLine().getStatusCode());
			return bfaHttpResponse;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (Exception err) {
			err.printStackTrace();
			return null;
		} finally {
			System.setProperty("jsse.enableSNIExtension", "true");
			try {
				if (responseObj != null) {
					responseObj.close();
					responseObj = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public BFAHttpResponse doPostCallWithoutSNI(String requestBody, String URL, Map<String, String> header,
			Map<String, String> cookies) {
		if (!isSensitiveUrl(URL)) {
			System.out.println("[doPostCallWithoutSNI] Making a POST request : " + URL);
		}
		System.setProperty("jsse.enableSNIExtension", "false");
		BFAHttpResponse bfaHttpResponse = new BFAHttpResponse();
		HttpPost httpPost = new HttpPost(URL);
		httpPost.setConfig(getRequestConfig(30000));

		httpPost.addHeader("Content-Type", "application/json");
		header.keySet().forEach(X -> httpPost.addHeader(X, header.get(X)));
		StringEntity postingString = null;
		try {
			postingString = new StringEntity(requestBody);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		httpPost.setEntity(postingString);
		CloseableHttpResponse responseObj = null;
		try {
			responseObj = httpclient.execute(httpPost);
			HttpEntity entity = responseObj.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			bfaHttpResponse.setAllHeaders(responseObj.getAllHeaders());
			bfaHttpResponse.setResponseBody(responseString);
			bfaHttpResponse.setResponseCode(responseObj.getStatusLine().getStatusCode());
			return bfaHttpResponse;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (Exception err) {
			err.printStackTrace();
			return null;
		} finally {
			System.setProperty("jsse.enableSNIExtension", "true");
			try {
				if (responseObj != null) {
					responseObj.close();
					responseObj = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private boolean isSensitiveUrl(String url) {
		if (url.contains("?hapikey=")) {
			return true;
		}
		return false;
	}
}


class MultipartUtility {
	private final String boundary;
	private static final String LINE_FEED = "\r\n";
	private HttpURLConnection httpConn;
	private String charset;
	private OutputStream outputStream;
	private PrintWriter writer;

	/**
	 * This constructor initializes a new HTTP POST request with content type is
	 * set to multipart/form-data
	 * 
	 * @param requestURL
	 * @param charset
	 * @throws IOException
	 */

	private void trustEveryone() {
		try {
			HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			});
			SSLContext context = SSLContext.getInstance("TLS");
			context.init(null, new X509TrustManager[] { new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}
			} }, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
		} catch (Exception e) { // should never happen
			e.printStackTrace();
		}
	}

	public MultipartUtility(String requestURL, String charset) throws IOException {
		this.charset = charset;
		this.boundary = "===" + System.currentTimeMillis() + "===";

		trustEveryone();

		URL url = new URL(requestURL);
		httpConn = (HttpURLConnection) url.openConnection();
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true); // indicates POST method
		httpConn.setDoInput(true);
		httpConn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
	}

	public void initialize() throws IOException {
		outputStream = httpConn.getOutputStream();
		writer = new PrintWriter(new OutputStreamWriter(outputStream, charset), true);
	}

	public void initializeWithHeaders(Map<String, String> headers) throws IOException {
		if (headers != null) {
			for (String key : headers.keySet()) {
				httpConn.setRequestProperty(key, headers.get(key));
			}
		}
		outputStream = httpConn.getOutputStream();
		writer = new PrintWriter(new OutputStreamWriter(outputStream, charset), true);
	}

	/**
	 * Adds a form field to the request
	 * 
	 * @param name
	 *            field name
	 * @param value
	 *            field value
	 */
	public void addFormField(String name, String value) {
		writer.append("--" + boundary).append(LINE_FEED);
		writer.append("Content-Disposition: form-data; name=\"" + name + "\"").append(LINE_FEED);
		writer.append("Content-Type: text/plain; charset=" + charset).append(LINE_FEED);
		writer.append(LINE_FEED);
		writer.append(value).append(LINE_FEED);
		writer.flush();
	}

	public void addJSONFormField(String name, String value) {
		writer.append("--" + boundary).append(LINE_FEED);
		writer.append("Content-Disposition: form-data; name=\"" + name + "\"").append(LINE_FEED);
		writer.append("Content-Type: application/json").append(LINE_FEED);
		writer.append(LINE_FEED);
		writer.append(value).append(LINE_FEED);
		writer.flush();
	}

	/**
	 * Adds a upload file section to the request
	 * 
	 * @param fieldName
	 *            name attribute in <input type="file" name="..." />
	 * @param uploadFile
	 *            a File to be uploaded
	 * @throws IOException
	 */
	public void addFilePart(String fieldName, File uploadFile) throws IOException {
		String fileName = uploadFile.getName();
		FileInputStream inputStream = new FileInputStream(uploadFile);
		addFilePart(fieldName, inputStream, fileName);
	}

	public void addFilePart(String fieldName, InputStream inputStream, String fileName) throws IOException {
		writer.append("--" + boundary).append(LINE_FEED);
		writer.append("Content-Disposition: form-data; name=\"" + fieldName + "\"; filename=\"" + fileName + "\"")
				.append(LINE_FEED);
		writer.append("Content-Type: " + URLConnection.guessContentTypeFromName(fileName)).append(LINE_FEED);
		writer.append("Content-Transfer-Encoding: binary").append(LINE_FEED);
		writer.append(LINE_FEED);
		writer.flush();

		byte[] buffer = new byte[4096];
		int bytesRead = -1;
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outputStream.write(buffer, 0, bytesRead);
		}
		outputStream.flush();
		inputStream.close();

		writer.append(LINE_FEED);
		writer.flush();
	}

	public void addFilePart(String fieldName, InputStream inputStream) throws IOException {
		addFilePart(fieldName, inputStream, "file");
	}

	/**
	 * Completes the request and receives response from the server.
	 * 
	 * @return a list of Strings as response in case the server returned status
	 *         OK, otherwise an exception is thrown.
	 * @throws IOException
	 */

	public String finish() throws IOException {
		List<String> response = new ArrayList<>();
		StringBuilder responseStr = new StringBuilder();

		writer.append(LINE_FEED).flush();
		writer.append("--" + boundary + "--").append(LINE_FEED);
		writer.close();
		// checks server's status code first
		int status = httpConn.getResponseCode();
		if (status == HttpURLConnection.HTTP_OK) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				response.add(line);
				responseStr.append(line);
			}
			reader.close();
			httpConn.disconnect();
		} else {
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpConn.getErrorStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				response.add(line);
				responseStr.append(line);
			}
			reader.close();
			httpConn.disconnect();
		}

		return responseStr.toString();
	}


}
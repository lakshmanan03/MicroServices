/**
 * 
 */
package com.bfa.application.core;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.request.entity.UpdateCustomerRequestByEmail;
import com.bfa.util.APIConstants;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

/**
 * BFA-1578
 * Makes a service call to recommendations to update the enquiry table with the email enquiry id along with the customer id.
 * 
 * @author pradheep
 *
 */
public class PersistEmailEnqDetails extends DiscoveryHelper implements Runnable {

	private UpdateCustomerRequestByEmail updateCustomerRequestByEmail;	

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private Environment environment;

	@Autowired
	private SecurityConstants constants;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@Override
	public void run() {
		getLogger().info("Updating the customer id and email enq id details ");
		setEnvironment(environment);
		loadSecurityHeader(constants.TOKEN_NAME);
		updateEnqIDByEmail();
	}

	private void updateEnqIDByEmail() {
		try {
			Thread.currentThread().sleep(3000);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		getLogger().info("Trying to update the email enq id / customer id  in recommendation service");
		String apiName = APIConstants.UPDATE_ENQUIRY_BY_EMAIL;
		String baseUrl = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE) + apiName;
		baseUrl = removePortNumbers(baseUrl);
		String requestBody = getRequestBodyForSelectedProducts();
		getLogger().info("Updating the recommendations service :" + requestBody);
		getLogger().info("Printing the base url " + baseUrl);
		addJobToQueue(baseUrl, requestBody, "update-email-enq-recommendations", 0);
	}

	private String getRequestBodyForSelectedProducts() {		
		Gson gson = new Gson();
		String requestBody = gson.toJson(updateCustomerRequestByEmail);
		return requestBody;
	}

	public UpdateCustomerRequestByEmail getUpdateCustomerRequestByEmail() {
		return updateCustomerRequestByEmail;
	}

	public void setUpdateCustomerRequestByEmail(UpdateCustomerRequestByEmail updateCustomerRequestByEmail) {
		this.updateCustomerRequestByEmail = updateCustomerRequestByEmail;
	}

}

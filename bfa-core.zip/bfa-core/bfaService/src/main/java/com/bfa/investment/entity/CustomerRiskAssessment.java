package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "customer_risk_assessment")
public class CustomerRiskAssessment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "question_option_id")
	private Integer questionOptionId;
	
	@Column(name = "custom_value")
	private String customValue;
	
	@Column(name = "preferred_portfolio_id")
	private int preferredPortfolioId;
		
	@Column(name = "enquiry_id")
	private int enquiryId;

	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "last_updated_time_stamp")
	private Date lastUpdatedTimeStamp;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getQuestionOptionId() {
		return questionOptionId;
	}

	public void setQuestionOptionId(Integer questionOptionId) {
		this.questionOptionId = questionOptionId;
	}

	public String getCustomValue() {
		return customValue;
	}

	public void setCustomValue(String customValue) {
		this.customValue = customValue;
	}

	public int getPreferredPortfolioId() {
		return preferredPortfolioId;
	}

	public void setPreferredPortfolioId(int preferredPortfolioId) {
		this.preferredPortfolioId = preferredPortfolioId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}
	
}

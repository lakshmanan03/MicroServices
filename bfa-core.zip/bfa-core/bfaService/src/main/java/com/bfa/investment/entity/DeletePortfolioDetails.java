package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "vw_deleted_portfolios")
public class DeletePortfolioDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "portfolio_name")
	private String portfolioName;

	@Column(name = "portfolio_id")
	private String portfolioId;

	@Column(name = "portfolio_ref_id")
	private Integer portfoliorefId;

	@Column(name = "risk_type_id")
	private int riskTypeId;

	@Column(name = "risk_type")
	private String riskType;

	@Column(name = "portfolio_status")
	private String portfolioStatus;

	@Column(name = "value_on_transaction_date")
	private Double valueOnTransactionDate;

	@Column(name = "closing_portfolio_value")
	private Double closingPortfolioValue;

	@Column(name = "returns_on_transaction_date")
	private Double returnsOnTransactionDate;

	@Column(name = "first_transaction_date")
	private Date firstTransactionDate;

	@Column(name = "recommended_date")
	private Date recommendedDate;
	
	@Column(name="created_date")
	private Date createdDate;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "initial_investment")
	private Double initialInvestment;

	@Column(name = "monthly_investment")
	private Double monthlyInvestment;

	@Column(name = "portfolio_value")
	private Double portfolioValue;

	@Column(name = "total_return")
	private Double totalReturns;

	@Column(name = "one_plus_total_return")
	private Double onePlusTotalReturns;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	/**
	 * @return the portfolioValue
	 */
    @Column(name = "ifast_refno")
	private String ifastRefno;

	@Column(name = "trust_id")
	private String trustId;
	
	@Column(name = "funding_type_id")
	private Integer fundingTypeId;
	
	@Column(name = "funding_type_value")
	private String fundingTypeValue;
	
	@Column(name = "updated_time_stamp")
	private Date lastUpdatedTimeStamp;
	
	@Column(name = "portfolio_type_id")
	private Integer portfolioTypeId;
	
	@Column(name = "portfolio_type_value")
	private String portfolioTypeValue;
		
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
   public Double getPortfolioValue() {
		return portfolioValue;
	}

	public Double getOnePlusTotalReturns() {
		return onePlusTotalReturns;
	}

	public void setOnePlusTotalReturns(Double onePlusTotalReturns) {
		this.onePlusTotalReturns = onePlusTotalReturns;
	}

	/**
	 * @param portfolioValue the portfolioValue to set
	 */
	public void setPortfolioValue(Double portfolioValue) {
		this.portfolioValue = portfolioValue;
	}

	/**
	 * @return the totalReturns
	 */

	public Double getTotalReturns() {
		return totalReturns;
	}

	/**
	 * @param totalReturns the totalReturns to set
	 */
	public void setTotalReturns(Double totalReturns) {
		this.totalReturns = totalReturns;
	}

	/**
	 * @return the closingPortfolioValue
	 */
	public Double getClosingPortfolioValue() {
		return closingPortfolioValue;
	}

	/**
	 * @param closingPortfolioValue the closingPortfolioValue to set
	 */
	public void setClosingPortfolioValue(Double closingPortfolioValue) {
		this.closingPortfolioValue = closingPortfolioValue;
	}

	public Date getFirstTransactionDate() {
		return firstTransactionDate;
	}

	public Date getRecommendedDate() {
		return recommendedDate;
	}

	public Double getInitialInvestment() {
		return initialInvestment;
	}

	public void setInitialInvestment(Double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}

	public Double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(Double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public void setRecommendedDate(Date recommendedDate) {
		this.recommendedDate = recommendedDate;
	}

	public void setFirstTransactionDate(Date firstTransactionDate) {
		this.firstTransactionDate = firstTransactionDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public int getRiskTypeId() {
		return riskTypeId;
	}

	public void setRiskTypeId(int riskTypeId) {
		this.riskTypeId = riskTypeId;
	}

	/**
	 * @return the portfoliorefId
	 */
	public Integer getPortfoliorefId() {
		return portfoliorefId;
	}

	/**
	 * @param portfoliorefId the portfoliorefId to set
	 */
	public void setPortfoliorefId(Integer portfoliorefId) {
		this.portfoliorefId = portfoliorefId;
	}

	public String getRiskType() {
		return riskType;
	}

	public void setRiskType(String riskType) {
		this.riskType = riskType;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public Double getValueOnTransactionDate() {
		return valueOnTransactionDate;
	}

	public void setValueOnTransactionDate(Double valueOnTransactionDate) {
		this.valueOnTransactionDate = valueOnTransactionDate;
	}

	public Double getReturnsOnTransactionDate() {
		return returnsOnTransactionDate;
	}

	public void setReturnsOnTransactionDate(Double returnsOnTransactionDate) {
		this.returnsOnTransactionDate = returnsOnTransactionDate;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getIfastRefno() {
		return ifastRefno;
	}

	public void setIfastRefno(String ifastRefno) {
		this.ifastRefno = ifastRefno;
	}

	public String getTrustId() {
		return trustId;
	}

    public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
	public Integer getEnquiryId() {
		return enquiryId;
	}

	public Integer getFundingTypeId() {
		return fundingTypeId;
	}

	public void setFundingTypeId(Integer fundingTypeId) {
		this.fundingTypeId = fundingTypeId;
	}

	public String getFundingTypeValue() {
		return fundingTypeValue;
	}

	public void setFundingTypeValue(String fundingTypeValue) {
		this.fundingTypeValue = fundingTypeValue;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public Integer getPortfolioTypeId() {
		return portfolioTypeId;
	}

	public void setPortfolioTypeId(Integer portfolioTypeId) {
		this.portfolioTypeId = portfolioTypeId;
	}

	public String getPortfolioTypeValue() {
		return portfolioTypeValue;
	}

	public void setPortfolioTypeValue(String portfolioTypeValue) {
		this.portfolioTypeValue = portfolioTypeValue;
	}
	
}

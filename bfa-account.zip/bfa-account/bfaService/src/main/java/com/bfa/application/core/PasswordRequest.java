/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import com.bfa.insurance.product.ProductList;

/**
 * @author pradheep.p
 *
 */
public class PasswordRequest {
	
	private String customerRef;
	
	private String password;
	
	private String callbackUrl;
	
	// New Password , Reset password
	private String resetType;
	
	// Secret key to validate the user;
	private String resetCode;

	// Can be of insurance or investment or will-writing
	private String journeyType;
	
	private String sessionId;
	
	private List<ProductList> selectedProducts;

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getResetType() {
		return resetType;
	}

	public void setResetType(String resetType) {
		this.resetType = resetType;
	}

	public String getResetCode() {
		return resetCode;
	}

	public void setResetCode(String resetCode) {
		this.resetCode = resetCode;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public String getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
}

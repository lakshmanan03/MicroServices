/**
 * 
 */
package com.bfa.insurance.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "premium")
public class Premium {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "prod_id")
	private String productId;

	@Column(name = "gender")
	private String gender;

	@Column(name = "min_age")
	private Integer minimumAge;

	@Column(name = "coverage_name")
	private String coverageName;	

	@Column(name = "duration_name")
	private String durationName;

	@Column(name = "premium_term")
	private String premiumTerm;

	@Column(name = "savings_dur")
	private String savingsDuration;

	@Column(name = "retirement_payout_amt")
	private String retirementPayoutAmount;

	@Column(name = "retirement_payout_dur")
	private String retirementPayoutDuration;
	
	@Column(name = "is_smoker")
	private boolean isSmoker;

	@Column(name = "premium_amt")
	private Double premiumAmount;
	
	@Column(name = "premium_amt_yearly")
	private Double premiumAmountYearly;

	@Column(name = "premium_frequency")
	private String premiumFrequency;

	@Column(name = "irr")
	private String intrestRateOfReturn;

	@Column(name = "ranking")
	private Integer ranking;
	
	@JsonIgnore
	@Column(name = "rider_id")
	private Integer riderId;

	@JsonIgnore
	@Column(name = "last_update")
	private Date lastUpdatedDate;

	@JsonIgnore
	@Column(name = "last_updated_by")
	private String lastUpdatedBy;	
	
	@Column(name="sum_assured")
	private Double sumAssured;
	
	@Column(name="income_payout_duration")
	private String incomePayoutDuration;
	
	@Column(name="payout_duration")
	private String payoutDuration;
	
	@Column(name="claim_criteria")
	private String claimCriteria;	
	
	@Column(name="claim_feature")
	private String claimFeature;	
	
	@Column(name="no_of_adl")
	private Integer numberOfADL;
	
	@Column(name="hospital_plan_type")
	private String hospitalPlanType;
	
	@Column(name="payout_age")
	private Integer payoutAge;
	
	@Column(name="guaranteed_monthly_income")
	private Double gaurenteedMonthlyIncome;
	
	@Column(name="monthly_benefit")
	private Double monthlyBenefit;
	
	/* -- BFA-1482 -- */
	@Column(name="multiplier")
	private Double multiplierRef;
	
	@Column(name="ranking_group_id")
	private Integer rankingGroupId;
	
	@Column(name="deferred_period")
	private Integer deferredPeriod;
	
	@Column(name ="escalating_benefit_percentage")
	private Double escalatingBenefit;
	
	@Column(name="total_guaranteed_payout")
	private String totalGuaranteedPayout;
	
	@Column(name="total_projected_payout_475")
	private String totalProjectedPayout475;
	
	@Column(name="total_projected_payout_325")
	private String totalProjectedPayout325;
	
	@Column(name="irr_325")
	private Double intrestRateOfReturn325;
	
	@Column(name="retire_pay_period_val")
	private String retirementPayPeriodDisplay;
	
	@Column(name="retire_pay_feature_val")
	private String retirementPayFeatureDisplay;
	
	
	
	public String getIncomePayoutDuration() {
		return incomePayoutDuration;
	}

	public void setIncomePayoutDuration(String incomePayoutDuration) {
		this.incomePayoutDuration = incomePayoutDuration;
	}

	public String getClaimCriteria() {
		return claimCriteria;
	}

	public void setClaimCriteria(String claimCriteria) {
		this.claimCriteria = claimCriteria;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getMinimumAge() {
		return minimumAge;
	}

	public void setMinimumAge(Integer minimumAge) {
		this.minimumAge = minimumAge;
	}

	public String getCoverageName() {
		return coverageName;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public String getDurationName() {
		return durationName;
	}

	public void setDurationName(String durationName) {
		this.durationName = durationName;
	}

	public String getPremiumTerm() {
		return premiumTerm;
	}

	public void setPremiumTerm(String premiumTerm) {
		this.premiumTerm = premiumTerm;
	}

	public String getSavingsDuration() {
		return savingsDuration;
	}

	public void setSavingsDuration(String savingsDuration) {
		this.savingsDuration = savingsDuration;
	}	

	public String getPremiumFrequency() {
		return premiumFrequency;
	}

	public void setPremiumFrequency(String premiumFrequency) {
		this.premiumFrequency = premiumFrequency;
	}	

	public Integer getRanking() {
		return ranking;
	}

	public void setRanking(Integer ranking) {
		this.ranking = ranking;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}	

	public boolean isSmoker() {
		return isSmoker;
	}

	public void setSmoker(boolean isSmoker) {
		this.isSmoker = isSmoker;
	}

	public Double getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}	

	public Integer getNumberOfADL() {
		return numberOfADL;
	}

	public void setNumberOfADL(Integer numberOfADL) {
		this.numberOfADL = numberOfADL;
	}

	public String getHospitalPlanType() {
		return hospitalPlanType;
	}

	public void setHospitalPlanType(String hospitalPlanType) {
		this.hospitalPlanType = hospitalPlanType;
	}

	public Integer getPayoutAge() {
		return payoutAge;
	}

	public void setPayoutAge(Integer payoutAge) {
		this.payoutAge = payoutAge;
	}

	public Double getGaurenteedMonthlyIncome() {
		return gaurenteedMonthlyIncome;
	}

	public void setGaurenteedMonthlyIncome(Double gaurenteedMonthlyIncome) {
		this.gaurenteedMonthlyIncome = gaurenteedMonthlyIncome;
	}

	public Double getMonthlyBenefit() {
		return monthlyBenefit;
	}

	public void setMonthlyBenefit(Double monthlyBenefit) {
		this.monthlyBenefit = monthlyBenefit;
	}

	public String getRetirementPayoutAmount() {
		return retirementPayoutAmount;
	}

	public void setRetirementPayoutAmount(String retirementPayoutAmount) {
		this.retirementPayoutAmount = retirementPayoutAmount;
	}

	public String getRetirementPayoutDuration() {
		return retirementPayoutDuration;
	}

	public void setRetirementPayoutDuration(String retirementPayoutDuration) {
		this.retirementPayoutDuration = retirementPayoutDuration;
	}

	public Integer getRankingGroupId() {
		return rankingGroupId;
	}

	public void setRankingGroupId(Integer rankingGroupId) {
		this.rankingGroupId = rankingGroupId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Integer getDeferredPeriod() {
		return deferredPeriod;
	}

	public void setDeferredPeriod(Integer deferredPeriod) {
		this.deferredPeriod = deferredPeriod;
	}

	public Double getEscalatingBenefit() {
		return escalatingBenefit;
	}

	public void setEscalatingBenefit(Double escalatingBenefit) {
		this.escalatingBenefit = escalatingBenefit;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRiderId() {
		return riderId;
	}

	public void setRiderId(Integer riderId) {
		this.riderId = riderId;
	}	

	public String getPayoutDuration() {
		return payoutDuration;
	}

	public void setPayoutDuration(String payoutDuration) {
		this.payoutDuration = payoutDuration;
	}

	public String getIntrestRateOfReturn() {
		return intrestRateOfReturn;
	}

	public void setIntrestRateOfReturn(String intrestRateOfReturn) {
		this.intrestRateOfReturn = intrestRateOfReturn;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Double getPremiumAmountYearly() {
		return premiumAmountYearly;
	}

	public void setPremiumAmountYearly(Double premiumAmountYearly) {
		this.premiumAmountYearly = premiumAmountYearly;
	}

	public String getTotalGuaranteedPayout() {
		return totalGuaranteedPayout;
	}

	public void setTotalGuaranteedPayout(String totalGuaranteedPayout) {
		this.totalGuaranteedPayout = totalGuaranteedPayout;
	}

	public String getTotalProjectedPayout475() {
		return totalProjectedPayout475;
	}

	public void setTotalProjectedPayout475(String totalProjectedPayout475) {
		this.totalProjectedPayout475 = totalProjectedPayout475;
	}

	public String getTotalProjectedPayout325() {
		return totalProjectedPayout325;
	}

	public void setTotalProjectedPayout325(String totalProjectedPayout325) {
		this.totalProjectedPayout325 = totalProjectedPayout325;
	}

	public Double getIntrestRateOfReturn325() {
		return intrestRateOfReturn325;
	}

	public void setIntrestRateOfReturn325(Double intrestRateOfReturn325) {
		this.intrestRateOfReturn325 = intrestRateOfReturn325;
	}

	public String getClaimFeature() {
		return claimFeature;
	}

	public void setClaimFeature(String claimFeature) {
		this.claimFeature = claimFeature;
	}	

	public String getRetirementPayFeatureDisplay() {
		return retirementPayFeatureDisplay;
	}

	public void setRetirementPayFeatureDisplay(String retirementPayFeatureDisplay) {
		this.retirementPayFeatureDisplay = retirementPayFeatureDisplay;
	}

	public String getRetirementPayPeriodDisplay() {
		return retirementPayPeriodDisplay;
	}

	public void setRetirementPayPeriodDisplay(String retirementPayPeriodDisplay) {
		this.retirementPayPeriodDisplay = retirementPayPeriodDisplay;
	}

	public Double getMultiplierRef() {
		return multiplierRef;
	}

	public void setMultiplierRef(Double multiplierRef) {
		this.multiplierRef = multiplierRef;
	}	

}

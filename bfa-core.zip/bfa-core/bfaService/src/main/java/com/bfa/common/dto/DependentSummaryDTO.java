/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;
import java.util.List;

public class DependentSummaryDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private List<DependentDTOResponse> dependentsList;	
	
	private Integer noOfHouseholdMembers;
	
	private String houseHoldIncome;	
	
	private Integer noOfYears;

	public Integer getNoOfHouseholdMembers() {
		return noOfHouseholdMembers;
	}

	public void setNoOfHouseholdMembers(Integer noOfHouseholdMembers) {
		this.noOfHouseholdMembers = noOfHouseholdMembers;
	}

	public String getHouseHoldIncome() {
		return houseHoldIncome;
	}

	public void setHouseHoldIncome(String houseHoldIncome) {
		this.houseHoldIncome = houseHoldIncome;
	}

	public List<DependentDTOResponse> getDependentsList() {
		return dependentsList;
	}

	public void setDependentsList(List<DependentDTOResponse> dependentsList) {
		this.dependentsList = dependentsList;
	}

	public Integer getNoOfYears() {
		return noOfYears;
	}

	public void setNoOfYears(Integer noOfYears) {
		this.noOfYears = noOfYears;
	}	

	
	
}

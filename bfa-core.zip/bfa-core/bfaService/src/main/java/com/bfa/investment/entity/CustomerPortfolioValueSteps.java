/**
 * 
 */
package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author DivakarU
 *
 */
@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = "customer_portfolio_value_steps")
public class CustomerPortfolioValueSteps {
	@Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "id")
	  private int id;
	
	@Column(name = "portfolio_id")
	private Integer portfolioId;
	
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	
	@Column(name = "last_modified_date")
	private Date lastModifiedDate;
	
	@Column(name = "portfolio_value")
	private Double portfolioValue;
	
	@Column(name = "portfolio_previous_value")
	private Double portfolioPreValue;

	@Column(name = "portfolio_value_formula")
	private String portfolioValueFormula;
	
	@Column(name = "prev_portfolio_value_formula")
	private String prevPortfolioValueFormula;
	
	@Column(name = "nav_date_info")
	private String navDateInfo;
	
	@Column(name = "total_returns_formula")
	private String totalReturnsFormula;
	
	@Column(name = "daily_return")
	private Double dailyReturn;
	
	@Column(name = "total_return")
	private Double totalReturn;
	
	@Column(name = "prev_total_return")
	private Double previousTotalReturn;
	
	@Column(name = "track_id")
	private String trackId;

	@OneToOne
	@JoinColumn(name = "customer_portfolio_id")
	private CustomerPortfolio customerPortfolio;
	
	
	/**
	 * @return the customerPortfolio
	 */
	public CustomerPortfolio getCustomerPortfolio() {
		return customerPortfolio;
	}

	/**
	 * @param customerPortfolio the customerPortfolio to set
	 */
	public void setCustomerPortfolio(CustomerPortfolio customerPortfolio) {
		this.customerPortfolio = customerPortfolio;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the portfolioid
	 */
	public Integer getPortfolioId() {
		return portfolioId;
	}

	/**
	 * @param portfolioid the portfolioid to set
	 */
	public void setPortfolioId(Integer portfolioid) {
		this.portfolioId = portfolioid;
	}

	/**
	 * @return the customerid
	 */
	public Integer getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerid the customerid to set
	 */
	public void setCustomerId(Integer customerid) {
		this.customerId = customerid;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the portfolioValue
	 */
	public Double getPortfolioValue() {
		return portfolioValue;
	}

	/**
	 * @param portfolioValue the portfolioValue to set
	 */
	public void setPortfolioValue(Double portfolioValue) {
		this.portfolioValue = portfolioValue;
	}

	/**
	 * @return the portfolioPreValue
	 */
	public Double getPortfolioPreValue() {
		return portfolioPreValue;
	}

	/**
	 * @param portfolioPreValue the portfolioPreValue to set
	 */
	public void setPortfolioPreValue(Double portfolioPreValue) {
		this.portfolioPreValue = portfolioPreValue;
	}

	/**
	 * @return the dailyReturn
	 */
	public Double getDailyReturn() {
		return dailyReturn;
	}

	/**
	 * @param dailyReturn the dailyReturn to set
	 */
	public void setDailyReturn(Double dailyReturn) {
		this.dailyReturn = dailyReturn;
	}

	/**
	 * @return the totalReturn
	 */
	public Double getTotalReturn() {
		return totalReturn;
	}

	/**
	 * @param totalReturn the totalReturn to set
	 */
	public void setTotalReturn(Double totalReturn) {
		this.totalReturn = totalReturn;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */

	

	public Double getPreviousTotalReturn() {
		return previousTotalReturn;
	}

	public void setPreviousTotalReturn(Double previousTotalReturn) {
		this.previousTotalReturn = previousTotalReturn;
	}

	@Override
	public String toString() {
		return "CustomerPortfolioValues [id=" + id + ", portfolioId=" + portfolioId + ", customerId=" + customerId
				+ ", createdDate=" + createdDate + ", portfolioValue=" + portfolioValue + ", portfolioPreValue="
				+ portfolioPreValue + ", dailyReturn=" + dailyReturn + ", totalReturn=" + totalReturn
				+ ", previousTotalReturn=" + previousTotalReturn + "]";
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getTotalReturnsFormula() {
		return totalReturnsFormula;
	}

	public void setTotalReturnsFormula(String totalReturnsFormula) {
		this.totalReturnsFormula = totalReturnsFormula;
	}

	public String getTrackId() {
		return trackId;
	}

	public void setTrackId(String trackId) {
		this.trackId = trackId;
	}

	public String getPortfolioValueFormula() {
		return portfolioValueFormula;
	}

	public void setPortfolioValueFormula(String portfolioValueFormula) {
		this.portfolioValueFormula = portfolioValueFormula;
	}

	public String getPrevPortfolioValueFormula() {
		return prevPortfolioValueFormula;
	}

	public void setPrevPortfolioValueFormula(String prevPortfolioValueFormula) {
		this.prevPortfolioValueFormula = prevPortfolioValueFormula;
	}

	public String getNavDateInfo() {
		return navDateInfo;
	}

	public void setNavDateInfo(String navDateInfo) {
		this.navDateInfo = navDateInfo;
	}
	
}


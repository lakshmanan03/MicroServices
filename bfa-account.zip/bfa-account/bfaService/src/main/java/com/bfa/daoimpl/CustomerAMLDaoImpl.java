package com.bfa.daoimpl;

import com.bfa.common.entity.CustomerAMLStatus;
import com.bfa.dao.CustomerAMLDao;

public class CustomerAMLDaoImpl extends BaseDaoImpl implements CustomerAMLDao {

	@Override
	public CustomerAMLStatus getCustomerAMLStatus(Integer customerId) {
		CustomerAMLStatus amlStatus = (CustomerAMLStatus) getFirst("FROM CustomerAMLStatus where customer.id = " + customerId);
		return amlStatus;
	}
	
	public CustomerAMLStatus saveOrUpdateAMLStatus(CustomerAMLStatus amlStatus) {
		saveOrUpdate(amlStatus);
		return amlStatus;
	}

}

package com.bfa.daoimpl;

import com.bfa.common.entity.Address;
import com.bfa.dao.AddressDao;

public class AddressDaoImpl extends BaseDaoImpl implements AddressDao {

	@Override
	public Address createOrUpdateAddress(Address address) {

		save(address);
		return address;
	}

}

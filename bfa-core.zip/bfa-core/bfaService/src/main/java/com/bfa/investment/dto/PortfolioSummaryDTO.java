package com.bfa.investment.dto;

public class PortfolioSummaryDTO {
	
	private Double overallPortfolioValue;
	private Double overallCashAccountBalance;
	private int numberOfPortfolios;
	private CommonPortfolioSummaryDTO investmentPortfolio;
	private CommonPortfolioSummaryDTO wiseSaverPortfolio;
	/**
	
	/**
	 * @return the numberOfPortfolios
	 */
	public int getNumberOfPortfolios() {
		return numberOfPortfolios;
	}
	/**
	 * @param numberOfPortfolios the numberOfPortfolios to set
	 */
	public void setNumberOfPortfolios(int numberOfPortfolios) {
		this.numberOfPortfolios = numberOfPortfolios;
	}
	public Double getOverallPortfolioValue() {
		return overallPortfolioValue;
	}
	public void setOverallPortfolioValue(Double overallPortfolioValue) {
		this.overallPortfolioValue = overallPortfolioValue;
	}
	public Double getOverallCashAccountBalance() {
		return overallCashAccountBalance;
	}
	public void setOverallCashAccountBalance(Double overallCashAccountBalance) {
		this.overallCashAccountBalance = overallCashAccountBalance;
	}
	public CommonPortfolioSummaryDTO getInvestmentPortfolio() {
		return investmentPortfolio;
	}
	public void setInvestmentPortfolio(CommonPortfolioSummaryDTO investmentPortfolio) {
		this.investmentPortfolio = investmentPortfolio;
	}
	public CommonPortfolioSummaryDTO getWiseSaverPortfolio() {
		return wiseSaverPortfolio;
	}
	public void setWiseSaverPortfolio(CommonPortfolioSummaryDTO wiseSaverPortfolio) {
		this.wiseSaverPortfolio = wiseSaverPortfolio;
	}
	

	

}

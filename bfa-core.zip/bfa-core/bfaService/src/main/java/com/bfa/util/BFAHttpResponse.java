/**
 * 
 */
package com.bfa.util;

import org.apache.http.Header;

/**
 * @author pradheep.p
 *
 */
public class BFAHttpResponse {

	private Exception exception;
	
	private int responseCode;

	private String responseBody;

	private Header[] allHeaders;

	
	
	public Exception getException() {
		return exception;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}

	public Header[] getAllHeaders() {
		return allHeaders;
	}

	public void setAllHeaders(Header[] allHeaders) {
		this.allHeaders = allHeaders;
	}

	public String toString() {
		return "Response Code :" + getResponseCode() + " Response Body: " + getResponseBody();
	}
}

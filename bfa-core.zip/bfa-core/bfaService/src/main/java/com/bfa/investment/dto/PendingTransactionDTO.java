package com.bfa.investment.dto;

import java.io.Serializable;

public class PendingTransactionDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String portfolioName;
	private Double amount;
	private String transactionFrequency;
	
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getTransactionFrequency() {
		return transactionFrequency;
	}
	public void setTransactionFrequency(String transactionFrequency) {
		this.transactionFrequency = transactionFrequency;
	}
	
	
	
}

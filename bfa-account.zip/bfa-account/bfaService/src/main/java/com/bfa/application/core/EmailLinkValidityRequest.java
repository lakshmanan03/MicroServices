/**
 * 
 */
package com.bfa.application.core;

/**
 * @author pradheep.p
 *
 */
public class EmailLinkValidityRequest {
	
	private String resetKey;
	private Boolean isAdmin;

	public String getResetKey() {
		return resetKey;
	}

	public void setResetKey(String resetKey) {
		this.resetKey = resetKey;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
}

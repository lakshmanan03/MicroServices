/**
 * 
 */
package com.bfa.common.dto; 

public class ComprehensiveReportDTO {
	
	private Integer enquiryId;
	
	private Integer customerId;

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

}

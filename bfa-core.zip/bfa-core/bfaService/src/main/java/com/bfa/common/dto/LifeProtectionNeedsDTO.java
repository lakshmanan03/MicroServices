package com.bfa.common.dto;

public class LifeProtectionNeedsDTO {
	
	private int id;
	
	private int enquiryId;
	
	private double coverageAmount;
	
	private String coverageDuration;	
	
	private boolean isPremiumWaiver;
	
	private int customerId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public String getCoverageDuration() {
		return coverageDuration;
	}

	public void setCoverageDuration(String coverageDuration) {
		this.coverageDuration = coverageDuration;
	}

	public boolean isPremiumWaiver() {
		return isPremiumWaiver;
	}

	public void setPremiumWaiver(boolean isPremiumWaiver) {
		this.isPremiumWaiver = isPremiumWaiver;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	

}

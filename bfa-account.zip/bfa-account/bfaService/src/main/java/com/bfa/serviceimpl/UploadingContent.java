/**
 * 
 */
package com.bfa.serviceimpl;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author pradheep.p
 *
 */
public class UploadingContent {
	
	private MultipartFile multiPartFile;
	
	private String documentType;

	public MultipartFile getMultiPartFile() {
		return multiPartFile;
	}

	public void setMultiPartFile(MultipartFile multiPartFile) {
		this.multiPartFile = multiPartFile;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
}

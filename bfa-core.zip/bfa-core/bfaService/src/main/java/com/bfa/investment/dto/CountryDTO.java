package com.bfa.investment.dto;

public class CountryDTO {

    private int id;
  
    private String country;
    
    private String nationality;
    
    private boolean isBlocked;

    
    private String countryCode;
    
    private boolean isCountryBlocked;
    
    private boolean isVisible;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
	public boolean isBlocked() {
		return isBlocked;
	}

	public void setBlocked(boolean isBlocked) {
		this.isBlocked = isBlocked;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public boolean isCountryBlocked() {
		return isCountryBlocked;
	}

	public void setCountryBlocked(boolean isCountryBlocked) {
		this.isCountryBlocked = isCountryBlocked;
	}

	public boolean isVisible() {
		return isVisible;
	}

	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}
   
	
	
}

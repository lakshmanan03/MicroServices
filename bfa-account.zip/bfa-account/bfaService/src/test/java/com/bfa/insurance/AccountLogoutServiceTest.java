/**
 * 
 */
package com.bfa.insurance;

import java.util.Date;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.core.BlacklistToken;
import com.bfa.application.security.LogoutService;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.serviceimpl.AccountLogoutService;

/**
 * @author pradheep.p
 *
 */

@RunWith(SpringRunner.class)
//@SpringBootTest(classes = AccountServiceConfiguration.class)
public class AccountLogoutServiceTest {

	@Mock
	private AccountsDao accountsDAO;

	@InjectMocks
	private AccountLogoutService logoutService;	
	
	@Mock
	protected ApplicationLoggerBean applicationLoggerBean;
	
	protected Logger getLogger() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}
	

	@Transactional
	public void init(String token,String reason) {
		BlacklistToken blackListedToken = new BlacklistToken();
		blackListedToken.setTokenValue(token);
		blackListedToken.setReason(reason);
		blackListedToken.setEjectTime(new Date());
		accountsDAO.saveObject(blackListedToken);
	}
	
	@Test
	public void testNonBlackListedToken() {
		
		String token = "hj89087df";
		String reason = "Test data";
		init(token,reason);
		try {
			String arg = logoutService.isTokenBlackListed("mnjkisde32");
			Assert.assertEquals(LogoutService.NOT_BLACKLISTED, arg);
		} catch (Exception err) {
			getLogger().error("Exception caught in testNonBlackListedToken(): " + err);
		}
	}

	@Test
	public void testBlackListedToken() {
		String token = "abcdefgh";
		String reason = "Test data";
		init(token,reason);
		try {
			String flag = logoutService.isTokenBlackListed(token);
			Assert.assertEquals(LogoutService.NOT_BLACKLISTED, flag);
		} catch (Exception e) {
			getLogger().error("Exception caught in testBlackListedToken(): " + e);
		}
	}

	
}

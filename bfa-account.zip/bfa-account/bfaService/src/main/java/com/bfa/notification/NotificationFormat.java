package com.bfa.notification;

public interface NotificationFormat {
public static String EMAIL_FORMAT = "Email";
public static String SMS_FORMAT = "SMS";
}

package com.bfa.util;

public  class ApplicationConfigurationKeys {
	public static String totalReturnsEnabled = "totalReturnsEnabled";
	
	public static String maxPortfoliosAllowed = "maxPortfoliosAllowed";
	
}


/**
 * 
 */
package com.bfa.ifast.exception;

/**
 * @author DivakarU
 *
 */
public class IFastUnauthorizedException extends IFastException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6143507515295335397L;

	/**
	 * @param exceptionMessage
	 */
	public IFastUnauthorizedException(String exceptionMessage) {
		super(exceptionMessage);
		// TODO Auto-generated constructor stub
	}

}


/**
 * 
 */
package com.bfa.request.aggregate;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.request.processor.HttpProcessorGetCommand;
import com.bfa.request.processor.ProcessorCommand;

/**
 * Aggregates the reults form many API calls.
 * 
 * @see InsuranceDataComposer
 * @author pradheep
 * @param <T>
 *
 */
public final class DefaultServiceAggregator<T extends ProcessorCommand> extends ServiceAggregator<T> {

	/**
	 * Inject the logger from the service layer or from calling module.
	 */
	private Logger logger;

	@Autowired
	public ThreadPoolTaskExecutor executor;

	private BFADataComposer givenDataComposer;
	
	private Object computedResult;

	/**
	 * Set the logger from the calling module before invoking this method.
	 */
	@Override
	public CompletableFuture<T> getResults(T obj) throws RuntimeException {
		if (getLogger() == null) {
			throw new RuntimeException("Try setting a logger to this bean by using a setLogger() method");
		}
		return CompletableFuture.supplyAsync(() -> {
			HttpProcessorGetCommand command = (HttpProcessorGetCommand) obj;
			System.out.println("Printing the thread name : " + Thread.currentThread().getName());
			command.run();			
			return obj;
		},executor);
	}

	/**
	 * Set a BFADataComposer before calling this method.
	 * 
	 * Also the logger has to be set before calling this method. If you have
	 * already set this can be ignored.
	 * 
	 * @see InsuranceDataComposer
	 */
	@Override
	public void aggregateResults(CompletableFuture<T>... completableFutures) throws RuntimeException {
		if (givenDataComposer == null) {
			throw new RuntimeException("Try setting a data composer for aggregating the results");
		}
		if (getLogger() == null) {
			throw new RuntimeException("Try setting a logger to this bean by using a setLogger() method");
		}
		CompletableFuture combinedFutureObj = CompletableFuture.allOf(completableFutures);					
		getLogger().info("Is all tasks done :" + combinedFutureObj.isDone());		
		ArrayList<T> results = new ArrayList<T>();
		for (CompletableFuture<T> obj : completableFutures) {
			T command = null;
			try {
				command = obj.get();
			} catch (InterruptedException e) {
				e.printStackTrace();
				getLogger().error("Error while processing the Http Processor Command " + command.getCommandName(), e);
			} catch (ExecutionException e) {
				getLogger().error("Error while execution of the Http Processor Command " + command.getCommandName(), e);
			}
			results.add(command);
		}
		getLogger().info("--- Finished completing collecting the data --- " );	
		/*try {
			Thread.currentThread().sleep(3000);
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}*/
		computedResult = givenDataComposer.composeAllData(results);		
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public BFADataComposer getGivenDataComposer() {
		return givenDataComposer;
	}

	/**
	 * Set the data composer required for aggregating the results.
	 * 
	 * @param givenDataComposer
	 */
	public void setGivenDataComposer(BFADataComposer givenDataComposer) {
		this.givenDataComposer = givenDataComposer;
	}

	@Override
	public Object getComputedResults() {		
		return computedResult;
	}

}

/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "critical_illness_needs")
public class CriticalIllnessNeeds implements Serializable{
	

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	@Column(name = "id")
	private int id;
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "coverage_years")
	private String coverageYears;
	
	@Column(name = "coverage_amount")
	private double coverageAmount;	
	
	@JsonProperty(value="isEarlyCriticalIllness")
	@Column(name = "early_ci",columnDefinition = "TINYINT")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean isEarlyCriticalIllness = false;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}	

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}


	public String getCoverageYears() {
		return coverageYears;
	}

	public void setCoverageYears(String coverageYears) {
		this.coverageYears = coverageYears;
	}
	
	public void setIsEarlyCriticalIllness(Boolean isEarlyCriticalIllness) {
		this.isEarlyCriticalIllness = isEarlyCriticalIllness;
	}
	
	@JsonProperty(value = "isEarlyCriticalIllness")
	public Boolean getIsEarlyCriticalIllness() {
		return isEarlyCriticalIllness;
	}
	
}

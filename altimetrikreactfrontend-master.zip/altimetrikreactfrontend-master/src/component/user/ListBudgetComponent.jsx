import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class ListBudgetComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            foodItems: [],
            message: null
        }
      
        this.getBudget = this.getBudget.bind(this);
        this.getRated=this.getRated.bind(this);
        this.placeOrder=this.placeOrder.bind(this);
        this.reloadUserList = this.reloadUserList.bind(this);
    }

    componentDidMount() {
        this.reloadUserList();
    }   

    reloadUserList() {
        ApiService.fetchBudget()
            .then((res) => {
                this.setState({foodItems: res.data})
            });
    }




    getRated() {
        window.localStorage.removeItem("foodId");
        this.props.history.push('/rated');
    }
    getBudget() {
        window.localStorage.removeItem("foodId");
        this.props.history.push('/budget');
    }
    placeOrder(name,price,restaurant)
    {   
        window.localStorage.setItem("item", name);
        
        window.localStorage.setItem("amount", price);

        window.localStorage.setItem("restaurant",restaurant);

        this.props.history.push('/confirmation');

    }
    render() {
        return (
            <div>
                 <h1 className="text-center" style={style}>Hungry to Eat?</h1>
                <h2 className="text-center">Drooling Tongue</h2>
                <button className="btn btn-danger" style={{width:'100px'}} onClick={() => this.getBudget()}> Budget</button>
                <button className="btn btn-danger" style={{width:'100px' ,position:'absolute',top:'150',left:'400'}} onClick={() => this.getRated()}> Top Rated</button>
                <table className="table table-striped">
                    <thead>
                        <tr>
                           
                            <th>Item</th>
                            <th>Price</th>
                            <th>RestaurantName</th>
                            <th>Rating</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.foodItems.map(
                        food =>
                                    <tr key={food.id}>
                                        <td>{food.name}</td>
                                        <td>{food.price}</td>
                                        <td>{food.restaurantName}</td>
                                        <td>{food.rating}</td>
                                        <td>
                                        <button className="btn btn-success" onClick={() => this.placeOrder(food.name,food.price,food.restaurantName)}> Order</button>
                                         
                                         
                                        </td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }
    

}
const style = {
    color: 'red',
    margin: '10px'
}
export default ListBudgetComponent;
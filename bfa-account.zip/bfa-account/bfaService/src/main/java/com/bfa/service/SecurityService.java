package com.bfa.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.bfa.application.core.AuthenticationRequest;
import com.bfa.application.core.EmailLinkValidityRequest;
import com.bfa.application.core.OTPRequest;
import com.bfa.application.core.OTPVerificationResponse;
import com.bfa.application.core.PasswordRequest;
import com.bfa.application.core.SaveSelectedProductsRequest;
import com.bfa.application.core.VerifyEmailRequest;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.ForgotPasswordDTO;
import com.bfa.common.dto.ResetPasswordDTO;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.insurance.product.ProductList;
import com.bfa.security.twofa.core.TwoFactorAuthValidation;
import com.bfa.util.ResponseMessageList;


public interface SecurityService {	

	public ResponseMessageList authenticateRequest(HttpServletRequest servletRequest,AuthenticationRequest authenticationRequest,boolean captchaCheck);	
	
	public ResponseMessageList authenticateAdvisor(HttpServletRequest servletRequest,AuthenticationRequest authenticationRequest);	
	
	public SessionDetails saveSessionDetails(String sessionId,HttpServletRequest httpServletRequest);	
	
	public String provideClientSecretKey();
	
	public OTPVerificationResponse verifyOTP(OTPRequest otpRequest);
	
	public boolean setPassword(PasswordRequest passwordRequest,HttpServletRequest servletRequest);
	
	public String verifyEmailAddress(VerifyEmailRequest verifyEmailRequest);
	
	public String decryptUserResponseData(String toBeDecrypted);
	
	public String generatePasswordResetMail(ForgotPasswordDTO dto);
	
	public PasswordResetStatus resetPassword(ResetPasswordDTO dto);
	
	public void saveSessionCaptchaDetails(HttpServletRequest request,String sessionId,String captcha);
	
	public SessionDetails getSessionDetailsBySessionId(String sessionId);
	
	public boolean isValidCaptcha(String sessionId,String captcha);
	
	public void updateCRMPostCustomerCreation(String customerId,List<ProductList> selectedProducts,boolean isNewCustomer,Integer enquiryId);
	
	public void updateCRMEnqByEmail(Integer customerId,List<ProductList> selectedProducts,boolean isNewCustomer,Integer enquiryId,String firstName,String lastName);
	
	public void updateCRMPostDuringSignup(PasswordRequest passwordRequest,boolean isNewCustomer);	
	
	public void blackList(String token,String reason);
	
	public String isEmailLinkValid(EmailLinkValidityRequest emailLinkValidityRequest);
	
	void sendSetUpInvestmentAccountMailerIfApplicable(Integer customerId);
	
	public CustomerContactVerification editEmail(ContactDetailsDTO updateCustomercontact, Integer customerId,HttpServletRequest servletRequest);

	public void updateCRMPostDuringSignupV2(SaveSelectedProductsRequest selectedProducts,boolean isNewCustomer);
	
	public PasswordResetStatus resetPasswordV2(ResetPasswordDTO dto);	
	
	public void savePromocode(int customerId, Integer enquiryId);

	public String generatePasswordResetMailForAdmin(ForgotPasswordDTO forgotPasswordDto);

	public PasswordResetStatus resetPasswordforAdmin(ResetPasswordDTO dto);
	
	public boolean isCaptchaApplicable(String sessionId) throws RuntimeException;
	
	public void send2FAOTP(Customer customerObj,String sessionId);
	
	public Integer validate2FADetails(String sessionId, String twoFactorOtpString,Integer customerId);
	
	public boolean authenticate2FA(String sessionId);
	
	public TwoFactorAuthValidation authenticate2FAWithReturnCode(String sessionId);
	
	public boolean isValidSession(String sessionId);
	
	public CustomerContactVerification getCustomerContactVerificationByCustomerIdAndType(Integer customerId,String actionType);
}

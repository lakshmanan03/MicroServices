package com.bfa.common.dto;

public class HospitalPlanListDTO {
	
	private int id;
	
	private String hospitalClass;	
	
	private String hospitalClassDescription;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHospitalClass() {
		return hospitalClass;
	}

	public void setHospitalClass(String hospitalClass) {
		this.hospitalClass = hospitalClass;
	}
	public String getHospitalClassDescription() {
		return hospitalClassDescription;
	}

	public void setHospitalClassDescription(String hospitalClassDescription) {
		this.hospitalClassDescription = hospitalClassDescription;
	}
}

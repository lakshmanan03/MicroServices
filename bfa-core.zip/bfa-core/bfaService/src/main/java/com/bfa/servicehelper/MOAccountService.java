package com.bfa.servicehelper;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.bfa.admin.dto.AddAdvisorRequestDTO;
import com.bfa.admin.dto.AdminCustomerDetails;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.SavePrommoCodeDTO;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.insurance.core.Customer;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.util.AMLVerificationServiceResponse;
import com.bfa.util.APIResponse;
import com.bfa.util.BFAHTTPFile;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessage;
import com.bfa.util.ResponseMessageList;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

public class MOAccountService extends MOServiceHelper {
	
	protected final Log logger = LogFactory.getLog(getClass());

	public ProfileSummaryDTO getProfileSummary() {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		ProfileSummaryDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.profileSummary());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<ProfileSummaryDTO>> typeToken = new TypeToken<APIResponse<ProfileSummaryDTO>>() {
			};
			APIResponse<ProfileSummaryDTO> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}
		return dto;
	}
	
	public ProfileSummaryDTO getProfileSummary_Debug(Map<String,Object> info) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		info.put("Auth token found", authorizationToken);
		ProfileSummaryDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.profileSummary());
		info.put("Profile Summary URL Found", URLDirectory.AccountService.profileSummary());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		info.put("response obj", response);
		if (response != null) {
			TypeToken<APIResponse<ProfileSummaryDTO>> typeToken = new TypeToken<APIResponse<ProfileSummaryDTO>>() {
			};
			APIResponse<ProfileSummaryDTO> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
				info.put("response dto", dto);
			}
		}
		return dto;
	}

	public List<CustomerBankDetail> getCustomerBankDetails(Integer customerId) {
		//
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		List<CustomerBankDetail> bankList = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.customerBankDetails(customerId));
		request.addHeader("Authorization", authorizationToken);

		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<List<CustomerBankDetail>>> typeToken = new TypeToken<APIResponse<List<CustomerBankDetail>>>() {
			};

			APIResponse<List<CustomerBankDetail>> apiResponse = APIResponse
					.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				bankList = apiResponse.getObjectList();
			}
		}
		return bankList;
	}

	public List<CustomerBankDetail> getCustomerBankDetails() {
		//
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		List<CustomerBankDetail> bankList = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.customerBankDetails());
		request.addHeader("Authorization", authorizationToken);

		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<List<CustomerBankDetail>>> typeToken = new TypeToken<APIResponse<List<CustomerBankDetail>>>() {
			};

			APIResponse<List<CustomerBankDetail>> apiResponse = APIResponse
					.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				bankList = apiResponse.getObjectList();
			}
		}
		return bankList;
	}

	public DetailedCustomerSummary getDetailedCustomerSummary(Integer customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		DetailedCustomerSummary dto = null;
		MOServiceRequest request = new MOServiceRequest();
		
		request.setUrl(URLDirectory.AccountService.detailedCustomerSummary(customerId));
		request.addHeader("Authorization", authorizationToken);

		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			TypeReference<APIResponse<DetailedCustomerSummary>> typeToken = new TypeReference<APIResponse<DetailedCustomerSummary>>() {
			};
			APIResponse<DetailedCustomerSummary> apiResponse = null;
			try {
				apiResponse = mapper.readValue(response.getResponseBody(), typeToken);
			} catch (com.fasterxml.jackson.core.JsonParseException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

//			
//			APIResponse<DetailedCustomerSummary> apiResponse = APIResponse.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
	
	public DetailedCustomerSummary getDetailedCustomerSummaryForAccountProcessing(Integer customerId,Integer enquiryId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		DetailedCustomerSummary dto = null;
		MOServiceRequest request = new MOServiceRequest();
		
		request.setUrl(URLDirectory.AccountService.detailedCustomerSummaryForAccountProcessing(customerId, enquiryId));
		request.addHeader("Authorization", authorizationToken);

		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			TypeReference<APIResponse<DetailedCustomerSummary>> typeToken = new TypeReference<APIResponse<DetailedCustomerSummary>>() {
			};
			APIResponse<DetailedCustomerSummary> apiResponse = null;
			try {
				apiResponse = mapper.readValue(response.getResponseBody(), typeToken);
			} catch (com.fasterxml.jackson.core.JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

//			
//			APIResponse<DetailedCustomerSummary> apiResponse = APIResponse.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
	
	public AMLVerificationServiceResponse clearAml(Integer customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		AMLVerificationServiceResponse dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.clearAML(customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		logger.info("clear AML URL: "+request.getUrl());
		MOServiceResponse response = get(request);
		if (response != null) {
			logger.info("verify AML call response: "+response.getResponseBody());
			TypeToken<APIResponse<AMLVerificationServiceResponse>> typeToken = new TypeToken<APIResponse<AMLVerificationServiceResponse>>() {
			};
			APIResponse<AMLVerificationServiceResponse> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}
		return dto;
	}

	public AdminCustomerDetails fetchIndividualCustomerDetails(Integer customerId, Integer advisorId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		AdminCustomerDetails dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.fetchCustomerSummary(customerId, advisorId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			APIResponse<AdminCustomerDetails> apiResponse = parseIndividualCustomerSummary(response.getResponseBody());
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}

	private APIResponse<AdminCustomerDetails> parseIndividualCustomerSummary(String json) {
		TypeToken<APIResponse<AdminCustomerDetails>> typeToken = new TypeToken<APIResponse<AdminCustomerDetails>>() {
		};
		APIResponse<AdminCustomerDetails> response = new GsonBuilder()
				.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {


					@Override
					public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
							throws JsonParseException {

						Date parsedDate = PublicUtility.tryParseDate(json.getAsString());
						if (parsedDate == null)
							parsedDate = new Date();
						System.out.println("Date: " + json.getAsString() + ", parsed: " + parsedDate);
						return parsedDate;
					}
				}).create().fromJson(json, typeToken.getType());
		return response;
	}

	public AMLVerificationServiceResponse verifyAML() {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		AMLVerificationServiceResponse dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.verifyAML());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		logger.info("verify AML call URL: "+request.getUrl());
		MOServiceResponse response = get(request);
		
		if (response != null) {
			logger.info("verify AML call response: "+response.getResponseBody());
			TypeToken<APIResponse<AMLVerificationServiceResponse>> typeToken = new TypeToken<APIResponse<AMLVerificationServiceResponse>>() {
			};
			APIResponse<AMLVerificationServiceResponse> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}
		return dto;
	}

	public Customer addAdvisorDetails(AddAdvisorRequestDTO addAdvisorRequest) {
		APIResponse<Customer> apiResponse = null;
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		Customer customerResponse = new Customer();
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.updateAdvisor());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		request.setRequestBody(addAdvisorRequest);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Customer>> typeToken = new TypeToken<APIResponse<Customer>>() {
			};
			apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					APIResponse.createSuccessResponse();
					customerResponse = apiResponse.getObjectList();
					return customerResponse;
				} else {
					APIResponse.createFailureResponse();
					return customerResponse;
				}
			}

		}
		return customerResponse;

	}
	
	public Boolean savePromocode(SavePrommoCodeDTO customerInvestmentObjectiveDTO) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.savePromoCode());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		request.setRequestBody(customerInvestmentObjectiveDTO);
		MOServiceResponse response = post(request);
		Boolean isPromocodeSaved = false;		
			if (response != null) {
				TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
				};
				APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
				if (apiResponse != null) {
					if (apiResponse.getObjectList() != null) {
						isPromocodeSaved = apiResponse.getObjectList();
					}
				}		
		
			}
			return isPromocodeSaved;
	}

	public CustomerSrsAccount getSrsCustomerDetails(Integer customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		CustomerSrsAccount dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.fetchCustomerSRSDetails());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<CustomerSrsAccount>> typeToken = new TypeToken<APIResponse<CustomerSrsAccount>>() {
			};
			APIResponse<CustomerSrsAccount> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null) {
				if (apiResponse.getObjectList() != null) {
					dto = apiResponse.getObjectList();
				}
			}
		}

		return dto;
	}
	

	public String editCustomerAddress(String customerId, UpdateCustomerAddressDTO updateCustomerAddressDTO,
			Integer advisorId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		Map<String, String> responseList = null;
		String sessionId = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.AccountService.updateCustomerAddress(customerId, advisorId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		request.setRequestBody(updateCustomerAddressDTO);
		MOServiceResponse response = post(request);
		if (response != null) {
			TypeToken<APIResponse<Map<String, String>>> typeToken = new TypeToken<APIResponse<Map<String, String>>>() {
			};
			APIResponse<Map<String, String>> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null
					&& apiResponse.getResponseMessage().getResponseCode() == ErrorCodes.SUCCESSFUL_RESPONSE
					&& (apiResponse.getObjectList() != null)) {
				responseList = apiResponse.getObjectList();
				sessionId = responseList.get("sessionDetails");
			}
		}
		return sessionId;
	}
	
	
	public Boolean saveDocument(MultipartFile nricFrontFile, MultipartFile nricBackFile, MultipartFile passportFile,
			MultipartFile mailingAddressProof, MultipartFile residentialAddressProof, MultipartFile beneficiaryPassport,
			MultipartFile supportingDocument, String details, String customerId) {
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		Boolean isDocumentSaved = false;
		MOServiceRequest request = new MOServiceRequest();
		Map<String, MultipartFile> files = new HashMap<>();
		files.put("nricFront", nricFrontFile);
		files.put("nricBack", nricBackFile);
		files.put("passport", passportFile);
		files.put("mailingAddressProof", mailingAddressProof);
		files.put("residentialAddressProof", residentialAddressProof);
		files.put("beneficiaryPassport", beneficiaryPassport);
		files.put("supportingDocument", supportingDocument);
		request.setUrl(URLDirectory.AccountService.saveDocumentForAdmin(customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		request.setFiles(files);
		MOServiceResponse response = formPost(request);
		if (response != null) {
			TypeToken<APIResponse<Boolean>> typeToken = new TypeToken<APIResponse<Boolean>>() {
			};
			APIResponse<Boolean> apiResponse = response.parseAbstractResponse(typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
					isDocumentSaved = apiResponse.getObjectList();
				}
		}
		return isDocumentSaved;
	}
		}

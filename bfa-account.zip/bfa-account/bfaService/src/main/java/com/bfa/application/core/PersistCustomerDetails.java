/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.UpdateCustomerRequest;
import com.bfa.request.entity.UpdateCustomerSelectedProductsRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

/**
 * @author pradheep.p
 *
 */
public class PersistCustomerDetails extends DiscoveryHelper implements Runnable {

	private UpdateCustomerRequest updateCustomerRequest;		

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private Environment environment;

	@Autowired
	private SecurityConstants constants;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@Override
	public void run() {
		getLogger().info("Updating the customer id details ");
		setEnvironment(environment);
		loadSecurityHeader(constants.TOKEN_NAME);
		updateFinancialNeedsData();
		updateInsuranceNeedsData();		
	}

	private void updateFinancialNeedsData() {
		getLogger().info("Updating the customer id in financial needs microservice ");
		String apiName = APIConstants.UPDATE_CUSTOMER_ID_API;
		String baseUrl = getBaseUrl(ServiceNames.FINANCIAL_NEED_MICROSERVICE) + apiName;
		baseUrl = removePortNumbers(baseUrl);
		String requestBody = getRequestBody();
		getLogger().info("Trying to call financial needs service :" + requestBody);
		getLogger().info("Printing the base url :" + baseUrl);
		addJobToQueue(baseUrl, requestBody, "update-customer-id-financial", 0);
	}

	private void updateInsuranceNeedsData() {
		getLogger().info("updating the customer id in insurance needs microservice");
		String apiName = APIConstants.UPDATE_CUSTOMER_ID_API;
		String baseUrl = getBaseUrl(ServiceNames.INSURANE_NEED_MICROSERVICE) + apiName;
		baseUrl = removePortNumbers(baseUrl);
		String requestBody = getRequestBody();
		getLogger().info("Updating the customer id in insuurance needs " + requestBody);
		getLogger().info("Printing the base url " + baseUrl);
		addJobToQueue(baseUrl, requestBody, "update-customer-id-insurance", 0);
	}	

	private String getRequestBody() {
		Gson gson = new Gson();
		String requestBody = gson.toJson(this.updateCustomerRequest);
		return requestBody;
	}	

	public UpdateCustomerRequest getUpdateCustomerRequest() {
		return updateCustomerRequest;
	}

	public void setUpdateCustomerRequest(UpdateCustomerRequest updateCustomerRequest) {
		this.updateCustomerRequest = updateCustomerRequest;
	}	
}

package com.bfa.application.discovery;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;

/**
 * 
 */

/**
 * @author pradheep.p
 *
 */
public class DiscoveryServiceImpl implements DiscoveryService {

	@Autowired
	private Environment environment;

	@Autowired
	private TokenProvider tokenProvider;

	private static final String defaultHostName = "discovery.base.url";

	public DiscoveryServiceImpl() {
		// created default constructor DiscoveryServiceImpl()
	}

	@Override
	public String getServiceInstanceByName(int port, String contextPath, String serviceName) {
		String defaultUrl = environment.getProperty(defaultHostName);
		String finalUrl = "";
		if (contextPath == null || "".equals(contextPath)) {
			if (port != 80 || port != 443) {
				finalUrl = defaultUrl + ":" + port + "/" + serviceName;
			}
		} else {
			if (port != 80 || port != 443) {
				finalUrl = defaultUrl + ":" + port + contextPath + "/" + serviceName;
			}
		}
		return finalUrl;
	}

	@Override
	public String preAuthorize() {
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		BFAGrandtedAuthority grantedAuthority = new BFAGrandtedAuthority("ROLE_USER");
		grantedAuthorities.add(grantedAuthority);
		return tokenProvider.getTokenString("-1", grantedAuthorities);
	}
	
	@Override
	public String preAuthorizeScheduler() {
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		BFAGrandtedAuthority grantedAuthority = new BFAGrandtedAuthority("SCHEDULER_JOB");
		grantedAuthorities.add(grantedAuthority);		
		return tokenProvider.getTokenString("-1", grantedAuthorities);
	}

	@Override
    public String preAuthorizeV2(Integer customerId) {
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        BFAGrandtedAuthority grantedAuthority = new BFAGrandtedAuthority("ROLE_USER");
        grantedAuthorities.add(grantedAuthority);
        BFAGrandtedAuthority signedgrantedAuthority = new BFAGrandtedAuthority("ROLE_SIGNED_USER");
        grantedAuthorities.add(signedgrantedAuthority);
        return tokenProvider.getTokenStringV2(customerId, grantedAuthorities);
    }
	
	@Override
	public String preAuthorize(List<GrantedAuthority> grantedAuthorities) {		
		return tokenProvider.getTokenString("-1", grantedAuthorities);
	}

}

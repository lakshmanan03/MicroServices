/**
 * 
 */
package com.bfa.application.exception;

/**
 * @author sureshkumar_su
 *
 */
public class DatabaseAccessException extends RuntimeException{	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DatabaseAccessException(){
		
	}
	
	public DatabaseAccessException(String message){
		super(message);
	}
}
package com.bfa.request.entity;

import java.util.List;

import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.ProtectionTypeEnum;
import com.bfa.hubspot.entity.HubspotDealRequest;
import com.bfa.insurance.product.ProductList;

public class CRMNewEnquiryRequest {

	private int customerId;

	private NewEnquiryRequest newEnquiryRequest;
	
	private List<ProductList> selectedProductList;

	private boolean newCustomer;
	
	
	/*  This fields are used in case the enquiry is made by email - BFA-1578*/
	
	private boolean isRequestByEmail = false;
	
	private String firstName;
	
	private String lastName;
	
	private String emailAddress;
	
	/* BFA-1729 */ 
	private JourneyTypeEnum journeyType;
	
	/* BFA-1729 */
	private ProtectionTypeEnum protectionType;
	
	/* Refers to the VID in Hubspot */
	private Integer hubspotReference = 0;
	
	private List<HubspotDealRequest> hubspotDealRequest;
	
	private Integer enquiryId;	
	
	/*------------------------------------------------------------------------------------------*/

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public NewEnquiryRequest getNewEnquiryRequest() {
		return newEnquiryRequest;
	}

	public void setNewEnquiryRequest(NewEnquiryRequest newEnquiryRequest) {
		this.newEnquiryRequest = newEnquiryRequest;
	}

	public List<ProductList> getSelectedProductList() {
		return selectedProductList;
	}

	public void setSelectedProductList(List<ProductList> selectedProductList) {
		this.selectedProductList = selectedProductList;
	}

	public boolean isNewCustomer() {
		return newCustomer;
	}

	public void setNewCustomer(boolean newCustomer) {
		this.newCustomer = newCustomer;
	}

	public boolean getIsRequestByEmail() {
		return isRequestByEmail;
	}

	public void setRequestByEmail(boolean isRequestByEmail) {
		this.isRequestByEmail = isRequestByEmail;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}	
	
	public JourneyTypeEnum getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(JourneyTypeEnum journeyType) {
		this.journeyType = journeyType;
	}

	public ProtectionTypeEnum getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(ProtectionTypeEnum protectionType) {
		this.protectionType = protectionType;
	}

	public Integer getHubspotReference() {
		return hubspotReference;
	}

	public void setHubspotReference(Integer hubspotReference) {
		this.hubspotReference = hubspotReference;
	}

	public List<HubspotDealRequest> getHubspotDealRequest() {
		return hubspotDealRequest;
	}

	public void setHubspotDealRequest(List<HubspotDealRequest> hubspotDealRequest) {
		this.hubspotDealRequest = hubspotDealRequest;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
}

/**
 * 
 */
package com.bfa.application.security;

/**
 * This service implementation has to be done to see if the authorization token
 * is black listed.
 * 
 * @author pradheep.p
 *
 */
public interface LogoutService {
	
	public static String NOT_BLACKLISTED = "No";
	
	public String isTokenBlackListed(String token) throws Exception;

}

/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.Household;
import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "customers")
public class Customer implements Serializable{

	private static final long serialVersionUID = 4416767423597655639L;

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private Integer id;

	@Column(name = "gender")
	private String gender;
	
	@Column(name = "nationality_code")
	private String nationalityCode;
	
	@Column(name = "date_of_birth")
	private String dateOfBirth;

	@Column(name = "is_smoker")
	private boolean isSmoker;

	@Column(name = "profession_status")
	private String professionStatus;

	@Column(name = "given_name")
	private String givenName;

	@Column(name = "sur_name")
	private String surName;
	
	@OneToOne
	@JoinColumn(name = "country_of_birth_id")
	private Country countryOfBirth;

	@Column(name = "email")
	private String email;

	@Column(name = "mobile_number")
	private String mobileNumber;

	@Column(name = "by_email")
	private boolean notificationByEmail;

	@JsonIgnore
	@Column(name = "password")
	private byte[] password;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "by_phone")
	private boolean notificationByPhone;

	@Column(name = "other_info")
	private String otherInfo;

	@Column(name = "subscribe")
	private String subscribe;

	@Column(name = "spam")
	private String spam;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "crm_id")
	private Integer crmId;
	
	@Column(name = "crm_agent_id")
	private String crmAgentId;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "crm_entity_type")
	private String crmEntityType;

	@Column(name = "last_updated_time_stamp")
	private String lastUpdatedTime;

	@Column(name = "salutation")
	private String salutation;

	@Column(name = "middle_name")
	private String middleName;

	@Column(name = "nric_name")
	private String nricName;

	@Column(name = "is_identity_verified")
	private boolean isIdentityVerified;

	@Column(name = "race")
	private String race;

	@JsonIgnore
	@Column(name = "otp")
	private String otpString;

	@JsonIgnore
	@Column(name = "otp_verified")
	private String otpVerfied;

	@JsonIgnore
	@Column(name = "email_verified")
	private String emailVerified;	

	@Column(name = "accept_market_emails")
	private boolean acceptMarketEmails;
	
	@OneToOne
	@JoinColumn(name = "home_address_id")
	private Address homeAddress;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "mailing_address_id")
	private Address mailingAddress;

	@OneToOne
	@JoinColumn(name = "household_id")
	private Household houseHoldDetail;
	
	
	@Column(name = "different_mailing_address_reason")
	private String differentMailingAddressReason;
	

	@Column(name = "different_mailing_address_id")
	private Integer differentMailingAddressReasonId;
	

	@Column(name="advisor_id")
	private Integer advisorId;
	
	/**
	 * This is to allow the user to edit the mobile number and email id during signup.
	 */	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@Column(name="verify_enq_id")
	private Integer verificationEnquiryId;
	
	/**
	 * This is to find if the link provided for password reset is valid 
	 */
	@Column(name="reset_token")
	private String resetToken;
	
	@JsonIgnore
	@Column(name="unique_id")
	private byte[] uniqueId;
	
	/**
	 * A new column added to capture PR flag for Robo3 relevant customer journey 
	 */
	
	@Column(name="comprehensive_nationality")
	private String nationalityStatus;
	
	@Column(name = "dob_updated_by")
	private String dobUpdatedBy;
	
	@Column(name="hubspot_ref")
	private Integer hubspotReference;

	
	public Country getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(Country countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public String getNationalityCode() {
		return nationalityCode;
	}

	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}

	public Household getHouseHoldDetail() {
		return houseHoldDetail;
	}

	public void setHouseHoldDetail(Household houseHoldDetail) {
		this.houseHoldDetail = houseHoldDetail;
	}

	public Address getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}

	public Address getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(Address mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getNricName() {
		return nricName;
	}

	public void setNricName(String nricName) {
		this.nricName = nricName;
	}

	public boolean isIdentityVerified() {
		return isIdentityVerified;
	}

	public void setIdentityVerified(boolean isIdentityVerified) {
		this.isIdentityVerified = isIdentityVerified;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}	

	public boolean isSmoker() {
		return isSmoker;
	}

	public void setSmoker(boolean isSmoker) {
		this.isSmoker = isSmoker;
	}

	public String getProfessionStatus() {
		return professionStatus;
	}

	public void setProfessionStatus(String professionStatus) {
		this.professionStatus = professionStatus;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public boolean isNotificationByEmail() {
		return notificationByEmail;
	}

	public byte[] getPassword() {
		return password;
	}

	public void setPassword(byte[] byte_password) {		
		this.password = byte_password;
	}

	public void setNotificationByEmail(boolean notificationByEmail) {
		this.notificationByEmail = notificationByEmail;
	}	

	public boolean isNotificationByPhone() {
		return notificationByPhone;
	}

	public void setNotificationByPhone(boolean notificationByPhone) {
		this.notificationByPhone = notificationByPhone;
	}

	public String getOtherInfo() {
		return otherInfo;
	}

	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}

	public String getSubscribe() {
		return subscribe;
	}

	public void setSubscribe(String subscribe) {
		this.subscribe = subscribe;
	}

	public String getSpam() {
		return spam;
	}

	public void setSpam(String spam) {
		this.spam = spam;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public Integer getCrmId() {
		return crmId;
	}

	public void setCrmId(Integer crmId) {
		this.crmId = crmId;
	}

	public String getCrmEntityType() {
		return crmEntityType;
	}

	public void setCrmEntityType(String crmEntityType) {
		this.crmEntityType = crmEntityType;
	}

	public String getOtpVerfied() {
		return otpVerfied;
	}

	public void setOtpVerfied(String otpVerfied) {
		this.otpVerfied = otpVerfied;
	}

	public String getEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(String emailVerified) {
		this.emailVerified = emailVerified;
	}

	public String getOtpString() {
		return otpString;
	}

	public void setOtpString(String otpString) {
		this.otpString = otpString;
	}

	public boolean isAcceptMarketEmails() {
		return acceptMarketEmails;
	}

	public void setAcceptMarketEmails(boolean acceptMarketEmails) {
		this.acceptMarketEmails = acceptMarketEmails;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	 public String getDateOfBirth() {
         return dateOfBirth;
  }

  public Date getFormattedDOB() {
         Date dob = null;
         if (dateOfBirth != null && !dateOfBirth.isEmpty()) {
                dob = formatDOB(dateOfBirth);
         }
         return dob;
  }
	
	private Date formatDOB(String dateOfBirth) {
		Date defaultDateFormat = null;
				String convertedDOB = null;
				try {
					defaultDateFormat = PublicUtility.parseDateString(dateOfBirth, "yyyy-MM-dd",null);
					if (defaultDateFormat == null) {
						defaultDateFormat = PublicUtility.parseDateString(dateOfBirth, "MM/dd/yyyy",null);
					}
					if (defaultDateFormat == null) {
						defaultDateFormat = PublicUtility.parseDateString(dateOfBirth, "yyyy-M-d", null);
					}
					if (defaultDateFormat == null) {
						defaultDateFormat = PublicUtility.parseDateString(dateOfBirth, "dd/MM/yyyy", null);
					}
					if (defaultDateFormat == null) {
						defaultDateFormat = PublicUtility.tryParseDate(dateOfBirth);
					}
					if (defaultDateFormat == null) {
						defaultDateFormat = new Date();
					}
				}
				catch(Exception ex) {
					// error log
				}
				return defaultDateFormat;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getVerificationEnquiryId() {
		return verificationEnquiryId;
	}

	public void setVerificationEnquiryId(Integer verificationEnquiryId) {
		this.verificationEnquiryId = verificationEnquiryId;
	}

	public String getCrmAgentId() {
		return crmAgentId;
	}

	public void setCrmAgentId(String crmAgentId) {
		this.crmAgentId = crmAgentId;
	}

	public String getResetToken() {
		return resetToken;
	}

	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}
	
	public String getDifferentMailingAddressReason() {
		return differentMailingAddressReason;
	}

	public void setDifferentMailingAddressReason(String differentMailingAddressReason) {
		this.differentMailingAddressReason = differentMailingAddressReason;
	}

	public Integer getDifferentMailingAddressReasonId() {
		return differentMailingAddressReasonId;
	}

	public void setDifferentMailingAddressReasonId(Integer differentMailingAddressReasonId) {
		this.differentMailingAddressReasonId = differentMailingAddressReasonId;
	}

	public Integer getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(Integer advisorId) {
		this.advisorId = advisorId;
	}

	public byte[] getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(byte[] uniqueId) {
		this.uniqueId = uniqueId;
	}


	public String getNationalityStatus() {
		return nationalityStatus;
	}

	public void setNationalityStatus(String nationalityStatus) {
		this.nationalityStatus = nationalityStatus;
	}

	public String getDobUpdatedBy() {
		return dobUpdatedBy;
	}

	public void setDobUpdatedBy(String dobUpdatedBy) {
		this.dobUpdatedBy = dobUpdatedBy;
	}

	public Integer getHubspotReference() {
		return hubspotReference;
	}

	public void setHubspotReference(Integer hubspotReference) {
		this.hubspotReference = hubspotReference;
	}

}

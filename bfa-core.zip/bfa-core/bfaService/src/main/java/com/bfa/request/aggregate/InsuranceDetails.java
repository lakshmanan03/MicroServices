/**
 * 
 */
package com.bfa.request.aggregate;

import java.util.List;

import com.bfa.insurance.core.CriticalIllnessNeeds;
import com.bfa.insurance.core.ExistingInsurance;
import com.bfa.insurance.core.HospitalizationNeeds;
import com.bfa.insurance.core.LifeProtectionNeeds;
import com.bfa.insurance.core.LongTermCareNeeds;
import com.bfa.insurance.core.OccupationalDisabilityNeeds;
import com.bfa.insurance.core.RetirementIncomePlan;
import com.bfa.insurance.core.SRSApprovedPlans;

/**
 *  This class is to aggregate the results of insurance journey.
 *  
 * @author pradheep
 *
 */
public class InsuranceDetails {
	
	private LifeProtectionNeeds lifeProtectionNeeds;
	
	private OccupationalDisabilityNeeds occupationalDisabilityNeeds;
	
	private ExistingInsurance existingInsurance;
	
	private CriticalIllnessNeeds criticalIllnessNeedsData;

	private HospitalizationNeeds hospitalizationNeeds;

	private LongTermCareNeeds longTermCareNeeds;

	private SRSApprovedPlans srsApprovedPlans;

	private RetirementIncomePlan retirementIncomePlan;

	public LifeProtectionNeeds getLifeProtectionNeeds() {
		return lifeProtectionNeeds;
	}

	public void setLifeProtectionNeeds(LifeProtectionNeeds lifeProtectionNeeds) {
		this.lifeProtectionNeeds = lifeProtectionNeeds;
	}

	public OccupationalDisabilityNeeds getOccupationalDisabilityNeeds() {
		return occupationalDisabilityNeeds;
	}

	public void setOccupationalDisabilityNeeds(OccupationalDisabilityNeeds occupationalDisabilityNeeds) {
		this.occupationalDisabilityNeeds = occupationalDisabilityNeeds;
	}

	public ExistingInsurance getExistingInsurance() {
		return existingInsurance;
	}

	public void setExistingInsurance(ExistingInsurance existingInsurance) {
		this.existingInsurance = existingInsurance;
	}

	public CriticalIllnessNeeds getCriticalIllnessNeedsData() {
		return criticalIllnessNeedsData;
	}

	public void setCriticalIllnessNeedsData(CriticalIllnessNeeds criticalIllnessNeedsData) {
		this.criticalIllnessNeedsData = criticalIllnessNeedsData;
	}

	public HospitalizationNeeds getHospitalizationNeeds() {
		return hospitalizationNeeds;
	}

	public void setHospitalizationNeeds(HospitalizationNeeds hospitalizationNeeds) {
		this.hospitalizationNeeds = hospitalizationNeeds;
	}

	public LongTermCareNeeds getLongTermCareNeeds() {
		return longTermCareNeeds;
	}

	public void setLongTermCareNeeds(LongTermCareNeeds longTermCareNeeds) {
		this.longTermCareNeeds = longTermCareNeeds;
	}

	public SRSApprovedPlans getSrsApprovedPlans() {
		return srsApprovedPlans;
	}

	public void setSrsApprovedPlans(SRSApprovedPlans srsApprovedPlans) {
		this.srsApprovedPlans = srsApprovedPlans;
	}

	public RetirementIncomePlan getRetirementIncomePlan() {
		return retirementIncomePlan;
	}

	public void setRetirementIncomePlan(RetirementIncomePlan retirementIncomePlan) {
		this.retirementIncomePlan = retirementIncomePlan;
	}
	
}

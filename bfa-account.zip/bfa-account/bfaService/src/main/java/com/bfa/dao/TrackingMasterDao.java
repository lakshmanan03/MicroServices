package com.bfa.dao;

import java.util.List;

import com.bfa.application.core.CustomerPreference;
import com.bfa.application.core.Tracker;

public interface TrackingMasterDao {
	Boolean trackCodeExists(String trackCode);
}

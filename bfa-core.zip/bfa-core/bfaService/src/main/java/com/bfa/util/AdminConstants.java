package com.bfa.util;

public class AdminConstants {
	public static class SortType {
		public static String SortingCustomerId = "id";
		public static String SortingCustomerName = "customer_name";
		public static String AscendingOrder = "asc";
		public static String DescendingOrder = "desc";
		
		public static String CustomerId = "moCustomerId";
		public static String CustomerName = "customerName";
		
	}
}

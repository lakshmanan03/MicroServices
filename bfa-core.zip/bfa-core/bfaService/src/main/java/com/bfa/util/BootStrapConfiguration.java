/**
 * 
 */
package com.bfa.util;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.application.discovery.DiscoveryService;
import com.bfa.application.discovery.DiscoveryServiceImpl;
import com.bfa.application.event.BFAApplicationEventPublisher;
import com.bfa.application.security.SecurityConstants;
import com.bfa.application.security.TokenEncryptor;
import com.bfa.application.security.TokenProvider;
import com.bfa.request.aggregate.DefaultFailureHandler;
import com.bfa.request.aggregate.DefaultSuccessHandler;
import com.bfa.request.processor.ApplicationProcessorQueue;
import com.bfa.request.processor.EventBuilderUtility;
import com.bfa.request.processor.HttpProcessorCommand;
import com.bfa.request.processor.HttpProcessorGetCommand;
import com.bfa.request.processor.HttpRequestFailureHandler;
import com.bfa.request.processor.HttpRequestSuccessHandler;
import com.bfa.request.processor.QueueProcessorController;

import com.bfa.servicehelper.MOAccountService;
import com.bfa.servicehelper.MOFinancialService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.servicehelper.MONotificationService;

import brave.Tracing;

/**
 * @author pradheep.p
 *
 */
@Configuration
public class BootStrapConfiguration {
	
	@Autowired
	private Tracing tracing;
	
	@Bean
	public BFAApplicationEventPublisher getApplicationEventPublisher() {
		return new BFAApplicationEventPublisher();
	}

	@Bean
	public ApplicationProcessorQueue getApplicationProcessorQueue() {
		return new ApplicationProcessorQueue();
	}

	@Bean
	public QueueProcessorController getQueueProcessorController() {
		return new QueueProcessorController();
	}

	@Bean(value="bfaHttpClient")
	@Scope("prototype")
	public BFAHttpClient getBFAHttpClient() {
		BFAHttpClient httpClient = new BFAHttpClient();
		return httpClient;
	}

	@Bean(name = "httpProcessorCommand")
	@Scope("prototype")
	public HttpProcessorCommand getHttpProcessorCommand() {
		return new HttpProcessorCommand();
	}

	@Bean(name = "httpSuccessHandler")
	@Scope("prototype")
	public HttpRequestSuccessHandler getHttpRequestSuccessHandler() {
		return new HttpRequestSuccessHandler();
	}

	@Bean(name = "httpFailureHandler")
	@Scope("prototype")
	public HttpRequestFailureHandler getHttpRequestFailureHandler() {
		return new HttpRequestFailureHandler();
	}

	@Bean
	public EventBuilderUtility getEventBuilderUtility() {
		return new EventBuilderUtility();
	}

	@Bean
	public ThreadPoolTaskExecutor getThreadPoolTaskExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setCorePoolSize(15);
		threadPoolTaskExecutor.setMaxPoolSize(500);
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setThreadNamePrefix("BFA");
		threadPoolTaskExecutor.setQueueCapacity(70000);
		threadPoolTaskExecutor.initialize();
		return threadPoolTaskExecutor;
	}

	@Bean
	public TokenProvider getTokenProvider() {
		return new TokenProvider();
	}

	@Bean(value = "securityConstants")
	@Scope("singleton")
	public SecurityConstants getSecurityConstants() {
		SecurityConstants constants = new SecurityConstants();
		constants.assignKey();
		return constants;
	}

	@Bean(value = "tokenEncryptor")
	public TokenEncryptor getTokenEncryptor() {
		return new TokenEncryptor();
	}

	@Bean
	public MOInvestmentService getMOInvestmentService() {
		return new MOInvestmentService();
	}

	@Bean
	public DiscoveryService getDiscoveryService() {
		return new DiscoveryServiceImpl();

	}

	@Bean(name = "httpProcessorGetCommand")
	@Scope("prototype")
	public HttpProcessorGetCommand getHttpProcessorGetCommand() {
		HttpProcessorGetCommand httpProcessorGetCommand = new HttpProcessorGetCommand();
		return httpProcessorGetCommand;
	}

	@Bean(name = "defaultSuccessHandler")
	@Scope("prototype")
	public DefaultSuccessHandler getDefaultSuccessHandler() {
		DefaultSuccessHandler defaultSuccessHandler = new DefaultSuccessHandler();
		return defaultSuccessHandler;
	}

	@Bean(name = "defaultFailureHandler")
	@Scope("prototype")
	public DefaultFailureHandler getDefaultFailureHandler() {
		DefaultFailureHandler defaultFailureHandler = new DefaultFailureHandler();
		return defaultFailureHandler;
	}

	@Bean(name = "moFinancialService")
	public MOFinancialService getMOFinancialService() {
		return new MOFinancialService();
	}	
	
	
	@Bean(name = "moAccountService")
	public MOAccountService getMOAccountService() {
		return new MOAccountService();
	}
	
	@Bean(name = "moNotificationService")
	public MONotificationService getMONotificationService() {
		return new MONotificationService();
	}
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}

package com.bfa.investment.ifast.dto;

import java.util.List;

public class IFastPortfolioDetail {

	private DPMSPortfolioDisplay dpmsPortfolioDisplay;
	private DPMSPortfolioAllocationDisplay dpmsPortfolioAllocationDisplay;
	private List<DPMSPortfolioProductDtlDisplay> dpmsPortfolioProductDtlDisplay;
	public DPMSPortfolioDisplay getDpmsPortfolioDisplay() {
		return dpmsPortfolioDisplay;
	}
	public void setDpmsPortfolioDisplay(DPMSPortfolioDisplay dpmsPortfolioDisplay) {
		this.dpmsPortfolioDisplay = dpmsPortfolioDisplay;
	}
	public DPMSPortfolioAllocationDisplay getDpmsPortfolioAllocationDisplay() {
		return dpmsPortfolioAllocationDisplay;
	}
	public void setDpmsPortfolioAllocationDisplay(DPMSPortfolioAllocationDisplay dpmsPortfolioAllocationDisplay) {
		this.dpmsPortfolioAllocationDisplay = dpmsPortfolioAllocationDisplay;
	}
	public List<DPMSPortfolioProductDtlDisplay> getDpmsPortfolioProductDtlDisplay() {
		return dpmsPortfolioProductDtlDisplay;
	}
	public void setDpmsPortfolioProductDtlDisplay(List<DPMSPortfolioProductDtlDisplay> dpmsPortfolioProductDtlDisplay) {
		this.dpmsPortfolioProductDtlDisplay = dpmsPortfolioProductDtlDisplay;
	}
	
	
	

}

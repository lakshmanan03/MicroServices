package com.bfa.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.sleuth.sampler.ProbabilityBasedSampler;
import org.springframework.cloud.sleuth.sampler.SamplerProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bfa.application.core.PersistCustomerDetails;
import com.bfa.application.core.PersistCustomerIDForEnquiry;
import com.bfa.application.core.PersistCustomerSelectedProducts;
import com.bfa.application.core.PersistEmailEnqDetails;
import com.bfa.application.core.UpdateEnquiryIdInWills;
import com.bfa.application.discovery.DiscoveryService;
import com.bfa.application.discovery.DiscoveryServiceImpl;
import com.bfa.application.security.SecurityConstants;

import com.bfa.dao.AccountsDao;
import com.bfa.dao.CustomerAMLDao;
import com.bfa.dao.CustomerDocumentDAO;
import com.bfa.dao.CustomerPreferenceDao;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.dao.SecurityDao;
import com.bfa.dao.TrackingMasterDao;
import com.bfa.daoimpl.AccountsDaoImpl;
import com.bfa.daoimpl.CustomerAMLDaoImpl;
import com.bfa.daoimpl.CustomerDocumentDetailsDaoImpl;
import com.bfa.daoimpl.CustomerPreferenceDaoImpl;
import com.bfa.daoimpl.FinlitDAOImpl;
import com.bfa.daoimpl.InvestmentAccountDaoImpl;
import com.bfa.daoimpl.SecurityDaoImpl;
import com.bfa.daoimpl.TrackingMasterDaoImpl;
import com.bfa.notification.messenger.BFAMessenger;
import com.bfa.notification.messenger.EmailHelper;
import com.bfa.notification.messenger.MessengerDelegate;
import com.bfa.notification.messenger.SMSGatewayActivator;
import com.bfa.notification.messenger.SMSGatewayPoller;
import com.bfa.notification.messenger.SMSInitiator;
import com.bfa.notification.messenger.SMSMessenger;
import com.bfa.notification.messenger.VerifyEmailInitiator;
import com.bfa.notification.messenger.WelcomeEmailInitiator;
import com.bfa.service.AMLVerificationService;
import com.bfa.service.AccountsService;
import com.bfa.service.BundleService;
import com.bfa.service.CommunicationService;
import com.bfa.service.CustomerDocumentDetailService;
import com.bfa.service.CustomerEnquiryService;
import com.bfa.service.EnquiryService;
import com.bfa.service.FinlitService;
import com.bfa.service.InvestmentAccountService;
import com.bfa.service.MailChimpService;
import com.bfa.service.PromoCodeService;
import com.bfa.service.RetirementLeadService;
import com.bfa.servicehelper.MOServiceHelper;
import com.bfa.serviceimpl.AccountLogoutService;
import com.bfa.serviceimpl.AccountsServiceImpl;
import com.bfa.serviceimpl.ArtemisAMLVerificationService;
import com.bfa.serviceimpl.BundleServiceImpl;
import com.bfa.serviceimpl.CRMBundleUpdater;
import com.bfa.serviceimpl.CRMServiceUpdater;
import com.bfa.serviceimpl.CRMUpdateThreadForEmailRequest;
import com.bfa.serviceimpl.CRMUpdaterForRetirementLeads;
import com.bfa.serviceimpl.CaptchaProvider;
import com.bfa.serviceimpl.CleanupBlackListedTokens;
import com.bfa.serviceimpl.CommunicationServiceImpl;
import com.bfa.serviceimpl.CreateHubspotContactService;
import com.bfa.serviceimpl.CustomerDocumentDetailsServiceImpl;
import com.bfa.serviceimpl.CustomerEnquiryServiceImpl;
import com.bfa.serviceimpl.DefaultEnquiryService;
import com.bfa.serviceimpl.DefaultPasswordEncryptionService;
import com.bfa.serviceimpl.DelegateHandler;
import com.bfa.serviceimpl.EnquiryServiceUpdater;
import com.bfa.serviceimpl.FileUploader;
import com.bfa.serviceimpl.FinlitServiceImpl;
import com.bfa.serviceimpl.InvestmentAccountServiceImpl;
import com.bfa.serviceimpl.MailChimpServiceImpl;
import com.bfa.serviceimpl.PromoCodeServiceImpl;
import com.bfa.serviceimpl.ReissueOTPRunnable;
import com.bfa.serviceimpl.RetirementServiceImpl;
import com.bfa.serviceimpl.ScheduledJobRunner;
import com.bfa.serviceimpl.SecurityUtility;
import com.bfa.serviceimpl.UploadService;
import com.bfa.serviceimpl.UserAuthTokenUpdater;
import com.bfa.util.AmazonS3ClientService;
import com.bfa.util.AmazonS3ClientServiceImpl;
import com.bfa.util.BootStrapConfiguration;
import com.bfa.util.MOEmailSQSClient;
import com.bfa.util.PublicUtility;

@Configuration
@EnableAsync
@ComponentScan({ "com.bfa.controllers" ,"com.bfa.components"})
@EntityScan(basePackages = { "com.bfa.application.core" })
@EnableJpaRepositories({ "com.bfa.repository" })
@SpringBootApplication
@Import({ SwaggerConfig.class, CustomWebSecurityConfigurerAdapter.class, BootStrapConfiguration.class,
		DBConfiguration.class, SMSConfiguration.class, JpaAuditConfig.class,ComprehensiveJourneyConfiguration.class })
public class AccountServiceConfiguration extends SpringBootServletInitializer {

	@Autowired
	private Environment environment;
	
	@Override
	public SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		super.configure(builder);
		builder.initializers(new PropertySouceInitializer());
		return builder;
	}

	@Bean
	public AmazonS3ClientService getAmazonS3ClientService() {
		return new AmazonS3ClientServiceImpl();
	}

	@Bean
	public AMLVerificationService getAMLVerificationService() {
		return new ArtemisAMLVerificationService();
	}

	@Bean
	public CustomerAMLDao getCustomerAMLDao() {
		return new CustomerAMLDaoImpl();
	}

	@Bean
	public MOEmailSQSClient getMOEmailSQSClient() {
		return new MOEmailSQSClient();
	}
	
	@Bean(name = "moServiceHelper")
	public MOServiceHelper getMOServiceHelper() {
		return new MOServiceHelper();
	}

	@Bean
	public CustomerDocumentDetailService getCustomerDocumentDetails() {
		return new CustomerDocumentDetailsServiceImpl();
	}

	@Bean
	public CustomerDocumentDAO getCustomerDocumentDao() {
		return new CustomerDocumentDetailsDaoImpl();
	}
	
	@Bean TrackingMasterDao getTrackingMasterDao() {
		return new TrackingMasterDaoImpl();
	}
	
	@Bean CustomerPreferenceDao getCustomerPreferenceDao() {
		return new CustomerPreferenceDaoImpl();
	}

	@Bean
	public InvestmentAccountService getInvestmentAccountService() {
		return new InvestmentAccountServiceImpl();
	}

	@Bean
	public InvestmentAccountDao getInvestmentAccountDao() {
		return new InvestmentAccountDaoImpl();
	}

	@Bean(value = "applicationLoggerBean")
	public ApplicationLoggerBean getApplicationLoggerBean() {
		return new ApplicationLoggerBean();
	}

	@Bean
	public AccountsService getInsuranceNeedsService() {
		return new AccountsServiceImpl();
	}

	@Bean(value="accountsDAO")
	public AccountsDao getAccountsDao() {
		return new AccountsDaoImpl();
	}

	@Bean
	public CustomerEnquiryService getCustomerEnquiryService() {
		return new CustomerEnquiryServiceImpl();
	}

	@Bean
	public ProbabilityBasedSampler getSampler() {
		SamplerProperties configuration = new SamplerProperties();
		configuration.setProbability(1.0f);
		return new ProbabilityBasedSampler(configuration);
	}

	@Bean(value = "securityConstants")
	@Scope("singleton")
	public SecurityConstants getSecurityConstants() {
		SecurityConstants constants = new SecurityConstants();
		constants.assignKey();
		return constants;
	}

	@Bean(value = "persistCustomerDetails")
	@Scope("prototype")
	public PersistCustomerDetails getPersistCustomerDetails() {
		return new PersistCustomerDetails();
	}

	@Bean(value = "crmServiceUpdater")
	@Scope("prototype")
	public CRMServiceUpdater getCRMUpdater() {
		return new CRMServiceUpdater();
	}

	@Bean
	public DelegateHandler getDelegateHandler() {
		return new DelegateHandler();
	}
	
	@Bean
	public DiscoveryService getDiscoveryService() {
		return new DiscoveryServiceImpl();
	}

	@Bean(name = "emailMessenger")
	@Scope("prototype")
	public BFAMessenger getEmailMessenger() {
		return new BFAMessenger();
	}

	@Bean(name = "smsMessenger")
	@Scope("prototype")
	public SMSMessenger getSMSMessenger() {
		return new SMSMessenger();
	}

	@Bean(name = "notificationDelegator")
	public MessengerDelegate getNotificationDelegate() {
		return new MessengerDelegate();
	}

	@Bean(value = "communicator")
	@Scope("prototype")
	public SMSInitiator getCommunicator() {
		return new SMSInitiator();
	}

	@Bean(value = "verifyEmailInitiator")
	@Scope("prototype")
	public VerifyEmailInitiator getEmailCommunicator() {
		return new VerifyEmailInitiator();
	}
	
	@Bean(value = "welcomeEmailInitiator")
	@Scope("prototype")
	public WelcomeEmailInitiator getWelcomeEmailCommunicator() {
		return new WelcomeEmailInitiator();
	}

	@Bean(value = "emailHelper")
	@Scope("prototype")
	public EmailHelper getEmailHelper() {
		return new EmailHelper();
	}

	@Bean(value = "smsGatewayActivator")
	@Scope("singleton")
	public SMSGatewayActivator getSMSGatewayActivator() {
		return new SMSGatewayActivator();
	}

	@Bean(value = "smsGatewayPoller")
	public SMSGatewayPoller getSMSGatewayPoller() {
		return new SMSGatewayPoller();
	}

	@Bean(value = "captchaProvider")
	public CaptchaProvider getCaptchaProvider() {
		return new CaptchaProvider();
	}

	@Bean(value = "enquiryServiceUpdater")
	@Scope("prototype")
	public EnquiryServiceUpdater getEnquiryServiceUpdater() {
		return new EnquiryServiceUpdater();
	}

	@Bean
	public PromoCodeService getPromoCodeService() {
		return new PromoCodeServiceImpl();
	}

	@Bean
	public AccountLogoutService getLogoutService() {
		return new AccountLogoutService();
	}

	@Bean
	public SecurityContextHolder getSecurityContextHolder() {
		return new SecurityContextHolder();
	}

	@Bean
	public ScheduledJobRunner getScheduledJobRunner() {
		return new ScheduledJobRunner();
	}

	@Bean
	public CleanupBlackListedTokens getCleanupBlackListedTokens() {
		return new CleanupBlackListedTokens();
	}

	@Bean(value = "userAuthTokenUpdater")
	@Scope("prototype")
	public UserAuthTokenUpdater getUserAuthTokenUpdater() {
		return new UserAuthTokenUpdater();
	}

	@Bean
	public ClassPathResource getClassPathresource() {
		String activeProfile = PublicUtility.getActiveProfile(environment);
		return new ClassPathResource("mail_template-" + activeProfile +".properties");
	}

	@Bean(value = "uploadService")
	@Scope("prototype")
	public UploadService getUploadService() {
		return new UploadService();
	}

	@Bean(value = "fileUploader")
	@Scope("prototype")
	public FileUploader getFileUploader() {
		return new FileUploader();
	}

	@Bean(value = "securityUtility")
	protected SecurityUtility getSecurityUtility() {
		return new SecurityUtility();
	}

	@Bean
	public DefaultPasswordEncryptionService getPasswordEncryptionService() {
		DefaultPasswordEncryptionService passwordEncryptionService = new DefaultPasswordEncryptionService();
		passwordEncryptionService.setSecurityUtility(getSecurityUtility());
		return passwordEncryptionService;
	}

	@Bean
	public CommunicationService getCommunicationService() {
		return new CommunicationServiceImpl();
	}

	@Bean(value="reissueOTPRunnable")
	@Scope("prototype")
	public ReissueOTPRunnable getReissueOTPRunnable() {
		return new ReissueOTPRunnable();
	}
	
	@Bean(value="updateEnquiryIdInWills")
	@Scope("prototype")
	public UpdateEnquiryIdInWills getUpdateEnquiryIdInWills(){
		return new UpdateEnquiryIdInWills();
	}
	
	@Bean(value="persistCustomerIdForEnquiry")
	@Scope("prototype")
	public PersistCustomerIDForEnquiry getPersistCustomerIDForEnquiry(){
		return new PersistCustomerIDForEnquiry();
	}
	
	@Bean(value="persistCustomerSelectedProducts")
	@Scope("prototype")
	public PersistCustomerSelectedProducts getPersistCustomerSelectedProducts(){
		PersistCustomerSelectedProducts  persistCustomerSelectedProducts = new PersistCustomerSelectedProducts();
		return persistCustomerSelectedProducts;
	}
	
	@Bean
	public BundleService getBundleService(){
		return new BundleServiceImpl();
	}
	
	@Bean
	public EnquiryService getEnquiryService(){
		EnquiryService enquiryService = new DefaultEnquiryService();
		return enquiryService;
	}
	
	@Bean(value="persistEmailEnqDetails")
	@Scope("prototype")
	public PersistEmailEnqDetails getPersistEmailEnqDetails(){
		PersistEmailEnqDetails  persistEmailEnqDetails = new PersistEmailEnqDetails();
		return persistEmailEnqDetails;
	}
	
	@Bean(value="crmUpdateThreadForEmailRequest")
	@Scope("prototype")
	public CRMUpdateThreadForEmailRequest getCRMUpdateThreadForEmailRequest(){
		CRMUpdateThreadForEmailRequest  crmUpdateThreadForEmailRequest = new CRMUpdateThreadForEmailRequest();
		return crmUpdateThreadForEmailRequest;
	}
	
	@Bean(value="updateCRMForRetirementLeads")
	@Scope("prototype")
	public CRMUpdaterForRetirementLeads getCRMUpdaterForRetirementLeads(){
		CRMUpdaterForRetirementLeads  cRMUpdaterForRetirementLeads = new CRMUpdaterForRetirementLeads();
		return cRMUpdaterForRetirementLeads;
	}
	
	@Bean
	public RetirementLeadService getRetirementLeadService(){
		RetirementLeadService retirementLeadService = new RetirementServiceImpl();
		return retirementLeadService;
	}
	
	@Bean("crmBundleUpdater")
	@Scope("prototype")
	public CRMBundleUpdater getBundleUpdater(){
		CRMBundleUpdater crmBundleUpdater = new CRMBundleUpdater();
		return crmBundleUpdater;
	}
	
	@Bean("finlitService")
	public FinlitService getFinlitService(){
		FinlitServiceImpl finlitService = new FinlitServiceImpl();
		return finlitService;
	}
	@Bean("mailChimpService")
	public MailChimpService getMailChimpService(){
		MailChimpService mailChimpService = new MailChimpServiceImpl();
		return mailChimpService;
	}
	
	@Bean
	public FinlitDAOImpl getFinlitDAO(){
		return new FinlitDAOImpl();
	}	
	
	@Bean(value="securityDAO")
	public SecurityDao getSecurityDao(){
		return new SecurityDaoImpl();
	}
	
	@Bean(value="createHubspotContactService")
	public CreateHubspotContactService getCreateHubspotContactService(){
		return new CreateHubspotContactService();
	}
}

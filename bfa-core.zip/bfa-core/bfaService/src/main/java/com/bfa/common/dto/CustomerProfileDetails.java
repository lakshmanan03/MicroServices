package com.bfa.common.dto;

import java.util.List;

import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.investment.dto.CustomerEmploymentInfo;
import com.bfa.investment.entity.CustomerDocumentDetails;

public class CustomerProfileDetails {
	
	private CustomerPersonalInformation personalInformation;
	private CustomerContactDetails contactDetails;
	private CustomerEmploymentInfo employmentDetails;
	private List<CustomerDocumentDetails> documentDetails;
	private List<CustomerBankDetail> customerBankDetail;
	
	public List<CustomerBankDetail> getCustomerBankDetail() {
		return customerBankDetail;
	}
	public List<CustomerDocumentDetails> getDocumentDetails() {
		return documentDetails;
	}
	public void setDocumentDetails(List<CustomerDocumentDetails> documentDetails) {
		this.documentDetails = documentDetails;
	}
	public void setCustomerBankDetail(List<CustomerBankDetail> customerBankDetail) {
		this.customerBankDetail = customerBankDetail;
	}
	public CustomerPersonalInformation getPersonalInformation() {
		return personalInformation;
	}
	public void setPersonalInformation(CustomerPersonalInformation personalInformation) {
		this.personalInformation = personalInformation;
	}
	public CustomerContactDetails getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(CustomerContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}
	
	public CustomerEmploymentInfo getEmploymentDetails() {
		return employmentDetails;
	}
	public void setEmploymentDetails(CustomerEmploymentInfo employmentDetails) {
		this.employmentDetails = employmentDetails;
	}
	
	
	
	

}

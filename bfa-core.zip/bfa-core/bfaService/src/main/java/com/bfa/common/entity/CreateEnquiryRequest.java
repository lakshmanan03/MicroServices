/**
 * 
 */
package com.bfa.common.entity;

/**
 * 
 * @author GajendraK
 *
 */
public class CreateEnquiryRequest {

	/**
	 * Accepted values are 1. insurance-guided 2. insurance-direct 3.investment
	 * 4. will-writing
	 */
	private String requestType;	
	
	private String sessionId;
	
	private String promoCodeId;
	
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getPromoCodeId() {
		return promoCodeId;
	}

	public void setPromoCodeId(String promoCodeId) {
		this.promoCodeId = promoCodeId;
	}
	
}

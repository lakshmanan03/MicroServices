package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.investment.entity.CustomerIFastAccount;

public interface CustomeriFASTAccountRepository extends CrudRepository<CustomerIFastAccount, String> {
	Optional<CustomerIFastAccount>  findFirstBycustomer_id(Integer customerId);

}

/**
 * 
 */
package com.bfa.common.entity;

import java.io.Serializable;

/**
 * @author pradheep.p
 *
 */
public class CustomerLoginData implements Serializable{

	private String customerIdEncrypted;

	public String getCustomerIdEncrypted() {
		return customerIdEncrypted;
	}

	public void setCustomerIdEncrypted(String customerIdEncrypted) {
		this.customerIdEncrypted = customerIdEncrypted;
	}	
	
}

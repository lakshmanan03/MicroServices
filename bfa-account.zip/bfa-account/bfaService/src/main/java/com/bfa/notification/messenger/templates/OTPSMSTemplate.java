/**
 * 
 */
package com.bfa.notification.messenger.templates;

/**
 * @author pradheep.p
 *
 */
public class OTPSMSTemplate extends BFATemplate {

	private String message;
	
	private String suffix = " is your MoneyOwl OTP Code. It will expire in 2 minutes.";	

	public OTPSMSTemplate(String arg) {
		this.message = arg;
	}

	@Override
	public String getFormatString() {
		return message + suffix;
	}

	@Override
	public int getType() {
		return TemplateType.SMS_OTP_TEMPLATE;
	}

}

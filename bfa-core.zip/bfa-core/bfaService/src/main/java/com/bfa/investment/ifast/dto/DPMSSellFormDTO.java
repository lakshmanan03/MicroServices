package com.bfa.investment.ifast.dto;

public class DPMSSellFormDTO implements IFastRequestObject {

	private String agentId;
	private String redemptionAmount;// initialInvestment cust invest obj
	private String redemptionCurrency;
	private String portfolioId;//
	private String refno;
	private String paymentMode;
	private String redeemAll = "N";
	
	
	
	
	public String getRedeemAll() {
		return redeemAll;
	}
	public void setRedeemAll(String redeemAll) {
		this.redeemAll = redeemAll;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getRedemptionAmount() {
		return redemptionAmount;
	}
	public void setRedemptionAmount(String redemptionAmount) {
		this.redemptionAmount = redemptionAmount;
	}
	public String getRedemptionCurrency() {
		return redemptionCurrency;
	}
	public void setRedemptionCurrency(String redemptionCurrency) {
		this.redemptionCurrency = redemptionCurrency;
	}
	public String getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	@Override
	public String toString() {
		return "DPMSSellFormDTO [agentId=" + agentId + ", redemptionAmount=" + redemptionAmount
				+ ", redemptionCurrency=" + redemptionCurrency + ", portfolioId=" + portfolioId + ", refno=" + refno
				+ ", paymentMode=" + paymentMode + ", redeemAll=" + redeemAll + "]";
	}
	@Override
	public String getReferenceNumber() {
		return this.refno;
	}
	
	

}

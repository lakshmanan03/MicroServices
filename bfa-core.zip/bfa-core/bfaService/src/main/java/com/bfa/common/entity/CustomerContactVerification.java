package com.bfa.common.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;

@Entity
@Table(name = "customer_contact_verification")
public class CustomerContactVerification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@Column(name = "mobile_number")
	private String mobileNumber;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "otp_verified")
	private String otpVerifiedStatus;
	
	@Column(name = "email_verified")
	private String emailVerifiedStatus;
	
	@Column(name = "otp")
	private String	OTPString;
	
	@Column(name = "country_code")
	private String	countryCode;
	
	@Column(name="otp_time_issued")
	private Timestamp otpTimeIssued;
	
	@Column(name="session_id")
	private String sessionId;
	
	@Column(name="action_type")
	private String actionType;
	
	@Column(name="otp_verified_time")
	private Timestamp otpVerifiedTime;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOtpVerifiedStatus() {
		return otpVerifiedStatus;
	}

	public void setOtpVerifiedStatus(String otpVerifiedStatus) {
		this.otpVerifiedStatus = otpVerifiedStatus;
	}

	public String getEmailVerifiedStatus() {
		return emailVerifiedStatus;
	}

	public void setEmailVerifiedStatus(String emailVerifiedStatus) {
		this.emailVerifiedStatus = emailVerifiedStatus;
	}

	public String getOTPString() {
		return OTPString;
	}

	public void setOTPString(String oTPString) {
		OTPString = oTPString;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public Timestamp getOtpTimeIssued() {
		return otpTimeIssued;
	}

	public void setOtpTimeIssued(Timestamp otpTimeIssued) {
		this.otpTimeIssued = otpTimeIssued;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Timestamp getOtpVerifiedTime() {
		return otpVerifiedTime;
	}

	public void setOtpVerifiedTime(Timestamp otpVerifiedTime) {
		this.otpVerifiedTime = otpVerifiedTime;
	}	
	
}

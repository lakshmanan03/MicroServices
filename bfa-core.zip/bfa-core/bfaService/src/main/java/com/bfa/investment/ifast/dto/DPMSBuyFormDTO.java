
package com.bfa.investment.ifast.dto;

public class DPMSBuyFormDTO extends BuyFormDTO {

	private Double investmentAmount;//initialInvestment	cust invest obj

	public Double getInvestmentAmount() {
		return investmentAmount;
	}

	public void setInvestmentAmount(Double investmentAmount) {
		this.investmentAmount = investmentAmount;
	}
	
	
}

package com.bfa.investment.dto;

public class InvestementDashboardResponseDTO {
	
	private InvestementDashboardStatusDTO investement;

	public InvestementDashboardStatusDTO getInvestement() {
		return investement;
	}

	public void setInvestement(InvestementDashboardStatusDTO investement) {
		this.investement = investement;
	} 
	
	

}

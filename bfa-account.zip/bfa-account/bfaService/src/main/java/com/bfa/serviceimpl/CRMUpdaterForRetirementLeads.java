/**
 * 
 */
package com.bfa.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.entity.BFAGrantedAuthority;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.request.entity.CRMNewEnquiryRequest;
import com.bfa.request.entity.NewEnquiryRequest;
import com.bfa.request.entity.ads.RetirementPlanningModel;
import com.bfa.service.RetirementLeadService;
import com.bfa.util.APIConstants;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

/**
 * @author pradheep
 *
 */
public class CRMUpdaterForRetirementLeads extends DiscoveryHelper implements Runnable {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;	

	@Autowired
	private Environment environment;

	@Autowired
	private SecurityConstants securityConstants;

	private String protectionPlan;

	private Gson gson = new Gson();

	private String API_NAME = APIConstants.CRM_API;

	@Autowired
	private AccountsDao accountsDAO;
	
	private RetirementPlanningModel retirementPlanningModel;
	
	public void setRetirementPlanningModel(RetirementPlanningModel retirementPlanningModel) {
		this.retirementPlanningModel = retirementPlanningModel;
	}

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}	
	
	private void loadSecurityHeader(){
		BFAGrantedAuthority roleServiceCall = new BFAGrantedAuthority("ROLE_SERVICE_CALL");
		BFAGrantedAuthority roleUser = new BFAGrantedAuthority("ROLE_USER");
		List<GrantedAuthority> grantedAuthorityList = new ArrayList<GrantedAuthority>();
		grantedAuthorityList.add(roleUser);
		grantedAuthorityList.add(roleServiceCall);
		loadSecurityHeader(SecurityConstants.TOKEN_NAME, grantedAuthorityList);
	}

	private void makeCRMCall() {
		setEnvironment(environment);
		String commandName = "crm-new-enquiry-ads";
		String targetURL = getBaseUrl(ServiceNames.CRM_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + API_NAME;
		NewEnquiryRequest crmEnquiryRequest = new NewEnquiryRequest();
		mapCRMData(crmEnquiryRequest);		
		loadSecurityHeader();
		String requestBody = "";
		boolean isNewCustomer = true;
		Customer existingCustomer = getExistingCustomerDetailsByMobileNumber(retirementPlanningModel.getMobileNumber());
		if (existingCustomer == null) {
			existingCustomer = getExistingCustomerDetailsByEmail(retirementPlanningModel.getEmailAddress());
			if (existingCustomer != null) {
				isNewCustomer = false;
				if (retirementPlanningModel.getMobileNumber().equalsIgnoreCase(existingCustomer.getMobileNumber())) {
					getLogger().info("The given mobile number " + retirementPlanningModel.getMobileNumber()
							+ " is matching the records in database");
				} else {
					getLogger().error("The given mobile number " + retirementPlanningModel.getMobileNumber()
							+ " is not matching the records in the database");
				}
			} else {
				getLogger().info("No matching records either found with email address or mobile number");
			}
		} else {
			isNewCustomer = false;
			if (retirementPlanningModel.getEmailAddress().equalsIgnoreCase(existingCustomer.getEmail())) {
				getLogger().info("The given email address " + retirementPlanningModel.getEmailAddress()
						+ " is matching the records in database");
			} else {
				getLogger().error("The given email address " + retirementPlanningModel.getEmailAddress()
						+ " is not matching the records in the database");
			}
		}
		// ---------------------------------------------------------------------//
		CRMNewEnquiryRequest crmEnquiryRequestObj = new CRMNewEnquiryRequest();
		crmEnquiryRequest.setDob(retirementPlanningModel.getDateOfBirth());
		crmEnquiryRequestObj.setFirstName(retirementPlanningModel.getFirstName());
		crmEnquiryRequestObj.setLastName(retirementPlanningModel.getLastName());
		crmEnquiryRequestObj.setEmailAddress(retirementPlanningModel.getEmailAddress());
		if (!isNewCustomer) {
			crmEnquiryRequestObj.setCustomerId(existingCustomer.getId());
		} else {
			crmEnquiryRequestObj.setCustomerId(0);
		}
		crmEnquiryRequestObj.setNewEnquiryRequest(crmEnquiryRequest);
		crmEnquiryRequestObj.setSelectedProductList(Collections.emptyList());
		crmEnquiryRequestObj.setNewCustomer(isNewCustomer);
		crmEnquiryRequestObj.setRequestByEmail(true);
		crmEnquiryRequestObj.setJourneyType(JourneyTypeEnum.Retirement_LEAD_BY_ADS);
		
		requestBody = gson.toJson(crmEnquiryRequestObj);
		getLogger().info("Printing the target URL :" + targetURL);
		getLogger().info(">> Calling crm microservice - " + "Request body :" + requestBody);
		addJobToQueue(targetURL, requestBody, commandName, 0);
		// ----------------------------------------------------------------------//
		getLogger().info("CRM Jobs added to queue");
	}

	private Customer getExistingCustomerDetailsByMobileNumber(String mobileNumber) {
		return accountsDAO.getCustomerFromMobile(mobileNumber);
	}

	private Customer getExistingCustomerDetailsByEmail(String emailAddress) {
		return accountsDAO.getCustomerDetails(emailAddress);
	}

	/*
	 * As discussed with Vadhani , those fields which are not known marking it
	 * as '-'
	 */
	private void mapCRMData(NewEnquiryRequest newEnquiryRequest) {
		try {
			StringBuffer eventPlans = new StringBuffer();
			eventPlans.append("-");
			newEnquiryRequest.setSubject("Thanks for using Money Owl Application.");
			newEnquiryRequest.setEmail(retirementPlanningModel.getEmailAddress());
			newEnquiryRequest.setContact(retirementPlanningModel.getMobileNumber());
			newEnquiryRequest.setName(retirementPlanningModel.getFirstName());
			newEnquiryRequest.setLast_name(retirementPlanningModel.getLastName());
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			newEnquiryRequest.setEmail_date(sdf.format(new Date()));
			newEnquiryRequest.setGender("NA");			
			newEnquiryRequest.setSmoker("NA");
			newEnquiryRequest.setContactTime("NA");
			newEnquiryRequest.setEventPlan(getProtectionPlan());
			newEnquiryRequest.setCategory(RetirementLeadService.RETIREMENT_PLAN_CATEGORY);
			newEnquiryRequest.setDob(retirementPlanningModel.getDateOfBirth());
			newEnquiryRequest.setDescription("New customer request");
		} catch (Exception err) {
			getLogger().error("Conversion of CRM data failed ", err);			
		}
	}

	@Override
	public void run() {
		makeCRMCall();
	}

	public String getProtectionPlan() {
		return protectionPlan;
	}

	/**
	 * This has to be set before calling CRM.
	 * @param protectionPlan
	 */
	public void setProtectionPlan(String protectionPlan) {
		this.protectionPlan = protectionPlan;
	}

}

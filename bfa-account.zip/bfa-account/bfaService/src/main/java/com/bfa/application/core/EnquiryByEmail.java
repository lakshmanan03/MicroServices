/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bfa.insurance.product.ProductList;

/**
 * {@link }
 * @author pradheep
 *@since release_2.12
 */
public final class EnquiryByEmail {

	@NotNull(message = "Selected products cannot be null")	
	private List<ProductList> selectedProducts;

	@NotNull(message = "Last name cannot be null")
	@NotBlank(message = "Last name cannot be blank")
	private String firstName;

	@NotNull(message = "Last name cannot be null")
	@NotBlank(message = "Last name cannot be blank")
	private String lastName;

	@NotNull(message = "Email cannot be null")
	@NotBlank(message = "Email cannot be blank")
	@Email(message = "Email should be valid")
	private String email;
	
	private String mobileNumber;

	private boolean acceptMarketingEmails;

	private ValidateCaptchaBean validateCaptchaBean;
	
	private Integer enquiryId;
	
    private boolean contactViaMobile;

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isAcceptMarketingEmails() {
		return acceptMarketingEmails;
	}

	public void setAcceptMarketingEmails(boolean acceptMarketingEmails) {
		this.acceptMarketingEmails = acceptMarketingEmails;
	}

	public ValidateCaptchaBean getValidateCaptchaBean() {
		return validateCaptchaBean;
	}

	public void setValidateCaptchaBean(ValidateCaptchaBean validateCaptchaBean) {
		this.validateCaptchaBean = validateCaptchaBean;
	}

	public String toString() {
		StringBuffer selectedProd = new StringBuffer();
		getSelectedProducts().forEach(x -> selectedProd.append(x.getProductName()));
		return getFirstName() + " " + getLastName() + " identified by :" + getEmail() + " has selected the products :"
				+ selectedProd.toString();
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the contactViaMobile
	 */
	public boolean isContactViaMobile() {
		return contactViaMobile;
	}

	/**
	 * @param contactViaMobile the contactViaMobile to set
	 */
	public void setContactViaMobile(boolean contactViaMobile) {
		this.contactViaMobile = contactViaMobile;
	}

}

package com.bfa.controllers;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.servlet.ModelAndView;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.service.SecurityService;

@RunWith(SpringJUnit4ClassRunner.class)
public class CaptchaControllerTest {

	@InjectMocks
	private CaptchaController mCaptchaController;

	@Mock
	private HttpServletRequest mHttpServletRequest;

	@Mock
	private HttpServletResponse mHttpServletResponse;

	@Mock
	private SessionDetails mSessionDetails;

	@Mock
	private SecurityService mSecurityService;

	@Mock
	private ModelAndView mModelAndView;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}

	@Test(expected = NullPointerException.class)
	public void testRedrawCaptcha() {
		when(mSecurityService.getSessionDetailsBySessionId("adkjba-3546aghda-rjgrk")).thenReturn(mSessionDetails);
		when(mHttpServletRequest.getParameter("code")).thenReturn("adkjba-3546aghda-rjgrk");
		mCaptchaController.redrawCaptcha(mHttpServletRequest, mHttpServletResponse, mModelAndView);
	}

}

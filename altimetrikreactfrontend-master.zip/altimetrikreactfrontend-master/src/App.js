import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import ListFoodComponent from "./component/user/ListFoodComponent";
import ListTopComponent from "./component/user/ListTopComponent";
import ListBudgetComponent from "./component/user/ListBudgetComponent";
import OrderComponent from "./component/user/OrderComponent";

function App() {
  return (
      <div className="container">
          <Router>
              <div className="col-md-6">
                 
                  <Switch>
                      <Route path="/" exact component={ListFoodComponent} />
                      <Route path="/budget" component={ListBudgetComponent} />
                      <Route path="/rated" component={ListTopComponent} />
                      <Route path="/confirmation" component={OrderComponent} />
                     </Switch>
              </div>
          </Router>
      </div>
  );
}



export default App;

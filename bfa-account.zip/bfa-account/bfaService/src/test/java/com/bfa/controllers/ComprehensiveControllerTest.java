package com.bfa.controllers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;
import com.bfa.configuration.AccountServiceConfiguration;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.ComprehensiveDependentMapping;
import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;
import com.bfa.investment.account.dto.ComprehensivePricingDTO;
import com.bfa.request.entity.ComprehensiveChildEndowmentPlanRequest;
import com.bfa.request.entity.ComprehensiveDependentRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ValidatePromoCodeRequest;
import com.bfa.service.ComprehensiveService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ResponseMessageList;

@RunWith(SpringJUnit4ClassRunner.class)
public class ComprehensiveControllerTest {

	@InjectMocks
	private ComprehensiveController mComprehensiveController;

	@Mock
	private HttpServletRequest mHttpServletRequest;

	@Mock
	ComprehensiveService mockComprehensiveService;

	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private TokenProvider tokenProvider;

	String customerIdInRequest = "1";

	String customerIdInRequestNegative = "-1";

	int enqId = 1;

	int cusId = 1;

	Integer customerId = 1;
	
	String journeyType=ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE;
	
	private String authHeader = "";
	
	
	@Before
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);
		List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
		BFAGrandtedAuthority grantedAuth = new BFAGrandtedAuthority("ROLE_COMPRE_DISCOUNT");
		grantedAuthorityList.add(grantedAuth);
		String jwtTokenobj = tokenProvider.getTokenString("-1", grantedAuthorityList);
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(jwtTokenobj);
	}

	private UpdateCustomerBasicInfo returnUpdateCustomerBasicInfo() {

		UpdateCustomerBasicInfo mUpdateCustomerBasicInfo = new UpdateCustomerBasicInfo();
		mUpdateCustomerBasicInfo.setCustomerId(cusId);
		mUpdateCustomerBasicInfo.setGender("male");
		mUpdateCustomerBasicInfo.setNation("singaporian");

		return mUpdateCustomerBasicInfo;
	}

	private ValidatePromoCodeRequest returnValidatePromoCodeRequest() {

		ValidatePromoCodeRequest validatePromoCodeRequest = new ValidatePromoCodeRequest();
		validatePromoCodeRequest.setEnquiryId(enqId);
		validatePromoCodeRequest.setComprehensivePromoCodeToken("promocode");

		return validatePromoCodeRequest;
	}

	private ComprehensiveDependentRequest returnComprehensiveDependentRequest() {

		ComprehensiveDependentRequest comprehensiveDependentRequest = new ComprehensiveDependentRequest();
		ComprehensiveDependentMapping comprehensiveDependentMapping = new ComprehensiveDependentMapping();
		comprehensiveDependentMapping.setCustomerId(cusId);
		comprehensiveDependentMapping.setEnquiryId(enqId);
		comprehensiveDependentMapping.setGender("male");
		comprehensiveDependentMapping.setName("rajesh");
		comprehensiveDependentMapping.setNation("singaporian");
		comprehensiveDependentMapping.setRelationship("single");
		comprehensiveDependentMapping.setDateOfBirth("20-05-1990");

		List<ComprehensiveDependentMapping> depedentList = new ArrayList<>();
		depedentList.add(comprehensiveDependentMapping);
		comprehensiveDependentRequest.setDependentMappingList(depedentList);

		return comprehensiveDependentRequest;
	}

	private ComprehensiveChildEndowmentPlanRequest returnChildEndowmentPlanReq() {

		ComprehensiveChildEndowmentPlanRequest childEndowmentPlanReq = new ComprehensiveChildEndowmentPlanRequest();
		ComprehensiveEndowmentPlanMapping comprehensiveEndowmentPlanMapping = new ComprehensiveEndowmentPlanMapping();
		List<ComprehensiveEndowmentPlanMapping> list = new ArrayList<>();
		comprehensiveEndowmentPlanMapping.setEducationCourse("graduation");
		comprehensiveEndowmentPlanMapping.setDependentId(2);
		comprehensiveEndowmentPlanMapping.setEndowmentMaturityAmount(2000.0);
		comprehensiveEndowmentPlanMapping.setEndowmentMaturityYears(10);
		comprehensiveEndowmentPlanMapping.setEnquiryId(enqId);
		comprehensiveEndowmentPlanMapping.setLocation("singapore");
		list.add(comprehensiveEndowmentPlanMapping);
		childEndowmentPlanReq.setEndowmentDetailsList(list);
		childEndowmentPlanReq.setHasEndowments("1");

		return childEndowmentPlanReq;
	}

	private ComprehensiveEnquiryPostRequest returnEnquiryRequest() {

		ComprehensiveEnquiryPostRequest mEnquiryRequest = new ComprehensiveEnquiryPostRequest();
		ComprehensiveEnquiryDTO mComprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		mComprehensiveEnquiryDTO.setCustomerId(cusId);
		mComprehensiveEnquiryDTO.setEnquiryId(enqId);
		mComprehensiveEnquiryDTO.setHasDependents(true);
		mComprehensiveEnquiryDTO.setHasRegularSavingsPlans(true);
		mComprehensiveEnquiryDTO.setIsValidatedPromoCode(true);
		mComprehensiveEnquiryDTO.setStepCompleted(1);

		mEnquiryRequest.setEnquiryObject(mComprehensiveEnquiryDTO);
		mEnquiryRequest.setBaseProfileOnlyFlag(true);
		mEnquiryRequest.setHospitalPlanId(1);

		return mEnquiryRequest;

	}

	@Test
	public void testSaveCustomerPersonalDetails() {

		UpdateCustomerBasicInfo updateCustomerBasicInfo = returnUpdateCustomerBasicInfo();
		ResponseMessageList response = mComprehensiveController.saveCustomerPersonalDetails(updateCustomerBasicInfo,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testRequestPromoCode() {

		ResponseMessageList response = mComprehensiveController.requestPromoCode(mHttpServletRequest, "");
		assertNotNull(response);

	}

	@Test
	public void requestPromoCodeNegativeTest() {

		mHttpServletRequest.setAttribute("customerIdInRequest", customerIdInRequestNegative);
		ResponseMessageList response = mComprehensiveController.requestPromoCode(mHttpServletRequest, null);

		assertEquals(ErrorCodes.INVALID_REQUEST, response.getResponseMessage().getResponseCode());

		assertNotNull(response);

	}

	@Test
	public void testValidateComprehensivePromoCode() {

		ValidatePromoCodeRequest mvalidateComprehensivePromoCode = returnValidatePromoCodeRequest();
		ResponseMessageList response = mComprehensiveController
				.validateComprehensivePromoCode(mvalidateComprehensivePromoCode, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void validateComprehensivePromoCodeNegative() {

		ValidatePromoCodeRequest mvalidateComprehensivePromoCode = returnValidatePromoCodeRequest();

		when(mockComprehensiveService.validatePromoCodeByUser(mvalidateComprehensivePromoCode, customerId))
				.thenReturn(true);

		ResponseMessageList response = mComprehensiveController
				.validateComprehensivePromoCode(mvalidateComprehensivePromoCode, mHttpServletRequest);

		assertEquals(5017, response.getResponseMessage().getResponseCode());

		assertNotNull(response);

	}

	@Test
	public void testGetBasicProfile() {
		
		mHttpServletRequest.setAttribute("customerIdInRequest", customerIdInRequest);
		ResponseMessageList response=mComprehensiveController.getBasicProfile(mHttpServletRequest,journeyType);
		assertNotNull(response);
	}

	@Test
	public void testSaveDependents() {

		ComprehensiveDependentRequest mComprehensiveDependentRequest = returnComprehensiveDependentRequest();
		ResponseMessageList response = mComprehensiveController.saveDependents(mComprehensiveDependentRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetDependentDetails() {

		ResponseMessageList response = mComprehensiveController.getDependentDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveChildEndowmentPlans() {

		ComprehensiveChildEndowmentPlanRequest mComprehensiveChildEndowmentPlanRequest = returnChildEndowmentPlanReq();
		ResponseMessageList response = mComprehensiveController
				.saveChildEndowmentPlans(mComprehensiveChildEndowmentPlanRequest, mHttpServletRequest);
		assertNotNull(response);

	}

	@Test
	public void saveChildEndowmentPlansNegative() {

		ComprehensiveChildEndowmentPlanRequest mComprehensiveChildEndowmentPlanRequest = returnChildEndowmentPlanReq();
		mComprehensiveChildEndowmentPlanRequest.setHasEndowments("0");
		ResponseMessageList response = mComprehensiveController
				.saveChildEndowmentPlans(mComprehensiveChildEndowmentPlanRequest, mHttpServletRequest);
		assertNotNull(response);

	}

	@Test
	public void testGetComprehensiveEnquiryDetails() {

		ComprehensiveEnquiryPostRequest menquiryRequest = returnEnquiryRequest();
		ResponseMessageList response = mComprehensiveController.getComprehensiveEnquiryDetails(menquiryRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGenerateCustomerToken() {

		ResponseMessageList response = mComprehensiveController.generateCustomerToken(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveCustomerPersonalDetailsDBException() {

		UpdateCustomerBasicInfo updateCustomerBasicInfo = returnUpdateCustomerBasicInfo();
		doThrow(new DatabaseAccessException()).when(mockComprehensiveService)
				.updateCustomerBasicDetails(updateCustomerBasicInfo, cusId);
		ResponseMessageList response = mComprehensiveController.saveCustomerPersonalDetails(updateCustomerBasicInfo,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveCustomerPersonalDetailsException() {

		UpdateCustomerBasicInfo updateCustomerBasicInfo = returnUpdateCustomerBasicInfo();
		doThrow(new RuntimeException()).when(mockComprehensiveService)
				.updateCustomerBasicDetails(updateCustomerBasicInfo, cusId);
		ResponseMessageList response = mComprehensiveController.saveCustomerPersonalDetails(updateCustomerBasicInfo,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveDependentsDBException() {

		ComprehensiveDependentRequest mComprehensiveDependentRequest = returnComprehensiveDependentRequest();
		when(mockComprehensiveService.getDependentDetailList(cusId,enqId)).thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mComprehensiveController.saveDependents(mComprehensiveDependentRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveDependentsException() {

		ComprehensiveDependentRequest mComprehensiveDependentRequest = returnComprehensiveDependentRequest();
		when(mockComprehensiveService.getDependentDetailList(cusId,enqId)).thenThrow(new RuntimeException());
		ResponseMessageList response = mComprehensiveController.saveDependents(mComprehensiveDependentRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testRequestPromoCodeDBException() {

		when(mockComprehensiveService.requestPromoCodeDetails(cusId, "COMPREHENSIVE"))
				.thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mComprehensiveController.requestPromoCode(mHttpServletRequest, "COMPREHENSIVE");
		assertNotNull(response);

	}

	@Test
	public void testRequestPromoCodeException() {

		when(mockComprehensiveService.requestPromoCodeDetails(cusId, "COMPREHENSIVE"))
				.thenThrow(new RuntimeException());
		ResponseMessageList response = mComprehensiveController.requestPromoCode(mHttpServletRequest, "COMPREHENSIVE");
		assertNotNull(response);

	}

	@Test
	public void testGetBasicProfileDBException() {
		
		mHttpServletRequest.setAttribute("customerIdInRequest", customerIdInRequest);
		when(mockComprehensiveService.getCustomerBasicDetails(cusId,journeyType)).thenThrow(new DatabaseAccessException());
		ResponseMessageList response=mComprehensiveController.getBasicProfile(mHttpServletRequest,journeyType);
		assertNotNull(response);
	}

	@Test
	public void testGetBasicProfileException() {
		
		mHttpServletRequest.setAttribute("customerIdInRequest", customerIdInRequest);
		when(mockComprehensiveService.getCustomerBasicDetails(cusId,journeyType)).thenThrow(new RuntimeException());
		ResponseMessageList response=mComprehensiveController.getBasicProfile(mHttpServletRequest,journeyType);
		assertNotNull(response);
	}

	@Test
	public void testSaveChildEndowmentPlansDBException() {

		ComprehensiveChildEndowmentPlanRequest mComprehensiveChildEndowmentPlanRequest = returnChildEndowmentPlanReq();
		when(mockComprehensiveService.getDependentEducationPreferences(enqId, cusId))
				.thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mComprehensiveController
				.saveChildEndowmentPlans(mComprehensiveChildEndowmentPlanRequest, mHttpServletRequest);
		assertNotNull(response);

	}

	@Test
	public void testSaveChildEndowmentPlansException() {

		ComprehensiveChildEndowmentPlanRequest mComprehensiveChildEndowmentPlanRequest = returnChildEndowmentPlanReq();
		when(mockComprehensiveService.getDependentEducationPreferences(enqId, cusId)).thenThrow(new RuntimeException());
		ResponseMessageList response = mComprehensiveController
				.saveChildEndowmentPlans(mComprehensiveChildEndowmentPlanRequest, mHttpServletRequest);
		assertNotNull(response);

	}

	@Test
	public void testGetDependentDetailsException() {

		when(mockComprehensiveService.getDependentDetailList(cusId,enqId)).thenThrow(new RuntimeException());
		ResponseMessageList response = mComprehensiveController.getDependentDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetDependentDetailsDBException() {

		when(mockComprehensiveService.getDependentDetailList(cusId,enqId)).thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mComprehensiveController.getDependentDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetComprehensiveEnquiryDetailsDBException() {
		
		mHttpServletRequest.setAttribute("customerIdInRequest", customerIdInRequest);
		ComprehensiveEnquiryPostRequest menquiryRequest=returnEnquiryRequest();
		when(mockComprehensiveService.getCustomerBasicDetails(cusId,journeyType)).thenThrow(new DatabaseAccessException());
		ResponseMessageList response=mComprehensiveController.getComprehensiveEnquiryDetails(menquiryRequest, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetComprehensiveEnquiryDetailsException() {
		
		mHttpServletRequest.setAttribute("customerIdInRequest", customerIdInRequest);
		ComprehensiveEnquiryPostRequest menquiryRequest=returnEnquiryRequest();
		when(mockComprehensiveService.getCustomerBasicDetails(cusId,journeyType)).thenThrow(new RuntimeException());
		ResponseMessageList response=mComprehensiveController.getComprehensiveEnquiryDetails(menquiryRequest, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGenerateCustomerTokenDBException() {

		when(mockComprehensiveService.generateCustomerToken(cusId)).thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mComprehensiveController.generateCustomerToken(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGenerateCustomerTokenException() {

		when(mockComprehensiveService.generateCustomerToken(cusId)).thenThrow(new RuntimeException());
		ResponseMessageList response = mComprehensiveController.generateCustomerToken(mHttpServletRequest);
		assertNotNull(response);
	}
	@Test
	public void testgetComprehensiveProductPricing(){
		String jwtTokenobj = getAuthToken();
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(jwtTokenobj);
		Map<String, Object> pricing  = new HashMap<>();
		pricing.put("productType","Comprehensive");
		when(mockComprehensiveService.getComprehensiveProductPricing("Comprehensive","ROLE_COMPRE_DISCOUNT")).thenThrow(new RuntimeException());
		ResponseMessageList response = mComprehensiveController.getComprehensiveProductPricing(pricing,mHttpServletRequest);
		assertNotNull(response);
	}
	
	private void init() {
		authHeader = getAuthToken();
	}
	
	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_COMPRE_DISCOUNT");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		return tokenProvider.getTokenString("-1", authorities);
	}
	
	@Test
	public void testgetComprehensiveProductPricingDBException(){
		when(mockComprehensiveService.getComprehensiveProductPricing("Comprehensive","ROLE_COMPRE_DISCOUNT")).thenThrow(new DatabaseAccessException());
		Map<String, Object> pricing  = new HashMap<>();
		pricing.put("productType","Comprehensive");
		ResponseMessageList response = mComprehensiveController.getComprehensiveProductPricing(pricing,mHttpServletRequest);
		assertNotNull(response);
	}
	@Test
	public void testgetComprehensiveProductPricingTokenException(){
		when(mockComprehensiveService.getComprehensiveProductPricing("Comprehensive","ROLE_COMPRE_DISCOUNT")).thenThrow(new RuntimeException());
		Map<String, Object> pricing   = new HashMap<>();
		pricing.put("productType","Comprehensive");
		ResponseMessageList response = mComprehensiveController.getComprehensiveProductPricing(pricing,mHttpServletRequest);
		assertNotNull(response);
	}
}

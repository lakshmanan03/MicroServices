package com.bfa.util;

public class EnquiryConstants {
	
	public static final String  INVESTMENT= "Investment";
	
}

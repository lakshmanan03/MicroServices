/**
 * 
 */
package com.bfa.application.core.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep
 * @since Release Robo3-lite
 */
@Entity
@Table(name = "finlit_access_code")
public class FinlitAccessCode {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "access_code")
	private String accessCode;

	@Column(name = "start_ts")	
	private java.sql.Timestamp startTimestamp;

	@Column(name = "end_ts")	
	private java.sql.Timestamp endTimestamp;

	@Column(name = "org_code")
	private String organisationCode;

	@Column(name = "workshop")
	private String workshop;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccessCode() {
		return accessCode;
	}

	public void setAccessCode(String accessCode) {
		this.accessCode = accessCode;
	}

	public java.sql.Timestamp getStartTimestamp() {
		return startTimestamp;
	}

	public void setStartTimestamp(java.sql.Timestamp startTimestamp) {
		this.startTimestamp = startTimestamp;
	}

	public java.sql.Timestamp getEndTimestamp() {
		return endTimestamp;
	}

	public void setEndTimestamp(java.sql.Timestamp endTimestamp) {
		this.endTimestamp = endTimestamp;
	}

	public String getOrganisationCode() {
		return organisationCode;
	}

	public void setOrganisationCode(String organisationCode) {
		this.organisationCode = organisationCode;
	}

	public String getWorkshop() {
		return workshop;
	}

	public void setWorkshop(String workshop) {
		this.workshop = workshop;
	}

	@Override
	public String toString() {
		return "FinlitAccessCode [" + (id != null ? "id=" + id + ", " : "")
				+ (accessCode != null ? "accessCode=" + accessCode + ", " : "")
				+ (startTimestamp != null ? "startTimestamp=" + startTimestamp + ", " : "")
				+ (endTimestamp != null ? "endTimestamp=" + endTimestamp + ", " : "")
				+ (organisationCode != null ? "organisationCode=" + organisationCode + ", " : "")
				+ (workshop != null ? "workshop=" + workshop : "") + "]";
	}

}

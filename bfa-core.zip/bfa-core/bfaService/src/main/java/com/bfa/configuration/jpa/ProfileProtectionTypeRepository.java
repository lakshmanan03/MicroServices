/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.insurance.core.ProfileProtectionType;

/**
 * @author pradheep.p
 *
 */
public interface ProfileProtectionTypeRepository extends JpaRepository<ProfileProtectionType, Integer> {

}

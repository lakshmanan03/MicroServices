/**
 * 
 */
package com.bfa.request.processor;

/**
 * @author pradheep.p
 *
 */
public interface WriteToStream {
	public boolean writeToFile();
}

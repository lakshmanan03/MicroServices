/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "expences")
public class ComprehensiveSpending {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	@JsonIgnore
	private int id;

	@JsonIgnore
	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "monthly_living_expenses")
	private Double monthlyLivingExpenses;

	@Column(name = "adhoc_expenses")
	private Double adHocExpenses;

	@Column(name = "hl_mortgage_payment_cpf")
	private Double HLMortgagePaymentUsingCPF;

	@Column(name = "hl_mortgage_payment_cash")
	private Double HLMortgagePaymentUsingCash;

	@Column(name = "hl_type_of_home")
	private String HLtypeOfHome;

	@Column(name = "hl_payoff_until")
	private Integer homeLoanPayOffUntil;

	@Column(name = "mortgage_payment_cpf")
	private Double mortgagePaymentUsingCPF;

	@Column(name = "mortgage_payment_cash")
	private Double mortgagePaymentUsingCash;

	@Column(name = "mortgage_type_of_home")
	private String mortgageTypeOfHome;

	@Column(name = "mortgage_pay_off_until")
	private Integer mortgagePayOffUntil;

	@Column(name = "car_loan_payment")
	private Double carLoanPayment;
	
	@Column(name = "car_loan_payoff_until")
	private Integer carLoanPayoffUntil;

	@Column(name = "other_loan_payment")
	private Double otherLoanPayment;

	@Column(name = "other_loan_payoff_until")
	private Integer otherLoanPayoffUntil;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getMonthlyLivingExpenses() {
		return monthlyLivingExpenses;
	}

	public void setMonthlyLivingExpenses(Double monthlyLivingExpenses) {
		this.monthlyLivingExpenses = monthlyLivingExpenses;
	}

	public Double getAdHocExpenses() {
		return adHocExpenses;
	}

	public void setAdHocExpenses(Double adHocExpenses) {
		this.adHocExpenses = adHocExpenses;
	}

	public Double getHLMortgagePaymentUsingCPF() {
		return HLMortgagePaymentUsingCPF;
	}

	public void setHLMortgagePaymentUsingCPF(Double hLMortgagePaymentUsingCPF) {
		HLMortgagePaymentUsingCPF = hLMortgagePaymentUsingCPF;
	}

	public Double getHLMortgagePaymentUsingCash() {
		return HLMortgagePaymentUsingCash;
	}

	public void setHLMortgagePaymentUsingCash(Double hLMortgagePaymentUsingCash) {
		HLMortgagePaymentUsingCash = hLMortgagePaymentUsingCash;
	}

	public String getHLtypeOfHome() {
		return HLtypeOfHome;
	}

	public void setHLtypeOfHome(String hLtypeOfHome) {
		HLtypeOfHome = hLtypeOfHome;
	}

	public Double getMortgagePaymentUsingCPF() {
		return mortgagePaymentUsingCPF;
	}

	public void setMortgagePaymentUsingCPF(Double mortgagePaymentUsingCPF) {
		this.mortgagePaymentUsingCPF = mortgagePaymentUsingCPF;
	}

	public Double getMortgagePaymentUsingCash() {
		return mortgagePaymentUsingCash;
	}

	public void setMortgagePaymentUsingCash(Double mortgagePaymentUsingCash) {
		this.mortgagePaymentUsingCash = mortgagePaymentUsingCash;
	}

	public String getMortgageTypeOfHome() {
		return mortgageTypeOfHome;
	}

	public void setMortgageTypeOfHome(String mortgageTypeOfHome) {
		this.mortgageTypeOfHome = mortgageTypeOfHome;
	}

	public Double getCarLoanPayment() {
		return carLoanPayment;
	}

	public void setCarLoanPayment(Double carLoanPayment) {
		this.carLoanPayment = carLoanPayment;
	}
	
	public Integer getCarLoanPayoffUntil() {
		return carLoanPayoffUntil;
	}

	public void setCarLoanPayoffUntil(Integer carLoanPayoffUntil) {
		this.carLoanPayoffUntil = carLoanPayoffUntil;
	}

	public Double getOtherLoanPayment() {
		return otherLoanPayment;
	}

	public void setOtherLoanPayment(Double otherLoanPayment) {
		this.otherLoanPayment = otherLoanPayment;
	}

	public Integer getHomeLoanPayOffUntil() {
		return homeLoanPayOffUntil;
	}

	public void setHomeLoanPayOffUntil(Integer homeLoanPayOffUntil) {
		this.homeLoanPayOffUntil = homeLoanPayOffUntil;
	}

	public Integer getMortgagePayOffUntil() {
		return mortgagePayOffUntil;
	}

	public void setMortgagePayOffUntil(Integer mortgagePayOffUntil) {
		this.mortgagePayOffUntil = mortgagePayOffUntil;
	}

	public Integer getOtherLoanPayoffUntil() {
		return otherLoanPayoffUntil;
	}

	public void setOtherLoanPayoffUntil(Integer otherLoanPayoffUntil) {
		this.otherLoanPayoffUntil = otherLoanPayoffUntil;
	}

}

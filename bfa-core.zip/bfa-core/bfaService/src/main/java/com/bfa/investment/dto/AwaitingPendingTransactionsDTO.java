package com.bfa.investment.dto;

public class AwaitingPendingTransactionsDTO {
	
	private Integer id;
	private Double amount;
	private String portfolioId;
	private String transactionStatus;
	private String transactionFrequency;
	
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @return the portfolioId
	 */
	public String getPortfolioId() {
		return portfolioId;
	}
	/**
	 * @param portfolioId the portfolioId to set
	 */
	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}
	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	/**
	 * @return the transactionFrequency
	 */
	public String getTransactionFrequency() {
		return transactionFrequency;
	}
	/**
	 * @param transactionFrequency the transactionFrequency to set
	 */
	public void setTransactionFrequency(String transactionFrequency) {
		this.transactionFrequency = transactionFrequency;
	}
	
	


}

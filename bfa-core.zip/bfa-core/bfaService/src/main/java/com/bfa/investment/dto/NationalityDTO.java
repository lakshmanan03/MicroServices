package com.bfa.investment.dto;

import java.util.List;

//{
//    "nationality": "American"
//    "countries": ["USA"],
//    "id": 1,
//    "isBlocked": false
//}
// To Add grouped
public class NationalityDTO {
	private String nationalityCode;
	private String name;

	private boolean isBlocked;

	private int listorder;
	
	private List<GroupedCountryDTO> countries;

	public int getListorder() {
		return listorder;
	}

	public void setListorder(int listorder) {
		this.listorder = listorder;
	}

	public String getNationalityCode() {
		return nationalityCode;
	}

	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}

	

	public boolean isBlocked() {
		return isBlocked;
	}

	public void setBlocked(boolean isBlocked) {
		this.isBlocked = isBlocked;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<GroupedCountryDTO> getCountries() {
		return countries;
	}

	public void setCountries(List<GroupedCountryDTO> countries) {
		this.countries = countries;
	}

}

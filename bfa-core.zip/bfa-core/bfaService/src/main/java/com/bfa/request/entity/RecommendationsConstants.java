/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep.p
 *
 */
public interface RecommendationsConstants {

	public static String PRODUCT_RECOMMENDED = "RECOMMENDED";
	
	public static String PRODUCT_SELECTED = "SELECTED_FOR_QUOTE";
	
	public static String PRODUCT_SELECTED_QUOTE = "QUOTE_SENT_TO_CUSTOMER";
	
	public static String PRODUCT_BOUGHT = "BOUGHT";
}

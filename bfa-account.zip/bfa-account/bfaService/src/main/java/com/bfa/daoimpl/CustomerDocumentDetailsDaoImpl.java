package com.bfa.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.dao.CustomerDocumentDAO;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.DocumentStatusMaster;

@Transactional
@Repository
public class CustomerDocumentDetailsDaoImpl extends BaseDaoImpl implements CustomerDocumentDAO{
	
	@PersistenceContext	
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerDocumentDetails> getAllDetails() {
		return getList("FROM CustomerDocumentDetails");
	}

	@Override
	public void saveCustomerDocument(CustomerDocumentDetails customerDocumentDetails) {
		saveOrUpdate(customerDocumentDetails);
	}
	
	public DocumentStatusMaster getDocumentStatus(String docStatus) {
		DocumentStatusMaster document = null;
		List<DocumentStatusMaster> list = getList("FROM DocumentStatusMaster where status = '" + docStatus + "'");
		if (list != null && !list.isEmpty())
			document = list.get(0);
		return document;
	}
	
	@Override
	public void saveCustomerDocument(CustomerDocumentDetails customerDocumentDetails, String status) {

		getLogger().info("status: " + status);
		List<DocumentStatusMaster> list = getList("FROM DocumentStatusMaster where status =:status ", new String[][] {{"status", status}});
		getLogger().info("list size" + list.size());
		DocumentStatusMaster documentStatus = list.get(0);
		customerDocumentDetails.setDocumentStatus(documentStatus);
		save(customerDocumentDetails);
	}
	
	@Override
	public CustomerDocumentDetails getCustomerDocument(int customerId, String docType) {
		CustomerDocumentDetails document = null;
		getLogger().info("customerId from getCustomerDocument(): " + customerId);
		List<CustomerDocumentDetails> list = getList("FROM CustomerDocumentDetails where customer.id = " + customerId + " AND docType = '" + docType + "'");
		if (list != null && !list.isEmpty())
			document = list.get(0);
		return document;
		
	}

	@Override
	public String getAwsFileName(int customerId) {
		getLogger().info("status" + customerId);
		List<CustomerDocumentDetails> list = getList("FROM CustomerDocumentDetails where customer.id = " + customerId);
		String awsFileName = list.get(0).getFileName();
		getLogger().info("awsFileName" + awsFileName);
		return awsFileName;
		
	}

	@Override
	public String deleteCustomerDocument(int customerId) {
		getLogger().info("status" + customerId);
		List<CustomerDocumentDetails> list = getList("FROM CustomerDocumentDetails where customer.id = " + customerId);
		String awsFileName = list.get(0).getFileName();
		getLogger().info("awsFileName" + awsFileName);
		return awsFileName;
	}

}

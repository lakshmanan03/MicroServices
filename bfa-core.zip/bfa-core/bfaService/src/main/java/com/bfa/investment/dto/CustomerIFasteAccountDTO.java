package com.bfa.investment.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerIFasteAccountDTO {
	
	private String accountCreatedDate;
	
	private String accountStatus;
	
	private Double cashAccountBalance;
	
	private String trustId;
	
	private String refNo;

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date statementCreatedDate;
	
	
	public Double getCashAccountBalance() {
		return cashAccountBalance;
	}

	public void setCashAccountBalance(Double cashAccountBalance) {
		this.cashAccountBalance = cashAccountBalance;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getAccountCreatedDate() {
		return accountCreatedDate;
	}

	public void setAccountCreatedDate(String accountCreatedDate) {
		this.accountCreatedDate = accountCreatedDate;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public Date getStatementCreatedDate() {
		return statementCreatedDate;
	}

	public void setStatementCreatedDate(Date statementCreatedDate) {
		this.statementCreatedDate = statementCreatedDate;
	}

}

/**
 * 
 */
package com.bfa.request.processor;

/**
 * @author pradheep.p
 *
 */
public abstract class SuccessHandler implements Runnable {
	
	private Object sourceObj;
	
	public abstract void setNextCommand(ProcessorCommand processorCommand);
	
	public Class parsableClass;
	
	public Object getSource(){
		return sourceObj;
	}

	public void setSource(Object source) {
		this.sourceObj = source;
	}

	public Object getSourceObj() {
		return sourceObj;
	}

	public void setSourceObj(Object sourceObj) {
		this.sourceObj = sourceObj;
	}

	public Class getParsableClass() {
		return parsableClass;
	}

	public void setParsableClass(Class parsableClass) {
		this.parsableClass = parsableClass;
	}

}

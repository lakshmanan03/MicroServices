package com.bfa.common.dto;

public class CustomerTaxDetailsDTO {
	private int taxCountryId;
	private String tinNumber;
	private String noTinReason;
	
	public int getTaxCountryId() {
		return taxCountryId;
	}
	public void setTaxCountryId(int taxCountryId) {
		this.taxCountryId = taxCountryId;
	}
	public String getTinNumber() {
		return tinNumber;
	}
	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}
	public String getNoTinReason() {
		return noTinReason;
	}
	public void setNoTinReason(String noTinReason) {
		this.noTinReason = noTinReason;
	}
	
	
}

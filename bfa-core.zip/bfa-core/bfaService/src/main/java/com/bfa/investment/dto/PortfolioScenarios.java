/**
 * 
 */
package com.bfa.investment.dto;

import java.util.List;

/**
 * @author DivakarU
 *
 */
public class PortfolioScenarios {

	private String scenarioId;
	private String partialScenarioId;
	private List<String> transactionStatus;
	private List<String> transactionType;
	private PortfolioActionBean portfolioActionBean;
	
	
	public PortfolioScenarios(String partialScenarioId, String scenarioId, List<String> transactionTypeList,List<String> transactionStatusList, PortfolioActionBean portfolioActionBean) {
		this.partialScenarioId = partialScenarioId;
		this.transactionStatus = transactionStatusList;
		this.scenarioId = scenarioId;
		this.transactionType = transactionTypeList;
		this.portfolioActionBean = portfolioActionBean;
	}
	/**
	 * @return the transactionType
	 */
	public List<String> getTransactionType() {
		return transactionType;
	}
	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(List<String> transactionType) {
		this.transactionType = transactionType;
	}
	/**
	 * @return the scenarioId
	 */
	public String getScenarioId() {
		return scenarioId;
	}
	/**
	 * @return the portfolioActionBean
	 */
	public PortfolioActionBean getPortfolioActionBean() {
		return portfolioActionBean;
	}
	/**
	 * @param portfolioActionBean the portfolioActionBean to set
	 */
	public void setPortfolioActionBean(PortfolioActionBean portfolioActionBean) {
		this.portfolioActionBean = portfolioActionBean;
	}
	/**
	 * @param scenarioId the scenarioId to set
	 */
	public void setScenarioId(String scenarioId) {
		this.scenarioId = scenarioId;
	}
	/**
	 * @return the partialScenarioId
	 */
	public String getPartialScenarioId() {
		return partialScenarioId;
	}
	/**
	 * @param partialScenarioId the partialScenarioId to set
	 */
	public void setPartialScenarioId(String partialScenarioId) {
		this.partialScenarioId = partialScenarioId;
	}
	/**
	 * @return the transactionStatus
	 */
	public List<String> getTransactionStatus() {
		return transactionStatus;
	}
	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(List<String> transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return String.format(
				"PortfolioScenarios [scenarioId=%s, partialScenarioId=%s, transactionStatus=%s, portfolioActionBean=%s]",
				scenarioId, partialScenarioId, transactionStatus, portfolioActionBean);
	}
	
}


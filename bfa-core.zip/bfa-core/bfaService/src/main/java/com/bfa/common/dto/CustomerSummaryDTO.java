package com.bfa.common.dto;

import com.bfa.investment.dto.CustomerInvestmentObjectiveDTO;

public class CustomerSummaryDTO {
	private int id;
	
	private ProfileSummaryDTO profile;
	
	private CustomerInvestmentObjectiveDTO investmentObjective;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ProfileSummaryDTO getProfile() {
		return profile;
	}

	public void setProfile(ProfileSummaryDTO profile) {
		this.profile = profile;
	}

	public CustomerInvestmentObjectiveDTO getInvestmentObjective() {
		return investmentObjective;
	}

	public void setInvestmentObjective(CustomerInvestmentObjectiveDTO investmentObjective) {
		this.investmentObjective = investmentObjective;
	}

}

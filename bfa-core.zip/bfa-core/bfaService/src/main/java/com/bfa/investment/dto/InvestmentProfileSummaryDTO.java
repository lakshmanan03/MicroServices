package com.bfa.investment.dto;

import java.util.List;

import com.bfa.investment.account.dto.InvestmentAccountStatusDTO;

public class InvestmentProfileSummaryDTO {
	
	
	private PortfolioSummaryDTO portfolioSummary;
	private InvestmentAccountStatusDTO investmentAccountStatus;
	
	
	/**
	 * @return the portfolioSummary
	 */
	public PortfolioSummaryDTO getPortfolioSummary() {
		return portfolioSummary;
	}
	/**
	 * @param portfolioSummary the portfolioSummary to set
	 */
	public void setPortfolioSummary(PortfolioSummaryDTO portfolioSummary) {
		this.portfolioSummary = portfolioSummary;
	}
	/**
	 * @return the investmentAccountStatus
	 */
	public InvestmentAccountStatusDTO getInvestmentAccountStatus() {
		return investmentAccountStatus;
	}
	/**
	 * @param investmentAccountStatus the investmentAccountStatus to set
	 */
	public void setInvestmentAccountStatus(InvestmentAccountStatusDTO investmentAccountStatus) {
		this.investmentAccountStatus = investmentAccountStatus;
	}
	
}

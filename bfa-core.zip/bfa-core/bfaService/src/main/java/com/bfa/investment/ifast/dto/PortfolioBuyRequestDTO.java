package com.bfa.investment.ifast.dto;

public class PortfolioBuyRequestDTO {
	private Integer transactionId;
	private Integer customerId;
	private String portfolioId;
	private String trustId;
	private Double investmentAmount;
	private boolean payMonthly;
	private boolean insufficientFund;
	private boolean notifyInsufficientFund;
	private Integer customerPortfolioId;
	
	
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}
	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public boolean isPayMonthly() {
		return payMonthly;
	}
	public void setPayMonthly(boolean payMonthly) {
		this.payMonthly = payMonthly;
	}
	public String getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	public String getTrustId() {
		return trustId;
	}
	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
	public Double getInvestmentAmount() {
		return investmentAmount;
	}
	public void setInvestmentAmount(Double investmentAmount) {
		this.investmentAmount = investmentAmount;
	}
	public boolean isInsufficientFund() {
		return insufficientFund;
	}
	public void setInsufficientFund(boolean insufficientFund) {
		this.insufficientFund = insufficientFund;
	}
	/**
	 * @return the notifyInsufficientFund
	 */
	public boolean isNotifyInsufficientFund() {
		return notifyInsufficientFund;
	}
	/**
	 * @param notifyInsufficientFund the notifyInsufficientFund to set
	 */
	public void setNotifyInsufficientFund(boolean notifyInsufficientFund) {
		this.notifyInsufficientFund = notifyInsufficientFund;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PortfolioBuyRequestDTO [transactionId=");
		builder.append(transactionId);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", portfolioId=");
		builder.append(portfolioId);
		builder.append(", trustId=");
		builder.append(trustId);
		builder.append(", investmentAmount=");
		builder.append(investmentAmount);
		builder.append(", payMonthly=");
		builder.append(payMonthly);
		builder.append(", insufficientFund=");
		builder.append(insufficientFund);
		builder.append(", notifyInsufficientFund=");
		builder.append(notifyInsufficientFund);
		builder.append("]");
		return builder.toString();
	}


	
	
	
}

/**
 * 
 */
package com.bfa.request.entity;

import java.io.Serializable;

/**
 * 
 * GajendraK
 */
public class CompreRecommendPortfolioReq implements Serializable {

	
	private static final long serialVersionUID = 1L;

	Integer customerId;
	
	Integer enquiryId;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
	
	
}

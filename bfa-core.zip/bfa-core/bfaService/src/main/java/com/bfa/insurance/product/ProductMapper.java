/**
 * 
 */
package com.bfa.insurance.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "product")
public class ProductMapper {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "prod_id")
	public String id;

	@Column(name = "rider_id")
	public int riderId;

	@OneToOne
	@JoinColumn(name = "insurer_id")
	public Insurer insurer;

	@Column(name = "prod_name")
	public String productName;

	@Column(name = "purpose_id")
	public int purposeId;

	@Column(name = "objective_id")
	public int objectiveId;

	@Column(name = "type_id")
	public int typeId;

	@OneToOne	
	@JoinColumn(name = "promo_id")
	public Promotion promotion;

	@Column(name = "search_count")
	public int searchCount;

	@Column(name = "whybuy")
	public String whyBuy;

	@Column(name = "payout")
	public String payOut;

	@Column(name = "underwriting")
	public String underWritting;

	@Column(name = "rebate")
	public String rebate;

	@Column(name = "cash_value")
	public String cashValue;

	@Column(name = "cash_payout_frequency")
	public String cashPayoutFrequency;

	@Column(name = "coverage_duration")
	public String coverageDuration;

	@Column(name = "premium_duration")
	public String premiumDuration;

	@Column(name = "features")
	public String features;

	@Column(name = "prod_desc")
	public String productDescription;

	@Column(name = "status")
	public String status;
	
	@Column(name = "brochure_link")
	public String brochureLink;

	@Column(name = "authorised")
	public boolean isAuthorised;

	@Column(name = "last_update")
	public Date lastUpdated;

	@Column(name = "last_updated_by")
	public String lastUpdatedBy;
}

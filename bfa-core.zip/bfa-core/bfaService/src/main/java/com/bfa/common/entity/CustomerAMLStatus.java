package com.bfa.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;

@Entity
@Table(name = "customer_aml_status")
public class CustomerAMLStatus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "reference_id")
	private String referenceId;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "approval_status")
	private String approvalStatus;
	
	@Column(name = "check_status_url")
	private String checkStatusURL;
	
	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	
	
	public String getCheckStatusURL() {
		return checkStatusURL;
	}

	public void setCheckStatusURL(String checkStatusURL) {
		this.checkStatusURL = checkStatusURL;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	
	
}

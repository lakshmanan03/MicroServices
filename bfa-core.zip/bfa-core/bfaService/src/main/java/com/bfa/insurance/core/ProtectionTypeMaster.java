/**
 * 
 */
package com.bfa.insurance.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "protection_type_master")
public class ProtectionTypeMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "protection_type")
	private String protectionType;
	
	@Column(name = "protection_type_description")
	private String protectionTypeDescription;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(String protectionType) {
		this.protectionType = protectionType;
	}

	public String getProtectionTypeDescription() {
		return protectionTypeDescription;
	}

	public void setProtectionTypeDescription(String protectionTypeDescription) {
		this.protectionTypeDescription = protectionTypeDescription;
	}
}

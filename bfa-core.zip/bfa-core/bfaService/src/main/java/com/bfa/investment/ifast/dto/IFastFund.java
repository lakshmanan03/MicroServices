package com.bfa.investment.ifast.dto;

public class IFastFund {
	
	private String productId;
	private String productName;
	private String dateOfLaunch;
	private Double minimumInitialInvestment;
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDateOfLaunch() {
		return dateOfLaunch;
	}
	public void setDateOfLaunch(String dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}
	public Double getMinimumInitialInvestment() {
		return minimumInitialInvestment;
	}
	public void setMinimumInitialInvestment(Double minimumInitialInvestment) {
		this.minimumInitialInvestment = minimumInitialInvestment;
	}
	
	

}

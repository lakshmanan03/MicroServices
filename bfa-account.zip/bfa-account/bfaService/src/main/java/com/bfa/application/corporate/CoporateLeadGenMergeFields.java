/**
 * 
 */
package com.bfa.application.corporate;

/**
 * @author pradheep
 *
 */
public class CoporateLeadGenMergeFields {
	/* BFA-1840 */
	
	private String FNAME;
	
	private String LNAME;
	
	private String JOB;
	
	private String COMPANY;
	
	private String COMSIZE;
	
	private String PHONE;	
	
	private String EMAIL;

	public String getFNAME() {
		return FNAME;
	}

	public void setFNAME(String fname) {
		FNAME = fname;
	}

	public String getLNAME() {
		return LNAME;
	}

	public void setLNAME(String lname) {
		LNAME = lname;
	}

	public String getJOB() {
		return JOB;
	}

	public void setJOB(String job) {
		JOB = job;
	}

	public String getCOMPANY() {
		return COMPANY;
	}

	public void setCOMPANY(String company) {
		COMPANY = company;
	}

	public String getCOMSIZE() {
		return COMSIZE;
	}

	public void setCOMSIZE(String comsize) {
		COMSIZE = comsize;
	}

	public String getPHONE() {
		return PHONE;
	}

	public void setPHONE(String phone) {
		PHONE = phone;
	}	

	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String email) {
		EMAIL = email;
	}
}

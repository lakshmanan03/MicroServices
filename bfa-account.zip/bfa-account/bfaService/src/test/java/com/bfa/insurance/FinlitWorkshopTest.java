/**
 * 
 */
package com.bfa.insurance;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.IOUtils;
import org.hibernate.SessionFactory;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.bfa.application.core.security.FinlitAccessCode;
import com.bfa.application.core.security.FinlitAccessCodePrivilege;
import com.bfa.application.core.security.FinlitAuthenticationRequest;
import com.bfa.application.security.SecurityConstants;
import com.bfa.application.security.TokenProvider;
import com.bfa.configuration.AccountServiceConfiguration;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.PrevilageMaster;
import com.bfa.insurance.core.ResponseList;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.service.FinlitService;
import com.bfa.util.APIConstants;
import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

/**
 * Finlit Workshop Authentication Tests.
 * 
 * @author pradheep.p
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = AccountServiceConfiguration.class)
@AutoConfigureMockMvc(secure = false)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@ContextConfiguration
public class FinlitWorkshopTest {
	
	/* This class contains the test cases for finlit workshop authentication.
	 * 
	 * KINDLY DO NOT CHANGE ANY VALUES IN THE TEST BELOW 
	 * 
	 * AS THE TEST CASES ARE DESIGNED WITH SOME PREDEFINED VALUES.
	 */
	
	/*
	 * Scenario Tested
	 * 1.Testing the previleges provided in the JWT token are correct as per requirement.
	 * 2.Generate the valid JWT token with proper credentials and access code.
	 * 3.Negative testing with a invalid access code.
	 * 4.Negative scenario to cover the user who has not verified his mobile number.
	 * 5.Negative scenario to cover the user who has not verified his email address.
	 * 6.Test for invalid access code which is already expired.
	 * 7.Negative scenario to check if the authorization header validated properly.
	 * 8.Negative scenario to check if the authentication works properly.
	 */
	
	@Autowired
	private SecurityConstants securityConstants;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private AccountsDao accountsDao;

	@Autowired
	private SessionFactory sessionFactory;
	
	String authHeader = "";

	PublicUtility utility = PublicUtility.getInstance("IMXYlDmP4f4=");

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	public String ACCESS_CODE = "XBFCNM1234";

	public String testEmail = "kevin.goh@example.com";

	public String testMobile = "11002200";

	public String staticPasswordDontChange = "Welcome@123";

	private String staticAuthHeader = "kH5l7sn1UbauaC46hT8tsSsztsDS5b/575zHBrNgQAA=";

	private String sessionId = "d9ab9de9-f719-4ede-a1e5-1195b951f1db";
	
	Integer customerId;

	private String password = "U2FsdGVkX19Ae4v4watoePn36aPMZKVPa4h6Szt47Sm2I+r6dVg/K3vRH/YfyYQ1m1hefjJr3UkHWdUKUWbiPpxqm1kSVT2yGLYgkH2hylC7HK4dedrpRYLGnHmCX0r9pspORvrerroazshpB2e1sWeM4FzQCZ+Eq9aAHk3BGh15Y+0LVdUWU2AHTobIQfOUaqMZd94XcGTvCseKqQ/vRw==";
	
	final String sql_file = "classpath:MO3-1435/authenticate_workshop.sql";

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	private void printDelimiter() {
		System.out.println("---------------------------------------------------------------");
	}

	private byte[] loadPassword() {
		String fileName = "MO3-1435/password.txt";
		return readFile(fileName);
	}

	private byte[] loadSalt() {
		String fileName = "MO3-1435/saltFile.txt";
		return readFile(fileName);
	}

	private byte[] readFile(String fileName) {
		byte[] content = null;
		try {
			Resource res = new ClassPathResource(fileName);
			File file = res.getFile();
			FileInputStream fis = new FileInputStream(file);
			content = IOUtils.toByteArray(fis);
			System.out.println("Size of file :" + fileName + content.length);
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return content;
	}

	private int loadCustomerAndPrivileges(FinlitAccessCode code) {
		Customer customer = new Customer();
		customer.setAcceptMarketEmails(false);
		customer.setCountryCode("+65");
		customer.setCreatedBy("system");
		customer.setDateOfBirth(getRandomDateOfBirth());
		customer.setEmail(testEmail);
		customer.setMobileNumber(testMobile);
		customer.setEmailVerified("Yes");
		customer.setGivenName("Kevin");
		customer.setOtpVerfied("Yes");
		customer.setSurName("Goh");
		customer.setPassword(loadPassword());
		customer.setUniqueId(loadSalt());

		customer = (Customer) accountsDao.saveObject(customer);
		int customerId = customer.getId();
		System.out.println("Printing the customer id: " + customerId);

		List<String> roles = new ArrayList<String>();
		roles.add("ROLE_COMPRE_LITE");
		roles.add("ROLE_DISCOUNT_PROMOTION");
		roles.add("ROLE_INVEST_10");
		roles.add("ROLE_USER");

		for (int i = 0; i < roles.size(); i++) {
			PrevilageMaster master = new PrevilageMaster();
			master.setPrvilegeName(roles.get(i));
			master.setDescription(roles.get(i));
			master = (PrevilageMaster) accountsDao.saveObject(master);

			FinlitAccessCodePrivilege finlitAccessCodePrivilege = new FinlitAccessCodePrivilege();
			finlitAccessCodePrivilege.setFinlitAccessCodeId(code.getId());
			finlitAccessCodePrivilege.setPrivilegeId(master.getPrevilegeId());
			accountsDao.saveOrUpdateObject(finlitAccessCodePrivilege);
		}
		System.out
				.println(accountsDao.getObjectByHql("from CustomerPrevilege").size() + " Customer previleges found !");

		return customerId;

	}
	
	private void loadExpiredAccessCode(){
		FinlitAccessCode code = new FinlitAccessCode();
		code.setAccessCode(ACCESS_CODE);
		SimpleDateFormat sdf = new SimpleDateFormat(FinlitService.finlitDateFormat);
		Date today = new Date();
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTime(today);
		gregorianCalendar.add(GregorianCalendar.DAY_OF_MONTH, -10);
		gregorianCalendar.set(GregorianCalendar.HOUR_OF_DAY, 0);
		gregorianCalendar.set(GregorianCalendar.MINUTE, 0);
		gregorianCalendar.set(GregorianCalendar.SECOND, 0);
		Date todayMidNight = gregorianCalendar.getTime();
		String startDate = sdf.format(todayMidNight);
		System.out.println("Start Date " + startDate);
		// ------------------------------------------------------------//
		gregorianCalendar.add(GregorianCalendar.DAY_OF_MONTH, -8);
		gregorianCalendar.set(GregorianCalendar.HOUR_OF_DAY, 0);
		gregorianCalendar.set(GregorianCalendar.MINUTE, 0);
		gregorianCalendar.set(GregorianCalendar.SECOND, 0);
		Date tomorrowMidNight = gregorianCalendar.getTime();
		String endDate = sdf.format(tomorrowMidNight);
		System.out.println("End Date:" + endDate);
		// -------------------------------------------------------------//

		code.setStartTimestamp(java.sql.Timestamp.valueOf(startDate));
		code.setEndTimestamp(java.sql.Timestamp.valueOf(endDate));
		code.setWorkshop("New Workshop - Expired");
		code.setOrganisationCode("SMRT-TEST");
		code = (FinlitAccessCode) accountsDao.saveObject(code);
		System.out.println(
				"Printing the Access Code details - Expired One :" + code.getId() + " Start Date: " + code.getStartTimestamp().toString()
						+ " end date: " + code.getEndTimestamp().toString() + " Access Code: " + code.getAccessCode());
		customerId = loadCustomerAndPrivileges(code);

	}
	
	private void loadUnExpiredAccessCode(){
		FinlitAccessCode code = new FinlitAccessCode();
		code.setAccessCode(ACCESS_CODE);
		SimpleDateFormat sdf = new SimpleDateFormat(FinlitService.finlitDateFormat);
		Date today = new Date();
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTime(today);
		gregorianCalendar.set(GregorianCalendar.HOUR_OF_DAY, 0);
		gregorianCalendar.set(GregorianCalendar.MINUTE, 0);
		gregorianCalendar.set(GregorianCalendar.SECOND, 0);
		Date todayMidNight = gregorianCalendar.getTime();
		String startDate = sdf.format(todayMidNight);
		System.out.println("Start Date " + startDate);
		// ------------------------------------------------------------//
		gregorianCalendar.add(GregorianCalendar.DAY_OF_MONTH, 1);
		gregorianCalendar.set(GregorianCalendar.HOUR_OF_DAY, 0);
		gregorianCalendar.set(GregorianCalendar.MINUTE, 0);
		gregorianCalendar.set(GregorianCalendar.SECOND, 0);
		Date tomorrowMidNight = gregorianCalendar.getTime();
		String endDate = sdf.format(tomorrowMidNight);
		System.out.println("End Date:" + endDate);
		// -------------------------------------------------------------//

		code.setStartTimestamp(java.sql.Timestamp.valueOf(startDate));
		code.setEndTimestamp(java.sql.Timestamp.valueOf(endDate));
		code.setOrganisationCode("SMRT-TEST");
		code.setWorkshop("New Workshop A");
		code = (FinlitAccessCode) accountsDao.saveObject(code);
		System.out.println(
				"Printing the Access Code details :" + code.getId() + " Start Date: " + code.getStartTimestamp().toString()
						+ " end date: " + code.getEndTimestamp().toString() + " Access Code: " + code.getAccessCode());

		customerId = loadCustomerAndPrivileges(code);
	}

	public void loadSampleDataWithValidAccessCode() {				
		loadUnExpiredAccessCode();
		loadSessionDetails();
	}
	
	public void loadSampleDataWithInValidAccessCode() {
		clearAccessCodeDetails();				
		loadExpiredAccessCode();
		loadSessionDetails();
	}
	
	private void clearAccessCodeDetails(){
		System.out.println("-- Clearing the access code details --");
		String hql = "delete from FinlitAccessCode";
		accountsDao.executeUpdate(hql);
	}

	private void loadSessionDetails() {
		SessionDetails sessionDetails = new SessionDetails();
		sessionDetails.setSessionId(sessionId);
		sessionDetails.setDevice("mobile");
		sessionDetails.setIpAddress("0.0.0.0");
		sessionDetails.setLastUpdated(new Date());
		accountsDao.saveObject(sessionDetails);
	}

	private String getRandomDateOfBirth() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		buffer.append("19");
		int yr = ran.nextInt(99);
		if (yr >= 10) {
			buffer.append(yr);
		} else {
			buffer.append("0");
			buffer.append(yr);
		}
		buffer.append("-");
		int month = ran.nextInt(12);
		if (month >= 10) {
			buffer.append(month);
		} else {
			buffer.append("0");
			if (month == 0) {
				month++;
			}
			buffer.append(month);
		}
		buffer.append("-");
		int day = ran.nextInt(28);
		if (day >= 10) {
			buffer.append(day);
		} else {
			buffer.append("0");
			if (day == 0) {
				day++;
			}
			buffer.append(day);
		}
		return buffer.toString();
	}
	
	/* 
	 * Positive JUnit test for testing the previleges provided in the JWT token are correct as per requirement	 
	 */ 
	
	@Test
	@Sql(scripts = {sql_file})
	public void finlitWorkshopTestA() {
		printDelimiter();
		loadSampleDataWithValidAccessCode();
		System.out.println("Testing and ensure the roles provided in the JWT token are correct ");
		printDelimiter();		
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode(ACCESS_CODE);
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);			
			ResultActions resultActions = mockMvc.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8));			
			String response = resultActions.andReturn().getResponse().getContentAsString();
			Assert.assertTrue(checkForRolesInResponse(response));			
		} catch (Exception err) {
			err.printStackTrace();
		}
	}


	/*
	 *  Positive test case to generate the valid JWT token with proper credentials and access code
	 */
	@Test
	@Sql(scripts = {sql_file})
	public void finlitWorkshopTestB() {
		loadSampleDataWithValidAccessCode();
		printDelimiter();
		System.out.println("Testing the finlit workshop test B ");
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest = new FinlitAuthenticationRequest();
		finlitAuthRequest.setEmail(testEmail);
		finlitAuthRequest.setAccessCode(ACCESS_CODE);
		finlitAuthRequest.setSessionId(sessionId);
		finlitAuthRequest.setMobile(testMobile);
		finlitAuthRequest.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody = null;
		try {
			requestBody = this.convertObjectToJsonBytes(finlitAuthRequest);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest));
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "6000").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (Exception err) {
			err.printStackTrace();
		}
	}

	/* 
	 * Test for a code which does not exists in the system - Negative testing with a invalid access code *
	 */	 
	@Test	
	public void finlitWorkshopTestC() {
		printDelimiter();
		System.out.println("Testing invalid access code ");
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode("dummy_access_code");
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5122").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (Exception err) {
			err.printStackTrace();
		}
	}

		
	/* 
	 * Checks the authentication response with the roles required.
	 * 
	 * */
	private boolean checkForRolesInResponse(String arg) {		
		System.out.println("Parsing the roles from response :" + arg);
		Gson gson = new Gson();
		ResponseList responseMessageList = gson.fromJson(arg, ResponseList.class);
		List securityDetails = responseMessageList.getObjectList();
		com.google.gson.internal.LinkedTreeMap securityInfo = ( com.google.gson.internal.LinkedTreeMap) securityDetails.get(0);
		String token = securityInfo.get("securityToken").toString();		
		securityConstants.assignKey();
		String secret = securityConstants.base64SecretBytes;
		System.out.println("Secret : " + secret);
		try {			
			Claims claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
			String roles = claims.get("roles",String.class);
			List<String> robo3GrantedRoles = new ArrayList<String>();
			robo3GrantedRoles.add("ROLE_COMPRE_LITE");
			robo3GrantedRoles.add("ROLE_DISCOUNT_PROMOTION");
			robo3GrantedRoles.add("ROLE_INVEST_10");
			robo3GrantedRoles.add("ROLE_USER");
			System.out.println("Printing the roles in response :" + roles);
			for (int i = 0; i < robo3GrantedRoles.size(); i++) {
				if(!roles.contains(robo3GrantedRoles.get(i))){
					return false;
				}
			}
		} catch (ExpiredJwtException e) {
			e.printStackTrace();
			return false;
		} catch (UnsupportedJwtException e) {
			e.printStackTrace();
			return false;
		} catch (MalformedJwtException e) {
			e.printStackTrace();
			return false;
		} catch (SignatureException e) {
			e.printStackTrace();
			return false;
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			return false;
		} 
		System.out.println("-- All roles are assigned in the JWT token ! --");
		return true;
	}
	
	private void makeMobileUnverified(String mobileNumber,boolean flag){
		String state = "No";
		if(!flag){
			state = "Yes";
		}
		String hql = "update Customer set otpVerfied='" + state + "' where mobileNumber='" + mobileNumber +"'";
		accountsDao.executeUpdate(hql);
	}	
	
	
	/* 
	 * Test for unverified mobile number , Negative scenario to cover the user who has not verified his mobile number.
	 * 
	 * */
	@Test	
	public void finlitWorkshopTestE() {
		printDelimiter();
		System.out.println(" -- Test for unverified mobile -- ");
		makeMobileUnverified(testMobile,true);
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode(ACCESS_CODE);
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			ResultActions result = mockMvc.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage,"5013").exists());
			result.andDo(MockMvcResultHandlers.print());
						
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
	
	
	/* 
	 * Test for unverified email address , Negative scenario to cover the user who has not verified his email address. 
	 */	
	@Test	
	public void finlitWorkshopTestF() {
		printDelimiter();
		System.out.println(" -- Test for unverified email address -- ");
		makeMobileUnverified(testMobile, false);
		makeEmailUnverified(testEmail,true);
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode(ACCESS_CODE);
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			ResultActions result = mockMvc.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage,"5012").exists());
			result.andDo(MockMvcResultHandlers.print());
						
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
	
	private void makeEmailUnverified(String emailAddress,boolean flag){
		String state = "No";
		if(!flag){
			state = "Yes";
		}
		String hql = "update Customer set emailVerified='" + state +"' where email='" + emailAddress +"'";
		accountsDao.executeUpdate(hql);
	}	
	
	/* 
	 * Negative scenario to check if the invalid access code which is already expired works correctly.
	 * 
	 */
	@Test	
	public void finlitWorkshopTestG() {
		printDelimiter();
		System.out.println("Testing invalid access code - Expired State test");
		loadSampleDataWithInValidAccessCode();
		makeMobileUnverified(testMobile, false);
		makeEmailUnverified(testEmail,false);
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode(ACCESS_CODE);
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5122").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
	
	/* 
	 * Negative scenario to check if the authorization header validated properly.
	 */
	@Test	
	public void finlitWorkshopTestH() {		
		printDelimiter();
		System.out.println("Test for authorization header");
		loadSampleDataWithInValidAccessCode();
		makeMobileUnverified(testMobile, false);
		makeEmailUnverified(testEmail,false);
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode(ACCESS_CODE);
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword(password);

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", "helloworld").header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5005").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
	
	/* 
	 * Negative scenario to check if the authentication works properly.
	 */
	@Test	
	public void finlitWorkshopTestI() {		
		printDelimiter();
		System.out.println("Test for authentication");
		loadSampleDataWithInValidAccessCode();
		makeMobileUnverified(testMobile, false);
		makeEmailUnverified(testEmail,false);
		printDelimiter();
		FinlitAuthenticationRequest finlitAuthRequest1 = new FinlitAuthenticationRequest();
		finlitAuthRequest1.setEmail(testEmail);
		finlitAuthRequest1.setAccessCode(ACCESS_CODE);
		finlitAuthRequest1.setSessionId(sessionId);
		finlitAuthRequest1.setMobile(testMobile);
		finlitAuthRequest1.setPassword("unknown");

		Gson gson = new Gson();
		byte[] requestBody1 = null;
		try {
			requestBody1 = this.convertObjectToJsonBytes(finlitAuthRequest1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(finlitAuthRequest1));
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			authHeader = staticAuthHeader;
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION).contentType(this.APPLICATION_JSON_UTF8)
							.content(requestBody1).header("Authorization", authHeader).header("User-Agent", "junit"))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5011").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (Exception err) {
			err.printStackTrace();
		}
	}
}

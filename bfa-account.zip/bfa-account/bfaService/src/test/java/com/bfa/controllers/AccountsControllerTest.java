package com.bfa.controllers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.admin.dto.AddAdvisorRequestDTO;
import com.bfa.admin.dto.AdminCustomerDetails;
import com.bfa.admin.dto.AdminCustomerSummary;
import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.core.SaveSelectedProductsRequest;
import com.bfa.application.core.UpdateMobileNumberRequest;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.AddressDTO;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.CustomerProfileDetails;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.OptionsSearchResultDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.UpdateContactDetailsDTO;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerOverview;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.controllers.BaseController.JWTAuthToken;
import com.bfa.insurance.core.CRMResponse;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.dto.InvestementDashboardResponseDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.UpdatePasswordDTO;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.request.entity.DependentMappingRequest;
import com.bfa.request.entity.UpdateProductEnquiryRequest;
import com.bfa.service.AMLVerificationService;
import com.bfa.service.AccountsService;
import com.bfa.service.SecurityService;
import com.bfa.util.AMLVerificationServiceResponse;
import com.bfa.util.APIResponse;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessageList;
import com.bfa.util.ServiceResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class AccountsControllerTest {

	@InjectMocks
	private AccountsController mAccountsController;
	
	@Mock
	private AccountsService mAccountsService;

	@Mock
	private HttpServletRequest mHttpServletRequest;
	
	@Mock
	private EmploymentDetailsDTO mEmploymentDetailsDTO;
	
	@Mock
	private AddressDTO mAddressDTO;
	
	@Mock
	private DependentMapping mDependentMapping;
	
	@Mock
	private DependentMappingRequest mDependentMappingRequest;

	@Mock
	private CustomerCreationPostRequest	mCustomerCreationPostRequest;

	@Mock
	private Customer mCustomer;
	
	@Mock
	private ContactDetailsDTO	mContactDetailsDTO;
	
	@Mock
	private CRMResponse mCRMResponse;
	
	@Mock
	private UpdateProductEnquiryRequest mUpdateProductRequest;
	
	@Mock
	private SecurityService mSecurityService;
	
	@Mock
	private SessionDetails mSessionDetails;
	
	@Mock
	private UpdateContactDetailsDTO mUpdateContactDetailsDTO;
	
	@Mock
	private UpdatePasswordDTO mUpdatePasswordDTO;
	
	@Mock
	private BFAUserDetails mBFAUserDetails;
	
	@Mock
	private CustomerDetailsDTO mCustomerDetailsDTO;
	
	@Mock
	private AddAdvisorRequestDTO mAddAdvisorRequestDTO;
	
	@Mock
	private CustomerBankDetail mCustomerBankDetail;
	
	@Mock
	private AdminCustomerDetails mAdminCustomerDetails;
	
	@Mock
	private SaveSelectedProductsRequest mSaveSelectedProductsRequest;
	
	@Mock
	private JWTAuthToken mJWTAuthToken;
	
	@Mock
	private CustomerAndPrevilege mCustomerAndPrevilege;
	
	@Mock
	private ProfileSummaryDTO mProfileSummaryDTO;
	
	@Mock
	private InvestementDashboardStatusDTO mInvestementDashboardStatusDTO;
	
	@Mock
	private CustomerCreationPostRequestV2 mCustomerCreationPostRequestV2;
	
	@Mock
	private ServiceResponse<Boolean> mServiceResposne;
	
	@Mock
	private UpdateMobileNumberRequest mUpdateMbl;
	
	@Mock
	private TokenProvider tokenProvider;
	
	@Mock
	private AdminCustomerSummary mAdminCustomerSummary;
	
	@Mock
	private AMLVerificationService mAmlService;
	
	@Mock
	private AMLVerificationServiceResponse mAmlResponse;
	
	@Mock
	private AdminSearchRequestDTO mAdminSearchRequestDTO;
	
	@Mock
	private UpdateCustomerAddressDTO mUpdateCustomerAddressDTO;
	
	@Mock
	private MultipartFile mMultipartFile;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;
	
	@Mock
	private Logger mLogger;
	
	
	String appKey = "IMXYlDmP4f4=";
	
	@Mock
	PublicUtility utility = PublicUtility.getInstance(appKey);
	
	String customerIdInRequest = "1";
	
	String sessionId="52145-ahdhkl";
	
	int enqId=1;
	
	int cusId=1;
	
	String cusStringId = "1";
	
	Integer cusIdInteger = 1;
	
	int advisorId=1;
		
	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	     
		
		List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
		BFAGrandtedAuthority grantedAuth = new BFAGrandtedAuthority("ROLE_USER");
		grantedAuthorityList.add(grantedAuth);
		String jwtTokenobj = tokenProvider.getTokenString("-1", grantedAuthorityList);
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn("1234");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(jwtTokenobj);
	}

	@Test
	public void testTestUpdateInvStatus() {

		APIResponse<Map<String, Object>> response = mAccountsController.testUpdateInvStatus();
		assertNotNull(response);
	}

	@Test
	public void testGetProfileList() {
		ResponseMessageList response = mAccountsController.getProfileList();
		assertNotNull(response);
	}
	
	@Test
	public void testGetProfileListDBException() {
		
		when(mAccountsService.getProfileList()).thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mAccountsController.getProfileList();
		assertNotNull(response);
	}
	
	@Test
	public void testGetProfileListException() {
		
		when(mAccountsService.getProfileList()).thenThrow(new RuntimeException());
		ResponseMessageList response = mAccountsController.getProfileList();
		assertNotNull(response);
	}
	
	@Test
	public void testGetEmploymentStatus() {

		ResponseMessageList response = mAccountsController.getEmploymentStatus();
		assertNotNull(response);
	}

	
	@Test
	public void testGetEmploymentStatusDBException() {
		when(mAccountsService.getEmploymentList()).thenThrow(new DatabaseAccessException());
		ResponseMessageList response = mAccountsController.getEmploymentStatus();
		assertNotNull(response);
	}
	
	@Test
	public void testGetEmploymentStatusException() {
		when(mAccountsService.getEmploymentList()).thenThrow(new RuntimeException());
		ResponseMessageList response = mAccountsController.getEmploymentStatus();
		assertNotNull(response);
	}
	
	@Test
	public void testEditProfileEmploymentDetailsDTOHttpServletRequest() {
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		mAddressDTO.setCity("chennai");
		mEmploymentDetailsDTO.setContactNumber("81098552");
		mEmploymentDetailsDTO.setEmployerName("gajendra");
		mEmploymentDetailsDTO.setEmployerAddress(mAddressDTO);
		ResponseMessageList response = mAccountsController.editProfile(mEmploymentDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	
	}
	
	
	@Test
	public void testEditProfileEmploymentException() {
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		doThrow(new RuntimeException()).when(mAccountsService).updateEmployment(mCustomer,mEmploymentDetailsDTO);
		ResponseMessageList response = mAccountsController.editProfile(mEmploymentDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	
	}
	
	@Test
	public void testSaveDependents() {

		List<DependentMapping> dependentMappingList = new ArrayList<>();
		dependentMappingList.add(mDependentMapping);
		mDependentMappingRequest.setDependentMappingList(dependentMappingList);
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		ResponseMessageList response = mAccountsController.saveDependents(mDependentMappingRequest,mHttpServletRequest);
		assertNotNull(response);

	}
	
	@Test
	public void testSaveDependentsDBException() {

		List<DependentMapping> dependentMappingList = new ArrayList<>();
		dependentMappingList.add(mDependentMapping);
		mDependentMappingRequest.setDependentMappingList(dependentMappingList);
		when(mDependentMappingRequest.getDependentMappingList()).thenReturn(dependentMappingList);
		doThrow(new DatabaseAccessException()).when(mAccountsService).saveDependents(dependentMappingList);
		ResponseMessageList response = mAccountsController.saveDependents(mDependentMappingRequest,mHttpServletRequest);
		assertNotNull(response);

	}	
	
	@Test
	public void testSaveDependentsException() {

		List<DependentMapping> dependentMappingList = new ArrayList<>();
		dependentMappingList.add(mDependentMapping);
		mDependentMappingRequest.setDependentMappingList(dependentMappingList);
		when(mDependentMappingRequest.getDependentMappingList()).thenReturn(dependentMappingList);
		doThrow(new RuntimeException()).when(mAccountsService).saveDependents(dependentMappingList);
		ResponseMessageList response = mAccountsController.saveDependents(mDependentMappingRequest,mHttpServletRequest);
		assertNotNull(response);

	}
	

	@Test
	public void testSignup() {
		
		when(mCustomerCreationPostRequest.getCaptcha()).thenReturn("svmjk");
		when(mCustomerCreationPostRequest.getSessionId()).thenReturn(sessionId);
		when(mCustomerCreationPostRequest.getJourneyType()).thenReturn("comprehsensive");
		when(mSecurityService.isValidCaptcha(sessionId, "svmjk")).thenReturn(true);
		when(mAccountsService.validateUser(mCustomerCreationPostRequest)).thenReturn("Validation success");
		when(mAccountsService.signup(mCustomerCreationPostRequest)).thenReturn(mCustomerAndPrevilege);
		when(mCustomerAndPrevilege.getCustomer()).thenReturn(mCustomer);
		when(mCustomer.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.Signup(mCustomerCreationPostRequest);
		assertNotNull(response);
		
		when(mSecurityService.isValidCaptcha(sessionId, "svmjk")).thenReturn(false);
		ResponseMessageList res = mAccountsController.Signup(mCustomerCreationPostRequest);
		assertNotNull(res);
		
		when(mSecurityService.isValidCaptcha(sessionId, "svmjk")).thenReturn(true);
		when(mAccountsService.validateUser(mCustomerCreationPostRequest)).thenReturn("fail");
		ResponseMessageList respo = mAccountsController.Signup(mCustomerCreationPostRequest);
		assertNotNull(respo);
	}
	
	
	@Test
	public void testSignupException() {
		
		when(mCustomerCreationPostRequest.getCaptcha()).thenReturn("svmjk");
		when(mCustomerCreationPostRequest.getSessionId()).thenReturn(sessionId);
		when(mCustomerCreationPostRequest.getJourneyType()).thenReturn("comprehsensive");
		when(mSecurityService.isValidCaptcha(sessionId, "svmjk")).thenReturn(true);
		when(mAccountsService.validateUser(mCustomerCreationPostRequest)).thenReturn("Validation success");
		when(mAccountsService.signup(mCustomerCreationPostRequest)).thenThrow(new RuntimeException());
		when(mCustomerAndPrevilege.getCustomer()).thenReturn(mCustomer);
		when(mCustomer.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.Signup(mCustomerCreationPostRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSignupDBException() {
		
		when(mCustomerCreationPostRequest.getCaptcha()).thenReturn("svmjk");
		when(mCustomerCreationPostRequest.getSessionId()).thenReturn(sessionId);
		when(mCustomerCreationPostRequest.getJourneyType()).thenReturn("comprehsensive");
		when(mSecurityService.isValidCaptcha(sessionId, "svmjk")).thenReturn(true);
		when(mAccountsService.validateUser(mCustomerCreationPostRequest)).thenReturn("Validation success");
		when(mAccountsService.signup(mCustomerCreationPostRequest)).thenThrow(new DatabaseAccessException());
		when(mCustomerAndPrevilege.getCustomer()).thenReturn(mCustomer);
		when(mCustomer.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.Signup(mCustomerCreationPostRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testEditPersonalDetails() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		when(mAccountsService.updateCustomerContactDetails(cusId, mContactDetailsDTO, mHttpServletRequest)).thenReturn(mServiceResposne);
		ResponseMessageList response = mAccountsController.editPersonalDetails(mContactDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	
	}


	@Test
	public void testSaveCRMDataInCustomer() {
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		ResponseMessageList response = mAccountsController.saveCRMDataInCustomer(mCRMResponse, mHttpServletRequest);
		assertNotNull(response);
	}

	
	@Test
	public void testSaveCRMDataInCustomerDBException() {
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		doThrow(new DatabaseAccessException()).when(mAccountsService).updateCRMDetailsOfCustomer(mCRMResponse);
		ResponseMessageList response = mAccountsController.saveCRMDataInCustomer(mCRMResponse, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSaveCRMDataInCustomerException() {
				
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		doThrow(new RuntimeException()).when(mAccountsService).updateCRMDetailsOfCustomer(mCRMResponse);
		ResponseMessageList response = mAccountsController.saveCRMDataInCustomer(mCRMResponse, mHttpServletRequest);
		assertNotNull(response);
	}
	
	
	@Test
	public void testGetProfileSummary() {
		
		APIResponse<ProfileSummaryDTO> response = mAccountsController.getProfileSummary(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetCustomerProfile() {
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
	//	when(mAccountsController.getCustomerId(mHttpServletRequest)).thenReturn(cusId);
		when(mAccountsService.getCustomerProfileDetails(cusId)).thenReturn(mProfileSummaryDTO);
		APIResponse<ProfileSummaryDTO> response= mAccountsController.getCustomerProfile(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetCustomerProfileException() {
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getCustomerProfileDetails(cusId)).thenThrow(new RuntimeException());
		APIResponse<ProfileSummaryDTO> response= mAccountsController.getCustomerProfile(mHttpServletRequest);
		assertEquals(response.getResponseMessage().getResponseCode(), ErrorCodes.INTERNAL_SERVER_ERROR);
		assertEquals(response.getResponseMessage().getResponseDescription(), ApplicationConstants.INTERNAL_SERVER_ERROR);
	
	}
	
	@Test
	public void testGetCustomerProfileDBException() {
			
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
//		when(mAccountsController.getCustomerId(mHttpServletRequest)).thenReturn(cusId);
		when(mAccountsService.getCustomerProfileDetails(cusId)).thenThrow(new DatabaseAccessException());
		APIResponse<ProfileSummaryDTO> response= mAccountsController.getCustomerProfile(mHttpServletRequest);
		assertEquals(response.getResponseMessage().getResponseCode(), ErrorCodes.INTERNAL_SERVER_ERROR);
		assertEquals(response.getResponseMessage().getResponseDescription(), ApplicationConstants.INTERNAL_SERVER_ERROR);
	}
	
	
	
	@Test
	public void testDashboardDetails() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsController.getAuthUser(mHttpServletRequest)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mAccountsService.getInvestmentDashboardStatus(cusId)).thenReturn(mInvestementDashboardStatusDTO);
		APIResponse<InvestementDashboardResponseDTO> response=mAccountsController.dashboardDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testDashboardDetailsException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsController.getAuthUser(mHttpServletRequest)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mAccountsService.getInvestmentDashboardStatus(cusId)).thenThrow(new RuntimeException());
		APIResponse<InvestementDashboardResponseDTO> response=mAccountsController.dashboardDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	
	/*@Test
	public void testGetDetailedCustomerSummary() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		APIResponse<DetailedCustomerSummary> response=mAccountsController.getDetailedCustomerSummary(cusId, mHttpServletRequest);
		assertNotNull(response);
	}*/


	@Test
	public void testFetchCustomerSummary() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.fetchIndividualCustomerDetails(cusId, advisorId)).thenReturn(mAdminCustomerDetails);
		APIResponse<AdminCustomerDetails> response = mAccountsController.fetchCustomerSummary(cusId, advisorId,mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testFetchCustomerSummaryException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.fetchIndividualCustomerDetails(cusId, advisorId)).thenThrow(new RuntimeException());
		APIResponse<AdminCustomerDetails> response = mAccountsController.fetchCustomerSummary(cusId, advisorId,mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testFetchCustomerSummaryDBException() {

		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.fetchIndividualCustomerDetails(cusId, advisorId)).thenThrow(new DatabaseAccessException());
		APIResponse<AdminCustomerDetails> response = mAccountsController.fetchCustomerSummary(cusId, advisorId,mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testFetchCustomerDetails() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		APIResponse<List<AdminCustomerDetails>> response = mAccountsController.fetchCustomerDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	
	@Test
	public void testFetchCustomerDetailsException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getCustomerSummaryByAdvisor(1)).thenThrow(new RuntimeException());
		APIResponse<List<AdminCustomerDetails>> response = mAccountsController.fetchCustomerDetails(mHttpServletRequest);
		assertNotNull(response);
	}
	
	
	@Test
	public void testFetchCustomerDetailsDBException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getCustomerSummaryByAdvisor(1)).thenThrow(new DatabaseAccessException());
		APIResponse<List<AdminCustomerDetails>> response = mAccountsController.fetchCustomerDetails(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testGetCustomerSummaryByAdvisor() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		APIResponse<List<AdminCustomerDetails>> response=mAccountsController.getCustomerSummaryByAdvisor(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetCustomerSummaryByAdvisorException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getCustomerSummaryByAdvisor(1)).thenThrow(new RuntimeException());
		APIResponse<List<AdminCustomerDetails>> response=mAccountsController.getCustomerSummaryByAdvisor(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testGetCustomerSummaryByAdvisorDBException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getCustomerSummaryByAdvisor(1)).thenThrow(new DatabaseAccessException());
		APIResponse<List<AdminCustomerDetails>> response=mAccountsController.getCustomerSummaryByAdvisor(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void UpdateProductEnquiry() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		ResponseMessageList response=mAccountsController.updateProductEnquiry(mUpdateProductRequest, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void UpdateProductEnquiryException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mUpdateProductRequest.getCustomerId()).thenThrow(new RuntimeException());
		ResponseMessageList response=mAccountsController.updateProductEnquiry(mUpdateProductRequest, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void UpdateProductEnquiryDBException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mUpdateProductRequest.getCustomerId()).thenThrow(new DatabaseAccessException());
		ResponseMessageList response=mAccountsController.updateProductEnquiry(mUpdateProductRequest, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSendContactUsEmail() {
		Map<String, Object> emailMap=new HashMap<>();
		emailMap.put("toEmail","gajendra@ntuc.com");
		emailMap.put("subject","greetings");
		emailMap.put("body","hi");
		emailMap.put("custEmail","gaja@ntuc.com");
		emailMap.put("custContactNo","6235844");
		ResponseMessageList response = mAccountsController.sendContactUsEmail(emailMap);
		assertNotNull(response);
	}

	@Test
	public void testSendContactUsEmailException() {
		Map<String, Object> emailMap=new HashMap<>();
		emailMap.put("toEmail","gajendra@ntuc.com");
		emailMap.put("subject","greetings");
		emailMap.put("body","hi");
		emailMap.put("custEmail","gaja@ntuc.com");
		emailMap.put("custContactNo","6235844");
		doThrow(new RuntimeException()).when(mAccountsService).sendContactUsEmail("gajendra@ntuc.com", "greetings", "hi", "gaja@ntuc.com", "6235844");
		ResponseMessageList response = mAccountsController.sendContactUsEmail(emailMap);
		assertNotNull(response);
	}
	
	@Test
	public void testGetSessionDetails() {
		
		when(mHttpServletRequest.getParameter("sessionId")).thenReturn("56863-12987-5687");
		when(mSecurityService.getSessionDetailsBySessionId("56863-12987-5687")).thenReturn(mSessionDetails);
		when(mSessionDetails.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.getSessionDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testEditProfileUpdateContactDetailsDTOHttpServletRequest() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		ResponseMessageList response = mAccountsController.editProfile(mEmploymentDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testEditProfileUpdateContactDetailsException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		doThrow(new RuntimeException()).when(mAccountsService).updateCustomerAddress(mCustomer.getId(),mCustomer.getAdvisorId(),mUpdateCustomerAddressDTO);
		ResponseMessageList response = mAccountsController.editProfile(mEmploymentDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testEditPassword() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		when(mAccountsService.editPassword(mCustomer, mUpdatePasswordDTO)).thenReturn(true);
		ResponseMessageList response = mAccountsController.editPassword(mUpdatePasswordDTO, mHttpServletRequest);
		assertNotNull(response);
		
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		when(mAccountsService.editPassword(mCustomer, mUpdatePasswordDTO)).thenReturn(false);
		ResponseMessageList res = mAccountsController.editPassword(mUpdatePasswordDTO, mHttpServletRequest);
		assertNotNull(res);
	}

	@Test
	public void testEditPasswordException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getDetailsByCustomerId(cusId)).thenReturn(mCustomer);
		when(mAccountsService.editPassword(mCustomer, mUpdatePasswordDTO)).thenThrow(new RuntimeException());
		ResponseMessageList response = mAccountsController.editPassword(mUpdatePasswordDTO, mHttpServletRequest);
		assertNotNull(response);

	}
	
	@Test
	public void testSaveCustomerDetails() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.saveCustomerDetails(mCustomerDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveCustomerDetailsException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mAccountsService.saveCustomerDetails(mCustomerDetailsDTO, cusId)).thenThrow(new RuntimeException());
		ResponseMessageList response = mAccountsController.saveCustomerDetails(mCustomerDetailsDTO, mHttpServletRequest);
		assertNotNull(response);
	}
	
	
	@Test
	public void testSaveDocumentsV2() {
		
		when(mAccountsService.getUserById(1234)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.saveDocumentsV2(mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, "details", mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSaveDocumentsV2Null() {
		
		when(mAccountsService.getUserById(1234)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		ResponseMessageList response = mAccountsController.saveDocumentsV2(null, null, null, null, null, null, null, null, mHttpServletRequest);
		assertNotNull(response);
	}

    //will be later
	@Test
	public void testAddAdvisorThrowNumberFormatException() {
		
		AddAdvisorRequestDTO addAdvisorRequestDTO = new AddAdvisorRequestDTO();
		addAdvisorRequestDTO.setCustomerId(cusStringId);
		when(utility.DecryptText(addAdvisorRequestDTO.getCustomerId())).thenReturn(null);
		
		doThrow(new RuntimeException()).when(utility).DecryptText(addAdvisorRequestDTO.getCustomerId());
	}
	
	@Test
	public void testAddAdvisorException() {
		
		when(mAddAdvisorRequestDTO.getAdvisorId()).thenReturn(1);
		when(mAddAdvisorRequestDTO.getCustomerId()).thenReturn(""+cusId);
		when(mAccountsService.addAdvisor(cusId, advisorId)).thenThrow(new RuntimeException());
	}
	
	@Test
	public void testVerifyAML() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		Object response=mAccountsController.verifyAML(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testVerifyAMLException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenThrow(new RuntimeException());
		Object response=mAccountsController.verifyAML(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testClearAML() {
			
		when(mAccountsService.getUserById(1234)).thenReturn(mBFAUserDetails);
		when(mAmlService.clearVerification(1234)).thenReturn(mAmlResponse);
		Object response=mAccountsController.clearAML(cusId, mHttpServletRequest);
		assertNotNull(response);
		
	}

	@Test
	public void testGetCustomerBanks() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		APIResponse<List<CustomerBankDetail>> response = mAccountsController.getCustomerBanks(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetCustomerBanksExcepion() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenThrow(new RuntimeException());
		APIResponse<List<CustomerBankDetail>> response = mAccountsController.getCustomerBanks(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSaveCustomerBank() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		APIResponse<CustomerBankDetail> response = mAccountsController.saveCustomerBank(mCustomerBankDetail, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveCustomerBankException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenThrow(new RuntimeException());
		APIResponse<CustomerBankDetail> response = mAccountsController.saveCustomerBank(mCustomerBankDetail, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testCustomerAddress() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		APIResponse<Map<String, Address>> response=mAccountsController.customerAddress(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testCustomerAddressException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenThrow(new RuntimeException());
		APIResponse<Map<String, Address>> response=mAccountsController.customerAddress(mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testCustomerProfileDetails() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenReturn(1);
		APIResponse<CustomerProfileDetails> response=mAccountsController.customerProfileDetails(mHttpServletRequest);
		assertNotNull(response);
		
	}
	
	@Test
	public void testCustomerProfileDetailsException() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mAccountsService.getUserById(cusId)).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.getId()).thenThrow(new RuntimeException());
		APIResponse<CustomerProfileDetails> response=mAccountsController.customerProfileDetails(mHttpServletRequest);
		assertNotNull(response);
		
	}
	
	@Test(expected = NullPointerException.class)
	public void testTestOptionsSearch() {
		OptionsSearchResultDTO response=mAccountsController.testOptionsSearch();
	}

	@Test
	public void testSignupv2() {
		
		ResponseMessageList response=mAccountsController.signupv2(mCustomerCreationPostRequestV2, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testUpdateSelectedProducts() {
		when(mHttpServletRequest.getAttribute("customerIdInRequest")).thenReturn(customerIdInRequest);
		when(mSaveSelectedProductsRequest.getIsNewCustomer()).thenReturn(true);
		ResponseMessageList response = mAccountsController.updateSelectedProducts(mSaveSelectedProductsRequest, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testUpdateMobileNumberByCustomerId(){
		
		when(mUpdateMbl.getCustomerRef()).thenReturn("customerref");
		when(mUpdateMbl.getMobileNumber()).thenReturn("91764301");
		when(mAccountsService.updateMobileNumber(mUpdateMbl)).thenReturn(mServiceResposne);
		when(mServiceResposne.getResponse()).thenReturn(true);
		ResponseMessageList response = mAccountsController.updateMobileNumberByCustomerId(mUpdateMbl);
		assertNotNull(response);
		
	}
	
	@Test
	public void testUpdateMobileNumberByCustomerIdException(){
		
		when(mUpdateMbl.getCustomerRef()).thenReturn("customerref");
		when(mUpdateMbl.getMobileNumber()).thenReturn("91764301");
		when(mAccountsService.updateMobileNumber(mUpdateMbl)).thenThrow(new RuntimeException());
		when(mServiceResposne.getResponse()).thenReturn(true);
		ResponseMessageList response = mAccountsController.updateMobileNumberByCustomerId(mUpdateMbl);
		assertNotNull(response);
		
	}
	
	@Test
	public void fetchCustomerSummaryTest() {
		
		when(mAccountsService.fetchCustomerSummary(cusId, 1234)).thenReturn(mAdminCustomerSummary);
		APIResponse<AdminCustomerSummary> response = mAccountsController.fetchCustomerSummary(cusId, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void fetchCustomerSummaryTestDBException() {

		when(mAccountsService.fetchCustomerSummary(cusId, 1234)).thenThrow(new DatabaseAccessException());
		APIResponse<AdminCustomerSummary> response = mAccountsController.fetchCustomerSummary(cusId, mHttpServletRequest);
		assertEquals(response.getResponseMessage().getResponseCode(), ErrorCodes.INTERNAL_SERVER_ERROR);
		assertEquals(response.getResponseMessage().getResponseDescription(), ApplicationConstants.INTERNAL_SERVER_ERROR);
	}
	
	@Test
	public void fetchCustomerSummaryTestException() {
		
		when(mAccountsService.fetchCustomerSummary(cusId, 1234)).thenThrow(new RuntimeException());
		APIResponse<AdminCustomerSummary> response = mAccountsController.fetchCustomerSummary(cusId, mHttpServletRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSearchCustomersDBException() {
		
		when(mAccountsService.findCustomers(mAdminSearchRequestDTO)).thenThrow(new DatabaseAccessException());
		APIResponse<List<CustomerOverview>> response = mAccountsController.searchCustomers(mAdminSearchRequestDTO, mHttpServletRequest);
		assertNull(response);
	}
	
	@Test
	public void testSearchCustomersException() {

		when(mAccountsService.findCustomers(mAdminSearchRequestDTO)).thenThrow(new RuntimeException());
		APIResponse<List<CustomerOverview>> response = mAccountsController.searchCustomers(mAdminSearchRequestDTO, mHttpServletRequest);
		assertNull(response);
	}
	
}

package com.bfa.investment.dto;

public class PortfolioInvestmentPreferenceDTO {
	private String portfolioId;
	private Double monthlyInvestmentAmount;
	
	public String getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	public Double getMonthlyInvestmentAmount() {
		return monthlyInvestmentAmount;
	}
	public void setMonthlyInvestmentAmount(Double monthlyInvestmentAmount) {
		this.monthlyInvestmentAmount = monthlyInvestmentAmount;
	}
	
	
}

/**
 * 
 */
package com.bfa.application.core;

/**
 * @author pradheep.p
 *
 */
public class OTPRequest {
	
	private String customerRef;
	
	private String otp;
	
	private boolean editProfile;

	
	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public boolean isEditProfile() {
		return editProfile;
	}

	public void setEditProfile(boolean editProfile) {
		this.editProfile = editProfile;
	}	
	

}

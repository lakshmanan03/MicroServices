package com.bfa.investment.ifast.dto;

public class RSPBuyForm extends BuyFormDTO {
	
	private String rspFrequency;
	private Double rspAmount;
	public String getRspFrequency() {
		return rspFrequency;
	}
	public void setRspFrequency(String rspFrequency) {
		this.rspFrequency = rspFrequency;
	}
	public Double getRspAmount() {
		return rspAmount;
	}
	public void setRspAmount(Double rspAmount) {
		this.rspAmount = rspAmount;
	}
}

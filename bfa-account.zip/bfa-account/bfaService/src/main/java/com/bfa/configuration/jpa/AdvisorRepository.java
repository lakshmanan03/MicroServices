package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.common.entity.Advisor;

public interface AdvisorRepository extends JpaRepository<Advisor, Integer> {
	Advisor findByEmailId(String emailId);
	Advisor findByMobileNumber(String mobileNumber);
}

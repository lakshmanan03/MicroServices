package com.bfa.admin.dto;

import java.util.Date;

public class VerifyEddDTO {

	private Integer id;
	private CustomerDTO customer;
	private int customerPortfolioId;
	private String agentId;
	private String ifastRefno;
	private String counterPartyAccountNumber;
	private String ifastStatus;
	private String investmentAccountStatus;
	private String reviewComments;
	private String trustId;
	private Double cashAccountBalance;
	private Date accountCreatedDate;
	private String ifastResponse;
	private Date createdDate;
	private Date lastUpdatedTimeStamp;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public CustomerDTO getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDTO customer) {
		this.customer = customer;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getIfastRefno() {
		return ifastRefno;
	}
	public void setIfastRefno(String ifastRefno) {
		this.ifastRefno = ifastRefno;
	}
	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}
	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}
	public String getIfastStatus() {
		return ifastStatus;
	}
	public void setIfastStatus(String ifastStatus) {
		this.ifastStatus = ifastStatus;
	}
	public String getInvestmentAccountStatus() {
		return investmentAccountStatus;
	}
	public void setInvestmentAccountStatus(String investmentAccountStatus) {
		this.investmentAccountStatus = investmentAccountStatus;
	}
	public String getReviewComments() {
		return reviewComments;
	}
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}
	public String getTrustId() {
		return trustId;
	}
	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
	public Double getCashAccountBalance() {
		return cashAccountBalance;
	}
	public void setCashAccountBalance(Double cashAccountBalance) {
		this.cashAccountBalance = cashAccountBalance;
	}
	public Date getAccountCreatedDate() {
		return accountCreatedDate;
	}
	public void setAccountCreatedDate(Date accountCreatedDate) {
		this.accountCreatedDate = accountCreatedDate;
	}
	public String getIfastResponse() {
		return ifastResponse;
	}
	public void setIfastResponse(String ifastResponse) {
		this.ifastResponse = ifastResponse;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}
	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}
	public int getCustomerPortfolioId() {
		return customerPortfolioId;
	}
	public void setCustomerPortfolioId(int customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	
}

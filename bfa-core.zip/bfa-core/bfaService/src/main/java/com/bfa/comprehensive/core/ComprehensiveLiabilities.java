/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "comprehensive_liabilities")
public class ComprehensiveLiabilities {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name="home_loan_outstanding_amt")
	private Double homeLoanOutstandingAmount;
	
	@Column(name="other_property_loan_outstanding_amt")
	private Double otherPropertyLoanOutstandingAmount;
	
	@Column(name="other_loan_outstanding_amt")
	private Double otherLoanOutstandingAmount;
	
	@Column(name="car_loan_amt")
	private Double carLoansAmount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}	

	public Double getOtherPropertyLoanOutstandingAmount() {
		return otherPropertyLoanOutstandingAmount;
	}

	public void setOtherPropertyLoanOutstandingAmount(Double otherPropertyLoanOutstandingAmount) {
		this.otherPropertyLoanOutstandingAmount = otherPropertyLoanOutstandingAmount;
	}

	public Double getOtherLoanOutstandingAmount() {
		return otherLoanOutstandingAmount;
	}

	public void setOtherLoanOutstandingAmount(Double otherLoanOutstandingAmount) {
		this.otherLoanOutstandingAmount = otherLoanOutstandingAmount;
	}

	public Double getHomeLoanOutstandingAmount() {
		return homeLoanOutstandingAmount;
	}

	public void setHomeLoanOutstandingAmount(Double homeLoanOutstandingAmount) {
		this.homeLoanOutstandingAmount = homeLoanOutstandingAmount;
	}

	public Double getCarLoansAmount() {
		return carLoansAmount;
	}

	public void setCarLoansAmount(Double carLoansAmount) {
		this.carLoansAmount = carLoansAmount;
	}	
	
}
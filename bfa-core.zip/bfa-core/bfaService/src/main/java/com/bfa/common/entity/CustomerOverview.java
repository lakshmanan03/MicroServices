package com.bfa.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_customer_overview")
public class CustomerOverview {

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private Integer moCustomerId;
	
	@Column(name = "customer_name")
	private String customerName;
	
	@Column(name = "mobile_number")
	private String mobileNumber;
	
	@Column(name = "email")
	private String emailId;
	
	@Column(name = "account_status")
	private String accountStatus;
	

	@Column(name = "advisor_id")
	private Integer advisorId;
	
	@Column(name = "advisor_name")
	private String advisorName;
	
	@Column(name = "journeys")
	private String journeys;
	
	@Column(name = "ifast_refno")
	private String iFastRefNo;
	
	@Column(name = "nric_number")
	private String nricNumber;
	
	@Column(name = "passport_number")
	private String passportNumber;
	


	

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	

	public Integer getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(Integer advisorId) {
		this.advisorId = advisorId;
	}

	public String getJourneys() {
		return journeys;
	}

	public void setJourneys(String journeys) {
		this.journeys = journeys;
	}

	

	
	public String getAdvisorName() {
		return advisorName;
	}

	public void setAdvisorName(String advisorName) {
		this.advisorName = advisorName;
	}

	public String getNricNumber() {
		return nricNumber;
	}

	public void setNricNumber(String nricNumber) {
		this.nricNumber = nricNumber;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public Integer getMoCustomerId() {
		return moCustomerId;
	}

	public void setMoCustomerId(Integer moCustomerId) {
		this.moCustomerId = moCustomerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getiFastRefNo() {
		return iFastRefNo;
	}

	public void setiFastRefNo(String iFastRefNo) {
		this.iFastRefNo = iFastRefNo;
	}

	@Override
	public String toString() {
		return "CustomerOverview [moCustomerId=" + moCustomerId + ", customerName=" + customerName + ", mobileNumber="
				+ mobileNumber + ", emailId=" + emailId + ", accountStatus=" + accountStatus + ", advisorId="
				+ advisorId + ", advisorName=" + advisorName + ", journeys=" + journeys + ", iFastRefNo=" + iFastRefNo
				+ ", nricNumber=" + nricNumber + ", passportNumber=" + passportNumber + "]";
	}

	

	
}

package com.bfa.common.dto;


public class HospitalizationNeedsDTO {
	
	private int id;

	private int customerId;

	private int enquiryId;

	private int hospitalClassId;

	private boolean isFullRider;

	private String hospitalPlanType;

	private boolean isPartialRider;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getHospitalClassId() {
		return hospitalClassId;
	}

	public void setHospitalClassId(int hospitalClassId) {
		this.hospitalClassId = hospitalClassId;
	}

	public boolean isFullRider() {
		return isFullRider;
	}

	public void setFullRider(boolean isFullRider) {
		this.isFullRider = isFullRider;
	}

	public String getHospitalPlanType() {
		return hospitalPlanType;
	}

	public void setHospitalPlanType(String hospitalPlanType) {
		this.hospitalPlanType = hospitalPlanType;
	}

	public boolean isPartialRider() {
		return isPartialRider;
	}

	public void setPartialRider(boolean isPartialRider) {
		this.isPartialRider = isPartialRider;
	}
	
	

}

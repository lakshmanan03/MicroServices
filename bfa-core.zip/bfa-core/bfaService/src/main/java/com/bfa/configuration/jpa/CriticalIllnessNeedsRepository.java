/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.insurance.core.CriticalIllnessNeeds;

/**
 * @author pradheep.p
 *
 */
public interface CriticalIllnessNeedsRepository extends JpaRepository<CriticalIllnessNeeds, Integer> {

}

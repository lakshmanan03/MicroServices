package com.bfa.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.comprehensive.core.ComprehensiveEnquiry;
import com.bfa.comprehensive.core.ComprehensiveHouseHold;
import com.bfa.comprehensive.core.DependentEducationPreferences;
import com.bfa.comprehensive.core.DependentEntity;
import com.bfa.dao.ComprehensiveDao;
import com.bfa.insurance.core.Enquiry;
import com.bfa.investment.entity.ComprehensivePricing;
import com.bfa.util.ApplicationConstants;

@Transactional
@Repository
public class ComprehensiveDaoImpl<T extends Object> extends BaseDaoImpl implements ComprehensiveDao {

	@Override
	public void saveDependentList(List dependents1) throws DatabaseAccessException {

		Session session = null;

		try {
			session = sessionFactory.openSession();
			Transaction trx = session.beginTransaction();

			if (dependents1 != null && !dependents1.isEmpty()) {

				for (Object depobj : dependents1) {

					session.saveOrUpdate(depobj);
				}
			}
			trx.commit();

		} catch (Exception e) {
			getLogger().error("Error while saving the dependents data", e);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}

	}

	@Override
	public List<DependentEntity> getDependentDetails(Integer customerId,Integer enquiryId) {
		List<DependentEntity> dependentList = new ArrayList<>();
		Session session = null;
		try {
		String active = "active";
		getLogger().info("getDependentDetails  customerId " + customerId + " enquiryId "+enquiryId);
		session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(DependentEntity.class);
		
		criteria.add(Restrictions.eq("customerId",customerId));
		criteria.add(Restrictions.eq("enquiryId", enquiryId));
		criteria.add(Restrictions.eq("status", active));
		dependentList = criteria.list();
		}catch (Exception ex) {
			getLogger().error("Exception occured in ComprehensiveDaoImpl.getDependentDetails():  " , ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}

		return dependentList;
	}

	@Override
	public ComprehensiveHouseHold getComprehensiveHouseHold(Integer customerId,Integer enquiryId) {
		
		
		ComprehensiveHouseHold houseHoldEntity = null;

		List<ComprehensiveHouseHold> listHouseHold =  new ArrayList<>();
		Session session = null;
		try {
			getLogger().info("getComprehensiveHouseHold  customerId " + customerId + " enquiryId"+enquiryId);
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ComprehensiveHouseHold.class);
			
			criteria.add(Restrictions.eq("customerId",customerId));
			criteria.add(Restrictions.eq("enquiryId", enquiryId));
			listHouseHold = criteria.list();
			
		if (! listHouseHold.isEmpty()) {

			houseHoldEntity = listHouseHold.get(0);
		}
		}catch (Exception ex) {
			getLogger().error("Exception occured in ComprehensiveDaoImpl.getComprehensiveHouseHold():  " , ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}

		return houseHoldEntity;
	}

	@Override
	public void saveDependentEndowmentPlan(List dependentEndowmentPlan, String hasEndowments, Integer enquiryId,
			Integer customerId) {

		getLogger().debug("started Pesrsisting saveDependentEndowmentPlan()");

		try {

			boolean isExistingEndowmentPlan = checkExisingEndowmentPlans(enquiryId, customerId);
			if (isExistingEndowmentPlan) {
				deleteChildEndowmentPlans(enquiryId, customerId, hasEndowments);
			}

			if (dependentEndowmentPlan != null && !dependentEndowmentPlan.isEmpty()) {
				getLogger().debug("Update record if preferences record existed and create new if not available");

				for (Object depobj : dependentEndowmentPlan) {
					save(depobj);
				}

				getLogger().info("Success saved endowment plans for the EnquiryId::" + enquiryId);
				getLogger().info("Success saved endowment plans for the CustomerId::" + customerId);

			} else {
				getLogger().info("Unable to process save dependent endowment plans for the customerId:" + customerId);
			}

		} catch (Exception e) {
			getLogger().error("Error while saving the child endowment Plan for the customerId::" + customerId, e);
			e.getMessage();
			throw new DatabaseAccessException();
		}
	}

	private void updateComprehensiveEnquiry(Integer enquiryId, int customerId, String hasEndowments) {

		Session session = sessionFactory.openSession();

		try {
			Transaction trx = session.beginTransaction();

			Query updateQuery = session.createQuery(
					"update ComprehensiveEnquiry set hasEndowments =:hasEndowments where enquiryId =:enquiryId and customerId=:customerId");
			updateQuery.setParameter("hasEndowments", hasEndowments);
			updateQuery.setParameter("enquiryId", enquiryId);
			updateQuery.setParameter("customerId", customerId);
			int resultedRows = updateQuery.executeUpdate();

			if (resultedRows > 0) {
				getLogger().info("Updated ComprehensiveEnquiry hasEndowments: " + hasEndowments
						+ " for the customer enquiry Id :" + enquiryId + " and customer :" + customerId);
			}

			trx.commit();

		} catch (Exception e) {
			getLogger().error("Error while update ComprehensiveEnquiry for the customerId" + customerId, e);
			e.getMessage();
			throw new DatabaseAccessException();
		} finally {
			session.clear();
			session.close();
		}

	}

	private boolean checkExisingEndowmentPlans(Integer enquiryId, Integer customerId) throws DatabaseAccessException {
		getLogger().info("checkExisingEndowmentPlans  customerId " + customerId + " enquiryId "+enquiryId);
		try {
			if (enquiryId != null && customerId != null) {
				List<DependentEducationPreferences> depEducationPrefList = null; 
				depEducationPrefList = getDependentEducationPreferences(enquiryId,customerId);
				if (depEducationPrefList != null && !depEducationPrefList.isEmpty()) {
					return true;
				}
			} else {
				getLogger().info("Unable to check whether existing record or not for the customerId:" + customerId);
			}
		} catch (Exception err) {
			getLogger().error("Error while checking preferences record existing or not", err);
			err.getMessage();
			throw new DatabaseAccessException();
		}
		return false;
	}

	@Override
	public void deleteChildEndowmentPlans(Integer enquiryId, Integer customerId, String hasEndowments) {

		getLogger().debug("deleting all endowment plans......");
		Session session = sessionFactory.openSession();

		try {
			Transaction trx = session.beginTransaction();

			Query query = session.createQuery(
					"delete DependentEducationPreferences where enquiryId = :enquiryId and customerId = :customerId");
			query.setParameter("enquiryId", enquiryId);
			query.setParameter("customerId", customerId);
			int result = query.executeUpdate();

			if (result > 0) {
				getLogger().info("deleted RegularSavings for the enquiryId:" + enquiryId);
			}

			trx.commit();

		} catch (Exception e) {
			getLogger().error("Error while deleteAllEndowmentPlans", e);
			throw new DatabaseAccessException();
		} finally {
			session.clear();
			session.close();
		}
	}

	private ComprehensiveEnquiry getComprehensiveEnquiryObject(Integer enquiryId, Integer customerId) {

		getLogger().debug("To update has endowments get getComprehensiveEnquiryObject(): " + enquiryId);

		getLogger().info("getComprehensiveEnquiryObject"+customerId);
		ComprehensiveEnquiry enquiryObj = getComprehensiveEnquiry(enquiryId,customerId);

		getLogger().info("Comprehensive Enquiry obj"+enquiryObj);
		
		return enquiryObj;
	}

	@Override
	public List<DependentEducationPreferences> getDependentEducationPreferences(int enquiryId, int customerId) {

		List<DependentEducationPreferences> childEndowmentPlans = new ArrayList<>();
		Session session = null;
		try {
			if (customerId != -1) {
				
				session = sessionFactory.openSession();
				Criteria criteria = session.createCriteria(DependentEducationPreferences.class);
				criteria.add(Restrictions.eq("customerId",customerId));
				criteria.add(Restrictions.eq("enquiryId", enquiryId));
				childEndowmentPlans = criteria.list();
			} else {
				getLogger().error("Enquiry id should not be empty, unable to get the DependentEducationPreferences");
			}
		} catch (Exception err) {
			getLogger().error("Error while getting Education Preferences and endowments", err);
			throw new DatabaseAccessException();
		}finally {
			session.clear();
			session.close();
		}

		return childEndowmentPlans;
	}

	@Override
	public ComprehensiveEnquiry getActiveComprehensiveEnquiry(final Integer enquiryId, Integer customerId) {

		getLogger().debug("To get Enquiry id, has endowments  getActiveComprehensiveEnquiry(): " + enquiryId);

		List<ComprehensiveEnquiry> comprehensiveEnquiryList = null;
		Session session = null;
		if (enquiryId != null) {
			try {
				session = sessionFactory.openSession();
				Criteria criteria = session.createCriteria(ComprehensiveEnquiry.class);
				criteria.add(Restrictions.eq("customerId",customerId));
				criteria.add(Restrictions.eq("enquiryId", enquiryId));
				criteria.add(Restrictions.eq("hasEndowments", String.valueOf(ApplicationConstants.NUMBER_ONE)));
				comprehensiveEnquiryList = criteria.list();
			} catch (Exception err) {
				getLogger().error("Error while getting enquiryId from getActiveComprehensiveEnquiry", err);
				throw new DatabaseAccessException();
			}
			finally {
				session.clear();
				session.close();
			}
		}
		return (comprehensiveEnquiryList == null || comprehensiveEnquiryList.isEmpty()) ? null
				: comprehensiveEnquiryList.get(0);
	}

	@Override
	public ComprehensiveEnquiry getComprehensiveEnquiry(Integer enquiryId, Integer customerId) {

		getLogger().info("getComprehensiveEnquiry enquiryId: "+enquiryId+" customerId: "+customerId);
		ComprehensiveEnquiry enquiryObj = null;
		List<ComprehensiveEnquiry> enquiryList = null;
		Session session = null;
			try {
				session = sessionFactory.openSession();
				Criteria criteria = session.createCriteria(ComprehensiveEnquiry.class);
				if(null != enquiryId) {
					criteria.add(Restrictions.eq("enquiryId", enquiryId));
				}
				criteria.add(Restrictions.eq("customerId",customerId));
				enquiryList = criteria.list();
			} catch (Exception err) {
				getLogger().error("Error while getting enquiryId from getComprehensiveEnquiry", err);
				throw new DatabaseAccessException();
			}
			finally {
				session.clear();
				session.close();
			}

		if (!enquiryList.isEmpty()) {

			enquiryObj = enquiryList.get(0);
		}

		return enquiryObj;

	}

	@Override
	public ComprehensiveEnquiry getComprehensiveEnquiryByCustId(Integer customerId) {

		getLogger().info("getComprehensiveEnquiryByCustId "+customerId);
		ComprehensiveEnquiry enquiryObj = getComprehensiveEnquiry(null,customerId);

		getLogger().info("Comprehensive Enquiry obj"+enquiryObj);
		
		return enquiryObj;

	}

	@Override
	public void saveComprehensiveEnquiry(ComprehensiveEnquiry enquiry) throws DatabaseAccessException {

		Session session = null;

		try {
			session = sessionFactory.openSession();

			Transaction trx = session.beginTransaction();

			session.saveOrUpdate(enquiry);

			trx.commit();

		} catch (Exception e) {
			getLogger().error("Error while saving the comprehensive enquiry", e);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}

	}
	
	@Override
	public Enquiry getCustomerEnquiryDetails(Integer customerId, String journeyType){
		getLogger().info("getCustomerEnquiryDetails: customerId: "+customerId+" journeyType: "+journeyType);
		Enquiry enquiry = null;
		try {
			List<Enquiry> list = null;
			Session session = null;
			try {
				session = sessionFactory.openSession();
				Criteria criteria = session.createCriteria(Enquiry.class);
				criteria.add(Restrictions.eq("type", journeyType));
				criteria.add(Restrictions.eq("customerId",customerId));
				criteria.addOrder(Order.desc("id"));
				list = criteria.list();
			} catch (Exception err) {
				getLogger().error("Error while getting enquiryId from getCustomerEnquiryDetails", err);
				throw new DatabaseAccessException();
			}
			finally {
				session.clear();
				session.close();
			}
			if (list != null && !list.isEmpty()) {
				enquiry = list.get(0);
			}
		} catch (Exception ex) {
			getLogger().error("Exception occured in ComprehensiveDaoImpl.getCustomerEnquiryDetails():  " + ex);
		}
		return enquiry;
	}
	
	@Override
	public List<ComprehensivePricing> getComprehensiveProductPricing(String productType, String promotion){
		Session session = null;
		List<ComprehensivePricing> productPricing=null;
		try{
			getLogger().error("getComprehensiveProductPricing ComprehensiveDaoImpl productType || promotion:  " + productType + "||"+promotion);
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ComprehensivePricing.class);
			
			 // promotion may be null, but if it isn't it must be value(ROLE_COMPRE_DISCOUNT).
			if(promotion!=null){
			criteria.add(Restrictions.eq("productName",productType));
			criteria.add(Restrictions.eq("promotion", promotion));
			}else{
				criteria.add(Restrictions.eq("productName",productType));
				criteria.add(Restrictions.isNull("promotion"));
			}
			productPricing = criteria.list();
			
		}catch (Exception ex) {
			getLogger().error("Exception occured in ComprehensiveDaoImpl.getProductPricing():  " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return productPricing;
	}

}

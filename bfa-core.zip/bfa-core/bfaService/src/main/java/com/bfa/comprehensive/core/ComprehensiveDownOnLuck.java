/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "comprehensive_down_on_luck")
public class ComprehensiveDownOnLuck {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	@JsonIgnore
	private Integer id;
	
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name="bad_mood_fund")
	private Double badMoodMonthlyAmount;
	
	@Column(name="hospital_plan")
	private Integer hospitalPlanId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getBadMoodMonthlyAmount() {
		return badMoodMonthlyAmount;
	}

	public void setBadMoodMonthlyAmount(Double badMoodMonthlyAmount) {
		this.badMoodMonthlyAmount = badMoodMonthlyAmount;
	}

	public Integer getHospitalPlanId() {
		return hospitalPlanId;
	}

	public void setHospitalPlanId(Integer hospitalPlanId) {
		this.hospitalPlanId = hospitalPlanId;
	}
	

}

/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep
 *
 */
public class EnquiryRecommendedDetails extends CustomerRecommendationsData {
	
	private UpdateCustomerRequest updateCustomerRequest;	

	public UpdateCustomerRequest getUpdateCustomerRequest() {
		return updateCustomerRequest;
	}

	public void setUpdateCustomerRequest(UpdateCustomerRequest updateCustomerRequest) {
		this.updateCustomerRequest = updateCustomerRequest;
	}
	
}

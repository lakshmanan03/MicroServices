package com.bfa.common.dto;

import com.bfa.investment.entity.DocumentStatusMaster;

public class CustomerDocumentInfo {
	
	private Integer id;
	private String fileName;
	private String docType;
	private String reviewComments;
	private DocumentStatusMaster documentStatus;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getReviewComments() {
		return reviewComments;
	}
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}
	public DocumentStatusMaster getDocumentStatus() {
		return documentStatus;
	}
	public void setDocumentStatus(DocumentStatusMaster documentStatus) {
		this.documentStatus = documentStatus;
	}
	
	

}

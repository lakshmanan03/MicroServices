/**
 * 
 */
package com.bfa.insurance;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.configuration.jpa.CustomerPrevilegeRepository;
import com.bfa.configuration.jpa.CustomerRepository;
import com.bfa.configuration.jpa.EmploymentStatusMasterRepository;
import com.bfa.configuration.jpa.PrevilegeMasterRepository;
import com.bfa.configuration.jpa.ProfileRepository;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.CRMResponse;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.DependentProtectionNeeds;
import com.bfa.insurance.core.EmploymentStatusMaster;
import com.bfa.insurance.core.Profile;
import com.bfa.insurance.product.ProductList;
import com.bfa.notification.messenger.EmailHelper;
import com.bfa.promotion.model.PromotionBundleModel;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.serviceimpl.AccountsServiceImpl;
import com.bfa.util.ApplicationConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pradheep.p
 *
 */

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure = false)
public class AccountsServiceTest {

//	@Resource
	@Mock
	private ProfileRepository profileRepository;

//	@Resource
	@Mock
	private EmploymentStatusMasterRepository employmentStatusMasterRepository;

	@InjectMocks
	private AccountsServiceImpl accountServiceImpl;

	@Mock
	private CustomerRepository customerRepository;

	@Mock
	private CustomerPrevilegeRepository customerPrevilegeRepository;

	@Mock
	private PrevilegeMasterRepository previlegeMasterRepository;

	@Mock
	private AccountsDao mAccountsDAO;

	@Mock
	private TokenProvider tokenProvider;

//	@Mock
	private MockMvc mockMvc;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private Customer mcustObj;
	
	@Mock
	private CustomerCreationPostRequest mCustomerCreationPostRequest;
	
	@Mock
	private EmailHelper helper;
	
	@Mock
	private ApplicationContext mApplicationContext;
	
	private Integer customerId = 1;
	
	@Mock
	private BFAUserDetails mBFAUserDetails;
	
	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	@Transactional
	private void loadProfiles() {
		System.out.println("Loading profile");
		Profile profileSample = new Profile();
		mAccountsDAO.saveObject(profileSample);
	}

	@Transactional
	private void loadEmploymentStatusMaster() {
		System.out.println("Loading EmploymentStatusMaster :: ");
		EmploymentStatusMaster employmentStatusMaster = new EmploymentStatusMaster();
		mAccountsDAO.saveObject(employmentStatusMaster);
	}

	@Transactional
	private Customer loadCustomers() {

		System.out.println("--- Inserting customer ---");
		Customer customerObj = new Customer();
		customerObj.setEmail("test@email.com");
		customerObj.setGender("male");
		customerObj.setSurName("test");
		customerObj.setGivenName("testuser");
		customerObj.setMobileNumber("80000001");
		customerObj.setSmoker(true);
		customerObj.setEmailVerified("Yes");
		customerObj.setOtpString("11111");
		customerObj.setOtpVerfied("Yes");
		customerObj.setCreatedDate(new Date());
		customerObj.setDateOfBirth("18/04/1990");
		customerObj.setCountryCode("65");
		customerObj.setVerificationEnquiryId(100);
		when((Customer) mAccountsDAO.saveObject(customerObj)).thenReturn(mcustObj);
		when(mcustObj.getId()).thenReturn(customerId);
		return mcustObj;
	}

	@Test
	public void getProfileListTest() {
		System.out.println("----- Loading profile test ------");
		loadProfiles();
		Collection profileCollection = accountServiceImpl.getProfileList();
		Assert.assertNotNull(profileCollection);
	}

	@Test
	public void testEmploymentStatusMaster() {
		System.out.println("------ Loading employment status master test -------- ");
		loadEmploymentStatusMaster();
		Collection employmentStatusMasterList = accountServiceImpl.getEmploymentList();
		Assert.assertNotNull(employmentStatusMasterList);
	}

	@Test
	public void testUserDetailByEmail() {
		System.out.println("---- Loading test user detail by email -----");
		loadCustomers();
		when(mAccountsDAO.loadUserByEmail("test@email.com")).thenReturn(mBFAUserDetails);
		UserDetails userDetails = accountServiceImpl.getUserByEmail("test@email.com");
		Assert.assertNotNull(userDetails);
	}

	@Test
	public void saveDependentsTest() {
		System.out.println("-- Testing save dependents ---");
		List<DependentMapping> dependentMappingList = new ArrayList<DependentMapping>();
		DependentMapping dependentMapping = new DependentMapping();
		dependentMapping.setCustomerId(1);
		dependentMapping.setEnquiryId(1);
		dependentMapping.setId(1);
		dependentMapping.setAge("33");
		DependentProtectionNeeds dependentProtectionNeeds = new DependentProtectionNeeds();
		dependentProtectionNeeds.setCountryOfEducation("singapore");
		dependentProtectionNeeds.setEducationCourse("medicine");
		dependentProtectionNeeds.setMonthlySupportAmount(500.0);
		dependentProtectionNeeds.setNationality("singaporean");
		dependentProtectionNeeds.setPremiumWaiver(true);
		dependentMapping.setDependentProtectionNeeds(dependentProtectionNeeds);
		dependentMappingList.add(dependentMapping);
		accountServiceImpl.saveDependents(dependentMappingList);
	}

	@Test
	public void testSaveSessionDetails() {
		System.out.println("---Testing save session details---");
		HttpServletRequest servletRequest = Mockito.mock(HttpServletRequest.class);
		when(servletRequest.getHeader("User-Agent")).thenReturn("windows");
		when(servletRequest.getHeader("X-FORWARDED-FOR")).thenReturn("1.1.1.1");
		accountServiceImpl.saveSessionDetails(servletRequest);
	}

	@Test
	public void testInValidUserEmail() {
		System.out.println("-- Testing invalid user email ---");
		CustomerCreationPostRequest customerCreationPostRequest = new CustomerCreationPostRequest();
		Customer customerObj = new Customer();
		customerObj.setEmail("test#email.org");
		customerCreationPostRequest.setEnquiryId(100);
		customerCreationPostRequest.setCustomer(customerObj);
		String result = accountServiceImpl.validateUser(customerCreationPostRequest);
		Assert.assertEquals(ApplicationConstants.VALIDATION_ERROR_INVALID_EMAIL, result);
	}

	@Test
	public void testInValidUserMobile() {
		System.out.println("-- Testing invalid user mobile ---");
		CustomerCreationPostRequest customerCreationPostRequest = new CustomerCreationPostRequest();
		Customer customerObj = new Customer();
		customerObj.setEmail("test@email.org");
		customerObj.setMobileNumber("df34qa2366");
		customerCreationPostRequest.setEnquiryId(100);
		customerCreationPostRequest.setCustomer(customerObj);
		String result = accountServiceImpl.validateUser(customerCreationPostRequest);
		Assert.assertEquals(ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE_NUM, result);
	}

	@Test
	public void testInValidUserMobile1() {
		System.out.println("-- Testing invalid user mobile1 ---");		

		when(mCustomerCreationPostRequest.getEnquiryId()).thenReturn(100);
		when(mcustObj.getEmail()).thenReturn("test@email.org");
		when(mcustObj.getMobileNumber()).thenReturn("66");
		when(mCustomerCreationPostRequest.getCustomer()).thenReturn(mcustObj);
		
		String result = accountServiceImpl.validateUser(mCustomerCreationPostRequest);
		Assert.assertEquals(ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE, result);
	}

	private Customer getSampleCustomer() {
		Customer customerObj = new Customer();
		customerObj.setEmail("test@email.com");
		customerObj.setGender("male");
		customerObj.setSurName("test");
		customerObj.setGivenName("testuser");
		customerObj.setMobileNumber("80000001");
		customerObj.setSmoker(true);
		customerObj.setEmailVerified("Yes");
		customerObj.setOtpString("11111");
		customerObj.setOtpVerfied("Yes");
		customerObj.setCreatedDate(new Date());
		customerObj.setDateOfBirth("18/04/1990");
		customerObj.setCountryCode("65");
		customerObj.setVerificationEnquiryId(100);
		return customerObj;
	}

	@Test
	public void testForUniqueMobile() {
		System.out.println("-- Testing unique mobile numbers ---");
		Customer xy = loadCustomers();
//		CustomerCreationPostRequest customerCreationPostRequest = new CustomerCreationPostRequest();
//		Customer customerObj = getSampleCustomer();
//		customerObj.setId(xy.getId());
//		customerObj.setEmail("test1@email.com");
//		customerCreationPostRequest.setEnquiryId(101);
//		customerCreationPostRequest.setCustomer(customerObj);
		
		when(mCustomerCreationPostRequest.getEnquiryId()).thenReturn(102);
		when(mcustObj.getEmail()).thenReturn("test@email.org");
		when(mcustObj.getMobileNumber()).thenReturn("86666666");
		when(mcustObj.getId()).thenReturn(customerId);
		when(mCustomerCreationPostRequest.getCustomer()).thenReturn(mcustObj);
		
		String result = accountServiceImpl.validateUser(mCustomerCreationPostRequest);
		System.out.println("Ans :" + result);
		Assert.assertEquals(ApplicationConstants.VALIDATION_SUCCESS, result);
	}

	@Test
	public void testForUniqueEmail() {
		System.out.println("-- Testing unique email address ---");
		Customer xy = loadCustomers();
		Customer obj = getSampleCustomer();
		
		
		when(mCustomerCreationPostRequest.getEnquiryId()).thenReturn(102);
		when(mcustObj.getEmail()).thenReturn("test@email.org");
		when(mcustObj.getMobileNumber()).thenReturn("86666666");
		when(mcustObj.getId()).thenReturn(customerId);
		when(mCustomerCreationPostRequest.getCustomer()).thenReturn(mcustObj);
		when(mCustomerCreationPostRequest.getEnquiryId()).thenReturn(1);
		
		String result = accountServiceImpl.validateUser(mCustomerCreationPostRequest);
		Assert.assertEquals(ApplicationConstants.VALIDATION_SUCCESS, result);
	}

	@Test
	public void testEncryptUserResponseData() {
		String arg = "to-be-encrypted";
		String result = accountServiceImpl.encryptUserResponseData(arg);
		Assert.assertNotNull(result);
	}

	@Test
	public void testUpdateCRMDetailsOfCustomer() {
		CRMResponse crmResponse = new CRMResponse();
		crmResponse.setAgent_id("12");
		crmResponse.setCustomerId(1);
		crmResponse.setEntity_id("34");
		crmResponse.setEntity_type("lead");
		accountServiceImpl.updateCRMDetailsOfCustomer(crmResponse);
	}

	@Test
	@Ignore
	public void testGetProfileSummaryTest() {
		ProfileSummaryDTO profileSummary = accountServiceImpl.getProfileSummary("test@email.com");
		Assert.assertNotNull(profileSummary);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateCustomerdetails() {
		String customerId = "1";
		int enquiryId = 100;
		List<ProductList> productList = Collections.emptyList();
		accountServiceImpl.updateCustomerdetails(enquiryId, customerId, productList);
	}

	@Test(expected = NullPointerException.class)
	public void testContactUsEmail() {
		when((EmailHelper) this.mApplicationContext.getBean("emailHelper")).thenReturn(helper);
		accountServiceImpl.sendContactUsEmail("notifications@moneyowl.sg", "Test Email",
				"Do not reply- This is a test email.", "test123@email123.com", "91234567");

	}

	@Test
	public void testisOTPValid() {
		accountServiceImpl.isOTPValid("abc", "990022");
	}

	@Test
	public void testUpdatePassword() {
		accountServiceImpl.updatePassword("dfcvgt", "123456");
	}	

	@Test
	public void retirementBundleTest() {
		System.out.println("--- Testing the retirement bundle --- ");		
		String API_REGISTER_BUNDLE = "/api/registerBundleEnquiry";
		String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";		
		PromotionBundleModel model = getPromotionBundleModel();
		String authHeader = getAuthToken();
		ResultActions result;
		try {
			result = mockMvc
					.perform(post(API_REGISTER_BUNDLE).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(model)).header("Authorization", authHeader).header("User-Agent", "JUnit"))					
					.andExpect(jsonPath(responseMessage, "6000").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private PromotionBundleModel getPromotionBundleModel(){
		PromotionBundleModel model = new PromotionBundleModel();
		model.setContactNumber("80011221");
		model.setDateOfBirth("01-05-1975");
		model.setEmailAddress("kevin.goh@gmail.com");
		model.setEnquiryType("retirement-bundle");
		model.setFirstName("Kevin");
		model.setGender("Male");
		model.setLastName("Goh");
		model.setReceiveMarketingEmails("Yes");
		return model;
	}

	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_USER");
		BFAGrandtedAuthority grantedAuthority2 = new BFAGrandtedAuthority("ROLE_SIGNED_USER");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		authorities.add(grantedAuthority2);
		return tokenProvider.getTokenString("-1", authorities);
	}

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

}

/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.CustomerPrevilege;

/**
 * @author pradheep.p
 *
 */
public class CustomerAndPrevilegeV2 extends AccountStatus {

	private Customer customer;

	private List<CustomerPrevilege> previleges;	
	
	private String securityToken;	

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<CustomerPrevilege> getPrevileges() {
		return previleges;
	}

	public void setPrevileges(List<CustomerPrevilege> previleges) {
		this.previleges = previleges;
	}

	public String getSecurityToken() {
		return securityToken;
	}

	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}	
}

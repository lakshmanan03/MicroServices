/**
 * 
 */
package com.bfa.request.entity;

import java.util.Date;

/**
 * BFA-1719
 * 
 * @author pradheep
 *
 */
public class CustomerRecommendationsData extends RecommendationPostRequest {	
	
	private Date lastEnquiredDate;

	public Date getLastEnquiredDate() {
		return lastEnquiredDate;
	}

	public void setLastEnquiredDate(Date lastEnquiredDate) {
		this.lastEnquiredDate = lastEnquiredDate;
	}
	
}

package com.bfa.application.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "customer_preference")
public class CustomerPreference {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "track_status")
	private Boolean trackStatus;
	
	@Column(name = "track_code")
	private String trackCode;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "last_updated_time_stamp")
	private Date lastupdatedtimeStamp;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Boolean getTrackStatus() {
		return trackStatus;
	}

	public void setTrackStatus(Boolean trackStatus) {
		this.trackStatus = trackStatus;
	}

	public String getTrackCode() {
		return trackCode;
	}

	public void setTrackCode(String trackCode) {
		this.trackCode = trackCode;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastupdatedtimeStamp() {
		return lastupdatedtimeStamp;
	}

	public void setLastupdatedtimeStamp(Date lastupdatedtimeStamp) {
		this.lastupdatedtimeStamp = lastupdatedtimeStamp;
	}

}

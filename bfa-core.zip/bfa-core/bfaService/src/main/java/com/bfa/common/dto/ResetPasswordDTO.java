package com.bfa.common.dto;

public class ResetPasswordDTO {

	private String password;
	
	private String resetKey;

	private String sessionId;
	
	private Boolean isAdmin;
	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getResetKey() {
		return resetKey;
	}

	public void setResetKey(String resetKey) {
		this.resetKey = resetKey;
	}

	public String getSessionId() {
	return sessionId;
	}
		
	public void setSessionId(String sessionId) {
	this.sessionId = sessionId;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	
}

/**
 * 
 */
package com.bfa.request.processor;

import java.util.Date;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.request.aggregate.DefaultSuccessHandler;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ErrorCodes;
import com.bfa.util.UniqueKeyGenerator;

/**
 * @author pradheep.p
 *
 */
public class HttpProcessorGetCommand extends ProcessorCommand {

	@Autowired
	private BFAHttpClient bfaHttpClient;

	@Autowired
	private Environment env;

	/**
	 * This is the URL to be hit for processing the command.
	 */
	private String URL;

	private String httpMethod;

	private HashMap headers;

	private HashMap cookies;

	private SuccessHandler successHandler;

	private FailureHandler failureHandler;

	private boolean isSucceeded = false;

	private String commandName;

	public void setParameters(String URL, String httpMethod, String commandName, HashMap headers, HashMap cookies) {
		this.commandName = commandName;
		this.URL = URL;
		this.httpMethod = httpMethod;
		this.headers = headers;		
		this.cookies = cookies;
		this.uniqueKey = UniqueKeyGenerator.getUniqueKey();
	}

	@Override
	public void run() {
		try {
			if (timeDelayForReschedule > 0) {
				System.out.println("Time delay set for :" + timeDelayForReschedule + " Milli Seconds");
				Thread.currentThread().sleep(timeDelayForReschedule);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Procesing command :" + this.uniqueKey + " Started : " + new Date() + " Thread name: "+ Thread.currentThread().getName());
		BFAHttpResponse responseObj = doHttpUpdate();
		System.out.println("---------------------------------------------------");
		if (responseObj != null) {
			System.out.println(responseObj.toString());
		} else {
			System.out.println("No response from remote call : " + getCommandName());
		}
		System.out.println("---------------------------------------------------");
		if (isHttpCallSuccessful(responseObj)) {
			isSucceeded = true;
			if (getSuccessHandler() instanceof HttpRequestSuccessHandler) {
				BFAHttpOperations httpOperations = (BFAHttpOperations) getSuccessHandler();
				httpOperations.setPreOpreratedResponse(responseObj);
			}
			if(getSuccessHandler() instanceof DefaultSuccessHandler) {
				BFAHttpOperations httpOperations = (BFAHttpOperations) getSuccessHandler();
				httpOperations.setPreOpreratedResponse(responseObj);
			}
			getSuccessHandler().run();
			System.out.println("Command executed successfully : " + getCommandName());
		} else {
			getFailureHandler().run();
			System.out.println("Command execution failed : " + getCommandName());
		}

	}

	private boolean isHttpCallSuccessful(BFAHttpResponse responseObj) {
		if (responseObj == null) {
			return false;
		}
		if (responseObj.getResponseCode() == ErrorCodes.HTTP_SUCCESS_CODE) {
			return true;
		}
		return false;
	}

	private BFAHttpResponse doHttpUpdate() {
		try {
			BFAHttpResponse responseObj = bfaHttpClient.doGetCall(getURL(), getHeaders(), getCookies());
			return responseObj;
		} catch (Exception err) {
			err.printStackTrace();
		}
		return null;
	}

	@Override
	public SuccessHandler getSuccessHandler() {
		return this.successHandler;
	}

	@Override
	public FailureHandler getFailureHandler() {
		return this.failureHandler;
	}

	@Override
	public boolean isCommandSucceeded() {
		return isSucceeded;
	}

	@Override
	public String getCommandName() {
		return this.commandName;
	}

	/**
	 * @return the uRL
	 */
	public String getURL() {
		return URL;
	}

	/**
	 * @param uRL
	 *            the uRL to set
	 */
	public void setURL(String uRL) {
		URL = uRL;
	}

	/**
	 * @return the httpMethod
	 */
	public String getHttpMethod() {
		return httpMethod;
	}

	/**
	 * @param httpMethod
	 *            the httpMethod to set
	 */
	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}	

	/**
	 * @return the isSucceeded
	 */
	public boolean isSucceeded() {
		return isSucceeded;
	}

	/**
	 * @param isSucceeded
	 *            the isSucceeded to set
	 */
	public void setSucceeded(boolean isSucceeded) {
		this.isSucceeded = isSucceeded;
	}

	/**
	 * @param successHandler
	 *            the successHandler to set
	 */
	public void setSuccessHandler(SuccessHandler successHandler) {
		this.successHandler = successHandler;
	}

	/**
	 * @param failureHandler
	 *            the failureHandler to set
	 */
	public void setFailureHandler(FailureHandler failureHandler) {
		this.failureHandler = failureHandler;
	}

	/**
	 * @param commandName
	 *            the commandName to set
	 */
	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}

	public HashMap getHeaders() {
		return headers;
	}

	public void setHeaders(HashMap headers) {
		this.headers = headers;
	}

	public HashMap getCookies() {
		return cookies;
	}

	public void setCookies(HashMap cookies) {
		this.cookies = cookies;
	}

	@Override
	public int compareTo(Object o) {
		return 0;
	}
}

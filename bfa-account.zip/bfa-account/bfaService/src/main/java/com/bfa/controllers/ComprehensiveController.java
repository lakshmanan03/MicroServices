package com.bfa.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bfa.application.core.EnquiryReference;
import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCode;
import com.bfa.application.core.PromoCodeRequest;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.BFAUserDetailsService;
import com.bfa.application.security.SecurityConstants;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveHouseHoldDTO;
import com.bfa.common.dto.ComprehensiveResult;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.common.dto.DependentSummaryDTO;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;
import com.bfa.comprehensive.dto.InsuranceAgentCallback;
import com.bfa.exception.ComprehensiveException;
import com.bfa.insurance.core.ComprehensiveDependentMapping;
import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;
import com.bfa.investment.account.dto.ComprehensivePricingDTO;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.request.entity.ComprehensiveChildEndowmentPlanRequest;
import com.bfa.request.entity.ComprehensiveDependentRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.request.entity.ValidatePromoCodeRequest;
import com.bfa.service.ComprehensiveService;
import com.bfa.service.PromoCodeService;
import com.bfa.util.APIConstants;
import com.bfa.util.APIResponse;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ResponseMessageList;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "/api")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ComprehensiveController extends BaseController {

	@Autowired
	private ComprehensiveService comprehensiveService;

	@Autowired
	private BFAUserDetailsService bfaUserDetailsService;

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private SecurityConstants securityConstants;

	@Autowired
	private Environment env;

	@Autowired
	private PromoCodeRepository promoCodeRepository;

	@Autowired
	private PromoCodeService promoCodeService;

	@PostMapping(value = "/api/customer/comprehensive/addPersonalDetails")
	@Produces({ "application/xml", "application/json" })
	@Path("/customer/comprehensive/addPersonalDetails")
	@ApiOperation(value = "Persists the user details like gender, nationality and dateofbirth ", notes = "Persists the user details like gender, nationality and dateofbirth", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public ResponseMessageList saveCustomerPersonalDetails(@RequestBody UpdateCustomerBasicInfo customerBasicInfo,
			HttpServletRequest request) {
		ResponseMessageList responseList = getDefaultMessageList();
		try {
			getLogger(this.getClass()).info("Persisting the customer gender nationality details.");
			Integer customerId = getCustomerId(request);
			comprehensiveService.updateCustomerBasicDetails(customerBasicInfo, customerId);
			List<Object> objectList = new ArrayList<>();
			responseList.setObjectList(objectList);
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@GetMapping(value = "/api/customer/comprehensive/requestComprehensivePromoCode")
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path("/api/customer/comprehensive/requestComprehensivePromoCode")
	@ApiOperation(value = "Validates the promo code of the user", notes = "Returns if the promo code is valid for the given user", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList requestPromoCode(HttpServletRequest request,
			@RequestParam("category") String category) {

		getLogger(this.getClass()).info("-- Saving the Valid Promo code --");
		ResponseMessageList responseList = getDefaultMessageList();
		ComprehensiveResult comprehensiveResult = null;

		try {

			Integer customerId = getCustomerId(request);

			getLogger(this.getClass()).debug("The customerId invoking requestPromoCode() ::" + customerId);

			if (customerId != -1 && null != category) {
				comprehensiveResult = comprehensiveService.requestPromoCodeDetails(customerId, category);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_REQUEST);
				getLogger(this.getClass()).error("saveCustomerPromoCode - " + ErrorCodes.INVALID_REQUEST + " - "
						+ ApplicationConstants.INVALID_REQUEST);
				getLogger(this.getClass())
						.error("saveCustomerPromoCode - customerId: " + customerId == null ? "null" : customerId);
				getLogger(this.getClass()).info(" Unable to process promocode for the customer::" + customerId);
			}

			List comprehensiveResultList = new ArrayList<ComprehensiveResult>();
			comprehensiveResultList.add(comprehensiveResult);

			responseList.setObjectList(comprehensiveResultList);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}

		return responseList;
	}

	@PostMapping(value = "/api/customer/comprehensive/validateComprehensivePromoCode")
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path("/api/customer/comprehensive/validateComprehensivePromoCode")
	@ApiOperation(value = "Validates the Promo Code entered by the user", notes = "Validates the Promo Code entered by the user", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList validateComprehensivePromoCode(
			@RequestBody ValidatePromoCodeRequest validatePromoCodeRequest, HttpServletRequest request) {

		getLogger(this.getClass()).debug("-- Validating Promo code --");
		ResponseMessageList responseList = getDefaultMessageList();
		ComprehensiveResult comprehensiveResult = new ComprehensiveResult();

		EnquiryResponseMessage enquiryResponseMessage = null;
		PromoCodeRequest promoCodeRequest = new PromoCodeRequest();

		try {

			boolean isExpired = true;
			Integer customerId = getCustomerId(request);

			String promoCodeByUser = validatePromoCodeRequest.getComprehensivePromoCodeToken();
			String journeyType = validatePromoCodeRequest.getPromoCodeCat();
			String sessionId = validatePromoCodeRequest.getSessionId();

			isExpired = comprehensiveService.validatePromoCodeByUser(validatePromoCodeRequest, customerId);

			if (!isExpired) {
				comprehensiveResult.setValidatePromoCode(true);
				getLogger(this.getClass()).info("Promo code is valid:" + isExpired);

				PromoCode promoCodeObj = promoCodeRepository.findByCodeAndCategory(promoCodeByUser, journeyType);

				if (null != sessionId) {

					promoCodeRequest.setSessionId(sessionId);
					promoCodeRequest.setRequestType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
					promoCodeRequest.setPromoCodeId(promoCodeObj.getId());

					enquiryResponseMessage = promoCodeService.getComprehensiveEnquiryReference(promoCodeRequest);

					if (null != enquiryResponseMessage && null != enquiryResponseMessage.getObjectList()
							&& !enquiryResponseMessage.getObjectList().isEmpty()) {
						getLogger(this.getClass()).info("Setting Compre hensive enquiry reference into Response");
						List objectList = new ArrayList();
						objectList = enquiryResponseMessage.getObjectList();
						EnquiryReference enq = (EnquiryReference) objectList.get(0);
						getLogger(this.getClass()).info("Created enquiry Id in Response::" + enq.getEnquiryId());

						comprehensiveResult.setEnquiryId(enq.getEnquiryId());
					}
				}

				responseList.getResponseMessage().setResponseCode(ErrorCodes.PROMO_CODE_VERIFICATION_SUCCESSFUL);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.VALIDATION_SUCCESS);
			} else {
				comprehensiveResult.setValidatePromoCode(false);
				getLogger(this.getClass()).info("Promo Code is invalid");
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_PROMO_CODE);
				responseList.getResponseMessage()
						.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_PROMO_CODE);
			}

			List comprehensiveResultList = new ArrayList<ComprehensiveResult>();
			comprehensiveResultList.add(comprehensiveResult);

			responseList.setObjectList(comprehensiveResultList);

		} catch (Exception err) {
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	// get personal details
	@RequestMapping(value = "/api/customer/comprehensive/getPersonalDetails", method = RequestMethod.GET)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path("/customer/comprehensive/getPersonalDetails")
	@ApiOperation(value = "Returns user profile summary", notes = "Returns user profile summary", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList getBasicProfile(@RequestBody HttpServletRequest httpServletRequest,
			String journeyType) {
		getLogger(this.getClass()).info("Calling the profile summary:");
		Integer customerId = getCustomerId(httpServletRequest);
		ResponseMessageList response = getDefaultMessageList();
		try {
			BaseProfileDTO baseProfileDTO = comprehensiveService.getCustomerBasicDetails(customerId, journeyType);
			List baseProfileDTOList = new ArrayList<BaseProfileDTO>();
			baseProfileDTOList.add(baseProfileDTO);
			response.setObjectList(baseProfileDTOList);
		} catch (DatabaseAccessException err) {
			getLogger(this.getClass()).error("Database access exception ", err);
			response.setResponseMessage(getDatabaseAccessExceptionResponse());
		} catch (Exception err) {
			response.setResponseMessage(getInternalServerError());
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/api/customer/comprehensive/saveDependents", method = RequestMethod.POST)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path("/customer/comprehensive/saveDependents")
	@ApiOperation(value = "Returns the list of Save Comprehensive Dependent Details", notes = "Save Comprehensive Dependent Details of the user.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public ResponseMessageList saveDependents(@RequestBody ComprehensiveDependentRequest dependentMappingRequest,
			HttpServletRequest httpServletRequest) {

		getLogger(this.getClass()).info("Inside method Save Comprehensive Dependents");
		ResponseMessageList responseList = getDefaultMessageList();
		List<ComprehensiveDependentMapping> dependents = dependentMappingRequest.getDependentMappingList();
		Integer customerId = getCustomerId(httpServletRequest);

		ComprehensiveHouseHoldDTO comprehensiveHouseHoldDTO = new ComprehensiveHouseHoldDTO();
		comprehensiveHouseHoldDTO.setCustomerId(customerId);
		comprehensiveHouseHoldDTO.setEnquiryId(dependents.get(0).getEnquiryId());
		comprehensiveHouseHoldDTO.setHouseHoldIncome(dependentMappingRequest.getHouseHoldIncome());
		comprehensiveHouseHoldDTO.setNoOfHouseholdMembers(dependentMappingRequest.getNoOfHouseholdMembers());
		comprehensiveHouseHoldDTO.setNoOfYears(dependentMappingRequest.getNoOfYears());
		Integer enquiryId = dependents.get(0).getEnquiryId();

		try {

			comprehensiveService.saveDependents(dependents, customerId, dependentMappingRequest.isHasDependents());

			comprehensiveService.saveComprehensiveHouseHold(comprehensiveHouseHoldDTO, enquiryId);

			List dependentsList = comprehensiveService.getDependentDetailList(customerId, enquiryId);

			comprehensiveHouseHoldDTO = comprehensiveService.getComprehensiveHouseHold(customerId, enquiryId);

			DependentSummaryDTO dependentSummary = new DependentSummaryDTO();
			dependentSummary.setDependentsList(dependentsList);
			if (null != comprehensiveHouseHoldDTO) {

				dependentSummary.setHouseHoldIncome(comprehensiveHouseHoldDTO.getHouseHoldIncome());
				dependentSummary.setNoOfHouseholdMembers(comprehensiveHouseHoldDTO.getNoOfHouseholdMembers());
				dependentSummary.setNoOfYears(comprehensiveHouseHoldDTO.getNoOfYears());
			}

			@SuppressWarnings("rawtypes")
			ArrayList finalList = new ArrayList<>();
			finalList.add(dependentSummary);

			responseList.setObjectList(finalList);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@RequestMapping(value = "/api/customer/comprehensive/getDependents", method = RequestMethod.GET)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path("/customer/comprehensive/getDependents")
	@ApiOperation(value = "Returns dependent details", notes = "Returns dependent details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList getDependentDetails(HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Calling the comprehensive dependent details:");
		Integer customerId = getCustomerId(httpServletRequest);
		ResponseMessageList responseList = getDefaultMessageList();
		try {
			Integer enquiryId = null;
			List<DependentDTO> dependentList = comprehensiveService.getDependentDetailList(customerId, enquiryId);
			responseList.setObjectList(addObjects(dependentList));
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(value = "/api/customer/comprehensive/saveChildEndowmentPlans")
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path("/customer/comprehensive/saveChildEndowmentPlans")
	@ApiOperation(value = "Returns the response list of Child Endowment Plans", notes = "Save Child Endowment Plans.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public ResponseMessageList saveChildEndowmentPlans(
			@RequestBody ComprehensiveChildEndowmentPlanRequest endowmentPlanMappingRequest,
			HttpServletRequest httpServletRequest) {

		getLogger(this.getClass()).info("Invoking controller method saveChildEndowmentPlans()");

		ResponseMessageList responseList = getDefaultMessageList();

		List<ComprehensiveEndowmentPlanMapping> childEndowmentPlanning = endowmentPlanMappingRequest
				.getEndowmentDetailsList();
		int customerId = getCustomerId(httpServletRequest);
		int enquiryId = childEndowmentPlanning.get(0).getEnquiryId();
		List<DependentEducationPreferencesDTO> dependentEducationPreferencesList = null;

		try {

			if (!childEndowmentPlanning.isEmpty() && customerId != -1) {
				String hasEndowments = endowmentPlanMappingRequest.getHasEndowments();

				getLogger(this.getClass()).info("saveChildEndowmentPlans enquiryId:" + enquiryId);
				getLogger(this.getClass()).info("saveChildEndowmentPlans customerId:" + customerId);

				if (ApplicationConstants.HAS_ENDOWMENTS.equals(hasEndowments)) {

					comprehensiveService.saveChildEndowmentPlanDetails(childEndowmentPlanning, hasEndowments,
							customerId);
					comprehensiveService.updateDependentsForInsuranceNeed(childEndowmentPlanning, customerId, enquiryId,
							hasEndowments);
					dependentEducationPreferencesList = comprehensiveService.getDependentEducationPreferences(enquiryId,
							customerId);

				} // hasEndowments = 0 or 2 means delete the endowments for the
					// customer
				else if ("0".equals(hasEndowments) || ("2".equals(hasEndowments))) {

					getLogger(this.getClass()).debug("saveChildEndowmentPlans: delete endowments plans");
					comprehensiveService.deleteChildEndowmentPlans(enquiryId, hasEndowments, customerId);
					comprehensiveService.updateDependentsForInsuranceNeed(childEndowmentPlanning, customerId, enquiryId,
							hasEndowments);

				} else {

					getLogger(this.getClass()).debug("The passed 'hasEndowments' is not valid: " + hasEndowments);
					throw new ComprehensiveException("The passed 'hasEndowments' is not valid.");
				}
			} else {
				getLogger(this.getClass()).info(
						"saveChildEndowmentPlans: Unable to save the child endowment preferences for the customer");
			}

			List<Object> objectList = new ArrayList<>();

			if (dependentEducationPreferencesList != null) {
				objectList.addAll(dependentEducationPreferencesList);
			}

			responseList.setObjectList(objectList);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (ComprehensiveException e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@RequestMapping(value = APIConstants.GET_COMPREHENSIVE_ENQUIRY_DETAILS, method = RequestMethod.POST)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path(APIConstants.GET_COMPREHENSIVE_ENQUIRY_DETAILS)
	@ApiOperation(value = "Returns the list of comprehensive enquiry Details", notes = "Returns the list of comprehensive enquiry Details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public ResponseMessageList getComprehensiveEnquiryDetails(
			@RequestBody ComprehensiveEnquiryPostRequest enquiryRequest, HttpServletRequest httpServletRequest) {

		getLogger(this.getClass()).info("*****CALL RECEIVED - GET COMPREHENSIVE DETAILS - ACCOUNT SERVICE****");

		ResponseMessageList responseList = getDefaultMessageList();

		ComprehensiveEnquiryPostResponse response = new ComprehensiveEnquiryPostResponse();

		List<Object> enquiryResponseList = new ArrayList<>();

		// Should not to pass through DTO
		// int customerId = enquiryRequest.getEnquiryObject().getCustomerId();

		String token = httpServletRequest.getHeader("Authorization");

		Integer customerId = getCustomerIdFromAuthToken(httpServletRequest);

		int enquiryId = enquiryRequest.getEnquiryObject().getEnquiryId();

		boolean isForDashBoard = enquiryRequest.isForDashBoard();

		String journeyType = enquiryRequest.getEnquiryObject().getType();

		getLogger(this.getClass()).info("The passed customerId:: " + customerId);

		getLogger(this.getClass()).info("The passed enquireId:: " + enquiryId);

		getLogger(this.getClass()).info("The passed journeyType: " + journeyType);

		try {

			if (isForDashBoard) {

				// getting the customer information
				BaseProfileDTO baseProfile = comprehensiveService.getCustomerBasicDetails(customerId, journeyType);
				response.setBaseProfile(baseProfile);

			} else {
				// getting the customer information
				BaseProfileDTO baseProfile = comprehensiveService.getCustomerBasicDetails(customerId, journeyType);
				response.setBaseProfile(baseProfile);

				// getting the dependents details
				List<DependentDTO> dependentList = comprehensiveService.getDependentDetailList(customerId, enquiryId);
				response.setDependentsList(dependentList);

				// getting the dependents endowment education plan
				List<DependentEducationPreferencesDTO> endowmentEducationList = comprehensiveService
						.getDependentEducationPreferences(enquiryId, customerId);
				response.setEndowmentEducationList(endowmentEducationList);

				// getting the comprehensive house hold details
				ComprehensiveHouseHoldDTO houseHoldDTO = comprehensiveService.getComprehensiveHouseHold(customerId,
						enquiryId);
				response.setComprehensiveHouseHold(houseHoldDTO);

			}

			enquiryResponseList.add(response);

			responseList.setObjectList(enquiryResponseList);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@RequestMapping(value = APIConstants.GET_REPORT_NOTIFICATION_TOKEN, method = RequestMethod.GET)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path(APIConstants.GET_REPORT_NOTIFICATION_TOKEN)
	@ApiOperation(value = "Returns customer token", notes = "Returns customer token", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList generateCustomerToken(HttpServletRequest httpServletRequest) {

		getLogger(this.getClass())
				.info("*****CALL RECEIVED - GENERATE REPORT NOTIFICATION DETAILS - ACCOUNT SERVICE****");

		ResponseMessageList responseList = getDefaultMessageList();

		try {

			List<Object> enquiryResponseList = new ArrayList<>();

			ComprehensiveEnquiryPostResponse response = new ComprehensiveEnquiryPostResponse();

			int customerId = getCustomerId(httpServletRequest);

			getLogger(this.getClass()).info("The passed customerId: " + customerId);

			InsuranceAgentCallback insurCallbackObj = comprehensiveService.generateCustomerToken(customerId);

			response.setInsuranceAgentCallBack(insurCallbackObj);

			enquiryResponseList.add(response);

			responseList.setObjectList(enquiryResponseList);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@PostMapping(value = APIConstants.API_ACCOUNT_PRODUCT_PRICING)
	@Produces({ "application/xml", "application/json" })
	@Path("/api/RiskAssessment")
	@ApiOperation(value = "product price based upon the product type & promotion role ", notes = "product price based upon the product type & promotion role ", response = APIResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 5000, message = "Internal server error"),
			@ApiResponse(code = 5001, message = "Database communication failure") })
	public @ResponseBody ResponseMessageList getComprehensiveProductPricing(@RequestBody Map<String, Object> pricing,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("*****CALL RECEIVED - getProductPricing - ACCOUNT SERVICE****" + pricing);
		ResponseMessageList responseList = getDefaultMessageList();
		String productType = (String) pricing.get("productType");
		try {
			List<Object> productResponseList = new ArrayList<>();

			boolean isLiteUser = false;
			// fetching role from token
			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();

			isLiteUser = grantedAuthorities.stream().anyMatch(a -> {
				return (a.getAuthority().contains(BFAGrandtedAuthority.ROLE_COMPRE_DISCOUNT));
			});

			String rolePromotion = BFAGrandtedAuthority.ROLE_COMPRE_DISCOUNT;

			String promotion = isLiteUser ? rolePromotion : null;

			getLogger(this.getClass()).info("*****getProductPricing - promotion****" + promotion);

			ComprehensivePricingDTO productObjList = comprehensiveService.getComprehensiveProductPricing(productType,
					promotion);

			productResponseList.add(productObjList);

			responseList.setObjectList(productResponseList);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

}

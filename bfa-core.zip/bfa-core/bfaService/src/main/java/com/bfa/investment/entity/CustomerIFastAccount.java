package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;

@Entity
@Table(name = "customer_ifast_account")
public class CustomerIFastAccount {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@OneToOne
	@JoinColumn(name = "customer_portfolio_id")
	private CustomerPortfolio customerPortfolio;

	@Column(name = "agent_id")
	private String agentId;

	@Column(name = "ifast_refno")
	private String ifastRefno;

	// Added
	@Column(name = "counter_party_number")
	private String counterPartyAccountNumber;

	@Column(name = "ifast_status")
	private String ifastStatus;

	@Column(name = "investment_account_status")
	private String investmentAccountStatus;

	@Column(name = "review_comments")
	private String reviewComments;

	@Column(name = "trust_id")
	private String trustId;

	@Column(name = "cash_account_balance")
	private Double cashAccountBalance;

	@Column(name = "account_created_date")
	private Date accountCreatedDate;

	@Column(name = "ifast_response")
	private String ifastResponse;
	
	public CustomerPortfolio getCustomerPortfolio() {
		return customerPortfolio;
	}

	public void setCustomerPortfolio(CustomerPortfolio customerPortfolio) {
		this.customerPortfolio = customerPortfolio;
	}
	
	

	public Double getCashAccountBalance() {
		return cashAccountBalance;
	}

	public void setCashAccountBalance(Double cashAccountBalance) {
		this.cashAccountBalance = cashAccountBalance;
	}

	public String getTrustId() {
		return trustId;
	}

	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "last_updated_time_stamp")
	private Date lastUpdatedTimeStamp;

	public String getReviewComments() {
		return reviewComments;
	}

	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}

	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}

	public String getInvestmentAccountStatus() {
		return investmentAccountStatus;
	}

	public void setInvestmentAccountStatus(String investmentAccountStatus) {
		this.investmentAccountStatus = investmentAccountStatus;
	}

	public Date getAccountCreatedDate() {
		return accountCreatedDate;
	}

	public void setAccountCreatedDate(Date accountCreatedDate) {
		this.accountCreatedDate = accountCreatedDate;
	}

	public String getIfastStatus() {
		return ifastStatus;
	}

	public void setIfastStatus(String ifastStatus) {
		this.ifastStatus = ifastStatus;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getIfastRefno() {
		return ifastRefno;
	}

	public void setIfastRefno(String ifastRefno) {
		this.ifastRefno = ifastRefno;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getIfastResponse() {
		return ifastResponse;
	}

	public void setIfastResponse(String ifastResponse) {
		this.ifastResponse = ifastResponse;
	}

	

}

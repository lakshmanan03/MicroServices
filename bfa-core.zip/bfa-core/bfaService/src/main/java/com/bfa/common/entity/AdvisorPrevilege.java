package com.bfa.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "advisor_previlege")
public class AdvisorPrevilege {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "advisor_id", nullable = false)
	@JsonIgnore
	private Advisor advisor;

	@OneToOne
	@JoinColumn(name = "previlege_id")
	private AdminPrevilege adminPrevilege;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Advisor getAdvisor() {
		return advisor;
	}

	public void setAdvisor(Advisor advisor) {
		this.advisor = advisor;
	}

	public AdminPrevilege getAdminPrevilege() {
		return adminPrevilege;
	}

	public void setAdminPrevilege(AdminPrevilege adminPrevilege) {
		this.adminPrevilege = adminPrevilege;
	}

}

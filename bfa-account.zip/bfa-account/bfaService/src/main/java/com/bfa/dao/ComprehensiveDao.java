package com.bfa.dao;

import java.util.List;

import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.comprehensive.core.ComprehensiveEnquiry;
import com.bfa.comprehensive.core.ComprehensiveHouseHold;
import com.bfa.comprehensive.core.DependentEducationPreferences;
import com.bfa.comprehensive.core.DependentEntity;
import com.bfa.insurance.core.Enquiry;
import com.bfa.investment.entity.ComprehensivePricing;

public interface ComprehensiveDao<T> extends BaseDao{

	void saveDependentList(List<DependentEntity> dependentList);

	List<DependentEntity> getDependentDetails(Integer customerId,Integer enquiryId);	
	
	void saveDependentEndowmentPlan(List<DependentEducationPreferences> dependentEducationPreferencesList, String hasEndowments, 
			Integer enquiryId, Integer customerId);
	
	void deleteChildEndowmentPlans(Integer enquiryId, Integer customerId,String hasEndowments) throws DatabaseAccessException;
	
	List<DependentEducationPreferences> getDependentEducationPreferences(int enquiryId, int customerId);
	
	ComprehensiveEnquiry getActiveComprehensiveEnquiry(Integer enquiryId, Integer customerId);

	public ComprehensiveEnquiry getComprehensiveEnquiry(Integer enquiryId, Integer customerId);
	
	public ComprehensiveEnquiry getComprehensiveEnquiryByCustId(Integer customerId);
	
	public void saveComprehensiveEnquiry(ComprehensiveEnquiry enquiry) throws DatabaseAccessException;
	
	public ComprehensiveHouseHold getComprehensiveHouseHold(Integer customerId,Integer enquiryId);
	
	public Enquiry getCustomerEnquiryDetails(Integer customerId, String journeyType);

	public List<ComprehensivePricing> getComprehensiveProductPricing(String productType, String promotion);
	
}
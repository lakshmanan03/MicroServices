/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.application.core.MailChimpModel;
import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.promotion.model.PromotionBundleModel;
import com.bfa.service.AccountsService;
import com.bfa.service.BundleService;
import com.bfa.service.MailChimpService;
import com.bfa.util.ApplicationConstants;
import com.google.gson.Gson;

/**
 * BFA-1565 * Modified for BFA-1643 & BFA-1647 in Release 2.22
 *
 * @author pradheep
 *
 */
public class BundleServiceImpl extends DiscoveryHelper implements BundleService {

	@Autowired
	private ApplicationLoggerBean applicationLogger;

	@Autowired
	private DelegateHandler delegateHandler;

	@Autowired
	private Environment environment;

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@Autowired
	private AccountsService accountsService;

	private Gson gson = new Gson();

	private final String adultBundleName = "Young Working Adult Protection Bundle";

	// private final String childBundleName = "Baby Bundle (Child Protection &
	// Education Savings Plan)";

	/* BFA-1643 */
	private final String childProtectionBundleName = "Baby Bundle - Child Protection Bundle";

	/* BFA-1647 */
	private final String childEducationBundleName = "Baby Bundle - Child Education Bundle";

	/* BFA-1701 */
	private final String retirementBundleName = "Retirement Bundle";

	@Autowired
	private MailChimpService mailChimpService;

	private Logger getLogger() {
		return this.applicationLogger.getLogBean(this.getClass());
	}

	/**
	 * Subscribes to mailchimp for marketing emails, and bundle packages.
	 * 
	 * @see com.bfa.service.BundleService#notifyBundleEnquiry(com.bfa.promotion.model
	 *      .PromotionBundleModel)
	 */
	@Override
	public String notifyBundleEnquiry(PromotionBundleModel model, HttpServletRequest httpServletRequest) {
		try {

			if (!validateEmailAddress(model.getEmailAddress())) {
				getLogger().error(
						"Invalid email address given as input - cannot process the request " + model.getEmailAddress());
				return "Invalid email address";
			}
			getLogger().info("-- Sending email to advisors --");
			NotifyEnquiry notifyEnqObj = new NotifyEnquiry(model);
			threadPoolTaskExecutor.execute(notifyEnqObj);
			SessionDetails sessionDetails = accountsService.saveSessionDetails(httpServletRequest);
			subscribeBundleNotifications(model, sessionDetails.getIpAddress());
			if (model.getReceiveMarketingEmails().equalsIgnoreCase("yes")) {
				mailChimpService.subscribeForMarketingEmails(model.getFirstName(), model.getLastName(),
						model.getEmailAddress(), 6000L);
				/*
				 * Given a six seconds delay to ensure that it is registered in
				 * the bundle subscription in MailChimp Then register for
				 * marketing emails later. Beause it needs a email confirmation.
				 */
			}
		} catch (Exception err) {
			getLogger().error("Error while handling notification bundle", err);
			return ApplicationConstants.INTERNAL_SERVER_ERROR;
		}
		return "Success";
	}

	private boolean validateEmailAddress(String emailAddress) {
		boolean valid = EmailValidator.getInstance().isValid(emailAddress);
		return valid;
	}

	class MailChimpSubscriptionThread implements Runnable {

		private MailChimpModel mailChimpModel;

		private String clientIPAddress;

		public MailChimpSubscriptionThread(MailChimpModel model, String IPAddress) {
			this.mailChimpModel = model;
			this.clientIPAddress = IPAddress;
		}

		@Override
		public void run() {
			mailChimpService.subscribeInMailChimp(mailChimpModel, clientIPAddress);
		}
	}

	private void subscribeBundleNotifications(PromotionBundleModel model, String ipaddress) {
		getLogger().info("Subscribe for bundle enquiry in Mail Chimp #");
		MailChimpSubscriptionThread mailChimpSubscription = new MailChimpSubscriptionThread(model, ipaddress);
		threadPoolTaskExecutor.execute(mailChimpSubscription);
		getLogger().info("##-- End of mail chimp API call -- ");
	}

	private boolean isNonProduction() {
		String[] profiles = environment.getActiveProfiles();
		for (int i = 0; i < profiles.length; i++) {
			if (profiles[i].toLowerCase().contains("pro")) {
				return false;
			}
		}
		return true;
	}

	private String getEmailBody(PromotionBundleModel model, String subject) {
		StringBuffer body = new StringBuffer();
		String dobPrefix = "Date of birth";
		String genderPrefix = "Gender";
		if (subject.toLowerCase().contains("baby")) {
			dobPrefix = "Baby's date of birth";
			genderPrefix = "Baby's gender";
		}
		body.append("Dear Advisor, <br>");
		body.append(model.getFirstName() + " " + model.getLastName() + " has shown interest in the " + subject
				+ ", following are the details <br>");
		body.append("<hr>");
		body.append("<table> <tr> <td> First Name : </td><td>" + model.getFirstName() + "</td></tr>");
		body.append("<tr> <td> Last Name : </td><td>" + model.getLastName() + "</td></tr>");
		body.append("<tr> <td> " + genderPrefix + " : </td><td>" + model.getGender() + "</td></tr>");
		body.append("<tr> <td> " + dobPrefix + " : </td><td>" + model.getDateOfBirth() + "</td></tr>");
		body.append("<tr> <td> Email : </td><td>" + model.getEmailAddress() + "</td></tr>");
		body.append("<tr> <td> Contact : </td><td>" + model.getContactNumber() + "</td></tr>");
		body.append("<tr> <td> Like to receive moneyowl marketing emails : </td><td>"
				+ model.getReceiveMarketingEmails() + "</td></tr>");
		body.append("</table>");
		return body.toString();
	}

	class NotifyEnquiry implements Runnable {

		private PromotionBundleModel promotionBundleModel;

		public NotifyEnquiry(PromotionBundleModel model) {
			promotionBundleModel = model;
		}

		@Override
		public void run() {
			notifyAdvisors();
		}

		private void notifyAdvisors() {
			String fromEmail = environment.getProperty("email.notification.address");
			String toEmail = environment.getProperty("email.enquiries.address");
			String templateName = "bundle_enquiry.template";
			String subject = "";
			/* Changes for BFA-1643 & BFA-1647 */
			if (promotionBundleModel.getEnquiryType().toLowerCase().equals(CHILD_BUNDLE_PRO_TYPE_ENQ)) {
				subject = childProtectionBundleName;
			} else if (promotionBundleModel.getEnquiryType().toLowerCase().equals(CHILD_BUNDLE_EDU_TYPE_ENQ)) {
				subject = childEducationBundleName;
			} else if (promotionBundleModel.getEnquiryType().toLowerCase().equals(RETIREMENT_BUNDLE_TYPE_ENQ)) {
				/* BFA-1701 */
				subject = retirementBundleName;
			} else if (promotionBundleModel.getEnquiryType().toLowerCase().contains("adult")) {
				subject = adultBundleName;
			}
			Map<String, String> params = new HashMap<String, String>();
			params.put("body", getEmailBody(promotionBundleModel, subject));
			if (isNonProduction()) {
				String[] ccList = new String[1];
				ccList[0] = environment.getProperty("email.dev.support.address");
				// Copy the email to dev support for testing purposes //
				delegateHandler.sendEmail(fromEmail, toEmail, subject, templateName, params, ccList);
			} else {
				delegateHandler.sendEmail(fromEmail, toEmail, subject, templateName, params);
			}
		}
	}

	@Override
	public void updateBundleDataInCRM(PromotionBundleModel promotionBundleModel) {
		try {
			getLogger().info("Trying to update the bundle data in CRM " + promotionBundleModel.toString());
			delegateHandler.updateBundleInformationInCRM(promotionBundleModel);
		} catch (Exception err) {
			getLogger().error("Error while updating the bundle data in CRM", err);
		}
	}
}

package com.bfa.investment.dto;

public class FundDTO {
//    "id":"FI3018",
//    "name":"Fidelity ASEAN A SGD",
//    "type":"UT",
//    "percentage":1,
//    "factSheetLink":"http://",
//    "htmlDesc":"<html-desc>"
	private String id;
	private String name;
	private String type;
	private String sectorName;
	private String prospectusLink;
	private int percentage;
	private String factSheetLink;
	private String htmlDesc;
	private String description;

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public String getProspectusLink() {
		return prospectusLink;
	}

	public void setProspectusLink(String prospectusLink) {
		this.prospectusLink = prospectusLink;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public String getFactSheetLink() {
		return factSheetLink;
	}
	public void setFactSheetLink(String factSheetLink) {
		this.factSheetLink = factSheetLink;
	}
	public String getHtmlDesc() {
		return htmlDesc;
	}
	public void setHtmlDesc(String htmlDesc) {
		this.htmlDesc = htmlDesc;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}

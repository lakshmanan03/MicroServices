/**
 * 
 */
package com.bfa.serviceimpl;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.core.AuthenticationRequest;
import com.bfa.application.core.CustomerIssuedToken;
import com.bfa.application.core.CustomerPassLog;
import com.bfa.application.core.CustomerPromo;
import com.bfa.application.core.EmailAndMobileNotVerifiedResponse;
import com.bfa.application.core.EmailLinkValidityRequest;
import com.bfa.application.core.OTPRequest;
import com.bfa.application.core.OTPVerificationResponse;
import com.bfa.application.core.PasswordRequest;
import com.bfa.application.core.PromoCode;
import com.bfa.application.core.SaveSelectedProductsRequest;
import com.bfa.application.core.VerifyEmailRequest;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.exception.NoSuchUserException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.BFAUserDetailsService;
import com.bfa.application.security.SecurityConstants;
import com.bfa.application.security.SecurityInfo;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.ForgotPasswordDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.ResetPasswordDTO;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.AdvisorPrevilege;
import com.bfa.common.entity.BFAGrantedAuthority;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.Common;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.CustomerData;
import com.bfa.common.entity.EmailContentWrapper;
import com.bfa.common.entity.EmailData;
import com.bfa.configuration.jpa.AdvisorRepository;
import com.bfa.dao.AccountsDao;
import com.bfa.dao.SecurityDao;

import com.bfa.exception.InvalidSessionIdException;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.LoginRetryCount;
import com.bfa.insurance.core.ResponseList;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.insurance.product.ProductList;
import com.bfa.investment.account.dto.InvestmentAccountStatusDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.notification.messenger.SMSMessenger;
import com.bfa.repository.CustomerPromoRepository;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.request.entity.CRMCustomerUpdateRequest;
import com.bfa.security.twofa.core.TwoFactorAuthValidation;
import com.bfa.service.AccountServiceConstants;
import com.bfa.service.AccountsService;
import com.bfa.service.CustomerEnquiryService;
import com.bfa.service.PasswordEncryptionService;
import com.bfa.service.PasswordResetStatus;
import com.bfa.service.SecurityService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.CustomerPortfolioStatus;
import com.bfa.util.ErrorCodes;
import com.bfa.util.MOEmailSQSClient;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessage;
import com.bfa.util.ResponseMessageList;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pradheep.p
 *
 */
@Service
@Transactional
public class SecurityServiceImpl extends DefaultServiceImpl implements SecurityService {

	@Autowired
	private CustomerEnquiryService customerEnquiryService;

	@Autowired
	private BFAUserDetailsService bfaUserDetailsService;

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	@Qualifier("securityConstants")
	private SecurityConstants constants;

	@Autowired
	private DelegateHandler delegateHandler;

	@Autowired
	private AccountsDao accountsDAO;

	@Autowired
	MOInvestmentService investServiceHelper;
	
	@Autowired
	MOEmailSQSClient moemailObj;
	
	@Autowired
	private AdvisorRepository advisorRepository;

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;
	
	@Autowired
	private PromoCodeRepository promoCodeRepository;
	
	@Autowired
	private CustomerPromoRepository customerPromoRepository;

	private String[] keys = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r",
			"s", "t", "u", "v", "w", "x", "y", "z" };

	private String[] secondLevelKeys = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P",
			"Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

	@Autowired
	private Environment environment;

	String appK = "EMVNbStacg8=";

	@Autowired
	private AccountsService accountsService;

	@Autowired
	private CaptchaProvider captchaProvider;
	
	@Autowired
	private MOInvestmentService investmentServiceHelper;

	@Autowired
	private PasswordEncryptionService passwordEncryptionService;
	
	@Autowired
	private SecurityDao securityDAO;
	
	@Value("${2fa.validation.time}")
	private long twoFactorValidationTime;	
	
	private String defaultOtpString = "111111";
	
	private boolean isSmsFeatureEnabled = false;
	
	@Autowired
	private SMSMessenger smsMessenger;
	
	private final long twoMinsInMilliSecs = 60 * 2 * 1000L;
	
	/*
	 * @PostConstruct public void init(){ smsMessenger.loadProperties();
	 * this.isSmsFeatureEnabled = isSmsFeatureEnabled(); }
	 */
	
	private boolean isSmsFeatureEnabled() {
		return smsMessenger.isSmsFeatureEnabled();
	}
	
	private BFAUserDetails buildBFAUserDetails(Advisor advisor) {
		BFAUserDetails userDetails = null;
		if (advisor != null) {
			userDetails = new BFAUserDetails();
			userDetails.setEmailVerified(true);
			userDetails.setMobileVerified(true);
			userDetails.setPassword(PublicUtility.passwordBlobToString(advisor.getPassword()));
			userDetails.setId(advisor.getId());
			userDetails.setUsername(advisor.getEmailId());
			List<BFAGrantedAuthority> authorities = new ArrayList<>();
			if (advisor.getPrevileges() != null) {
				for (AdvisorPrevilege previlege : advisor.getPrevileges()) {
					BFAGrantedAuthority authority = new BFAGrantedAuthority(
							previlege.getAdminPrevilege().getPrevilegeName());
					authorities.add(authority);
				}
			}
			userDetails.setAuthorities(authorities);
		}
		return userDetails;
	}

	@Override
	public ResponseMessageList authenticateAdvisor(HttpServletRequest servletRequest,
			AuthenticationRequest authenticationRequest) {
		String email = authenticationRequest.getEmail();
		String mobileNumber = authenticationRequest.getMobile();
		BFAUserDetails userDetails = null;
		ResponseMessage defaultMessage = (ResponseMessage) getDefaultResponseMessage(ResponseMessage.class);
		ResponseMessageList authenticationResponse = new ResponseList(defaultMessage);
		String secretKey = servletRequest.getHeader("Authorization");
		boolean isSecretKeyValid = isSecretKeyValid(secretKey);
		if (!isSecretKeyValid) {
			getLoggerBean().warn("Invalid secret key provided.");
			authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SECRET_KEY);
			authenticationResponse.getResponseMessage()
					.setResponseDescription(ApplicationConstants.INVALID_SECRET_CODE);
			return authenticationResponse;
		}
		try {
			// Un signed work flow.
			if ((email == null || email.isEmpty()) && (mobileNumber == null || mobileNumber.isEmpty())) {
				List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
				BFAGrandtedAuthority grantedAuth = new BFAGrandtedAuthority("ROLE_USER");
				grantedAuthorityList.add(grantedAuth);
				String jwtTokenobj = tokenProvider.getTokenString("-1", grantedAuthorityList);
				String sessionId = getUniqueSessionId();
				saveSessionDetails(sessionId, servletRequest);
				SecurityInfo securityInfo = new SecurityInfo(jwtTokenobj, sessionId, "");
				List<Object> tokenList = new ArrayList<>();
				tokenList.add(securityInfo);
				authenticationResponse.setObjectList(tokenList);
				return authenticationResponse;
			}
			if (!isValidSession(authenticationRequest)) {
				// Need to have a valid session id for login //
				authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
				authenticationResponse.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INVALID_SESSION_ID);
				return authenticationResponse;
			}
			LoginRetryResponse response = isCaptchaRequired(authenticationRequest, servletRequest);
			if (response.status && (!isValidCaptcha(authenticationRequest.getSessionId(), authenticationRequest.getCaptchaValue()))) {
				authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CAPTCHA);
				authenticationResponse.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INVALID_CAPTCHA);
				List<Object> retryInfoList = buildResponseFromRetryCount(response);
				authenticationResponse.setObjectList(retryInfoList);
				return authenticationResponse;
			}
			if (email != null && !email.isEmpty()) {
				getLogger().info("Fetching user details by email: " + email);
				// buildBFAUserDetails
				Advisor advisor = advisorRepository.findByEmailId(email);
				userDetails = buildBFAUserDetails(advisor);
			} else if (mobileNumber != null && !mobileNumber.isEmpty()) {
				getLogger().info("Fetching user details by mobileNumber: " + mobileNumber);
				Advisor advisor = advisorRepository.findByMobileNumber(mobileNumber);
				userDetails = buildBFAUserDetails(advisor);
			}
			if (userDetails != null) {
				getLogger().info("Fetched user details: " + userDetails.getUsername());
			} else {
				getLogger().info("User not found");
			}
			// No user found
			String passwordToCompare = passwordEncryptionService.decrypt(authenticationRequest.getPassword(),
					authenticationRequest.getSessionId());
			if (userDetails == null || userDetails.getPassword().compareTo(passwordToCompare) != 0) {
				// Login retry Count
				LoginRetryInfo retryInfo = null;
				getLogger().info("Authentication Error " + ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS);				
				if (response != null) {
					List<Object> retryInfoList = buildResponseFromRetryCount(response);
					authenticationResponse.setObjectList(retryInfoList);
				}
				authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CREDENTIALS);
				authenticationResponse.getResponseMessage()
						.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS);
				return authenticationResponse;
			}
			// If unverified user
			else if (!userDetails.isEnabled()) {
				clearRetryCount(authenticationRequest);
				// Email & Mobile unverified
				if (!userDetails.isEmailVerified() && !userDetails.isMobileVerified()) {
					getLogger().info("User Email & Mobile not verified.....");
					authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_AND_MOBILE_UNVERIFIED);
					authenticationResponse.getResponseMessage()
							.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED);
				}
				// Email unverified
				else if (!userDetails.isEmailVerified()) {
					getLogger().info("User Email not verified.....");
					authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_UNVERIFIED);
					authenticationResponse.getResponseMessage()
							.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_UNVERIFIED);
				}
				// Mobile unverified
				else if (!userDetails.isMobileVerified()) {
					getLogger().info("User Mobile not verified.....");
					authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.MOBILE_UNVERIFIED);
					authenticationResponse.getResponseMessage()
							.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_MOBILE_UNVERIFIED);
				}
				return authenticationResponse;
			}

		} catch (DatabaseAccessException exp) {
			getLogger().error("DatabaseAccessException Error in authenticateAdvisor : " + exp);
			authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			authenticationResponse.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			return authenticationResponse;
		} catch (NoSuchUserException err) {
			getLogger().error("NoSuchUserException Error: " + err.toString());
			authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			authenticationResponse.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			return authenticationResponse;
		} catch (Exception err) {
			getLogger().error("Exception in authenticateAdvisor(): " + err);
		}
		getLogger().info("Generating token from Authorities");
		if (userDetails != null) {
			Collection<GrantedAuthority> grantedAuthorities = (Collection<GrantedAuthority>) userDetails.getAuthorities();
			String jwtToken = "";

		if (userDetails != null) {
			Integer customerId = userDetails.getId();
			jwtToken = tokenProvider.getTokenStringV2(customerId, grantedAuthorities);
		}

			// To Map Customer to the Enquiry
			if (customerEnquiryService != null && authenticationRequest.getEnquiryId() != null
					&& authenticationRequest.getEnquiryId() > 0) {
				customerEnquiryService.mapCustomerToEnquiry(userDetails.getId(), authenticationRequest.getEnquiryId());
			}
			if (customerEnquiryService != null && authenticationRequest.getEnquiryId() != null
					&& authenticationRequest.getEnquiryId() > 0) {
				customerEnquiryService.mapCustomerToEnquiry(userDetails.getId(), authenticationRequest.getEnquiryId());
			}
			getLogger().info("Token Generated from Authorities: " + jwtToken);
			String sessionId = getUniqueSessionId();
			getLogger().info("Session id: " + sessionId);
			saveSessionDetails(sessionId, servletRequest);
			PublicUtility utility = PublicUtility.getInstance(appK);
			String customerIdString = utility.EncryptText("" + userDetails.getId());
			SecurityInfo securityInfo = new SecurityInfo(jwtToken, sessionId, customerIdString, grantedAuthorities);
			List<Object> tokenList = new ArrayList<>();
			tokenList.add(securityInfo);
			authenticationResponse.setObjectList(tokenList);
			logNewToken(userDetails.getId(), jwtToken);
			clearRetryCount(authenticationRequest);
		}
		return authenticationResponse;
	}

	@Override
	public ResponseMessageList authenticateRequest(HttpServletRequest servletRequest,
			AuthenticationRequest authenticationRequest,boolean captchaCheck) {
		String email = authenticationRequest.getEmail();
		String mobileNumber = authenticationRequest.getMobile();
		BFAUserDetails userDetails = null;
		ResponseMessage defaultMessage = (ResponseMessage) getDefaultResponseMessage(ResponseMessage.class);
		ResponseMessageList authenticationResponse = new ResponseList(defaultMessage);
		String secretKey = servletRequest.getHeader("Authorization");
		boolean isSecretKeyValid = isSecretKeyValid(secretKey);
		if (!isSecretKeyValid) {
			getLoggerBean().warn("Invalid secret key provided.");
			authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SECRET_KEY);
			authenticationResponse.getResponseMessage()
					.setResponseDescription(ApplicationConstants.INVALID_SECRET_CODE);
			return authenticationResponse;
		}
		try {
			// Un signed work flow.
			if ((email == null || email.isEmpty()) && (mobileNumber == null || mobileNumber.isEmpty())) {
				List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
				BFAGrandtedAuthority grantedAuth = new BFAGrandtedAuthority("ROLE_USER");
				grantedAuthorityList.add(grantedAuth);
				String jwtTokenobj = tokenProvider.getTokenString("-1", grantedAuthorityList);
				String sessionId = getUniqueSessionId();
				saveSessionDetails(sessionId, servletRequest);
				SecurityInfo securityInfo = new SecurityInfo(jwtTokenobj, sessionId, "");
				List<Object> tokenList = new ArrayList<>();
				tokenList.add(securityInfo);
				authenticationResponse.setObjectList(tokenList);
				return authenticationResponse;
			}
			if (!isValidSession(authenticationRequest)) {
				// Need to have a valid session id for login //
				authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
				authenticationResponse.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INVALID_SESSION_ID);
				return authenticationResponse;
			}
			LoginRetryResponse response = null;
			if(captchaCheck){
				response = isCaptchaRequired(authenticationRequest, servletRequest);
			if (response.status
					&& !isValidCaptcha(authenticationRequest.getSessionId(), authenticationRequest.getCaptchaValue())) {
				authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CAPTCHA);
				authenticationResponse.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INVALID_CAPTCHA);
				List<Object> retryInfoList = buildResponseFromRetryCount(response);
				authenticationResponse.setObjectList(retryInfoList);
				return authenticationResponse;
			}
			}
			if (email != null && !email.isEmpty()) {
				getLogger().info("Fetching user details by email: " + email);
				userDetails = (BFAUserDetails) bfaUserDetailsService.loadUserByEmail(email);
			} else if (mobileNumber != null && !mobileNumber.isEmpty()) {
				getLogger().info("Fetching user details by mobileNumber: " + mobileNumber);
				userDetails = (BFAUserDetails) bfaUserDetailsService.loadUserByMobile(mobileNumber);
			}
			if (userDetails != null) {
				getLogger().info("Fetched user details: " + userDetails.getUsername());
				getLogger().info("Encrypted password in DB: " + userDetails.getPassword());
			} else {
				getLogger().info("User not found");
			}
			// No user found
			String passwordToCompare = passwordEncryptionService.decrypt(authenticationRequest.getPassword(),
					authenticationRequest.getSessionId());
			if (userDetails == null || !userDetails.getPassword().equals(passwordToCompare)) {
				// Login retry Count
				getLogger().info("Authentication Error " + ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS);
				getLogger().info("User PWD: " + passwordToCompare);
				if (response != null) {
					List<Object> retryInfoList = buildResponseFromRetryCount(response);
					authenticationResponse.setObjectList(retryInfoList);
				}
				authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CREDENTIALS);
				authenticationResponse.getResponseMessage()
						.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS);
				return authenticationResponse;
			}
			// If unverified user
			else if (!userDetails.isEnabled()) {
				clearRetryCount(authenticationRequest);
				// To Map Customer to the Enquiry even if not verified
				if (customerEnquiryService != null && authenticationRequest.getEnquiryId() != null
						&& authenticationRequest.getEnquiryId() > 0) {

					customerEnquiryService.mapCustomerToEnquiry(userDetails.getId(),
							authenticationRequest.getEnquiryId());

					if (authenticationRequest.getJourneyType() != null
							&& authenticationRequest.getJourneyType().equalsIgnoreCase("investment")) {

						savePromocode(userDetails.getId(), authenticationRequest.getEnquiryId());

					}					
				}
				// Email & Mobile unverified
				Integer customerId = userDetails.getId();
				String customerRef = accountsService.encryptCustomerId(customerId.toString());
				if (!userDetails.isEmailVerified() && !userDetails.isMobileVerified()) {
					getLogger().info("User Email & Mobile not verified");
					authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_AND_MOBILE_UNVERIFIED);
					authenticationResponse.getResponseMessage()
							.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED);
					/**
					 * Add mobile number in response when the user account is
					 * not verified. This will be used in front end application
					 * for displaying the mobile number.
					 */

					delegateHandler.reIssueOTP(customerRef);
					String mobileNumberStr = userDetails.getMobileNumber();
					ArrayList list = new ArrayList();
					EmailAndMobileNotVerifiedResponse emailAndMobileNotVerifiedResponse = new EmailAndMobileNotVerifiedResponse();
					emailAndMobileNotVerifiedResponse.setCustomerRef(customerRef);
					emailAndMobileNotVerifiedResponse.setMobileNumber(mobileNumberStr);
					list.add(emailAndMobileNotVerifiedResponse);
					authenticationResponse.setObjectList(list);
					getLogger().info("Printing the mobile number for sending SMS " + mobileNumberStr);
					return authenticationResponse;
				}
				// Email unverified
				else if (!userDetails.isEmailVerified()) {
					getLogger().info("User Email not verified");
					authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_UNVERIFIED);
					authenticationResponse.getResponseMessage()
							.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_UNVERIFIED);
					ArrayList list = new ArrayList();
					EmailAndMobileNotVerifiedResponse emailAndMobileNotVerifiedResponse = new EmailAndMobileNotVerifiedResponse();
					emailAndMobileNotVerifiedResponse.setCustomerRef(customerRef);
					emailAndMobileNotVerifiedResponse.setMobileNumber("");
					list.add(emailAndMobileNotVerifiedResponse);
					authenticationResponse.setObjectList(list);
				}
				// Mobile unverified
				else if (!userDetails.isMobileVerified()) {
					getLogger().info("User Mobile not verified");
					authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.MOBILE_UNVERIFIED);
					authenticationResponse.getResponseMessage()
							.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_MOBILE_UNVERIFIED);
				}
				return authenticationResponse;
			}

		} catch (DatabaseAccessException exp) {
			exp.printStackTrace();
			getLogger().error("DatabaseAccessException Error: " + exp.toString());
			authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			authenticationResponse.getResponseMessage()
					.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			return authenticationResponse;
		} catch (NoSuchUserException err) {
			getLogger().error("NoSuchUserException Error: " + err.toString());
			authenticationResponse.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			authenticationResponse.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			return authenticationResponse;
		} catch (Exception err) {
			getLogger().error("DatabaseAccessException Error: " + err);
		}
		getLogger().info("Generating token from Authorities");
		getLogger().info(userDetails);
		Collection<GrantedAuthority> grantedAuthorities = (Collection<GrantedAuthority>) userDetails.getAuthorities();
		String jwtToken = "";
		if (userDetails != null) {
			Integer customerId = userDetails.getId();
			jwtToken = tokenProvider.getTokenStringV2(customerId, grantedAuthorities);
		}

		// To Map Customer to the Enquiry
		if (customerEnquiryService != null && authenticationRequest.getEnquiryId() != null
				&& authenticationRequest.getEnquiryId() > 0) {
			customerEnquiryService.mapCustomerToEnquiry(userDetails.getId(), authenticationRequest.getEnquiryId());
			if (authenticationRequest.getJourneyType() != null
					&& authenticationRequest.getJourneyType().equalsIgnoreCase("investment")) {
				savePromocode(userDetails.getId(), authenticationRequest.getEnquiryId());
			}
		}

		// get promocode from enquiry table

		// get promocode table id using promo code

		// save customer id and promode id in customer promocode table

		getLogger().info("Token Generated from Authorities: " + jwtToken);
		String sessionId = getUniqueSessionId();
		getLogger().info("Session id: " + sessionId);
		saveSessionDetails(sessionId, servletRequest);
		PublicUtility utility = PublicUtility.getInstance(appK);
		String customerId = utility.EncryptText("" + userDetails.getId());
		SecurityInfo securityInfo = new SecurityInfo(jwtToken, sessionId, customerId);
		List<Object> tokenList = new ArrayList<Object>();
		tokenList.add(securityInfo);
		authenticationResponse.setObjectList(tokenList);
		logNewToken(userDetails.getId(), jwtToken);
		clearRetryCount(authenticationRequest);

		try {
			if (userDetails != null) {
				getLogger().info("Calling sendSetUpInvestmentAccountMailerIfApplicable: " + userDetails.getUsername());
				getLogger().info("Calling sendSetUpInvestmentAccountMailerIfApplicable: " + userDetails.getId());
				sendSetUpInvestmentAccountMailerIfApplicable(userDetails.getId());
				int enquiryId = authenticationRequest.getEnquiryId();
				String journeyType = authenticationRequest.getJourneyType();
				delegateHandler.handlePostLoginProcess(enquiryId, userDetails.getId(), journeyType);
				getLogger().info("User logged in successfully at " + new Date().toString() + " [Customer Id]:" + userDetails.getId());
			} else {
				getLogger().info("User details null");
			}
		}

		catch (Exception ex) {
			getLogger().error("Error in sendSetUpInvestmentAccountMailerIfApplicable: " + ex);
		}
		return authenticationResponse;
	}


	

	private String getPromoCode(Integer enquiryId) {
		String hql = "from Enquiry where id=:enquiryId";
		try {
			String[] paramName = new String[]{"enquiryId"};
			Integer[] paramValue = new Integer[]{enquiryId};
			List<Enquiry> enquiryList = accountsDao.getObjectByHql(hql,paramName,paramValue);
			if (enquiryList != null && !enquiryList.isEmpty()) {
				Enquiry obj = enquiryList.remove(0);
				String promoCodeId = obj.getPromoCodeId();
				
				getLogger().info("#savepromo:: trying to update the promocode id-"+promoCodeId);
				return promoCodeId;
			}
		} catch (DatabaseAccessException e) {
			e.printStackTrace();
			getLogger().error("#savepromo:: Error while obtaining the promo code ", e);
			return "-1";
		}
		return "-1";
	}

	/**
	 * Login from other devices has to blacklist the old issued token.
	 * @param customerId
	 * @param token
	 */
	private void logNewToken(int customerId, String token) {
		getLogger().info("Persisting the security token issued for customer ");	
		delegateHandler.maintainAuthTokenState(token,customerId);
	}
	
	private int getEmailLinkValidityInSeconds(){
		String periodInSecs = this.environment.getProperty("email.link.validity.in.seconds");
		return Integer.parseInt(periodInSecs);
	}

	private boolean isValidSession(AuthenticationRequest authenticationRequest) {
		String sessionId = authenticationRequest.getSessionId();
		if (authenticationRequest == null || sessionId == null || sessionId.isEmpty()) {
			getLogger().error("Invalid session details");
			return false;
		}
		if (getSessionDetailsBySessionId(sessionId) == null) {
			getLogger().error("No such session id " + sessionId);
			return false;
		}

		return true;
	}

	private boolean isProdEnvironment() {
		String[] profileList = environment.getActiveProfiles();
		for (int i = 0; i < profileList.length; i++) {
			String profileName = profileList[i];
			if (profileName.toLowerCase().equals("prod")) {
				return true;
			}
		}
		return false;
	}

	private List<Object> buildResponseFromRetryCount(LoginRetryResponse response) {
		List<Object> retryInfoList = new ArrayList<>();
		Map<String, Object> retryCountDc = new HashMap<>();
		if (response.retryCountInfo != null) {
			retryCountDc.put("attempt", response.retryCountInfo.getRetryCount());
		} else {
			retryCountDc.put("sessionId", response.newSessionId);
		}
		retryInfoList.add(retryCountDc);
		return retryInfoList;
	}

	private LoginRetryCount getRetryCountFromSessionId(AuthenticationRequest authenticationRequest) {
		return accountsDao.getRetryCountInfo(authenticationRequest.getSessionId());
	}

	private LoginRetryResponse isCaptchaRequired(AuthenticationRequest authenticationRequest,
			HttpServletRequest servletRequest) {
		LoginRetryCount retryCountDetail = accountsDao.getRetryCountInfo(authenticationRequest.getSessionId());
        if (StringUtils.isNotBlank(authenticationRequest.getCaptchaValue())) {
            if (retryCountDetail != null && retryCountDetail.getRetryCount() < 3) {
                retryCountDetail = accountsDao.resetRetryCount(authenticationRequest.getSessionId(), 3);
                return new LoginRetryResponse(true, retryCountDetail);
            }
        }
		if (retryCountDetail == null) {
            if (StringUtils.isNotBlank(authenticationRequest.getCaptchaValue())) {
            	accountsDao.createRetryCount(authenticationRequest.getSessionId());
                retryCountDetail = accountsDao.resetRetryCount(authenticationRequest.getSessionId(), 3);
                return new LoginRetryResponse(true, retryCountDetail);
            } else {
                retryCountDetail = accountsDao.createRetryCount(authenticationRequest.getSessionId());
                return new LoginRetryResponse(false, retryCountDetail);
            }
		} else {
			Date sentDate = retryCountDetail.getLastModifiedDate();
			Date currentDate = PublicUtility.getCurrentUTC();
			long days = PublicUtility.getDifferenceDays(sentDate, currentDate);
			if (days < 1) {
				if (retryCountDetail.getRetryCount() >= 3 && StringUtils.isNotBlank(authenticationRequest.getCaptchaValue())) {
					retryCountDetail = updateRetryCount(authenticationRequest);
					return new LoginRetryResponse(true, retryCountDetail);
				} else {
					retryCountDetail = updateRetryCount(authenticationRequest);
				}
			} else if (days >= 1) {
				retryCountDetail = resetRetryCount(authenticationRequest);
			}
			return new LoginRetryResponse(false, retryCountDetail);
		}
	}

	private LoginRetryCount updateRetryCount(AuthenticationRequest authenticationRequest) {
		return accountsDao.incrementRetryCount(authenticationRequest.getSessionId());
	}

	private LoginRetryCount resetRetryCount(AuthenticationRequest authenticationRequest) {
		return accountsDao.resetRetryCount(authenticationRequest.getSessionId(), 1);
	}

	private LoginRetryCount clearRetryCount(AuthenticationRequest authenticationRequest) {
		return accountsDao.resetRetryCount(authenticationRequest.getSessionId(), 0);
	}

	

	class LoginRetryResponse {
		public boolean status;
		public LoginRetryCount retryCountInfo;
		public String newSessionId;

		public LoginRetryResponse(boolean status, LoginRetryCount responseObject, String newSessionId) {
			this.status = status;
			this.retryCountInfo = responseObject;
			this.newSessionId = newSessionId;
		}

		public LoginRetryResponse(boolean status, LoginRetryCount responseObject) {
			this.status = status;
			this.retryCountInfo = responseObject;
		}
	}

	class LoginRetryInfo {

		public String sessionId;

		public int retryCount;

		public LoginRetryInfo(String sessionId, int retryCount) {
			this.sessionId = sessionId;
			this.retryCount = retryCount;
		}
	}

	class SessionIdentifier {
		public String sessionId;

		public SessionIdentifier(String sessionId) {
			this.sessionId = sessionId;
		}
	}

	private Logger getLoggerBean() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}

	private String getPartString() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		int size = keys.length;
		for (int i = 0; i <= 2; i++) {
			buffer.append(keys[ran.nextInt(size - 1)]);
			buffer.append(secondLevelKeys[ran.nextInt(size - 1)]);
		}
		return buffer.toString();
	}

	private boolean isSecretKeyValid(String secretKey) {
		try {
			String decrypt = utility.DecryptText(secretKey);
			System.out.println("Printing the decrypt " + decrypt);
			String[] parsedStr = decrypt.split("#");
			String dateStr = parsedStr[0];
			String token = parsedStr[1];
			SimpleDateFormat sdf = new SimpleDateFormat(SecurityConstants.date_format);
			Date date = sdf.parse(dateStr);
			System.out.println(date.toString());
			if (!isNumberValid(token)) {
				System.out.println("The given secret number is not valid");
				return false;
			}
		} catch (Exception err) {
			System.out.println("Error in parsing secret key");
			return false;
		}
		return true;
	}

	private boolean isDateWithinTTL(Date dateObj) {
		Date currentDate = new Date();
		long milliSecs = currentDate.getTime() - dateObj.getTime();
		long expectedTimeLimit = SecurityConstants.timeToLive * 60 * 1000L; //Sonar: Critical: Cast one of the operands of this multiplication operation to a "long"
		if (milliSecs > expectedTimeLimit) {
			return false;
		}
		return true;
	}

	private boolean isNumberValid(String arg) {
		long value = Long.parseLong(arg);
		long x = value % SecurityConstants.divisor_value;
		if (x == 0) {
			return true;
		}
		return false;
	}

	public synchronized String getUniqueSessionId() {
		return UUID.randomUUID().toString();
		/*
		 * GregorianCalendar calendar = new GregorianCalendar(); Date obj =
		 * calendar.getTime(); SimpleDateFormat sdf = new SimpleDateFormat(
		 * "SSS HH:mm:ss yyyy-MM-dd"); String dateStr = sdf.format(obj); //
		 * ------------------------------------------ String _tt = dateStr + "#" +
		 * getPartString(); String appK = "EMVNbStacg8="; PublicUtility utility =
		 * PublicUtility.getInstance(appK); String xy = utility.EncryptText(_tt); return
		 * xy;
		 */
	}

	@Override
	public String provideClientSecretKey() {
		System.out.println("Providing secret key");
		GregorianCalendar calendar = new GregorianCalendar();
		Date obj = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("SSS HH:mm:ss yyyy-MM-dd");
		String dateStr = sdf.format(obj);
		// #################################
		Random ran = new Random();
		long randomNumber = ran.nextLong();
		long _xy = 19 * randomNumber;
		String _tt = dateStr + "#" + _xy;
		String appK = "EMVNbStacg8=";
		PublicUtility utility = PublicUtility.getInstance(appK);
		String xy = utility.EncryptText(_tt);
		System.out.println(xy);
		return xy;
	}

	@Override
	public SessionDetails saveSessionDetails(String sessionId, HttpServletRequest request) {
		SessionDetails sessionDetails = getSessionDetails(request);
		sessionDetails.setSessionId(sessionId);
		getLogger().info("Saving session details " + sessionDetails.toString());
		try {
			return (SessionDetails) accountsDao.saveOrUpdateObject(sessionDetails);
		} catch (Exception err) {
			getLoggerBean().error("Error while updating session details ", err);
		}
		return null;
	}

	@Override
	public OTPVerificationResponse verifyOTP(OTPRequest otpRequest) {

		OTPVerificationResponse response = new OTPVerificationResponse();
		response.setVerified(false);
		response.setResetCode("invalid");
		try {
			// -----------------------------------------------------------------//
			if (otpRequest.isEditProfile()) {
				String customerRef = otpRequest.getCustomerRef();
				CustomerContactVerification customerObj = getNewVerificationrByReference(customerRef);
				if (customerObj == null) {
					response.setVerified(false);
					return response;
				}
				String resetCode = null;
				if(customerObj.getEmail()!=null) {
				 resetCode = utility.EncryptText(customerObj.getEmail());
				}
				if ("Yes".equalsIgnoreCase(customerObj.getOtpVerifiedStatus())) {
					response.setVerified(false);
					getLogger().info("Customer OTP already verified ");
					response.setResetCode(ApplicationConstants.USER_OPT_ALREADY_VERIFIED);
					return response;
				}

				String origOTP = customerObj.getOTPString();
				ParsedOTP parseOtp = parseOTP(origOTP);
				if (parseOtp!=null && !parseOtp.isOTPValid()) {
					getLogger().info("OTP Expired for customer :" + customerObj.getId());
					response.setVerified(false);
					response.setResetCode(ApplicationConstants.USER_OTP_EXPIRED);
					return response;
				}
				if (parseOtp != null) {
					String otpToBeVerified = parseOtp.getOTP();
					getLogger().info("Printing the OTP provided by the user :" + otpToBeVerified);
					if (otpToBeVerified.equalsIgnoreCase(otpRequest.getOtp())
							|| (!isProdEnvironment() && ("111111".equals(otpRequest.getOtp())))) {
						getLogger().info("Successfully verified the OTP string.");
						customerObj.setOtpVerifiedStatus("Yes");
						response.setVerified(true);
						accountsDao.saveOrUpdateObject(customerObj);
						if ("yes".equalsIgnoreCase(customerObj.getOtpVerifiedStatus())) {
							Customer existingCustomerDetails = accountsDao
									.getCustomerById(customerObj.getCustomer().getId());
							existingCustomerDetails.setMobileNumber(customerObj.getMobileNumber());
							existingCustomerDetails.setOtpVerfied("Yes");
							accountsDao.saveOrUpdateObject(existingCustomerDetails);
						}
						response.setResetCode(resetCode);
						return response;
					}
				} else {
					getLogger().error("OTP Provided the user was not matching .. ");
				}
			}

			else {

				String customerRef = otpRequest.getCustomerRef();
				Customer customerObj = getCustomerByReferenceV1(customerRef);

				if (customerObj == null) {
					response.setVerified(false);
					return response;
				}

				String resetCode = utility.EncryptText(customerObj.getEmail());
				if ("Yes".equalsIgnoreCase(customerObj.getOtpVerfied())) {
					response.setVerified(false);
					getLogger().info("Customer OTP already verified ");
					response.setResetCode(ApplicationConstants.USER_OPT_ALREADY_VERIFIED);
					return response;
				}
				String origOTP = customerObj.getOtpString();
				ParsedOTP parseOtp = parseOTP(origOTP);
				if (parseOtp!=null && !parseOtp.isOTPValid()) {
					getLogger().info("OTP Expired for customer :" + customerObj.getId());
					response.setVerified(false);
					response.setResetCode(ApplicationConstants.USER_OTP_EXPIRED);
					return response;
				}
				if (parseOtp != null) {
					String otpToBeVerified = parseOtp.getOTP();
					getLogger().info("Printing the OTP provided by the user :" + otpToBeVerified);
					if (otpToBeVerified.equalsIgnoreCase(otpRequest.getOtp())
							|| (!isProdEnvironment() && ("111111".equals(otpRequest.getOtp())))) {
						getLogger().info("Successfully verified the OTP string.");
						customerObj.setOtpVerfied("Yes");
						response.setVerified(true);
						accountsDao.saveOrUpdateObject(customerObj);
						response.setResetCode(resetCode);
						return response;
					}
				} else {
					getLogger().error("OTP Provided the user was not matching .. ");
				}

			}
		} catch (Exception err) {
			getLogger().error("Error while verifying the OTP", err);
		}
		return response;
	}		

	private ParsedOTP parseOTP(String encryptedArg) {
		String[] splitData = getParsedOtp(encryptedArg);
		if (splitData.length == 2) {
			ParsedOTP parsedOTP = new ParsedOTP();
			getLogger().info("OTP In DB :" + splitData[0]);
			parsedOTP.setOTP(splitData[0]);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			String dateSrc = splitData[1];
			getLogger().info("OTP Provided at :" + dateSrc);
			Date dateToBeCompared = null;
			try {
				dateToBeCompared = sdf.parse(dateSrc);
			} catch (ParseException e) {
				getLogger().error("ParseException: " + e);
			}
			Date currentTime = new Date();
			if (dateToBeCompared != null) {
				long diffInMills = currentTime.getTime() - dateToBeCompared.getTime();
				boolean flag = false;				
				if (diffInMills < twoMinsInMilliSecs) {
					flag = true;
				} else {
					getLogger().error("OTP expired ");
				}
				parsedOTP.setOTPValid(flag);
			}
			return parsedOTP;
		}
		return null;

	}

	private String[] getUserDetailsFromKey(String key) {
		try {
			String appK = "EMVNbStacg8=";
			PublicUtility utility = PublicUtility.getInstance(appK);
			try {
				key = URLDecoder.decode(key, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				getLogger().error("UnsupportedEncodingException caught in getUserDetailsFromKey(): " + e);
			}
			String decryptedStr = utility.DecryptText(key);
			return decryptedStr.split("###");
		} catch (Exception ex) {
			getLogger().error("Exception caught in getUserDetailsFromKey(): " + ex);
			return null;
		}

	}

	public PasswordResetStatus resetPassword(ResetPasswordDTO dto) {
		try {
			String[] userDetails = getUserDetailsFromKey(dto.getResetKey());			
			if (userDetails == null || userDetails.length < 3) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return PasswordResetStatus.createInvalidTokenStatus();
			}
			Customer customer = null;
			String emailAddress = userDetails[0];
			List<Customer> customers = accountsDao.getObjectsByRef(Customer.class, "email", userDetails[0]);
			if (customers != null && !customers.isEmpty()) {
				customer = customers.get(0);
			}
			if (customer == null) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return PasswordResetStatus.createInvalidCredentialsStatus();
			}
			// Expired link			
			String datePart = userDetails[2];	
			getLogger().info("Printing the date to be formated:" + datePart);
			Date sentDate = PublicUtility.parseDateString(datePart,AccountServiceConstants.EMAIL_LINK_DATE_FORMAT);
			Date currentDate = new Date();
			long days = PublicUtility.getDifferenceDays(sentDate, currentDate);
			if (days > 1) {
				getLogger().error("Password Link expired");
				return PasswordResetStatus.createLinkExpiredStatus();
			}
			else{
				getLogger().info("Printing the days : " + days);
			}			
			String password = passwordEncryptionService.decrypt(dto.getPassword(), dto.getSessionId());
			getLogger().info("User new password " + password);
			// --------- Fix for BFA-1236 ------------------------//
			String sessionId = dto.getSessionId();
			if (isPasswordUsedFor5Times(password, emailAddress,sessionId)) {
				PasswordResetStatus passwordResetStatus = new PasswordResetStatus(ErrorCodes.PASSWORD_USED_FOR_5_TIMES,
						ApplicationConstants.CREDENTIAL_USED_FOR_5_TIMES);
				getLogger().error("The same password is used in the last five times");
				return passwordResetStatus;
			}
			// ----------------------------------------------------//
			String newPassword = password;
			String encrypted = null;
			// -------------------------------------------------------------
			//------------------- BFA-1552 ----------------------------
			byte[] uniqueId = null;
			try {
				uniqueId = utility.getSalt();
				customer.setUniqueId(uniqueId);
				encrypted = utility.encryptTextWithKey(newPassword, false, uniqueId);
				customer.setPassword(encrypted.getBytes());			
			} catch (NoSuchAlgorithmException e) {			
				getLogger().error("Error while obtaining the salted key",e);
			}
			logPassword(customer.getId(), encrypted.getBytes(),uniqueId);
			// -------------------------------------------------------------- 
			customer.setResetToken(getRandomResetToken());
			accountsDao.saveOrUpdateObject(customer);
			invalidateCurrentUserSession(customer.getId(), "Password was reset - login again");
			getLogger().info("Password updated successfully!");
			return PasswordResetStatus.createSuccessStatus();
		} catch (Exception err) {
			getLogger().error("Unable to persist the user password: ", err);
			return PasswordResetStatus.createFailureStatus();
		}
	}

	@Override
	public PasswordResetStatus resetPasswordforAdmin(ResetPasswordDTO dto) {
		try {
			String[] userDetails = getUserDetailsFromKey(dto.getResetKey());
			if (userDetails == null || userDetails.length < 3) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return PasswordResetStatus.createInvalidTokenStatus();
			}
			Advisor advisor = null;
			String emailAddress = userDetails[0];
			List<Advisor> advisors = accountsDao.getObjectsByRef(Advisor.class, "emailId", userDetails[0]);
			if (advisors != null && advisors.size() > 0) {
				advisor = advisors.get(0);
			}
			if (advisors == null) {
				getLogger().error(" Unable to find the Advisor based on the customer reference.");
				return PasswordResetStatus.createInvalidCredentialsStatus();
			}

			// Expired link
			Date sentDate = PublicUtility.parseDateString(userDetails[0]);
			Date currentDate = PublicUtility.getCurrentUTC();
			long days = PublicUtility.getDifferenceDays(sentDate, currentDate);
			if (days > 1) {
				getLogger().error("Password Link expired");
				return PasswordResetStatus.createLinkExpiredStatus();
			}
			String password = passwordEncryptionService.decrypt(dto.getPassword(), dto.getSessionId());
			getLogger().info("User new password " + password);
			// --------- Fix for BFA-1236 ------------------------//
			String sessionId = dto.getSessionId();
			/*
			 * if (isPasswordUsedFor5Times(password, emailAddress, sessionId)) {
			 * PasswordResetStatus passwordResetStatus = new
			 * PasswordResetStatus(ErrorCodes.PASSWORD_USED_FOR_5_TIMES,
			 * ApplicationConstants.PASSWORD_USED_FOR_5_TIMES);
			 * getLogger().error("The same password is used in the last five times"); return
			 * passwordResetStatus; } //
			 * ----------------------------------------------------//
			 */ String newPassword = password;
			String encrypted = utility.EncryptText(newPassword);
			advisor.setPassword(encrypted.getBytes());
			advisor.setResetToken(getRandomResetToken());
			accountsDAO.saveOrUpdateObject(advisor);
			invalidateCurrentUserSession(advisor.getId(), "Password was reset - login again");
			getLogger().info("Password updated successfully");
			return PasswordResetStatus.createSuccessStatus();
		} catch (Exception err) {
			getLogger().error("Unable to persist the advisor password .", err);
			return PasswordResetStatus.createFailureStatus();
		}
	}

	private boolean isPasswordUsedFor5Times(String newPassword, String emailAddress,String sessionId) {
		getLogger().info("Printing the new password " + newPassword);
		String hql = "select cp from CustomerPassLog cp, Customer cust where cust.id = cp.customerId and cust.email=:emailAddress order by cp.updateDate desc ";// limit 5";
		getLogger().info("Printing the hql " + hql);
		// Take only the TOP five records for comparison //
		List passwords = accountsDAO.getObjectByHqlAndLimit(hql,"emailAddress",emailAddress, 5);
		getLogger().info("Number of passwords obtained :" + passwords.size());
		Iterator iter = passwords.iterator();
		while (iter.hasNext()) {
			CustomerPassLog customerPassLog = (CustomerPassLog)  iter.next();			
			String encText = new String(customerPassLog.getPassword());
			String decryptedPassword = "";
			byte[] uniqueId = customerPassLog.getUniqueId();
			if(uniqueId == null){
				decryptedPassword = utility.DecryptText(encText);
			}
			else{
				decryptedPassword = utility.decryptTextWithKey(encText, uniqueId);
			}			
			getLogger().info("Printing the decrypted " + decryptedPassword);
			if (newPassword.equals(decryptedPassword)) {
				getLogger().info("Password matching with last 5 passwords");
				return true;
			}
		}
		getLogger().info("Password is not matching last 5 records");
		return false;
	}

	@Override
	public boolean setPassword(PasswordRequest passwordRequest, HttpServletRequest servletRequest) {
		try {
			String customerRef = passwordRequest.getCustomerRef();
			Customer customerObj = getCustomerByReference(customerRef);
			if (customerObj == null) {
				getLogger().error(" Unable to find the customer based on the customer reference " + customerRef);
				return false;
			}
			if (!isValidResetCode(customerObj, passwordRequest.getResetCode())) {
				getLogger().error("Invalid reset code " + passwordRequest.getResetCode());
				return false;
			}
			String _encryptedPass = passwordRequest.getPassword();
			String password = passwordEncryptionService.decrypt(_encryptedPass, passwordRequest.getSessionId());
			String encrypted = "";
			// -------------------------------------------------------------
			//------------------- BFA-1552 ----------------------------
			byte[] uniqueId = null;
			try {
				uniqueId = utility.getSalt();
				customerObj.setUniqueId(uniqueId);
				encrypted = utility.encryptTextWithKey(password, false, uniqueId);
				customerObj.setPassword(encrypted.getBytes());			
			} catch (NoSuchAlgorithmException e) {			
				getLogger().error("Error while obtaining the salted key",e);
			}
			// --------------------------------------------------------------			
			accountsDAO.saveOrUpdateObject(customerObj);
			logPassword(customerObj.getId(), encrypted.getBytes(),uniqueId);
			getLogger().info("Password updated successfully");
			String hostedServerName = servletRequest.getServerName();
			delegateHandler.sendVerificationEmail(customerObj, null, passwordRequest.getCallbackUrl(),
					hostedServerName);
			return true;
		} catch (Exception err) {
			getLogger().error("Unable to persist the user password .", err);
			return false;
		}
	}

	private void logPassword(int customerId, byte[] password,byte[] unique_id) {
		getLogger().info("Logging the user password for customer :" + customerId);
		CustomerPassLog customerPasswordLog = new CustomerPassLog();
		customerPasswordLog.setCustomerId(customerId);	
		//------------------- BFA-1552 ----------------------------				
		customerPasswordLog.setPassword(password);			
		// --------------------------------------------------------------		
		customerPasswordLog.setUpdateDate(new Date());
		customerPasswordLog.setUniqueId(unique_id);
		accountsDAO.saveOrUpdateObject(customerPasswordLog);
	}

	private boolean isValidResetCode(Customer customerObj, String resetCode) {
		String emailId = customerObj.getEmail();
		String emailToBeVrified = utility.DecryptText(resetCode);
		if (emailId.equals(emailToBeVrified)) {
			return true;
		}
		return false;
	}

	public String generatePasswordResetMail(ForgotPasswordDTO dto) {
		try {
			BFAUserDetails bfaUser = bfaUserDetailsService.loadUserByEmail(dto.getEmail());
			getLogger().error("Forgot Password: " + "-- bfaUser" + bfaUser);

			if (bfaUser == null) {
				getLogger().error("Forgot Password: " + "-- bfaUser" + bfaUser);
				return ApplicationConstants.NO_SUCH_USER;
			}
			if (!bfaUser.isEmailVerified()) {
				return ApplicationConstants.VALIDATION_ERROR_EMAIL_UNVERIFIED;
			}
			if (!bfaUser.isEnabled()) {
				return ApplicationConstants.VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED;
			}
			if (bfaUser != null && bfaUser.isEnabled()) {
				getLogger().info("About to generate the reset password email " + dto.getEmail());
				PublicUtility utility = PublicUtility.getInstance(appK);
				Date today = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat(AccountServiceConstants.EMAIL_LINK_DATE_FORMAT);
				String utcDate = sdf.format(today);
				/*
				 * --------- BFA-1236 -------- 
				 * This token is compared
				 * everytime to ensure the link is not used again.
				 */
				String token = getRandomResetToken();
				getLogger().info("Printing the password reset token " + token);
				Customer customerObj = getCustomerByEmail(dto.getEmail());
				if (customerObj != null) {
					customerObj.setResetToken(token);
					accountsDao.saveOrUpdateObject(customerObj);
					getLogger().info("Saved the reset token in customer ..");
				}
				/*------------------------------*/

				String encUserDetails = utility.EncryptTextURLSafe(
						bfaUser.getUserName() + "###" + bfaUser.getPassword() + "###" + utcDate + "###" + token);
				encUserDetails = URLEncoder.encode(encUserDetails, "UTF-8");
				getLogger().error("Forgot Password: " + "-- encUserDetails" + encUserDetails);

				sendResetPasswordMail(dto, encUserDetails);

				return ApplicationConstants.VALIDATION_SUCCESS;
			}
		} catch (Exception e) {

			getLogger().error("Error while password reset ", e);
			return ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS;
		}

		return "";
	}

	private String getRandomResetToken() {
		return getPartString();
	}

	private void sendResetPasswordMail(ForgotPasswordDTO dto, String encUserDetail) {
		try {
			getLogger().info("Enc: " + encUserDetail);
			String fromEmail = "notifications@moneyowl.sg";
			String toEmail = dto.getEmail();
			String subject = "Reset Password";
			Map<String, String> params = new HashMap<String, String>();
			params.put("resetLink", dto.getRedirectUrl() + encUserDetail);
			params.put("#contact_email#",environment.getProperty("email.support.contact",""));
			params.put("#contact_number#",environment.getProperty("mobile.support.contact",""));
			HttpServletRequest request = PublicUtility.getCurrentHttpRequest();
			if (request != null) {
				String imagePath = environment.getProperty("server.context.sub.domain", "");
				params.put("root-url", "https://" + request.getServerName() + imagePath);
			}
			delegateHandler.sendEmail(fromEmail, toEmail, subject, "reset_password.template", params);
		} catch (Exception e) {
			getLogger().error("Error while password reset ", e);

		}

	}

	private Customer getCustomerByEmail(String email) {
		List<Customer> customers = (List<Customer>) accountsDao.getObjectsByRef(Customer.class, "email", email);
		Customer customer = null;
		if (customers != null && !customers.isEmpty()) {
			customer = customers.get(0);
		}
		return customer;
	}

	private Advisor getAdvisorfByEmail(String email) {
		List<Advisor> advisors = (List<Advisor>) accountsDAO.getObjectsByRef(Advisor.class, "emailId", email);
		Advisor advisor = null;
		if (advisors != null && advisors.size() > 0) {
			advisor = advisors.get(0);
		}
		return advisor;
	}

	@Override
	public String verifyEmailAddress(VerifyEmailRequest verifyEmailRequest) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			String code = verifyEmailRequest.getCode();
			byte[] token = Base64.getDecoder().decode(code.getBytes());
			String tokenStr = new String(token);
			String decryptedData = utility.DecryptText(tokenStr);
			getLogger().info("Printing the decoded token" + decryptedData);
			String email = null;
			String[] emailDetails = decryptedData.split(ApplicationConstants.DELIMITER);
			String date = emailDetails[0];
			Date dateobj = sdf.parse(date);
			boolean flag = isEmailLinkValid(dateobj);
			if(!flag){
				return ApplicationConstants.EMAIL_LINK_EXPIRED;
			}			
			String customerId = emailDetails[2];
			Integer custId = Integer.parseInt(customerId);
			Customer obj = getCustomerById(custId);

			if (emailDetails.length >= 4) {
				CustomerContactVerification updateEmailDetails = getCustomerFromVerification(custId);
				if(updateEmailDetails.getEmailVerifiedStatus().toLowerCase().equals("yes")){
					return ApplicationConstants.VALIDATION_ERROR_EMAIL_ALREADY_VERIFIED;
				}
				email = emailDetails[3];
				if (updateEmailDetails.getEmail().equalsIgnoreCase(email)) {
					obj.setEmail(email);
					obj.setEmailVerified("Yes");
					updateEmailDetails.setEmailVerifiedStatus("Yes");
					accountsDao.saveOrUpdateObject(obj);
					accountsDao.saveOrUpdateObject(updateEmailDetails);
					return email;
				}
				else {
					getLogger().error(obj.getEmail());
					getLogger().error("Email id could not be verified : Email ID not matching" + email);
					return "Invalid";
				}

			} else {
				if(obj.getEmailVerified().toLowerCase().equals("yes")){
					return ApplicationConstants.VALIDATION_ERROR_EMAIL_ALREADY_VERIFIED;
				}
				email = emailDetails[1];
				if (obj.getEmail().equalsIgnoreCase(email)) {
					obj.setEmailVerified("Yes");
					accountsDao.saveOrUpdateObject(obj);
					sendSetUpInvestmentAccountMailerIfApplicable(obj.getId());
					getLogger().info("Email address verified successfully " + email);
					return email;
				} else {
					getLogger().error(obj.getEmail());
					getLogger().error("Email id could not be verified : Email ID not matching" + email);
					return "Invalid";
				}
			}

		} catch (Exception err) {
			getLogger().error("Error while verifying email address", err);
			return "Invalid";
		}
	}

	/**
	 * BFA-1246
	 * 
	 * @param emailIssuedTime
	 * @return
	 */
	private boolean isEmailLinkValid(Date emailIssuedTime) {
		String linkValidity = environment.getProperty(AccountServiceConstants.EMAIL_LINK_VALIDITY);
		Integer timeInSeconds = Integer.parseInt(linkValidity);
		getLogger().info("Printing the email link validity in seconds " + timeInSeconds);
		long timeInMilliSecs = timeInSeconds * 1000L;

		Date now = new Date();
		long timeDiff = now.getTime() - emailIssuedTime.getTime();
		getLogger().info("Printing the time in milli seconds: " + timeDiff + ":" + timeInMilliSecs);
		if (timeDiff <= timeInMilliSecs) {
			getLogger().info("The email link is valid can be verified " + timeDiff + ":" + timeInMilliSecs);
			return true;
		}
		return false;
	}
	
	@Override
	public void sendSetUpInvestmentAccountMailerIfApplicable(Integer customerId) {
		try {
			getLogger().info("customerInvestmentProfile called: CustomerId: " + customerId);
			InvestmentAccountStatusDTO investmentAccountStatus = investServiceHelper
					.customerInvestmentAccountActions(customerId);
			getLogger().info("StartInvestingMail: CustomerId: " + customerId
					+ " sendSetUpInvestmentAccountMailerIfApplicable called");
			if (investmentAccountStatus != null && (investmentAccountStatus.isShowInvestmentAccountCreationForm()
					&& (investmentAccountStatus.getAccountCreationState() != null
							&& investmentAccountStatus.getAccountCreationState()
									.equalsIgnoreCase(CustomerPortfolioStatus.PROPOSED.toString())))) {
				getLogger().error("StartInvestingMail: CustomerId: " + customerId + " portfolios recommended.");
				CustomerAdditionalDetails additionalDetails = accountsService.getCustomerAdditionalDetails(customerId);

				boolean emailAlreadySent = false;
				if (additionalDetails != null) {
					getLogger().error(
							"StartInvestingMail: CustomerId: " + customerId + " additionalDetails already found.");
					emailAlreadySent = (additionalDetails.isSetUpInvestmentMailerSent() != null
							&& additionalDetails.isSetUpInvestmentMailerSent() == true);
					if (!emailAlreadySent) {
						additionalDetails.isSetUpInvestmentMailerSent(true);
						accountsService.updateCustomerAdditionalDetails(additionalDetails);
					}
				} else {
					getLogger()
							.info("StartInvestingMail: CustomerId: " + customerId + " creating new additionalDetails");
					additionalDetails = new CustomerAdditionalDetails();
					Customer customer = new Customer();
					customer.setId(customerId);
					additionalDetails.setCustomer(customer);
					additionalDetails.isSetUpInvestmentMailerSent(true);
					accountsService.updateCustomerAdditionalDetails(additionalDetails);
					getLogger().info("StartInvestingMail: CustomerId: " + customerId + " saving new additionalDetails");
					// Fetch details along with customer
					additionalDetails = accountsService.getCustomerAdditionalDetails(customerId);
					getLogger().info("StartInvestingMail: CustomerId: " + customerId + " fetching the saved details");
				}
				if (additionalDetails != null && !emailAlreadySent) {
					ProfileSummaryDTO profileSummary = new ProfileSummaryDTO();
					profileSummary.setId(additionalDetails.getCustomer().getId());
					profileSummary.setFirstName(additionalDetails.getCustomer().getGivenName());
					profileSummary.setLastName(additionalDetails.getCustomer().getSurName());
					profileSummary.setFullName(additionalDetails.getCustomer().getNricName());
					profileSummary.setEmailAddress(additionalDetails.getCustomer().getEmail());
					getLogger().info("StartInvestingMail: CustomerId: " + customerId + " send email called");
					investmentServiceHelper.notifyInvestmentAccountSetup(profileSummary);
				}
			} else {
				getLogger().info("StartInvestingMail: CustomerId: " + customerId
						+ " investmentDashboardStatus is not null. else part called");
				if (investmentAccountStatus != null && investmentAccountStatus.isShowInvestmentAccountCreationForm()) {
					getLogger().info("StartInvestingMail: CustomerId: " + customerId
							+ " investmentAccountStatus.getAccountCreationState(): "
							+ investmentAccountStatus.getAccountCreationState());
				} else {
					getLogger().error("Investment dashboard status not found !");
				}
			}
		} catch (Exception error) {
			getLogger().error("Error while sendSetUpInvestmentAccountMailerIfApplicable ", error);
		}

	}
	
	private void sendSetUpInvestmentAccount(Customer custObj) {
		ClassPathResource classPathResourceObj = new ClassPathResource("mail_template.properties");

		Properties prop = new Properties();
		try {
			InputStream input = classPathResourceObj.getInputStream();
			prop.load(input);
		} catch (IOException e1) {
			getLogger().debug("Exception while loading properties" + e1.getMessage());
		}
		EmailContentWrapper emailObj = new EmailContentWrapper();
		EmailData emailDataObj = new EmailData();
		CustomerData custDataObj = new CustomerData();
		custDataObj.setNricName(custObj.getNricName());
		emailDataObj.setCustomer(custDataObj);
		List<String> custEmailAddress = new ArrayList<>();
		List<String> bccEmailList = new ArrayList<>();
		custEmailAddress.add(custObj.getEmail());
		String bccEmailAddress = prop.getProperty("common.mo.clientsupport");
		getLogger().info("Account service Bcc Email from propertry" + bccEmailAddress);
		StringTokenizer st = new StringTokenizer(bccEmailAddress, ",");
		getLogger().info("Bcc Email tokenizer" + st.toString());
		while (st.hasMoreTokens()) {
			String token = st.nextToken();
			getLogger().info("sendEmail(): Bcc Email: " + token);
			bccEmailList.add(token);
		}
		Common commonObj = new Common();
		commonObj.setAdvisorynumber(prop.getProperty("common.mo.advisorynumber"));
		commonObj.setContactEmail(prop.getProperty("common.mo.generalemail"));
		commonObj.setGeneralenquiry(prop.getProperty("common.mo.generalenquiry"));
		commonObj.setLoginUrl(prop.getProperty("common.mo.loginUrl"));
		emailDataObj.setCommon(commonObj);
		emailObj.setData(emailDataObj);
		ObjectMapper mapper = new ObjectMapper();
		emailObj.setFromEmailAddress("notifications@moneyowl.sg");
		emailObj.setToEmailAddress(custEmailAddress);
		emailObj.setSubjectOfEmail(prop.getProperty("ifasteddcddcheck.subject"));
		emailObj.setAcknowledgeURL("https://test");
		emailObj.setScheduledEmailTime(new Date());
		emailObj.setNumberOfRetry(1);
		emailObj.setBccEmailAddress(bccEmailList);
		emailObj.getToEmailAddress().set(0, custObj.getEmail());
		emailObj.setEmailRequestId("123");
		emailObj.setEmailTemplateName("eddcddcheck.ftl");

		mapper.setSerializationInclusion(Include.NON_NULL);
		try {
			String mailJsonObj = mapper.writeValueAsString(emailObj);
			getLogger().info("MAIL OBJ PREPARED" + mailJsonObj);
			moemailObj.sendMessage(mailJsonObj);
			getLogger().info("Mail Sent");
		} catch (JsonProcessingException e) {
			getLogger().info("Exception while loading properties" + e);
		}
	}

	class ParsedOTP {

		public boolean isOTPValid;

		public String OTP;

		public boolean isOTPValid() {
			return isOTPValid;
		}

		public void setOTPValid(boolean isOTPValid) {
			this.isOTPValid = isOTPValid;
		}

		public String getOTP() {
			return OTP;
		}

		public void setOTP(String oTP) {
			OTP = oTP;
		}
	}

	@Override
	public void saveSessionCaptchaDetails(HttpServletRequest request, String sessionId, String captcha) {
		SessionDetails sessionDetails = getSessionDetailsBySessionId(sessionId);
		if (sessionDetails == null) {
			// Save the session details if it does not exists //
			SessionDetails sessionDetailsObj = getSessionDetails(request);
			sessionDetailsObj.setSessionId(sessionId);
			sessionDetailsObj.setCaptcha(captcha);
			getLogger().info("Saving session details " + sessionDetailsObj.toString());
			try {
				SessionDetails sessionDetObj = (SessionDetails) accountsDao.saveOrUpdateObject(sessionDetailsObj);
			} catch (Exception err) {
				getLoggerBean().error("Error while updating session details ", err);
			}
		} else {
			sessionDetails.setCaptcha(captcha);
			accountsDao.saveOrUpdateObject(sessionDetails);
			getLogger().info("Succssfully saved the session details " + sessionId + " with captcha :" + captcha);
		}
	}

	@Override
	public SessionDetails getSessionDetailsBySessionId(String sessionId) {
		String hql = "from SessionDetails where sessionId =:sessionId";
		List sessionDetailList = accountsDAO.getObjectByHql(hql,"sessionId",sessionId);
		if (sessionDetailList != null && !sessionDetailList.isEmpty()) {
			return (SessionDetails) sessionDetailList.get(0);
		}
		return null;
	}

	/**
	 * Fix for pen test issue
	 * 
	 * @param sessionDetails
	 */
	private void swapCaptcha(SessionDetails sessionDetails) {
		getLogger().info("Swapping the captcha details after verification");
		String captcha = captchaProvider.getCaptchaString();
		sessionDetails.setCaptcha(captcha);
		accountsDao.saveOrUpdateObject(sessionDetails);
	}

	@Override
	public boolean isValidCaptcha(String sessionId, String captcha) {
		try {
			SessionDetails sessionDetails = getSessionDetailsBySessionId(sessionId);

			if (sessionDetails == null) {
				getLogger().error("No session details available " + sessionId);
				return false;
			} else {
				getLogger().error("Input captcha: " + captcha);
				getLogger().error("SessionDetails instance captcha: " + sessionDetails.getCaptcha());
				if (sessionDetails != null && sessionDetails.getCaptcha().equals(captcha)) {
					getLogger().debug("Captcha was matching, Captcha: " + captcha + ", Session: " + sessionId);
					swapCaptcha(sessionDetails);
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception ex) {
			getLogger().error("Exception occurred  at isValidCaptcha() : " + ex);
			return false;
		}

	}

	@Override
	public void updateCRMPostCustomerCreation(String customerId, List<ProductList> selectedProducts,
			boolean isNewCustomer, Integer enquiryId) {
		getLogger().info("Updating the CRM ta"
				+ "sk");
		String[] paramNames = new String[]{"customerId"};
		Integer custId = Integer.parseInt(customerId);
		Object[] paramValues = new Integer[]{custId};
		Customer customerObj;
		List<Object> customerList = accountsDao.getObjectByHql("from Customer where id =:customerId",paramNames,paramValues);
		if (customerList != null && !customerList.isEmpty()) {
			customerObj = (Customer) customerList.get(0);
		} else {
			getLogger().error("Unable to find the customer details " + customerId);
			return;
		}
		if(enquiryId == -1){
			enquiryId = customerObj.getVerificationEnquiryId();
		}
		getLogger().info("Printing the enquiry id for CRM Upatate " + enquiryId);
		
		CRMCustomerUpdateRequest crmCustomerUpdateRequest = new CRMCustomerUpdateRequest();
		crmCustomerUpdateRequest.setCustomer(customerObj);
		crmCustomerUpdateRequest.setEnquiryId(enquiryId);
		crmCustomerUpdateRequest.setSelectedProducts(selectedProducts);
		crmCustomerUpdateRequest.setNewCustomer(isNewCustomer);
		CRMUpdateThread crmUpdateThread = new CRMUpdateThread(crmCustomerUpdateRequest, isNewCustomer);
		threadPoolTaskExecutor.execute(crmUpdateThread);
	}

	class CRMUpdateThread implements Runnable {

		private CRMCustomerUpdateRequest crmCustomerUpdateRequest;

		private boolean newCustomer;

		public CRMUpdateThread(CRMCustomerUpdateRequest request, boolean newCustomer) {
			this.crmCustomerUpdateRequest = request;
			this.newCustomer = newCustomer;
		}

		@Override
		public void run() {
			delegateHandler.updateCRMDetails(crmCustomerUpdateRequest, newCustomer);
		}
	}

	@Override
	public void updateCRMPostDuringSignup(PasswordRequest passwordRequest, boolean isNewCustomer) {
		List<ProductList> selectedProducts = passwordRequest.getSelectedProducts();
		String customerReference = passwordRequest.getCustomerRef();
		String customerId = decryptUserResponseData(customerReference);
		getLogger().info("passing the customer details to CRM: " + customerId);
		updateCRMPostCustomerCreation(customerId, selectedProducts, isNewCustomer,-1);
	}

	@Override
	public void blackList(String token,String reason) {
		super.blackList(token,reason);
	}
	
	private void invalidateCurrentUserSession(int customerId,String reason){
		getLogger().info("Invalidating the user session " + customerId);
		getLogger().info("Printing the reason " + reason);
		CustomerIssuedToken customerIssuedToken = getCustomerIssuedToken(customerId);
		// -- Fix for BFA-1443 -- //
		if(customerIssuedToken == null){
			getLogger().info("Token issued to customer was not found ");
			return;
		}
		String token = customerIssuedToken.getTokenValue();
		blackList(token, reason);
		getLogger().info("Blacklisted token " + token);
	}
	
	@Override
	public String isEmailLinkValid(EmailLinkValidityRequest emailLinkValidityRequest) {
		String[] userDetails = getUserDetailsFromKey(emailLinkValidityRequest.getResetKey());
		Customer customer = null;
		Advisor advisor = null;
		if (userDetails == null || userDetails.length < 3) {
			getLogger().error(" Unable to find the customer based on the customer reference.");
			return ApplicationConstants.USER_NOT_FOUND;
		}
		if (emailLinkValidityRequest.getIsAdmin() != null && emailLinkValidityRequest.getIsAdmin() == true) {

			String emailAddress = userDetails[0];
			List<Advisor> advisors = accountsDAO.getObjectsByRef(Advisor.class, "emailId", userDetails[0]);
			if (advisors != null && advisors.size() > 0) {
				advisor = advisors.get(0);
			}
			if (advisor == null) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return ApplicationConstants.USER_NOT_FOUND;
			}
		} else {

			String emailAddress = userDetails[0];
			List<Customer> customers = accountsDAO.getObjectsByRef(Customer.class, "email", userDetails[0]);
			if (customers != null && customers.size() > 0) {
				customer = customers.get(0);
			}
			if (customer == null) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return ApplicationConstants.USER_NOT_FOUND;
			}
		}
		// --- Expired link if the link is more than 1 day old --- //
		SimpleDateFormat sdf = new SimpleDateFormat(AccountServiceConstants.EMAIL_LINK_DATE_FORMAT);
		getLogger().info("Printing the input date :" + userDetails[2]);
		Date sentDate = null;
		try {
			sentDate = sdf.parse(userDetails[2]);
		} catch (ParseException e) {			
			getLogger().error("Error while parsing the date", e);
		}
		Date currentDate = new Date();
		long diffInMillies = Math.abs(currentDate.getTime() - sentDate.getTime());			
		int numberOfDays = (int) diffInMillies / (1000 * getEmailLinkValidityInSeconds());			
		getLogger().info("Printing the number of days of link expiry " + numberOfDays);
		if (numberOfDays >= 1) {
			getLogger().error("Password Link expired");
			return ApplicationConstants.LINK_EXPIRED_CREDENTIAL;
		}
	
		// ---- Expired link check if that is used already --- //
		if (emailLinkValidityRequest.getIsAdmin() != null && emailLinkValidityRequest.getIsAdmin() == true) {
			String resetToken = advisor.getResetToken();
			getLogger()
					.info("Printing the reset token in DB:" + resetToken + " | reset token in URL :" + userDetails[3]);
			if (!resetToken.equals(userDetails[3])) {
				getLogger().error("Link is already used and expired : Token in DB:" + resetToken + "Token from email :"
						+ userDetails[3]);
				return ApplicationConstants.LINK_ALREADY_USED_CREDENTIAL;
			}
		} else {
			String resetToken = customer.getResetToken();
			getLogger()
					.info("Printing the reset token in DB:" + resetToken + " | reset token in URL :" + userDetails[3]);
			if (!resetToken.equals(userDetails[3])) {
				getLogger().error("Link is already used and expired : Token in DB:" + resetToken + "Token from email :"
						+ userDetails[3]);
				return ApplicationConstants.LINK_ALREADY_USED_CREDENTIAL;
			}
		}
		// ------------------------------------------------------//
		return ApplicationConstants.LINK_VALID_CREDENTIAL;
	}
	
	public CustomerContactVerification editEmail(ContactDetailsDTO updateCustomercontact, Integer customerId,
			HttpServletRequest servletRequest) {
		CustomerContactVerification updatedContactedDetails = securityDAO
				.getCustomerContactVerificationByCustomerIdAndType(customerId,
						ApplicationConstants.CUSTOMER_UPDATE_TYPE);
		if (null == updatedContactedDetails) {
			updatedContactedDetails = new CustomerContactVerification();
		}
		Customer customerObj = getCustomerById(customerId);	
		if (updateCustomercontact.getEmailId() != null) {
			updatedContactedDetails.setCustomer(customerObj);
			updatedContactedDetails.setEmail(updateCustomercontact.getEmailId());
			updatedContactedDetails.setEmailVerifiedStatus("No");
			updatedContactedDetails.setActionType(ApplicationConstants.CUSTOMER_UPDATE_TYPE);
			accountsDao.saveOrUpdateObject(updatedContactedDetails);
		}
		String hostedServerName = servletRequest.getServerName();

		delegateHandler.sendVerificationEmail(customerObj, updatedContactedDetails,
				updateCustomercontact.getCallbackUrl(), hostedServerName);
		return updatedContactedDetails;
	}

	@Override
	public void updateCRMPostDuringSignupV2(SaveSelectedProductsRequest passwordRequest, boolean isNewCustomer) {
		List<ProductList> selectedProducts = passwordRequest.getSelectedProducts();
		String customerReference = passwordRequest.getCustomerRef();
		String customerId = decryptUserResponseData(customerReference);
		getLogger().info("passing the customer details to CRM: " + customerId);
		updateCRMPostCustomerCreation(customerId, selectedProducts, isNewCustomer,-1);
	}	

	@Override
	public PasswordResetStatus resetPasswordV2(ResetPasswordDTO dto) {
		try {
			String[] userDetails = getUserDetailsFromKey(dto.getResetKey());			
			if (userDetails == null || userDetails.length < 3) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return PasswordResetStatus.createInvalidTokenStatus();
			}
			Customer customer = null;
			String emailAddress = userDetails[0];
			List<Customer> customers = accountsDao.getObjectsByRef(Customer.class, "email", userDetails[0]);
			if (customers != null && !customers.isEmpty()) {
				customer = customers.get(0);
			}
			if (customer == null) {
				getLogger().error(" Unable to find the customer based on the customer reference.");
				return PasswordResetStatus.createInvalidCredentialsStatus();
			}			
			// ------------------------------------------------------//

			String password = dto.getPassword();
			getLogger().info("User new password " + password);
			// --------- Fix for BFA-1236 ------------------------//
			String sessionId = dto.getSessionId();
			if (isPasswordUsedFor5Times(password, emailAddress,sessionId)) {
				PasswordResetStatus passwordResetStatus = new PasswordResetStatus(ErrorCodes.PASSWORD_USED_FOR_5_TIMES,
						ApplicationConstants.CREDENTIAL_USED_FOR_5_TIMES);
				getLogger().error("The same password is used in the last five times");
				return passwordResetStatus;
			}
			// ----------------------------------------------------//

			String newPassword = dto.getPassword();			
			getLogger().info("Printing the session id - before resetting password " + sessionId);
			String encrypted = passwordEncryptionService.getEncryptedPassword(newPassword, sessionId);
			// -------------------------------------------------------------
			//------------------- BFA-1552 ----------------------------
			byte[] uniqueId = null;
			try {
				uniqueId = utility.getSalt();
				customer.setUniqueId(uniqueId);
				encrypted = utility.encryptTextWithKey(encrypted, false, uniqueId);
				customer.setPassword(encrypted.getBytes());			
			} catch (NoSuchAlgorithmException e) {			
				getLogger().error("Error while obtaining the salted key",e);
			}
			//-----------------------------------------------------------
			logPassword(customer.getId(), encrypted.getBytes(),uniqueId);			
			customer.setResetToken(getRandomResetToken());
			accountsDao.saveOrUpdateObject(customer);
			invalidateCurrentUserSession(customer.getId(), "Password was reset - login again");
			getLogger().info("Password updated successfully");
			return PasswordResetStatus.createSuccessStatus();
		} catch (Exception err) {
			getLogger().error("Unable to persist the user password .", err);
			return PasswordResetStatus.createFailureStatus();
		}
	}

	@Override
	public void savePromocode(int customerId, Integer enquiryId) {
		// TODO Auto-generated method stub
		String promoCode = getPromoCode(enquiryId);
		getLogger().info("#savepromo:: saving promocode for the customerId--"+customerId +"with the enquiry Id"+enquiryId+"with the promocode"+promoCode);
		
		if (promoCode == null || promoCode.equals("-1")) {
			getLogger().error("Unable to find the promo code for enquiry " + enquiryId);
			return;
		}
		boolean promoCodeIdExists = StringUtils.isNotBlank(promoCode);
		getLogger().info("#savepromo:: Checking promocodeExists--"+promoCodeIdExists);
		
		String promoCodeCategory = null;
		boolean promoCodeAndCatExists = StringUtils.isNotBlank(promoCode) && StringUtils.isNotBlank(promoCodeCategory);
		
		getLogger().info("Save Promo code: promoCodeAndCatExists:" + promoCodeAndCatExists);
		if (customerId >= 0 && (promoCodeAndCatExists || promoCodeIdExists)) {
			CustomerPromo customerPromoObj = null;
			Integer promoCodeId = null;

			if (promoCodeIdExists) {
				getLogger().info("#savepromo:: pomocodeidexists is true--");
				promoCodeId = Integer.parseInt(promoCode);
				getLogger().info("Save Promo code: promocodeID:" + promoCodeId);
				Optional<PromoCode> promoCodeOpt = promoCodeRepository.findById(promoCodeId);
				
				if (promoCodeOpt.isPresent()) {
					PromoCode promoCodeObj = promoCodeOpt.get();
					promoCodeCategory = promoCodeObj.getCategory();
					getLogger().info("#savepromo:: promoCodeCategory:" + promoCodeCategory);
				} else if (StringUtils.isBlank(promoCodeCategory)) {
					promoCodeCategory = "WILLS";
				}
			} else {
				PromoCode promoCodeObj = promoCodeRepository.findByCodeAndCategory(promoCode, promoCodeCategory);
				if (null != promoCodeObj) {
					promoCodeId = promoCodeObj.getId();
					getLogger().info("#savepromo:: promoCodeId:" + promoCodeId);
				} else {
					try {
						getLogger()
								.info("#savepromo:: Save Promo code: PromoCode not found - " + promoCode + ", " + promoCodeCategory);
						throw new Exception("PromoCode not found - " + promoCode + ", " + promoCodeCategory);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

			CustomerPromo customerPromoDB = customerPromoRepository.findByCustomerIdAndPromoCodeCategory(customerId,
					promoCodeCategory);
			if (null != customerPromoDB) {

				customerPromoDB.setPromoCodeId(promoCodeId);
				getLogger().info("#savepromo:: from customerPromo Db: promoCodeId - " + promoCodeId);
				customerPromoObj = customerPromoDB;
			} else {
				customerPromoObj = new CustomerPromo();
				customerPromoObj.setCustomerId(customerId);
				customerPromoObj.setPromoCodeId(promoCodeId);
				getLogger().info("#savepromo::  from customerPromo object" + "promoCodeId:" + promoCodeId + "customerId:" + customerId);
			}
			customerPromoRepository.save(customerPromoObj);

		}
	}

	@Override
	public String generatePasswordResetMailForAdmin(ForgotPasswordDTO forgotPasswordDto) {
		try {

			if (forgotPasswordDto.getIsAdmin() != null && forgotPasswordDto.getIsAdmin() == true) {
				BFAUserDetails bfaUser = bfaUserDetailsService.loadAdminByEmail(forgotPasswordDto.getEmail());
				getLogger().error("Forgot Password: " + "-- bfaUser" + bfaUser);

				if (bfaUser == null) {
					getLogger().error("Forgot Password: " + "-- bfaUser" + bfaUser);
					return ApplicationConstants.NO_SUCH_USER;

				}
				if (!bfaUser.isEmailVerified()) {
					return ApplicationConstants.VALIDATION_ERROR_EMAIL_UNVERIFIED;
				}
				if (!bfaUser.isEnabled()) {
					return ApplicationConstants.VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED;
				}
				if (bfaUser != null && bfaUser.isEnabled()) {
					getLogger().info("About to generate the reset password email " + forgotPasswordDto.getEmail());
					PublicUtility utility = PublicUtility.getInstance(appK);
					Date today = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat(AccountServiceConstants.EMAIL_LINK_DATE_FORMAT);
					String utcDate = sdf.format(today);
					/*
					 * --------- BFA-1236 -------- This token is compared everytime to ensure the
					 * link is not used again.
					 */
					String token = getRandomResetToken();
					getLogger().info("Printing the password reset token " + token);
					Advisor advisorObj = getAdvisorfByEmail(forgotPasswordDto.getEmail());
					advisorObj.setResetToken(token);
					accountsDAO.saveOrUpdateObject(advisorObj);
					getLogger().info("Saved the reset token in customer ..");
					getLogger().error("Forgot Password: " + "-- bfaUser" + advisorObj.getEmailId());
					/*------------------------------*/

					String encUserDetails = utility.EncryptTextURLSafe(
							bfaUser.getUserName() + "###" + bfaUser.getPassword() + "###" + utcDate + "###" + token);
					encUserDetails = URLEncoder.encode(encUserDetails, "UTF-8");
					getLogger().error("Forgot Password: " + "-- encUserDetails" + encUserDetails);
					sendResetPasswordMail(forgotPasswordDto, encUserDetails);
					return ApplicationConstants.VALIDATION_SUCCESS;
				}
			}
		} catch (Exception e) {

			getLogger().error("Error while password reset ", e);
			return ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS;
		}

		return ApplicationConstants.VALIDATION_SUCCESS;
	}
	
	/**
	 * This method is to be called only when we need to check for a valid captcha and the session id cannot be null or empty.
	 * 
	 * Avoid calling this method if you are not passing a valid session id.
	 * 
	 * @param sessionId
	 * @return
	 * @throws RuntimeException
	 */
	@Override
	public boolean isCaptchaApplicable(String sessionId) throws RuntimeException {
		if (sessionId == null || sessionId.isEmpty()) {
			throw new InvalidSessionIdException("Invalid session id, cannot be null or empty");
		}
		SessionDetails sessionDetails = getSessionDetailsBySessionId(sessionId);
		if (sessionDetails == null) {
			getLogger().error("No session details available " + sessionId);
			throw new InvalidSessionIdException("No session details found");
		} else {
			if (null != sessionDetails.getCaptcha() && !sessionDetails.getCaptcha().isEmpty()) {
				getLogger().info("Captcha is applicable for the given session : " + sessionId);
				return true;
			}
			getLogger().info("Captcha is not applicable for the given session : " + sessionId);
			return false;
		}		
	}

	@Override
	public void updateCRMEnqByEmail(Integer customerId, List<ProductList> selectedProducts, boolean isNewCustomer,
			Integer enquiryId, String firstName, String lastName) {
		getLogger().info("Updating the CRM task");
		Customer customerObj;
		List<Object> customerList = accountsDao.getObjectByHql("from Customer where id =:customerId","customerId",customerId);		
		if (customerList != null && !customerList.isEmpty()) {
			customerObj = (Customer) customerList.get(0);
		} else {
			getLogger().error("Unable to find the customer details " + customerId);
			return;
		}
		if (enquiryId == -1) {
			enquiryId = customerObj.getVerificationEnquiryId();
		}
		getLogger().info("Printing the enquiry id for CRM Upatate " + enquiryId);
		customerObj.setGivenName(firstName);
		customerObj.setSurName(lastName);
		CRMCustomerUpdateRequest crmCustomerUpdateRequest = new CRMCustomerUpdateRequest();
		crmCustomerUpdateRequest.setCustomer(customerObj);
		crmCustomerUpdateRequest.setEnquiryId(enquiryId);
		crmCustomerUpdateRequest.setSelectedProducts(selectedProducts);
		crmCustomerUpdateRequest.setNewCustomer(isNewCustomer);
		CRMUpdateThread crmUpdateThread = new CRMUpdateThread(crmCustomerUpdateRequest, isNewCustomer);
		threadPoolTaskExecutor.execute(crmUpdateThread);
	}

	@Override
	public void send2FAOTP(Customer customerObj, String sessionId) {
		Integer customerId = customerObj.getId();
		getLogger().info("Sending 2FAOTP for mobile number for [Customer]: " + customerId + ",Session Id:" + sessionId);
		String otpString = accountsService.generateOTP();
		Date issuedTime = new Date();
		String actionType = ApplicationConstants.TWO_FA_ACTION_TYPE;
		String defaultVerifiedState = "No";
		CustomerContactVerification customerContactVerification = securityDAO.getCustomerContactVerificationByCustomerIdAndType(customerId, actionType);
		if (null == customerContactVerification) {
			customerContactVerification = new CustomerContactVerification();
		}
		String parsedOtp = appendDateToOTP(otpString);
		customerContactVerification.setOTPString(parsedOtp);
		customerContactVerification.setActionType(actionType);
		customerContactVerification.setSessionId(sessionId);
		customerContactVerification.setOtpTimeIssued(new Timestamp(issuedTime.getTime()));
		customerContactVerification.setOtpVerifiedStatus(defaultVerifiedState);
		customerContactVerification.setCustomer(customerObj);
		customerContactVerification.setEmail(customerObj.getEmail());
		securityDAO.updateCustomerContactVerification(customerContactVerification);
		getLogger().info("Successfully persisted the customer contact verification details.");
		// ------------- Step 2 : send the OTP SMS -----------//
		String contactNumber = customerObj.getMobileNumber();
		String countryCode = customerObj.getCountryCode();
		accountsService.sendOTP(contactNumber, countryCode, otpString, false);
	}

	@Override
	public Integer validate2FADetails(String sessionId, String twoFactorOtpString, Integer customerId) {
		getLogger().info("Validating the [Customer] :" + customerId + ",[Session id]:" + sessionId + ",[OTP]:"
				+ twoFactorOtpString);
		CustomerContactVerification customerContactVerification = securityDAO
				.getCustomerContactVerificationBySessionAndType(sessionId, ApplicationConstants.TWO_FA_ACTION_TYPE);
		if (null != customerContactVerification) {
			String otpStringEncrypted = customerContactVerification.getOTPString();
			String[] otpStringArg = getParsedOtp(otpStringEncrypted);
			String otpString = otpStringArg[0];
			getLogger().info("Printing the OTP for validation:" + otpString);
			Integer custId = customerContactVerification.getCustomer().getId();			
			boolean isDefaultOtpAllowed = (!isSmsFeatureEnabled && defaultOtpString.equals(twoFactorOtpString));
			//------- Time calculation -------------//
			long timeIssued = 0L;
			if (null != customerContactVerification.getOtpTimeIssued()) {
				timeIssued = customerContactVerification.getOtpTimeIssued().getTime();
			}
			Date currentTime = new Date();
			long timeDiff = currentTime.getTime() - timeIssued;
			if (timeDiff > twoMinsInMilliSecs) {
				getLogger().info("OTP expired after 2 mins interval.");
				return ErrorCodes.OTP_EXPIRED;
			}
			//---------------------------------------//
			if (null != otpString && null != custId) {
				getLogger().debug("Cust Id:" + custId + ",Customer Id:" + customerId);	
				getLogger().debug("Otp in DB:" + otpString + ",OTP in request:" + twoFactorOtpString +",Default OTP String:" + defaultOtpString);
				if ((otpString.equals(twoFactorOtpString) || isDefaultOtpAllowed) && custId.equals(customerId)) {
					getLogger().info("Two factor validation success.");
					customerContactVerification.setOtpVerifiedStatus("Yes");
					Timestamp otpVerifiedTime = new Timestamp(new Date().getTime());
					customerContactVerification.setOtpVerifiedTime(otpVerifiedTime);
					securityDAO.updateCustomerContactVerification(customerContactVerification);
					return ErrorCodes.TWO_FACTOR_AUTH_SUCCESS;
				} else {
					getLogger().warn("The OTP string / Customer id did not match !");
				}
			} else {
				getLogger().error("OTP String / customer id not found in customer contact verification.");
			}
		} else {
			getLogger().error("No customer contact verification found for [session id]:" + sessionId);
		}
		return ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED;
	}

	@Override
	public boolean authenticate2FA(String sessionId) {
		return authenticate2FAWithReturnCode(sessionId).getIsValidated();
	}

	@Override
	public TwoFactorAuthValidation authenticate2FAWithReturnCode(String sessionId) {
		Boolean isValidated = false;
		Long timeDiff = 0L;
		int returnCode = ErrorCodes.SUCCESSFUL_RESPONSE;
		// ------------------------------------------------//
		if (!isValidSession(sessionId)) {
			returnCode = ErrorCodes.INVALID_SESSION_ID;
		} else {
			CustomerContactVerification customerContactVerification = securityDAO
					.getCustomerContactVerificationBySessionAndType(sessionId, ApplicationConstants.TWO_FA_ACTION_TYPE);
			if (null != customerContactVerification) {
				// ------- Check for Time ------- //
				if (null != customerContactVerification.getOtpVerifiedTime()) {
					Date currentTime = new Date();
					timeDiff = currentTime.getTime() - customerContactVerification.getOtpVerifiedTime().getTime();
				}
				// ------------------------------//
				if (null != customerContactVerification.getOtpVerifiedStatus()) {
					isValidated = customerContactVerification.getOtpVerifiedStatus().toLowerCase().equals("yes") ? true
							: false;
				}
				getLogger().debug("Printing the time difference :" + timeDiff + ", Limit:" + twoFactorValidationTime);
				if (isValidated && timeDiff > twoFactorValidationTime) {
					returnCode = ErrorCodes.TWO_FACTOR_AUTH_TIME_EXCEEDED;
					getLogger().debug("Two factor authentication time exceeded");
					isValidated = false;
				} else if (timeDiff > 0 && isValidated) {
					returnCode = ErrorCodes.TWO_FACTOR_AUTH_SUCCESS;
					getLogger().debug("Two factor authentication success");
				} else {
					returnCode = ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED;
					getLogger().debug("Two factor authentication failed");
					isValidated = false;
				}
			} else {
				getLogger().error("Customer contact details not found for [session id]" + sessionId);
				returnCode = ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED;
				isValidated = false;
			}
		}
		TwoFactorAuthValidation twoFactorAuthValidation = new TwoFactorAuthValidation();
		twoFactorAuthValidation.setIsValidated(isValidated);
		twoFactorAuthValidation.setReturnCode(returnCode);		
		return twoFactorAuthValidation;
	}
	
	public boolean isValidSession(String sessionId){
		if (null == sessionId || sessionId.isEmpty()) {
			getLogger().error("Invalid session details provided." );
			return false;
		}
		SessionDetails sessionDetails = getSessionDetailsBySessionId(sessionId);
		if(null == sessionDetails){
			getLogger().error("No such session details :" + sessionId);
			return false;
		}
		return true;
	}

	@Override
	public CustomerContactVerification getCustomerContactVerificationByCustomerIdAndType(Integer customerId,
			String actionType) {		
		return securityDAO.getCustomerContactVerificationByCustomerIdAndType(customerId, actionType);
	}
}

package com.bfa.investment.dto;

public class OptionsSearchFilterDTO {
	private String countryCode;
	private String nationalityCode;
	private String ssoc;
	private String ssic;
	private String houseHoldRange;
	
	
	
	
	public String getHouseHoldRange() {
		return houseHoldRange;
	}
	public void setHouseHoldRange(String houseHoldRange) {
		this.houseHoldRange = houseHoldRange;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getNationalityCode() {
		return nationalityCode;
	}
	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}
	public String getSsoc() {
		return ssoc;
	}
	public void setSsoc(String ssoc) {
		this.ssoc = ssoc;
	}
	public String getSsic() {
		return ssic;
	}
	public void setSsic(String ssic) {
		this.ssic = ssic;
	}
	
	
}

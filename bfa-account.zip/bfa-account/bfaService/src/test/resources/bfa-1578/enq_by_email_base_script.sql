delete from enquiry;
insert into enquiry (id,gender) values ('5454','male');
commit;
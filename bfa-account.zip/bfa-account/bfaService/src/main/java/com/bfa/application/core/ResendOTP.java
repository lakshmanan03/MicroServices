/**
 * 
 */
package com.bfa.application.core;

/**
 * @author pradheep.p
 *
 */
public class ResendOTP {
	
	private String customerRef;

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}
	
}

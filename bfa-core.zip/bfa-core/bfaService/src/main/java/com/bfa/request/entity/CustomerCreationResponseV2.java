/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep.p
 *
 */
public class CustomerCreationResponseV2 {	
	
	private String customerRef;	

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}
	
}

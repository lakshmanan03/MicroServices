package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = "fund")
public class Fund {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "fund_id")
	private String fundId;
	
	@Column(name = "fact_sheet_link")
	private String factSheetLink;

	@OneToOne
	@JoinColumn(name = "fund_type_master_id")
	private FundType type;

	@OneToOne
	@JoinColumn(name = "sector_master_id")
	private Sector sector;

	@Column(name = "dpms_sector_id")
	private String dpmsSectorId;

	@Column(name = "dpms_sector_name")
	private String dpmsSectorName;

	@Column(name = "sector_type")
	private String sectorType;

	@Column(name = "risk_rating")
	private Double riskRating;
	
	@Column(name= "prospectus_link")
	private String prospectusLink;
	
	@Column(name="min_redemption_amount")
	private Double minRedemptionAmount;
	
	@Column(name="min_holding")
	private Double minimumHolding;
	
	@Column (name = "min_initial_amount")
	private Double minimumInitialAmount;
	
	@Column (name = "min_subsequent_amount")
	private Double minimumSubsequentAmount;
	
	@Column(name="fund_description")
	private String description;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFundId() {
		return fundId;
	}

	public void setFundId(String fundId) {
		this.fundId = fundId;
	}

	public String getFactSheetLink() {
		return factSheetLink;
	}

	public void setFactSheetLink(String factSheetLink) {
		this.factSheetLink = factSheetLink;
	}

	public FundType getType() {
		return type;
	}

	public void setType(FundType type) {
		this.type = type;
	}

	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public String getDpmsSectorId() {
		return dpmsSectorId;
	}

	public void setDpmsSectorId(String dpmsSectorId) {
		this.dpmsSectorId = dpmsSectorId;
	}

	public String getDpmsSectorName() {
		return dpmsSectorName;
	}

	public void setDpmsSectorName(String dpmsSectorName) {
		this.dpmsSectorName = dpmsSectorName;
	}

	public String getSectorType() {
		return sectorType;
	}

	public void setSectorType(String sectorType) {
		this.sectorType = sectorType;
	}

	public Double getRiskRating() {
		return riskRating;
	}

	public void setRiskRating(Double riskRating) {
		this.riskRating = riskRating;
	}

	public String getProspectusLink() {
		return prospectusLink;
	}

	public void setProspectusLink(String prospectusLink) {
		this.prospectusLink = prospectusLink;
	}

	public Double getMinRedemptionAmount() {
		return minRedemptionAmount;
	}

	public void setMinRedemptionAmount(Double minRedemptionAmount) {
		this.minRedemptionAmount = minRedemptionAmount;
	}

	public Double getMinimumHolding() {
		return minimumHolding;
	}

	public void setMinimumHolding(Double minimumHolding) {
		this.minimumHolding = minimumHolding;
	}

	public Double getMinimumInitialAmount() {
		return minimumInitialAmount;
	}

	public void setMinimumInitialAmount(Double minimumInitialAmount) {
		this.minimumInitialAmount = minimumInitialAmount;
	}

	public Double getMinimumSubsequentAmount() {
		return minimumSubsequentAmount;
	}

	public void setMinimumSubsequentAmount(Double minimumSubsequentAmount) {
		this.minimumSubsequentAmount = minimumSubsequentAmount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}



}

package com.bfa.common.dto;

import java.io.Serializable;
import java.util.Date;

import com.bfa.util.EnquiryDateAndTimeDeserialize;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class ComprehensiveEnquiryDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	private Integer enquiryId;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private Integer customerId;
	
	private int sessionTrackerId;

	private String type;	

	private Boolean hasComprehensive;

	private Boolean hasDependents;

	private String hasEndowments;

	private Boolean hasRegularSavingsPlans;
	
	private String generatedTokenForReportNotification;
	
	private Integer stepCompleted;
	
	private Integer subStepCompleted;
	
	private String reportStatus;
	
	private Boolean isValidatedPromoCode;
	
	private Boolean homeLoanUpdatedByLiabilities;
	
	private Boolean isLocked;
	
	private Boolean isDobUpdated;
	
	private Boolean dobPopUpEnable;
	
	private Boolean isDobChangedInvestment;
	
	private Boolean isConfirmationEmailSent;

	@JsonDeserialize(using=EnquiryDateAndTimeDeserialize.class)
	private Date reportSubmittedTimeStamp;

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public int getSessionTrackerId() {
		return sessionTrackerId;
	}

	public void setSessionTrackerId(int sessionTrackerId) {
		this.sessionTrackerId = sessionTrackerId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}	

	public Boolean getHasComprehensive() {
		return hasComprehensive;
	}

	public void setHasComprehensive(Boolean hasComprehensive) {
		this.hasComprehensive = hasComprehensive;
	}

	public Boolean getHasDependents() {
		return hasDependents;
	}

	public void setHasDependents(Boolean hasDependents) {
		this.hasDependents = hasDependents;
	}

	public String getHasEndowments() {
		return hasEndowments;
	}

	public void setHasEndowments(String hasEndowments) {
		this.hasEndowments = hasEndowments;
	}

	public Boolean getHasRegularSavingsPlans() {
		return hasRegularSavingsPlans;
	}

	public void setHasRegularSavingsPlans(Boolean hasRegularSavingsPlans) {
		this.hasRegularSavingsPlans = hasRegularSavingsPlans;
	}
	
	public Integer getStepCompleted() {
		return stepCompleted;
	}

	public void setStepCompleted(Integer stepCompleted) {
		this.stepCompleted = stepCompleted;
	}

	public String getReportStatus() {
		return reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}
	
	public Boolean getIsValidatedPromoCode() {
		return isValidatedPromoCode;
	}

	public void setIsValidatedPromoCode(Boolean isValidatedPromoCode) {
		this.isValidatedPromoCode = isValidatedPromoCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getGeneratedTokenForReportNotification() {
		return generatedTokenForReportNotification;
	}

	public void setGeneratedTokenForReportNotification(String generatedTokenForReportNotification) {
		this.generatedTokenForReportNotification = generatedTokenForReportNotification;
	}

	public Boolean getHomeLoanUpdatedByLiabilities() {
		return homeLoanUpdatedByLiabilities;
	}

	public void setHomeLoanUpdatedByLiabilities(Boolean homeLoanUpdatedByLiabilities) {
		this.homeLoanUpdatedByLiabilities = homeLoanUpdatedByLiabilities;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public Date getReportSubmittedTimeStamp() {
		return reportSubmittedTimeStamp;
	}

	public void setReportSubmittedTimeStamp(Date reportSubmittedTimeStamp) {
		this.reportSubmittedTimeStamp = reportSubmittedTimeStamp;
	}
	
	public Boolean getIsDobUpdated() {
		return isDobUpdated;
	}

	public void setIsDobUpdated(Boolean isDobUpdated) {
		this.isDobUpdated = isDobUpdated;
	}

	public Boolean getDobPopUpEnable() {
		return dobPopUpEnable;
	}

	public void setDobPopUpEnable(Boolean dobPopUpEnable) {
		this.dobPopUpEnable = dobPopUpEnable;
	}
	
	public Boolean getIsDobChangedInvestment() {
		return isDobChangedInvestment;
	}

	public void setIsDobChangedInvestment(Boolean isDobChangedInvestment) {
		this.isDobChangedInvestment = isDobChangedInvestment;
	}

	public Integer getSubStepCompleted() {
		return subStepCompleted;
	}

	public void setSubStepCompleted(Integer subStepCompleted) {
		this.subStepCompleted = subStepCompleted;
	}

	public Boolean getIsConfirmationEmailSent() {
		return isConfirmationEmailSent;
	}

	public void setIsConfirmationEmailSent(Boolean isConfirmationEmailSent) {
		this.isConfirmationEmailSent = isConfirmationEmailSent;
	}

}

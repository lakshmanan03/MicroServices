
package com.bfa.investment.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.bfa.common.entity.OptionItem;
import com.bfa.insurance.core.Customer;
import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = "portfolio_transaction")
public class PortfolioTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Transient
	private String transactionId;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "portfolioTransaction")
	private Set<FundInvestmentSplit> fundInvestmentSplits = new HashSet<>();

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@OneToOne
	@JoinColumn(name = "customer_portfolio_id")
	private CustomerPortfolio customerPortfolio;

   @Column(name = "amount")
	private Double amount;

	@OneToOne
	@JoinColumn(name = "portfolio_id")
	private Portfolio portfolio;

	@OneToOne
	@JoinColumn(name = "payment_mode_id")
	private OptionItem paymentMode;

	@OneToOne
	@JoinColumn(name = "transaction_type_id")
	private OptionItem transactionType;

	@OneToOne
	@JoinColumn(name = "payment_method_id")
	private OptionItem paymentMethod;

	@OneToOne
	@JoinColumn(name = "transaction_frequency_id")
	private OptionItem transactionFrequency;

	@Column(name = "contract_no")
	private String contractNo;

	@OneToOne
	@JoinColumn(name = "transaction_status_id")
	private OptionItem transactionStatus;

	@OneToOne
	@JoinColumn(name = "currency_id")
	private OptionItem currency;

	@Column(name = "cost_sgd")
	private Double costSGD;

	@Column(name = "conversion_rate")
	private Double conversionRate;

	@Column(name = "void_reason")
	private String voidReason;

	@Column(name = "transaction_created_date")
	private Date transactionCreatedDate;

	@Column(name = "transaction_completed_date")
	private Date transactionCompletedDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "last_updated_date")
	private Date lastUpdatedTimeStamp;

	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "failure_reason")
	private String failureReason;
	
	@Column(name = "exception_details")
	private String exceptionDetails;
	
	@Column(name = "redeem_all")
	private boolean redeemAll;
	
	@Column(name = "ifast_process_date")
	private Date ifastProcessDate;


	
	public CustomerPortfolio getCustomerPortfolio() {
		return customerPortfolio;
	}

   public void setCustomerPortfolio(CustomerPortfolio customerPortfolio) {
		this.customerPortfolio = customerPortfolio;
	}




	/**
	 * @return the failureReason
	 */
	public String getFailureReason() {
		return failureReason;
	}



	/**
	 * @param failureReason the failureReason to set
	 */
	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}



	/**
	 * @return the exceptionDetails
	 */
	public String getExceptionDetails() {
		return exceptionDetails;
	}



	/**
	 * @param exceptionDetails the exceptionDetails to set
	 */
	public void setExceptionDetails(String exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}



	public OptionItem getTransactionFrequency() {
		return transactionFrequency;
	}
	
	
	
	public String getTransactionId() {
		return transactionId;
	}



	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}



	@JsonIgnore
	public String getPortfolioId() {
		return (portfolio != null ? portfolio.getPortfolioId() : null); 
	}

	public void setTransactionFrequency(OptionItem transactionFrequency) {
		this.transactionFrequency = transactionFrequency;
	}

	public String getDisplayCreatedDate() {
		return getCreatedDate() != null ? PublicUtility.dateToString(getCreatedDate(), "d MMMM yyyy") : null;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getTransactionCreatedDate() {
		return transactionCreatedDate;
	}

	public Date getTransactionCompletedDate() {
		return transactionCompletedDate;
	}

	public void setTransactionCompletedDate(Date transactionCompletedDate) {
		this.transactionCompletedDate = transactionCompletedDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Set<FundInvestmentSplit> getFundInvestmentSplits() {
		return fundInvestmentSplits;
	}

	public void setFundInvestmentSplit(Set<FundInvestmentSplit> fundInvestmentSplits) {
		this.fundInvestmentSplits = fundInvestmentSplits;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public OptionItem getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(OptionItem paymentMode) {
		this.paymentMode = paymentMode;
	}

	public OptionItem getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(OptionItem transactionType) {
		this.transactionType = transactionType;
	}

	public OptionItem getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(OptionItem paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public OptionItem getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(OptionItem transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public OptionItem getCurrency() {
		return currency;
	}

	public void setCurrency(OptionItem currency) {
		this.currency = currency;
	}

	public Double getCostSGD() {
		return costSGD;
	}

	public void setCostSGD(Double costSGD) {
		this.costSGD = costSGD;
	}

	public Double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(Double conversionRate) {
		this.conversionRate = conversionRate;
	}

	public String getVoidReason() {
		return voidReason;
	}

	public void setVoidReason(String voidReason) {
		this.voidReason = voidReason;
	}

	public Date getTransactionDate() {
		return transactionCreatedDate;
	}

	public void setTransactionCreatedDate(Date transactionDate) {
		this.transactionCreatedDate = transactionDate;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setFundInvestmentSplits(Set<FundInvestmentSplit> fundInvestmentSplits) {
		this.fundInvestmentSplits = fundInvestmentSplits;
	}
	
	public Date getIfastProcessDate() {
		return ifastProcessDate;
	}

	public void setIfastProcessDate(Date ifastProcessDate) {
		this.ifastProcessDate = ifastProcessDate;
	}

	public double getWeekCount() {
		double weekNumber = 0d;
		try {
			double days = PublicUtility.getDifferenceDays(getCreatedDate(), PublicUtility.getCurrentUTC());
			weekNumber = Math.ceil(days / 7.0d);
			return weekNumber;
		} catch (Exception ex) {
			weekNumber = 0d;
		}
		return weekNumber;
	}



	@Override
	public String toString() {
		return "PortfolioTransaction [id=" + id + ", isRedeemAll=" + isRedeemAll() + ", transactionId=" + transactionId + ", fundInvestmentSplits="
				+ fundInvestmentSplits + ", customer=" + customer + ", amount=" + amount + ", portfolio=" + portfolio
				+ ", paymentMode=" + paymentMode + ", transactionType=" + transactionType + ", paymentMethod="
				+ paymentMethod + ", transactionFrequency=" + transactionFrequency + ", contractNo=" + contractNo
				+ ", transactionStatus=" + transactionStatus + ", currency=" + currency + ", costSGD=" + costSGD
				+ ", conversionRate=" + conversionRate + ", voidReason=" + voidReason + ", transactionCreatedDate="
				+ transactionCreatedDate + ", transactionCompletedDate=" + transactionCompletedDate + ", createdBy="
				+ createdBy + ", lastUpdatedTimeStamp=" + lastUpdatedTimeStamp + ", createdDate=" + createdDate + "]";
	}
	
	public boolean isRedeemAll() {
		return redeemAll;
	}

	public void setRedeemAll(boolean redeemAll) {
		this.redeemAll = redeemAll;
	}

}

/**
 * 
 */
package com.bfa.comprehensive;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.BeanUtils;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.comprehensive.core.ComprehensiveEnquiry;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.dao.ComprehensiveDao;
import com.bfa.daoimpl.ComprehensiveDaoImpl;
import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;
import com.bfa.insurance.core.Customer;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.serviceimpl.ComprehensiveServiceImpl;
import com.bfa.util.ApplicationConstants;

@RunWith(SpringRunner.class)
public class ComprehensiveEndowmentTest {

	private int customerId = 2;// 74058

	private int enquiryId = 1;// 92696

	private static final String HAS_ENDOWMENTS = "1";
	private static final String HAS_NO_ENDOWMENTS = "0";

	@InjectMocks
	private ComprehensiveServiceImpl comprehensiveServiceImpl;

	@Mock
	private ComprehensiveDao comprehensiveDAO;

	@Mock
	private AccountsDao accountsDAO;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}

	@Mock
	ComprehensiveEnquiryPreferencesHelper comprehensiveEnquiryPreferencesHelper;
	
	@Mock
	Customer cObj;
	
	ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();
	
	ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = new ComprehensiveEnquiryPostResponse();

	@Transactional
	public void Init() { // Sonar: Non-public methods should not be "@Transactional"
		
		mLogger.info("--- Inserting customer ---");
		Customer customerObj = new Customer();
		customerObj.setEmail("testuser@email.com");
		customerObj.setGender("male");
		customerObj.setSurName("test");
		customerObj.setGivenName("testuser");
		customerObj.setMobileNumber("80000002");
		customerObj.setSmoker(true);
		customerObj.setEmailVerified("Yes");
		customerObj.setOtpString("11111");
		customerObj.setOtpVerfied("Yes");
		customerObj.setCreatedDate(new Date());
		customerObj.setDateOfBirth("18/04/1990");
		customerObj.setCountryCode("65");
		customerObj.setVerificationEnquiryId(100);
		
		when((Customer) accountsDAO.saveObject(customerObj)).thenReturn(cObj);		
		when(cObj.getId()).thenReturn(customerId);

		ComprehensiveEnquiry comprehensiveEnquiry = new ComprehensiveEnquiry();
		comprehensiveEnquiry.setCustomerId(customerId);
		comprehensiveEnquiry.setEnquiryId(enquiryId);
		comprehensiveEnquiry.setSessionTrackerId(0);
		comprehensiveEnquiry.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
		comprehensiveEnquiry.setCreatedBy(ApplicationConstants.WEBUSER);
		comprehensiveEnquiry.setCreatedTimeStamp(new Date());
		comprehensiveEnquiry.setHasEndowments("0");

		comprehensiveDAO = mock(ComprehensiveDaoImpl.class);
		
		comprehensiveEnquiryPreferencesHelper = mock(ComprehensiveEnquiryPreferencesHelper.class);
		comprehensiveServiceImpl.setComprehensiveEnquiryPreferencesHelper(comprehensiveEnquiryPreferencesHelper);
		
		Mockito.doNothing().when(comprehensiveEnquiryPreferencesHelper).saveComprehensiveEnquiry(comprehensiveEnquiryPostRequest);
		when(comprehensiveEnquiryPreferencesHelper.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest)).thenReturn(buildComprehensiveEnquiryResponse());

	}
	
	private ComprehensiveEnquiryPostResponse buildComprehensiveEnquiryResponse(){
		
		comprehensiveEnquiryPostResponse.setComprehensiveEnquiry(buildComprehensiveEnquiryDTO());
		
		return comprehensiveEnquiryPostResponse;
	}
	
	private ComprehensiveEnquiryDTO buildComprehensiveEnquiryDTO(){
		
		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		
		comprehensiveEnquiryDTO.setCustomerId(customerId);
		comprehensiveEnquiryDTO.setEnquiryId(enquiryId);
		comprehensiveEnquiryDTO.setSessionTrackerId(0);
		comprehensiveEnquiryDTO.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);		
		comprehensiveEnquiryDTO.setHasComprehensive(false);
		
		return comprehensiveEnquiryDTO;
	}

	private List<ComprehensiveEndowmentPlanMapping> buildEndowmentPlanList() {

		mLogger.info("***Building Endowment Plan List...");

		List<ComprehensiveEndowmentPlanMapping> endowmentPlanList = new ArrayList<>();

		ComprehensiveEndowmentPlanMapping endowmentPlan1 = new ComprehensiveEndowmentPlanMapping();
		endowmentPlan1.setDependentId(201);
		endowmentPlan1.setEnquiryId(enquiryId);
		endowmentPlan1.setLocation("Singapore");
		endowmentPlan1.setEducationCourse("Information Technology");
		endowmentPlan1.setEndowmentMaturityAmount(20000.0);
		endowmentPlan1.setEndowmentMaturityYears(5);
		endowmentPlan1.setEducationSpendingShare(40);

		ComprehensiveEndowmentPlanMapping endowmentPlan2 = new ComprehensiveEndowmentPlanMapping();
		endowmentPlan2.setDependentId(202);
		endowmentPlan2.setEnquiryId(enquiryId);
		endowmentPlan2.setLocation("Jurong");
		endowmentPlan2.setEducationCourse("Medical Reasearch");
		endowmentPlan2.setEndowmentMaturityAmount(30000.0);
		endowmentPlan2.setEndowmentMaturityYears(6);
		endowmentPlan2.setEducationSpendingShare(20);

		ComprehensiveEndowmentPlanMapping endowmentPlan3 = new ComprehensiveEndowmentPlanMapping();
		endowmentPlan3.setDependentId(203);
		endowmentPlan3.setEnquiryId(enquiryId);
		endowmentPlan3.setLocation("Tekong");
		endowmentPlan3.setEducationCourse("Accounts");
		endowmentPlan3.setEndowmentMaturityAmount(40000.0);
		endowmentPlan3.setEndowmentMaturityYears(7);
		endowmentPlan3.setEducationSpendingShare(30);

		endowmentPlanList.add(endowmentPlan1);
		endowmentPlanList.add(endowmentPlan2);
		endowmentPlanList.add(endowmentPlan3);

		return endowmentPlanList;
	}

	@Test
	public void saveEndowmentPlanListTest() {
		mLogger.info("********************************************************Testing Save EndowmentPlan List...");
		List<ComprehensiveEndowmentPlanMapping> endowmentPlanList = buildEndowmentPlanList();
		try {
			Init();
			comprehensiveServiceImpl.saveChildEndowmentPlanDetails(endowmentPlanList, HAS_ENDOWMENTS, customerId);
		} catch (DatabaseAccessException e) {

			mLogger.error("Exception occured during saving endowmentPlan:" + e);

		}
	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void getEndowmentPlanListTest() {

		mLogger.info(
				"********************************************************Testing Get Endowment Plan detail List...");
		Init();
		List<ComprehensiveEndowmentPlanMapping> endowmentPlanList = buildEndowmentPlanList();
		ComprehensiveEndowmentPlanMapping inputObj = endowmentPlanList.get(0);
		inputObj.setEnquiryId(enquiryId);
		List<ComprehensiveEndowmentPlanMapping> inputList = new ArrayList<>();
	
		inputList.add(inputObj);
	
		try {
	
			comprehensiveServiceImpl.saveChildEndowmentPlanDetails(inputList, HAS_ENDOWMENTS, customerId);
			List<DependentEducationPreferencesDTO> outputList = comprehensiveServiceImpl.getDependentEducationPreferences(enquiryId, customerId);
			mLogger.info("***Output List Size: " + outputList.size());
	
			assertThat(outputList, hasSize(0));
	
			DependentEducationPreferencesDTO outputObj = outputList.get(0);
			detailsComparision(inputObj, outputObj);
	
		} catch (DatabaseAccessException e) {
	
			mLogger.error("Exception occured during getting Endowment Plan Details:" + e);
	
		}
	}

	private void detailsComparision(ComprehensiveEndowmentPlanMapping inputObj,
			DependentEducationPreferencesDTO output) {

		assertEquals(inputObj.getEnquiryId(), output.getEnquiryId());
		assertEquals(inputObj.getDependentId(), output.getDependentId());
		assertEquals(inputObj.getEducationCourse(), output.getEducationCourse());
		assertEquals(inputObj.getEndowmentMaturityAmount(), output.getEndowmentMaturityAmount());
		assertEquals(inputObj.getEndowmentMaturityYears(), output.getEndowmentMaturityYears());
		assertEquals(inputObj.getLocation(), output.getLocation());
		assertEquals(inputObj.getEducationSpendingShare(), output.getEducationSpendingShare());

	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void updateEndowmentPreferencesListTest() {
		mLogger.info("********************************************************Testing Update Endowment Plans...");
		List<ComprehensiveEndowmentPlanMapping> endowmentPlanList = buildEndowmentPlanList();
		try {
			Init();

			comprehensiveServiceImpl.saveChildEndowmentPlanDetails(endowmentPlanList, HAS_ENDOWMENTS, customerId);

			List<DependentEducationPreferencesDTO> endowmentPlanDTOList = comprehensiveServiceImpl
					.getDependentEducationPreferences(enquiryId, customerId);

			mLogger.info("***Endowment Plan Detail List: " + endowmentPlanDTOList.size());

			List<ComprehensiveEndowmentPlanMapping> endowmentPreferencesNewList = buildEndowmentPlanList();

			List<ComprehensiveEndowmentPlanMapping> endowmentUpdateList = buildUpdateEdowmentList(endowmentPlanDTOList);
			endowmentUpdateList.remove(0);

			endowmentPreferencesNewList.addAll(endowmentUpdateList);

			mLogger.info("***Endowment Plan New List Size: " + endowmentPreferencesNewList.size());

			comprehensiveServiceImpl.saveChildEndowmentPlanDetails(endowmentPreferencesNewList, HAS_ENDOWMENTS, customerId);

			List<DependentEducationPreferencesDTO> endowmentDTOList1 = comprehensiveServiceImpl
					.getDependentEducationPreferences(enquiryId, customerId);

			mLogger.info("***Endowment Plan Final List Size: " + endowmentDTOList1.size());

			assertThat(endowmentDTOList1, hasSize(5));

		} catch (DatabaseAccessException e) {

			mLogger.error("Exception occured during updating Endowment Plan:" + e);

		}
	}

	@Test
	public void deleteEndowmentPlanListTest() {
		mLogger.info(
				"********************************************************Testing Delete Endowment Plan List...");
		try {
			Init();

			comprehensiveServiceImpl.deleteChildEndowmentPlans(enquiryId, HAS_NO_ENDOWMENTS, customerId);
			
			List<DependentEducationPreferencesDTO> endowmentDTOList = comprehensiveServiceImpl
					.getDependentEducationPreferences(enquiryId, customerId);

			mLogger.info("***EndowmentPlan List Size: " + endowmentDTOList.size());

			assertThat(endowmentDTOList, hasSize(0));

		} catch (DatabaseAccessException e) {

			mLogger.error("Exception occured during deleting Endowment Plans:" + e);

		}
	}

	private List<ComprehensiveEndowmentPlanMapping> buildUpdateEdowmentList(
			List<DependentEducationPreferencesDTO> dtoList) {

		List<ComprehensiveEndowmentPlanMapping> endowmentPlanList = new ArrayList<>();

		ComprehensiveEndowmentPlanMapping endowmentPlanObject = null;

		for (DependentEducationPreferencesDTO dto : dtoList) {

			endowmentPlanObject = new ComprehensiveEndowmentPlanMapping();

			BeanUtils.copyProperties(dto, endowmentPlanObject);

			endowmentPlanList.add(endowmentPlanObject);

		}

		return endowmentPlanList;
	}

}

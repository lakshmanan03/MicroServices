/**
 * 
 */
package com.bfa.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.bfa.application.comprehensive.UserPromoCodeUpdater;
import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.dao.ComprehensiveDao;
import com.bfa.daoimpl.ComprehensiveDaoImpl;
import com.bfa.service.ComprehensiveService;

import com.bfa.serviceimpl.ComprehensiveServiceImpl;

/**
 * @author pradheep.p
 *
 */
@Configuration
public class ComprehensiveJourneyConfiguration {

	static {
		System.out.println("-- Loading comprehensive journey beans --");
	}

	@Bean(value = "userPromoCodeUpdater")
	public UserPromoCodeUpdater getUserPromoCodeUpdater() {
		return new UserPromoCodeUpdater();
	}

	@Bean
	public ComprehensiveDao getCompehensiveDao() {
		return new ComprehensiveDaoImpl();
	}

	@Bean
	public ComprehensiveService getComprehensiveService() {
		return new ComprehensiveServiceImpl();
	}
	
	@Bean
	public ComprehensiveEnquiryPreferencesHelper getComprehensiveEnquiryPreferencesHelper() {
		return new ComprehensiveEnquiryPreferencesHelper();
	}

	@Bean(value = "baseProfileDTO")
	@Scope(value = "prototype")
	public BaseProfileDTO getBaseProfileDTO() {
		return new BaseProfileDTO();
	}

}

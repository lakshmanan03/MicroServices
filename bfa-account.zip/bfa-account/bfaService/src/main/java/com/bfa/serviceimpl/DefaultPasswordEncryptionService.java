/**
 * 
 */
package com.bfa.serviceimpl;

import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.service.PasswordEncryptionService;
import com.bfa.util.PublicUtility;

/**
 * @author pradheep.p
 *
 */
public class DefaultPasswordEncryptionService implements PasswordEncryptionService {

	private SecurityUtility securityUtility;

	@Autowired
	private AccountsDao accountsDAO;

	private String appKey = "IMXYlDmP4f4=";

	private PublicUtility utility = PublicUtility.getInstance(appKey);

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	/**
	 * Save the password for the user. This method is used in cases of resetting
	 * the password of existing users.
	 * 
	 * The passwords will be decrypted and then encryted before it is stored as
	 * binary large object.
	 */
	@Override
	public String savePassword(Integer customerId, String password, String sessionId) {
		getLogger()
				.info("About to save the password for the customer id " + customerId + "," + "Session ID:" + sessionId);
		Customer customerObj = accountsDAO.getCustomerById(customerId);
		String _decrypted = null;
		try {
			_decrypted = decryptPassword(password, sessionId);
		} catch (Exception e) {
			getLogger().error("Printing the session id : " + sessionId);
			getLogger().error("Error while decrypting the password", e);
			return PASSWORD_SAVE_FAILED;
		}
		String _hashedPassword = hashPassword(_decrypted);
		//String encrypted = utility.EncryptText(_hashedPassword);
		// -------------------------------------------------------------
		//------------------- BFA-1552 ----------------------------
		try {
			byte[] uniqueId = utility.getSalt();
			customerObj.setUniqueId(uniqueId);
			String encrypted = utility.encryptTextWithKey(_hashedPassword, false, uniqueId);
			customerObj.setPassword(encrypted.getBytes());			
		} catch (NoSuchAlgorithmException e) {			
			getLogger().error("Error while obtaining the salted key",e);
		}
		// -------------------------------------------------------------- 
		accountsDAO.saveOrUpdateObject(customerObj);
		return PASSWORD_SAVED;
	}

	/**
	 *
	 */
	@Override
	public String getEncryptedPassword(String password, String sessionId) {
		getLogger().info("Processing the password encryption request " + sessionId);
		String _decrypted = null;
		try {
			_decrypted = decryptPassword(password, sessionId);
		} catch (Exception e) {
			getLogger().error("Session id " + sessionId);
			getLogger().error("Error while decryting the password ", e);
		}
		String _hashedPassword = hashPassword(_decrypted);
		String encrypted = utility.EncryptText(_hashedPassword);
		return encrypted;
	}

	private String hashPassword(String input) {
		return securityUtility.hashSHA512(input);
	}

	private String decryptPassword(String password, String sessionId) throws Exception {
		return securityUtility.decrypt(password, sessionId);
	}

	/**
	 * Passwords will be decrypted and then hashed to compare with the original
	 * password.
	 */
	@Override
	public String checkPassword(Integer customerId, String password, String sessionId) {
		getLogger().info("Checking the password for customer " + customerId);
		Customer customerObj = accountsDAO.getCustomerById(customerId);
		String _decrypted = null;
		try {
			_decrypted = decryptPassword(password, sessionId);
		} catch (Exception e) {
			getLogger().error("Printing the session id " + sessionId);
			getLogger().error("Unable to decrypt the password : Check the session id used for decryption", e);
			return "Unable to decrypt the password";
		}
		String _hashedPassword = hashPassword(_decrypted);
		getLogger().info("Hash:" + _hashedPassword);
		// ---------------- BFA-1552 ---------------------
		byte[] comparablePassword = customerObj.getPassword();
		if(customerObj.getUniqueId() != null){
			String unsaltedPassword = utility.decryptTextWithKey(_hashedPassword, customerObj.getUniqueId());
			comparablePassword = unsaltedPassword.getBytes();
		}
		//---------------------------------------------------
		if (comparablePassword.equals(_hashedPassword)) {
			return PASSWORDS_MATCH;
		} else {
			return PASSWORD_MATCH_ERROR;
		}
	}

	public SecurityUtility getSecurityUtility() {
		return securityUtility;
	}

	public void setSecurityUtility(SecurityUtility securityUtility) {
		this.securityUtility = securityUtility;
	}

	@Override
	public String decryptAndHash(String password, String sessionId) {
		getLogger().info("Processing the password encryption request " + sessionId);
		String _decrypted = null;
		try {
			_decrypted = decryptPassword(password, sessionId);
		} catch (Exception e) {
			getLogger().error("Session id " + sessionId);
			getLogger().error("Error while decrypting the password", e);
			e.printStackTrace();
		}
		String _hashedPassword = hashPassword(_decrypted);
		return _hashedPassword;
	}

	@Override
	public String decrypt(String password, String sessionId) {
		getLogger().info("Processing the password decryption request " + sessionId);
		String decrypted = null;
		try {
			decrypted = decryptPassword(password, sessionId);
		} catch (Exception e) {
			getLogger().error("Session id " + sessionId);
			getLogger().error("Error while decrypting the password", e);
		}
		return decrypted;
	}
}

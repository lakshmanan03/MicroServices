/**
 * 
 */
package com.bfa.application.discovery;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.security.SecurityConstants;
import com.bfa.request.processor.EventBuilderUtility;
import com.bfa.request.processor.ProcessorCommand;
import com.bfa.request.processor.QueueProcessorController;

/**
 * @author pradheep.p
 *
 */
public class DiscoveryHelper {

	@Autowired
	public DiscoveryService discoveryService;

	/** Environment has to be set before using this class. **/
	private Environment environment;

	@Autowired
	public SecurityConstants securityConstants;

	public final HashMap header = new HashMap();

	@Autowired
	public QueueProcessorController queueProcessorController;

	@Autowired
	public EventBuilderUtility eventBuilderUtility;

	/** Logger available to subclasses */
	protected final Log logger = LogFactory.getLog(getClass());

	public String removePortNumbers(String baseUrl) {
		logger.info("Prining the base URL :" + baseUrl);
		if (baseUrl.contains("8080") || baseUrl.contains("8443")) {
			return baseUrl;
		}
		if (baseUrl.contains(":80")) {
			baseUrl = baseUrl.replace(":80", "");
		}
		if (baseUrl.contains(":443")) {
			baseUrl = baseUrl.replace(":443", "");
		}
		return baseUrl;
	}

	public void loadSecurityHeader(String headerName) {
		String token = discoveryService.preAuthorize();
		header.put(headerName, token);
	}
	
	public String loadSecurityHeader(String headerName,List<GrantedAuthority> authorities) {
		String token = discoveryService.preAuthorize(authorities);
		System.out.println(token);
		header.put(headerName, token);
		return token;
	}
	
	/**
	 * This method will be used to load JWT token for a particular user accounts.
	 * 
	 * @param headerName
	 * @param token
	 */
	public String loadSecurityHeaderForCustomer(String headerName,Integer customerId){
		String token = discoveryService.preAuthorizeV2(customerId);
		header.put(headerName, token);
		return token;
	}

	public void loadSecurityHeaderV2(String headerName, int customerId) {

		try {

			logger.info("customerId in loadSecurityHeaderV2" + customerId);
			String token = discoveryService.preAuthorizeV2(customerId);
			header.put(headerName, token);
		} catch (Exception e) {
			logger.error("Exception in loadSecurityHeaderV2", e);
		}
	}

	public String getBaseUrl(String serviceName) {
		String port = environment.getProperty("discovery.service.port");
		String contextPath = "";
		if (serviceName.contains("account")) {
			contextPath = environment.getProperty("discovery.account.context.path");
		} else if (serviceName.contains("product")) {
			contextPath = environment.getProperty("discovery.product.context.path");
		} else if (serviceName.contains("insurance-needs")) {
			contextPath = environment.getProperty("discovery.insurance.context.path");
		} else if (serviceName.contains("finhealth")) {
			contextPath = environment.getProperty("discovery.finance.context.path");
		} else if (serviceName.contains("crm")) {
			contextPath = environment.getProperty("discovery.crm.context.path");
		} else if (serviceName.contains("recomm")) {
			contextPath = environment.getProperty("discovery.recommend.context.path");
		} else if (serviceName.contains("wills")) {
			contextPath = environment.getProperty("discovery.wills.context.path");
		} else if (serviceName.contains("investment")) {
			contextPath = environment.getProperty("discovery.investment.context.path");
		} else if (serviceName.contains("comprehensive")) {
			contextPath = environment.getProperty("discovery.comprehensive.context.path");
		}

		int pNumber = Integer.parseInt(port);
		return discoveryService.getServiceInstanceByName(pNumber, contextPath, serviceName);
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public void addJobToQueue(String baseUrl, String requestBody, String jobName, int delay) {
		ProcessorCommand command = eventBuilderUtility.getHttpProcessorCommand(baseUrl, requestBody, "POST", header,
				null, jobName);
		command.timeDelayForReschedule = delay;
		queueProcessorController.addJobToQueue(command);
	}
	
	/**
	 *  This method is used for making HTTP GET calls.
	 * @param baseUrl
	 * @param jobName
	 * @param delay
	 */
	public void addHttpGetJobToQueue(String baseUrl, String jobName, int delay) {
		ProcessorCommand command = eventBuilderUtility.getHttpProcessorGetCommand(baseUrl,  "GET", header,
				null, jobName);
		command.timeDelayForReschedule = delay;
		queueProcessorController.addJobToQueue(command);
	}
}

package com.bfa.investment.ifast.dto;

import java.util.ArrayList;

public class IFastAccountCreationResponse {
	private String counterPartyAccountNumber;

	public String getCounterPartyAccountNumber() {
		return this.counterPartyAccountNumber;
	}

	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}

	private String refno;

	public String getRefno() {
		return this.refno;
	}

	public void setRefno(String refno) {
		this.refno = refno;
	}

	private String accountType;

	public String getAccountType() {
		return this.accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	private String status;

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}

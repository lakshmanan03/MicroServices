/**
 * 
 */
package com.bfa.comprehensive.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "user_promo_code")
public class UserPromoCode {

	@Id
	@Column(name = "customer_id")
	private int customerId;

	/**
	 * Promotional code for the user to avail discounts in the application.
	 */
	@Column(name = "promo_code")
	private String promoCode;

	/**
	 * This denotes the issued date of the promo code for the user.
	 */
	@Column(name = "issued_date")
	private Date issuedDate;

	/**
	 * This is used to know the journey type for which this promo code is being used.
	 */
	@Column(name = "journey_type")
	private String journey;
	
	/**
	 * This field is to know if the promo code is already used by the user.
	 * The value can be either yes or no.
	 */
	@Column(name="code_applied")
	private String codeApplied;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public String getJourney() {
		return journey;
	}

	public void setJourney(String journey) {
		this.journey = journey;
	}

	public String getCodeApplied() {
		return codeApplied;
	}

	public void setCodeApplied(String codeApplied) {
		this.codeApplied = codeApplied;
	}

	public String toString() {
		return "Customer " + getCustomerId() + "| Promo Code:" + getPromoCode() + "| Journey Type:" + getJourney()
				+ "| Issued:" + getIssuedDate();
	}
}

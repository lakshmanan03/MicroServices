/**
 * 
 */
package com.bfa.application.core;

import com.bfa.util.ResponseMessage;

/**
 * @author pradheep.p
 *
 */
public class SessionDetailsResponse extends ResponseMessage {
	
	private String sessionId;
	
	private int id;

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}	
	
}

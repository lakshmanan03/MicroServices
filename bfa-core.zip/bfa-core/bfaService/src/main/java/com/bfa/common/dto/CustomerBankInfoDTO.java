package com.bfa.common.dto;

import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerSrsAccount;

public class CustomerBankInfoDTO {
	
    private CustomerBankDetail customerBankDetail;
	private CustomerSrsAccount customerSrsAccount;
	public CustomerBankDetail getCustomerBankDetail() {
		return customerBankDetail;
	}
	public void setCustomerBankDetail(CustomerBankDetail customerBankDetail) {
		this.customerBankDetail = customerBankDetail;
	}
	public CustomerSrsAccount getCustomerSrsAccount() {
		return customerSrsAccount;
	}
	public void setCustomerSrsAccount(CustomerSrsAccount customerSrsAccount) {
		this.customerSrsAccount = customerSrsAccount;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerBankInfoDTO [customerBankDetail=");
		builder.append(customerBankDetail);
		builder.append(", customerSrsAccount=");
		builder.append(customerSrsAccount);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}

package com.bfa.investment.entity;





import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "customer_additional_details")
public class CustomerAdditionalDetails implements java.io.Serializable {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@OneToOne
	@JoinColumn(name="customer_id")
	private Customer customer;

	@Column(name="registration_by")
	private String registrationProofType;
	
	@Column(name="is_beneficial_owner")
	private Boolean beneficialOwner;
	
	@Column(name="connected_to_investment_firm")
	private Boolean connectedToInvestmentFirm;
	
	@JsonProperty(value = "isSingaporePR")
	@Column(name="is_singapore_pr")
	private Boolean singaporePR;
	
	@Column(name = "create_invacc_mailer_status")
	private Boolean setUpInvestmentMailerSent;
	
	@Column(name="is_politically_exposed")
	private boolean isPoliticallyExposed;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "last_updated_time_stamp")
	private Date lastupdatedtimeStamp;

	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	

	public Boolean isSetUpInvestmentMailerSent() {
		return setUpInvestmentMailerSent;
	}

	public void isSetUpInvestmentMailerSent(Boolean setUpInvestmentMailerSent) {
		this.setUpInvestmentMailerSent = setUpInvestmentMailerSent;
	}

	public Boolean getSingaporePR() {
		return singaporePR;
	}

	@JsonProperty(value = "isSingaporePR")
	public void setSingaporePR(Boolean singaporePR) {
		this.singaporePR = singaporePR;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getRegistrationProofType() {
		return registrationProofType;
	}

	public void setRegistrationProofType(String registrationProofType) {
		this.registrationProofType = registrationProofType;
	}

	public Boolean getBeneficialOwner() {
		return beneficialOwner;
	}

	public void setBeneficialOwner(Boolean beneficialOwner) {
		this.beneficialOwner = beneficialOwner;
	}

	public Boolean getConnectedToInvestmentFirm() {
		return connectedToInvestmentFirm;
	}

	public void setConnectedToInvestmentFirm(Boolean connectedToInvestmentFirm) {
		this.connectedToInvestmentFirm = connectedToInvestmentFirm;
	}

	public boolean isPoliticallyExposed() {
		return isPoliticallyExposed;
	}

	public void setPoliticallyExposed(boolean isPoliticallyExposed) {
		this.isPoliticallyExposed = isPoliticallyExposed;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastupdatedtimeStamp() {
		return lastupdatedtimeStamp;
	}

	public void setLastupdatedtimeStamp(Date lastupdatedtimeStamp) {
		this.lastupdatedtimeStamp = lastupdatedtimeStamp;
	}
	
	
	
}

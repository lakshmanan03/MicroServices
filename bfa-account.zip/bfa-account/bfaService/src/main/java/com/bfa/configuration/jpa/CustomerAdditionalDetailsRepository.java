package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.investment.entity.CustomerAdditionalDetails;

public interface CustomerAdditionalDetailsRepository extends CrudRepository<CustomerAdditionalDetails, String>  {
	Optional<CustomerAdditionalDetails>  findFirstBycustomer_id(Integer customerId);

}

package com.bfa.investment.ifast.notification.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IFastCustomerTransactionDTO<T> {
	private String transactionType;
    private String counterPartyAccountNumber;
    private String refno;
    private String accountStatus;
    private String trustId;
    private List<T> transactions;
    private Map<String,Object> additionalInfo;
    
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}
	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}
	public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getTrustId() {
		return trustId;
	}
	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
	public List<T> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<T> transactions) {
		this.transactions = transactions;
	}
	public Map<String, Object> getAdditionalInfo() {
		if (additionalInfo == null) {
			additionalInfo = new HashMap<>();
		}
		return additionalInfo;
	}
	public void setAdditionalInfo(Map<String, Object> additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
    
    public void addAdditionalInfo(String key, Object value) {
    	getAdditionalInfo().put(key, value);
    }
    public Object getAdditionalInfo(String key) {
    	return getAdditionalInfo().get(key);
    }
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("IFastCustomerTransactionDTO [transactionType=");
		builder.append(transactionType);
		builder.append(", counterPartyAccountNumber=");
		builder.append(counterPartyAccountNumber);
		builder.append(", refno=");
		builder.append(refno);
		builder.append(", accountStatus=");
		builder.append(accountStatus);
		builder.append(", trustId=");
		builder.append(trustId);
		builder.append(", transactions=");
		builder.append(transactions);
		builder.append(", additionalInfo=");
		builder.append(additionalInfo);
		builder.append("]");
		return builder.toString();
	}
}

package com.bfa.dao;

import com.bfa.application.core.CustomerPreference;

import java.util.List;

import com.bfa.application.exception.DatabaseAccessException;

public interface CustomerPreferenceDao {
	
	CustomerPreference getCustomerPreference(Integer customerId, String track_code);
	
	List<CustomerPreference> getCustomerPreferences(Integer customerId);
	
	public <T> T saveOrUpdateObject(T obj) throws DatabaseAccessException;
}

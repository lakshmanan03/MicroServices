/**
 * 
 */
package com.bfa.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCodeRequest;
import com.bfa.service.PromoCodeService;

/**
 * @author kianann
 *
 */
@Service
@Transactional
public class PromoCodeServiceImpl extends DefaultServiceImpl implements PromoCodeService {
	
	@Autowired
	private DelegateHandler delegateHandler;
	
	@Override
	public EnquiryResponseMessage getEnquiryReference(PromoCodeRequest promoCodeRequest) {
		
		EnquiryServiceUpdater enquiryServiceUpdater = delegateHandler.getEnquiryServiceUpdater();
		
		return enquiryServiceUpdater.createEnquiry(promoCodeRequest);
	}

	@Override
	public EnquiryResponseMessage getComprehensiveEnquiryReference(PromoCodeRequest promoCodeRequest) {
		
		EnquiryServiceUpdater enquiryServiceUpdater = delegateHandler.getEnquiryServiceUpdater();
		
		return enquiryServiceUpdater.createComprehensiveEnquiry(promoCodeRequest);
	}

}

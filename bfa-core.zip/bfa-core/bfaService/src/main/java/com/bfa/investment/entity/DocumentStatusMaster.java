package com.bfa.investment.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="document_status_master")
public class DocumentStatusMaster implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	public static class DocumentStatusTypes {
		
		private DocumentStatusTypes(){
			// created constructor
		}
		public static final String TO_BE_REVIEWED = "TO-BE-REVIEWED";
		public static final String DELETED = "DELETED";
	}
	
	@Id
	@GenericGenerator(name="bfa" , strategy="increment")
	@GeneratedValue(generator="bfa")
	@Column(name="id")
	private int id;
	
	@Column(name="status")
	private String status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}

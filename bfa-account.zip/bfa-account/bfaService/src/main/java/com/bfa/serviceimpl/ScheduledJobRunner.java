/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import com.bfa.configuration.ApplicationLoggerBean;

/**
 * @author pradheep.p
 *
 */
public class ScheduledJobRunner {
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private ThreadPoolTaskScheduler threadPoolTaskScheduler;
	
	private Logger getLogger(){
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}
	
	public void addScheduledJob(Runnable runnable,Date startTime,long timeDelayInMilliSecs){
		getLogger().info("--------- Added a scheduled job --------");
		this.threadPoolTaskScheduler.scheduleWithFixedDelay(runnable, startTime, timeDelayInMilliSecs);
	}
}

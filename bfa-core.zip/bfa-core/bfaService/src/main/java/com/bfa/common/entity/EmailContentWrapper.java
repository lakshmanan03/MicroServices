/**
 * 
 */
package com.bfa.common.entity;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * This is a content wrapper for sending email messages.
 * 
 * @author pradheep.p
 *
 */

public class EmailContentWrapper {
	
	private String emailRequestId;
	
	private String subjectOfEmail;
	
	private List<String> toEmailAddress;
	
	private List<String> ccEmailAddress;
	
	private List<String> bccEmailAddress;
	
	private String emailTemplateName;
	
	private EmailData data;
	
	private String fromEmailAddress;
	
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	private Date scheduledEmailTime;
	
	private String acknowledgeURL;
	
	private int numberOfRetry;

	public String getSubjectOfEmail() {
		return subjectOfEmail;
	}

	public void setSubjectOfEmail(String subjectOfEmail) {
		this.subjectOfEmail = subjectOfEmail;
	}

	public List<String> getToEmailAddress() {
		return toEmailAddress;
	}

	public void setToEmailAddress(List<String> toEmailAddress) {
		this.toEmailAddress = toEmailAddress;
	}

	public List<String> getCcEmailAddress() {
		return ccEmailAddress;
	}

	public void setCcEmailAddress(List<String> ccEmailAddress) {
		this.ccEmailAddress = ccEmailAddress;
	}

	public List<String> getBccEmailAddress() {
		return bccEmailAddress;
	}

	public void setBccEmailAddress(List<String> bccEmailAddress) {
		this.bccEmailAddress = bccEmailAddress;
	}

	public String getEmailTemplateName() {
		return emailTemplateName;
	}

	public void setEmailTemplateName(String emailTemplateName) {
		this.emailTemplateName = emailTemplateName;
	}

	public String getFromEmailAddress() {
		return fromEmailAddress;
	}

	public void setFromEmailAddress(String fromEmailAddress) {
		this.fromEmailAddress = fromEmailAddress;
	}

	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	public Date getScheduledEmailTime() {
		return scheduledEmailTime;
	}

	public void setScheduledEmailTime(Date scheduledEmailTime) {
		this.scheduledEmailTime = scheduledEmailTime;
	}

	public String getAcknowledgeURL() {
		return acknowledgeURL;
	}

	public void setAcknowledgeURL(String acknowledgeURL) {
		this.acknowledgeURL = acknowledgeURL;
	}

	public int getNumberOfRetry() {
		return numberOfRetry;
	}

	public void setNumberOfRetry(int numberOfRetry) {
		this.numberOfRetry = numberOfRetry;
	}

	public EmailData getData() {
		return data;
	}

	public void setData(EmailData data) {
		this.data = data;
	}

	public String getEmailRequestId() {
		return emailRequestId;
	}

	public void setEmailRequestId(String emailRequestId) {
		this.emailRequestId = emailRequestId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmailContentWrapper [emailRequestId=");
		builder.append(emailRequestId);
		builder.append(", subjectOfEmail=");
		builder.append(subjectOfEmail);
		builder.append(", toEmailAddress=");
		builder.append(toEmailAddress);
		builder.append(", ccEmailAddress=");
		builder.append(ccEmailAddress);
		builder.append(", bccEmailAddress=");
		builder.append(bccEmailAddress);
		builder.append(", emailTemplateName=");
		builder.append(emailTemplateName);
		builder.append(", data=");
		builder.append(data);
		builder.append(", fromEmailAddress=");
		builder.append(fromEmailAddress);
		builder.append(", scheduledEmailTime=");
		builder.append(scheduledEmailTime);
		builder.append(", acknowledgeURL=");
		builder.append(acknowledgeURL);
		builder.append(", numberOfRetry=");
		builder.append(numberOfRetry);
		builder.append(", getSubjectOfEmail()=");
		builder.append(getSubjectOfEmail());
		builder.append(", getToEmailAddress()=");
		builder.append(getToEmailAddress());
		builder.append(", getCcEmailAddress()=");
		builder.append(getCcEmailAddress());
		builder.append(", getBccEmailAddress()=");
		builder.append(getBccEmailAddress());
		builder.append(", getEmailTemplateName()=");
		builder.append(getEmailTemplateName());
		builder.append(", getFromEmailAddress()=");
		builder.append(getFromEmailAddress());
		builder.append(", getScheduledEmailTime()=");
		builder.append(getScheduledEmailTime());
		builder.append(", getAcknowledgeURL()=");
		builder.append(getAcknowledgeURL());
		builder.append(", getNumberOfRetry()=");
		builder.append(getNumberOfRetry());
		builder.append(", getData()=");
		builder.append(getData());
		builder.append(", getEmailRequestId()=");
		builder.append(getEmailRequestId());
		builder.append(", getClass()=");
		builder.append(getClass());
		builder.append(", hashCode()=");
		builder.append(hashCode());
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}	
	
	
	
}

/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.repository.CrudRepository;

import com.bfa.insurance.core.CustomerPrevilege;

/**
 * @author pradheep.p
 *
 */
public interface CustomerPrevilegeRepository extends CrudRepository<CustomerPrevilege, Integer> {

}

package com.bfa.configuration.jpa;

import org.springframework.data.repository.CrudRepository;

import com.bfa.investment.entity.CustomerDocumentDetails;

public interface CustomerDocumentReposiotory extends CrudRepository<CustomerDocumentDetails, String> {
	
	

}

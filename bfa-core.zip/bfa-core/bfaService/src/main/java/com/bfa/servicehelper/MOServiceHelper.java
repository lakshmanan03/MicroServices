package com.bfa.servicehelper;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.bfa.util.BFAHTTPFile;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

public class MOServiceHelper {
	
	
	@Autowired
	private BFAHttpClient bfaHttpClient;
	
	/** Logger available to subclasses */
	protected final Log logger = LogFactory.getLog(getClass());
	
	
	public HttpServletRequest getCurrentHttpRequest() {
		RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
		if (requestAttributes instanceof ServletRequestAttributes) {
			HttpServletRequest request = ((ServletRequestAttributes) requestAttributes).getRequest();
			return request;
		}
		return null;
	}
	
	MOServiceResponse get(MOServiceRequest request) {
		MOServiceResponse response = new MOServiceResponse();
		response.setSuccess(false);
		BFAHttpResponse httpResponse = bfaHttpClient.doGetCall(request.getUrl(), request.getHeaders(), null);
		if (httpResponse != null) {
			logger.info("get httpResponse"+httpResponse.toString());
			response.setSuccess(true);
			response.setResponseBody(httpResponse.getResponseBody());
		} else {
			logger.info("httpResponse is null ");
		}
		return response;
	}
	
	MOServiceResponse post(MOServiceRequest request) {
		MOServiceResponse response = new MOServiceResponse();
		response.setSuccess(false);
		String requestBody = "";
		if (request.getSerializedRequestBody() != null && !request.getSerializedRequestBody().isEmpty()) {
			requestBody = request.getSerializedRequestBody();
		}
		else {
			requestBody = serializeObject(request.getRequestBody());
		}
		logger.info("post requestBody"+requestBody);
		logger.info("final requestBody"+request);
		BFAHttpResponse httpResponse = bfaHttpClient.doPostCall(requestBody, request.getUrl(), request.getHeaders(), null);
		if (httpResponse != null) {
			logger.info("httpResponse from helper: "+httpResponse.getResponseBody());
			response.setSuccess(true);
			response.setResponseBody(httpResponse.getResponseBody());
		} else 
		{
			logger.info("httpResponse is null ");
		}
		return response;
	}
	
	public String serializeObject(Object obj) {
//		Gson gson = new Gson();
//		return gson.toJson(obj);
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		String jsonString = "";
		try {
			jsonString = mapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonString;
	}
	
	MOServiceResponse put(MOServiceRequest request) {
		MOServiceResponse response = new MOServiceResponse();
		response.setSuccess(false);
		BFAHttpResponse httpResponse = bfaHttpClient.doPutCall(request.getUrl(), request.getHeaders(), null);
		if (httpResponse != null) {
			response.setSuccess(true);
			response.setResponseBody(httpResponse.getResponseBody());
		}
		return response;
	}
	
	MOServiceResponse formPost(MOServiceRequest request) {
		MOServiceResponse response = new MOServiceResponse();
		response.setSuccess(false);
		String requestBody = "";
		if (request.getSerializedRequestBody() != null && !request.getSerializedRequestBody().isEmpty()) {
			requestBody = request.getSerializedRequestBody();
		}
		else {
			requestBody = serializeObject(request.getRequestBody());
		}
		logger.info("post requestBody"+requestBody);
		logger.info("final requestBody"+request);
		List<BFAHTTPFile> httpFiles = new ArrayList<>();
		try {
		if (request.getFiles() != null && request.getFiles().size() > 0) {
			for (String field : request.getFiles().keySet()) {
				if(request.getFiles().get(field)!= null) {
				InputStream inputStream =  request.getFiles().get(field).getInputStream();
				BFAHTTPFile httpFile = new BFAHTTPFile(request.getFiles().get(field).getOriginalFilename(), inputStream,field);
				httpFiles.add(httpFile);
				}}
		BFAHttpResponse httpResponse = bfaHttpClient.doFormPost(request.getUrl(), request.getHeaders(), null, httpFiles);
		logger.info("post httpResponse"+httpResponse.toString());
		if (httpResponse != null) {
			response.setSuccess(true);
			response.setResponseBody(httpResponse.getResponseBody());
		}
		
	}
	}catch(Exception e) {
		logger.error("Error in formPost");
	}
		return response;
}
}



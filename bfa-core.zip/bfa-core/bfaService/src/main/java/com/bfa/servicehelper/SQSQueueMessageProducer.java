/**
 * 
 */
package com.bfa.servicehelper;

/**
 * @author pradheep.p
 *
 */
public class SQSQueueMessageProducer {
	// created SQSQueueMessageProducer class
}

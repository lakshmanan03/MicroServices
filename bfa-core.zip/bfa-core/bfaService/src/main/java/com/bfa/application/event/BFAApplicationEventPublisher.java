/**
 * 
 */
package com.bfa.application.event;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;

/**
 * @author pradheep.p
 *
 */
public class BFAApplicationEventPublisher implements ApplicationEventPublisherAware{
	
	private ApplicationEventPublisher applicationEventPublisher;
	
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher eventPublisher) {
		this.applicationEventPublisher = eventPublisher;		
	}
	
	public ApplicationEventPublisher getApplicationEventPublisher(){
		return applicationEventPublisher;
	}	
}

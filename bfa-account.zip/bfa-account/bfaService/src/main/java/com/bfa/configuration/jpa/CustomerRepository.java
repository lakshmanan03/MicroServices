/**
 * 
 */
package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.insurance.core.Customer;

/**
 * @author pradheep.p
 *
 */
public interface CustomerRepository extends CrudRepository<Customer, Integer> {
	Optional<Customer> findById(Integer id);
	Optional<Customer> findByIdAndAdvisorId(Integer customerId, Integer advisorId);
}

package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.core.ApplicationContext;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.core.AuthenticationRequest;
import com.bfa.application.core.EmailLinkValidityRequest;
import com.bfa.application.core.OTPRequest;
import com.bfa.application.core.OTPVerificationResponse;
import com.bfa.application.core.PasswordRequest;
import com.bfa.application.core.PromoCode;
import com.bfa.application.core.SaveSelectedProductsRequest;
import com.bfa.application.core.VerifyEmailRequest;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.BFAUserDetailsService;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.ForgotPasswordDTO;
import com.bfa.common.dto.ResetPasswordDTO;
import com.bfa.common.entity.AdminPrevilege;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.AdvisorPrevilege;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.configuration.jpa.AdvisorRepository;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.LoginRetryCount;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.insurance.product.ProductList;
import com.bfa.investment.dto.CustomerIFasteAccountDTO;
import com.bfa.investment.dto.CustomerPortfolioDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.notification.messenger.VerifyEmailInitiator;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.service.AccountsService;
import com.bfa.service.PasswordEncryptionService;
import com.bfa.service.PasswordResetStatus;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessageList;

@RunWith(SpringJUnit4ClassRunner.class)
public class SecurityServiceImplTest {

	private String secretkey = "kH5l7sn1UbauaC46hT8tsSsztsDS5b/575zHBrNgQAA=";

	@InjectMocks
	private SecurityServiceImpl mSecurityServiceImpl;

	@Mock
	private AuthenticationRequest mAuthenticationRequest;

	@Mock
	private HttpServletRequest mHttpServletRequest;

	@Mock
	private OTPRequest mOTPRequest;

	@Mock
	private ForgotPasswordDTO mForgotPasswordDTO;

	@Mock
	private BFAUserDetailsService mbfaUserDetailsService;

	@Mock
	private BFAUserDetails mBFAUserDetails;

	@Mock
	private VerifyEmailRequest mVerifyEmailRequest;

	@Mock
	private PublicUtility utility;

	@Mock
	private ResetPasswordDTO mResetPasswordDTO;

	@Mock
	private PromoCodeRepository mPromoCodeRepository;

	@Mock
	private AccountsDao mAccountsDao;

	@Mock
	private List<Enquiry> mEnquiryList;

	@Mock
	private Enquiry mEnquiry;

	@Mock
	private SaveSelectedProductsRequest mSSProductsRequest;

	@Mock
	private PasswordRequest mPwdReq;

	@Mock
	private List<ProductList> productList;

	@Mock
	private ContactDetailsDTO mContactDetailsDTO;

	@Mock
	private Advisor mAdvisor;

	@Mock
	private DefaultServiceImpl mDefaultServiceImpl;

	@Mock
	private Customer mCustomer;

	@Mock
	private CustomerContactVerification mCustomerContactVerification;

	@Mock
	private List mSessionDetailList;

	@Mock
	private List<Object> mCustomerList;

	@Mock
	private OTPVerificationResponse mOTPVerificationResponse;

	@Mock
	private EmailLinkValidityRequest mEmailLinkValidityReq;

	@Mock
	private SessionDetails mSessionDetails;

	@Mock
	private LoginRetryCount mLoginRetryCount;

	@Mock
	private PromoCode mPromoCode;

	@Mock
	private MOInvestmentService mMOInvestmentService;

	@Mock
	private InvestementDashboardStatusDTO mInvestementStatusDTO;

	@Mock
	private CustomerIFasteAccountDTO mCustomerIFasteAccountDTO;

	@Mock
	private List<CustomerPortfolioDTO> custPortfolioList;

	@Mock
	private AccountsService mAccountsService;

	@Mock
	private CustomerAdditionalDetails mCustomerAdditionalDetails;

	@Mock
	private AdvisorRepository mAdvisorRepository;

	@Mock
	private PasswordEncryptionService mPasswordEncryptionService;

	@Mock
	private AdvisorPrevilege mAdvisorPrevilege;

	@Mock
	private AdminPrevilege mAdminPrevilege;

	int enqId = 1;

	int cusId = 1;

	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);
	}

	@Test
	public void testBuildBFAUserDetails() throws Exception {

		BFAUserDetails response = Whitebox.invokeMethod(mSecurityServiceImpl, "buildBFAUserDetails", mAdvisor);
		assertNotNull(response);
	}

	@Test
	public void testBlackList() {
		mSecurityServiceImpl.blackList("apkbfaQ20=", "Invalid");
	}

	@Test
	public void testAuthenticateAdvisorInvalidSKey() {
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn("bsdjbaks");
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateAdvisorNull() {
		when(mAuthenticationRequest.getEmail()).thenReturn(null);
		when(mAuthenticationRequest.getMobile()).thenReturn(null);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateAdvisor() {
		Date mDate = new Date();
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getCaptchaValue()).thenReturn("12bg9");
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mAccountsDao.getRetryCountInfo("123")).thenReturn(mLoginRetryCount);
		when(mLoginRetryCount.getLastModifiedDate()).thenReturn(mDate);
		when(mLoginRetryCount.getRetryCount()).thenReturn(3);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateAdvisorMblNull() {
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn(null);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateAdvisorMblNullElse() {
		when(mAdvisorRepository.findByEmailId("abc@ntuc.com")).thenReturn(mAdvisor);
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn(null);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateAdvisorMblNullElseIf() {
		Set<AdvisorPrevilege> advisorMap = new HashSet<>();
		advisorMap.add(mAdvisorPrevilege);
		when(mAdminPrevilege.getPrevilegeName()).thenReturn("PrevilegeName");
		when(mAdvisorPrevilege.getAdminPrevilege()).thenReturn(mAdminPrevilege);
		when(mAdvisor.getPrevileges()).thenReturn(advisorMap);
		when(mAdvisorRepository.findByEmailId("abc@ntuc.com")).thenReturn(mAdvisor);
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn(null);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateAdvisorEmailNull() {
		String name = "0dKw/AxQYy+lkZ+CfmdDRw==";
		byte[] byteArray = name.getBytes();
		Set<AdvisorPrevilege> advisorMap = new HashSet<>();
		advisorMap.add(mAdvisorPrevilege);
		when(mAdminPrevilege.getPrevilegeName()).thenReturn("PrevilegeName");
		when(mAdvisorPrevilege.getAdminPrevilege()).thenReturn(mAdminPrevilege);
		when(mAdvisor.getId()).thenReturn(1);
		when(mAdvisor.getPassword()).thenReturn(byteArray);
		when(mAdvisor.getPrevileges()).thenReturn(advisorMap);
		when(mAdvisorRepository.findByMobileNumber("1236554845")).thenReturn(mAdvisor);
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mAuthenticationRequest.getEmail()).thenReturn(null);
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mAuthenticationRequest.getPassword()).thenReturn("asdfghjkl");
		when(mAuthenticationRequest.getEnquiryId()).thenReturn(1);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		when(mPasswordEncryptionService.decrypt("asdfghjkl", "123")).thenReturn("password");
		ResponseMessageList response = mSecurityServiceImpl.authenticateAdvisor(mHttpServletRequest,
				mAuthenticationRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateRequest() {
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateRequest(mHttpServletRequest,mAuthenticationRequest,false);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateRequestElse() {
		when(mBFAUserDetails.isEnabled()).thenReturn(false);
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mbfaUserDetailsService.loadUserByMobile("1236554845")).thenReturn(mBFAUserDetails);
		when(mAuthenticationRequest.getEmail()).thenReturn(null);
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mAuthenticationRequest.getPassword()).thenReturn("asdfghjkl");
		when(mAuthenticationRequest.getEnquiryId()).thenReturn(1);
		when(mAuthenticationRequest.getJourneyType()).thenReturn("investment");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateRequest(mHttpServletRequest,mAuthenticationRequest,false);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateRequestIf() {

		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		when(mAuthenticationRequest.getEmail()).thenReturn(null);
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mAuthenticationRequest.getPassword()).thenReturn("asdfghjkl");
		when(mAuthenticationRequest.getEnquiryId()).thenReturn(1);
		when(mAuthenticationRequest.getJourneyType()).thenReturn("investment");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		when(mAccountsDao.getRetryCountInfo("123")).thenReturn(mLoginRetryCount);
		when(mAccountsDao.resetRetryCount("123", 3)).thenReturn(mLoginRetryCount);
		when(mLoginRetryCount.getRetryCount()).thenReturn(2);
		when(mAuthenticationRequest.getCaptchaValue()).thenReturn("66lkh");
		ResponseMessageList response = mSecurityServiceImpl.authenticateRequest(mHttpServletRequest,mAuthenticationRequest,true);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateRequestInvalidSKey() {
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn("bsdjbaks");
		ResponseMessageList response = mSecurityServiceImpl.authenticateRequest(mHttpServletRequest,mAuthenticationRequest,false);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateRequestInvalidSKeyElse() {
		when(mAuthenticationRequest.getEmail()).thenReturn("Testmail@owl.com");
		when(mAuthenticationRequest.getMobile()).thenReturn("1236554845");
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
		ResponseMessageList response = mSecurityServiceImpl.authenticateRequest(mHttpServletRequest,mAuthenticationRequest,false);
		assertNotNull(response);
	}

	/*
	 * @Test public void testAuthenticateRequestNull() {
	 * when(mAuthenticationRequest.getEmail()).thenReturn(null);
	 * when(mAuthenticationRequest.getMobile()).thenReturn(null);
	 * when(mHttpServletRequest.getHeader("Authorization")).thenReturn(secretkey);
	 * ResponseMessageList response =
	 * mSecurityServiceImpl.authenticateRequest(mHttpServletRequest,
	 * mAuthenticationRequest); assertNotNull(response); }
	 */

	@Test
	public void testGetUniqueSessionId() {
		String response = mSecurityServiceImpl.getUniqueSessionId();
		assertNotNull(response);
	}

	@Test
	public void testProvideClientSecretKey() {
		String response = mSecurityServiceImpl.provideClientSecretKey();
		assertNotNull(response);
	}

	@Test
	public void testSaveSessionDetails() {
		String sessionId = mSecurityServiceImpl.getUniqueSessionId();
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '" + sessionId + "'"))
				.thenReturn(mSessionDetailList);
		when(mHttpServletRequest.getHeader("User-Agent")).thenReturn("windows Chrome");
		SessionDetails response = mSecurityServiceImpl.saveSessionDetails(sessionId, mHttpServletRequest);
		assertNull(response);
		assertNotNull(sessionId);
	}

	@Test
	public void testVerifyOTP() {
		when(mOTPRequest.isEditProfile()).thenReturn(true);
		when(mOTPRequest.getCustomerRef()).thenReturn("G0016534");
		OTPVerificationResponse response = mSecurityServiceImpl.verifyOTP(mOTPRequest);
		assertNotNull(response);
	}

	@Test
	public void testResetPassword() {
		when(mResetPasswordDTO.getResetKey()).thenReturn("IMXYlDmP4f4=");
		PasswordResetStatus response = mSecurityServiceImpl.resetPassword(mResetPasswordDTO);
		assertNotNull(response);
	}

	@Test
	public void testSetPassword() {

	}

	@Test
	public void testGeneratePasswordResetMail() {
		when(mBFAUserDetails.isEmailVerified()).thenReturn(true);
		when(mBFAUserDetails.isEnabled()).thenReturn(true);
		when(mForgotPasswordDTO.getEmail()).thenReturn("Testmail@owl.com");
		when(mbfaUserDetailsService.loadUserByEmail("Testmail@owl.com")).thenReturn(mBFAUserDetails);
		String response = mSecurityServiceImpl.generatePasswordResetMail(mForgotPasswordDTO);
		assertNotNull(response);
	}

	@Test
	public void testGeneratePasswordResetMailException() {
		when(mForgotPasswordDTO.getEmail()).thenReturn("Testmail@owl.com");
		when(mbfaUserDetailsService.loadUserByEmail("Testmail@owl.com")).thenThrow(new RuntimeException());
		String response = mSecurityServiceImpl.generatePasswordResetMail(mForgotPasswordDTO);
		assertNotNull(response);
	}

	@Test
	public void testVerifyEmailAddress() {
		when(mVerifyEmailRequest.getCode()).thenReturn("Gt6B7Gt6B7");
		String emailDetails = "dsds###Yopmail@owl.com###3";
		when(utility.DecryptText("ށ�kz")).thenReturn(emailDetails);
		String response = mSecurityServiceImpl.verifyEmailAddress(mVerifyEmailRequest);
		assertNotNull(response);
	}

	@Test
	public void testSendSetUpInvestmentAccountMailerIfApplicable() {
		when(custPortfolioList.isEmpty()).thenReturn(true);
		when(mCustomerIFasteAccountDTO.getAccountStatus()).thenReturn("active");
		when(mInvestementStatusDTO.getAccount()).thenReturn(mCustomerIFasteAccountDTO);
		when(mInvestementStatusDTO.getPortfolios()).thenReturn(custPortfolioList);
		when(mMOInvestmentService.customerInvestmentProfile(cusId)).thenReturn(mInvestementStatusDTO);
		mSecurityServiceImpl.sendSetUpInvestmentAccountMailerIfApplicable(cusId);

	}

	@Test
	public void testSendSetUpInvestmentAccountMailerIfApplicableElse() {
		when(mCustomer.getSurName()).thenReturn("ch");
		when(mCustomer.getEmail()).thenReturn("abc@ntuc.com");
		when(mCustomerAdditionalDetails.getCustomer()).thenReturn(mCustomer);
		when(mCustomerAdditionalDetails.isSetUpInvestmentMailerSent()).thenReturn(false);
		when(mAccountsService.getCustomerAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(custPortfolioList.isEmpty()).thenReturn(false);
		when(mInvestementStatusDTO.getPortfolios()).thenReturn(custPortfolioList);
		when(mMOInvestmentService.customerInvestmentProfile(cusId)).thenReturn(mInvestementStatusDTO);
		mSecurityServiceImpl.sendSetUpInvestmentAccountMailerIfApplicable(cusId);

	}

	@Test
	public void testSendSetUpInvestmentAccountMailerIfApplicableIf() {
		when(mCustomerAdditionalDetails.isSetUpInvestmentMailerSent()).thenReturn(false);
		when(mAccountsService.getCustomerAdditionalDetails(cusId)).thenReturn(null);
		when(custPortfolioList.isEmpty()).thenReturn(false);
		when(mInvestementStatusDTO.getPortfolios()).thenReturn(custPortfolioList);
		when(mMOInvestmentService.customerInvestmentProfile(cusId)).thenReturn(mInvestementStatusDTO);
		mSecurityServiceImpl.sendSetUpInvestmentAccountMailerIfApplicable(cusId);

	}

	@Test(expected = NullPointerException.class)
	public void testSaveSessionCaptchaDetails() {
		when(mSessionDetailList.get(0)).thenReturn(mSessionDetails);
		when(mAuthenticationRequest.getSessionId()).thenReturn("123");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(mSessionDetailList);
		mSecurityServiceImpl.saveSessionCaptchaDetails(mHttpServletRequest, "123", "12gj77");
	}

	@Test
	public void testSaveSessionCaptchaDetailsElse() {
		when(mHttpServletRequest.getHeader("X-FORWARDED-FOR")).thenReturn("10.123.15");
		when(mHttpServletRequest.getHeader("User-Agent")).thenReturn("iphone");
		when(mAccountsDao.getObjectByHql("from SessionDetails where sessionId = '123'")).thenReturn(null);
		mSecurityServiceImpl.saveSessionCaptchaDetails(mHttpServletRequest, "123", "12gj77");
	}

	@Test
	public void testIsValidCaptcha() {

	}

	@Test
	public void testUpdateCRMPostCustomerCreation() {
		String hqlString = "from Customer where id = '1'";
		when(mCustomerList.isEmpty()).thenReturn(false);
		when(mCustomerList.get(0)).thenReturn(mCustomer);
		when(mAccountsDao.getObjectByHql(hqlString)).thenReturn(mCustomerList);
		mSecurityServiceImpl.updateCRMPostCustomerCreation("1", productList, true, enqId);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateCRMPostDuringSignup() {
		when(mPwdReq.getSelectedProducts()).thenReturn(productList);
		when(mPwdReq.getCustomerRef()).thenReturn("IMXYlDmP4f4=");
		mSecurityServiceImpl.updateCRMPostDuringSignup(mPwdReq, true);
	}

	@Test
	public void testIsEmailLinkValid() {

		String resposne = mSecurityServiceImpl.isEmailLinkValid(mEmailLinkValidityReq);
		assertNotNull(resposne);
	}

	@Mock
	VerifyEmailInitiator communicator;
	
	@Mock
	ApplicationContext applicationContext;
	
	List<Object> customerList = new ArrayList<>();
	
	@Test(expected = NullPointerException.class)
	public void testEditEmail() {
		when(mDefaultServiceImpl.getCustomerById(cusId)).thenReturn(mCustomer);
		when(mAccountsDao.getCustomerVerificationDetailsbyId(cusId)).thenReturn(mCustomerContactVerification);
		when(mAccountsDao.getObjectsById(Customer.class, "id", cusId)).thenReturn(customerList);
		when(mHttpServletRequest.getServerName()).thenReturn("Test Server");
		when(mContactDetailsDTO.getCallbackUrl()).thenReturn("Test URL");
		when(this.applicationContext.getAttribute("verifyEmailInitiator")).thenReturn("verifyEmailInitiator");
		CustomerContactVerification res = mSecurityServiceImpl.editEmail(mContactDetailsDTO, cusId,
				mHttpServletRequest);
		assertNotNull(res);
	}

	@Test(expected = NullPointerException.class)
	public void testEditEmailElse() {
		when(mDefaultServiceImpl.getCustomerById(cusId)).thenReturn(mCustomer);
		when(mContactDetailsDTO.getEmailId()).thenReturn("abc@ntuc.com");
		when(mAccountsDao.getCustomerVerificationDetailsbyId(cusId)).thenReturn(mCustomerContactVerification);
		CustomerContactVerification res = mSecurityServiceImpl.editEmail(mContactDetailsDTO, cusId,
				mHttpServletRequest);
		assertNotNull(res);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateCRMPostDuringSignupV2() {
		when(mSSProductsRequest.getSelectedProducts()).thenReturn(productList);
		when(mSSProductsRequest.getCustomerRef()).thenReturn("G0016534");
		mSecurityServiceImpl.updateCRMPostDuringSignupV2(mSSProductsRequest, true);
	}

	@Test
	public void testResetPasswordV2() {
		when(mResetPasswordDTO.getResetKey()).thenReturn(secretkey);
		PasswordResetStatus response = mSecurityServiceImpl.resetPasswordV2(mResetPasswordDTO);
		assertNotNull(response);
	}

	@Test
	public void testSavePromocode() {

		String hqlString = "from Enquiry where id=1";
		when(mEnquiry.getPromoCodeId()).thenReturn("12");
		when(mEnquiryList.remove(0)).thenReturn(mEnquiry);
		when(mAccountsDao.getObjectByHql(hqlString)).thenReturn(mEnquiryList);
		mSecurityServiceImpl.savePromocode(cusId, enqId);
	}

	@Test
	public void testGeneratePasswordResetMailForAdmin() {

		when(mForgotPasswordDTO.getEmail()).thenReturn("abc@ntuc.com");
		when(mForgotPasswordDTO.getIsAdmin()).thenReturn(true);
		when(mbfaUserDetailsService.loadAdminByEmail("abc@ntuc.com")).thenReturn(mBFAUserDetails);
		when(mBFAUserDetails.isEmailVerified()).thenReturn(true);
		when(mBFAUserDetails.isEnabled()).thenReturn(true);
		String response = mSecurityServiceImpl.generatePasswordResetMailForAdmin(mForgotPasswordDTO);
		assertNotNull(response);
	}

	@Test
	public void testGetPromoCode() throws Exception {
		String hqlString = "from Enquiry where id=1";
		when(mEnquiry.getPromoCodeId()).thenReturn("12");
		when(mEnquiryList.remove(0)).thenReturn(mEnquiry);
		when(mAccountsDao.getObjectByHql(hqlString)).thenReturn(mEnquiryList);
		Whitebox.invokeMethod(mSecurityServiceImpl, "getPromoCode", enqId);
	}

	@Test
	public void testGetPromoCodeException() throws Exception {

		String hqlString = "from Enquiry where id=1";
		when(mEnquiry.getPromoCodeId()).thenReturn("12");
		when(mEnquiryList.remove(0)).thenReturn(mEnquiry);
		when(mAccountsDao.getObjectByHql(hqlString)).thenThrow(new DatabaseAccessException());
		Whitebox.invokeMethod(mSecurityServiceImpl, "getPromoCode", enqId);

	}

	@Test
	public void testInvalidateCurrentUserSession() throws Exception {

		Whitebox.invokeMethod(mSecurityServiceImpl, "invalidateCurrentUserSession", cusId, "reason");

	}

	@Test(expected=NullPointerException.class)
	public void testSendSetUpInvestmentAccount() throws Exception {

		Whitebox.invokeMethod(mSecurityServiceImpl, "sendSetUpInvestmentAccount", mCustomer);

	}

}

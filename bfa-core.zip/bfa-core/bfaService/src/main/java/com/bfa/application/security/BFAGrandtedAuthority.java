/**
 * 
 */
package com.bfa.application.security;

import org.springframework.security.core.GrantedAuthority;

/**
 * @author pradheep.p
 *
 */
public class BFAGrandtedAuthority implements GrantedAuthority {

	public static final String ROLE_USER = "USER";

	public static final String ROLE_SIGNED_USER = "SIGNED_USER";

	public static final String ROLE_ADMIN = "ROLE_ADMIN";
	public static final String ROLE_ADVISOR = "ROLE_SIGNED_ADMIN";
	public static final String ROLE_ADVISOR_USER = "ROLE_ADVISOR";
	
	//ROBO3 Lite ROles
	
	public static final String ROLE_COMPRE_LITE = "ROLE_COMPRE_LITE";
	public static final String ROLE_COMPRE_DISCOUNT = "ROLE_COMPRE_DISCOUNT";
	public static final String ROLE_INVEST_10 = "ROLE_INVEST_10";
	
	
	
	public static final String ROLE_ADVISOR_MANAGER = "ROLE_ADVISOR_MANAGER";
	public static final String ROLE_CLIENT_SERVICE = "ROLE_CLIENT_SERVICE";
	public static final String ROLE_CLIENT_SERVICE_MANAGER = "ROLE_CLIENT_SERVICE_MANAGER";
	public static final String ROLE_PRODUCT_OWNER_MANAGER = "ROLE_PRODUCT_OWNER_MANAGER";
	public static final String ROLE_COMPLIANCE_MANAGER = "ROLE_COMPLIANCE_MANAGER";
	
	public static final String ROLE_BUSINESS_USER = "BUSINESS_USER";
	
	public static final String ROLE_IFAST = "IFAST";
	
	public static final String ROLE_SERVICE_CALL = "SERVICE_CALL";

	private String grantedAuthority;

	public BFAGrandtedAuthority(String grantedAuthority) {
		this.grantedAuthority = grantedAuthority;
	}

	@Override
	public String getAuthority() {
		return this.grantedAuthority;
	}

	public String toString() {
		return grantedAuthority;
	}
}

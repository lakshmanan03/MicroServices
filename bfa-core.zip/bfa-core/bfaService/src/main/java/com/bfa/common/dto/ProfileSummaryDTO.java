package com.bfa.common.dto;

import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.NationalityDTO;

public class ProfileSummaryDTO {

	private int id;

	private String firstName;

	private String lastName;
	
	private String gender;
	
	private String dateOfBirth;

	private String emailAddress;

	private String mobileNumber;

	private String fullName;

	private NationalityDTO nationality;

	private InvestementDashboardStatusDTO investementDetails;

	private String comprehensiveReportStatus;
	

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public NationalityDTO getNationality() {
		return nationality;
	}

	public void setNationality(NationalityDTO nationality) {
		this.nationality = nationality;
	}

	public InvestementDashboardStatusDTO getInvestementDetails() {
		return investementDetails;
	}

	public void setInvestementDetails(InvestementDashboardStatusDTO investementDetails) {
		this.investementDetails = investementDetails;
	}

	public String getComprehensiveReportStatus() {
		return comprehensiveReportStatus;
	}

	public void setComprehensiveReportStatus(String comprehensiveReportStatus) {
		this.comprehensiveReportStatus = comprehensiveReportStatus;
	}

}

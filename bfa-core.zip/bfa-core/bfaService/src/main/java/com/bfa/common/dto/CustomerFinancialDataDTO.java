package com.bfa.common.dto;

import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Expenses;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;

public class CustomerFinancialDataDTO {
	private Assets assets;
	private Liabilities liabilities;
	private Expenses expenses;
	private Income income;
	public Assets getAssets() {
		return assets;
	}
	public void setAssets(Assets assets) {
		this.assets = assets;
	}
	public Liabilities getLiabilities() {
		return liabilities;
	}
	public void setLiabilities(Liabilities liabilities) {
		this.liabilities = liabilities;
	}
	public Expenses getExpenses() {
		return expenses;
	}
	public void setExpenses(Expenses expenses) {
		this.expenses = expenses;
	}
	public Income getIncome() {
		return income;
	}
	public void setIncome(Income income) {
		this.income = income;
	}
	

}

/**
 * 
 */
package com.bfa.application.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * BFA-1233
 * @author pradheep.p
 *
 */
@Entity
@Table(name="customer_issued_token")
public class CustomerIssuedToken {		
	
	@Id
	@Column(name="customer_id")
	private int customerId;
	
	@Column(name = "token")
	private String tokenValue;
	
	@Column(name="issued_time")
	private Date issuedTime;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getTokenValue() {
		return tokenValue;
	}

	public void setTokenValue(String tokenValue) {
		this.tokenValue = tokenValue;
	}

	public Date getIssuedTime() {
		return issuedTime;
	}

	public void setIssuedTime(Date issuedTime) {
		this.issuedTime = issuedTime;
	}	
}

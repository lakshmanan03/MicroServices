package com.bfa.configuration.jpa;

import org.springframework.data.repository.CrudRepository;


import com.bfa.investment.entity.CustomerInvestmentObjective;

public interface CustomerInvestmentObjectiveRepository extends CrudRepository<CustomerInvestmentObjective, String> {

}

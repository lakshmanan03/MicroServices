/**
 * 
 */
package com.bfa.insurance.product;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * This class is used in returning the list of recommended products.
 * 
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "protection_type")
public class ProductProtectionType {

	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;	
	
	@JsonIgnore
	@Column(name="type_id")
	private Integer typeId;
	
	@JsonIgnore
	@Column(name="purpose_id")
	private Integer purposeId;	
	
	@JsonIgnore
	@Column(name="objective_id")
	private Integer objectiveId;	

	@Column(name = "protection_type")
	private String protectionType;
	
	@JsonIgnore
	@Column(name = "protection_type_description")
	private String protectionTypeDescription;	
	
	@OneToMany
	@JoinColumns({
		@JoinColumn(name="type_id",referencedColumnName="type_id"),
		@JoinColumn(name="purpose_id",referencedColumnName="purpose_id"),
		@JoinColumn(name="objective_id",referencedColumnName="objective_id")
	})	
	private List<ProductList> productList;	
		

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}	

	public String getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(String protectionType) {
		this.protectionType = protectionType;
	}

	public String getProtectionTypeDescription() {
		return protectionTypeDescription;
	}

	public void setProtectionTypeDescription(String protectionTypeDescription) {
		this.protectionTypeDescription = protectionTypeDescription;
	}	

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public Integer getPurposeId() {
		return purposeId;
	}

	public void setPurposeId(Integer purposeId) {
		this.purposeId = purposeId;
	}

	public Integer getObjectiveId() {
		return objectiveId;
	}

	public void setObjectiveId(Integer objectiveId) {
		this.objectiveId = objectiveId;
	}

	public List<ProductList> getProductList() {
		return productList;
	}

	public void setProductList(List<ProductList> productList) {
		this.productList = productList;
	}

}

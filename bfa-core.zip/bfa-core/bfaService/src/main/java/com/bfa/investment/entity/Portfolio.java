package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.common.entity.OptionItem;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = "portfolio")
public class Portfolio {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "portfolio_name")
	private String name;
	
	@Column(name = "portfolio_id")
	private String portfolioId;
	
	@Column(name = "projected_returns")
	private String projectedReturns;
	
	@Column(name ="min_subscribe_amt")
	private Double minSubscribeAmt; 
	
	@Column(name = "min_subsequence_subscribe_amt")
	private Double minSubsequenceSubscribeAmt;

	@Column(name = "min_redemption_amt")
	private Double minRedemptionAmt;
	
	@Column(name="min_retain_amt")
	private Double minRetainAmt;
	
	@Column(name="median_projected_return")
	private String medianProjectedReturn;
	
	@OneToOne
	@JoinColumn(name = "funding_type")
	private OptionItem fundingType;
	
	@OneToOne
	@JoinColumn(name = "portfolio_type")
	private OptionItem portfolioType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getProjectedReturns() {
		return projectedReturns;
	}

	public void setProjectedReturns(String projectedReturns) {
		this.projectedReturns = projectedReturns;
	}

	public Double getMinSubscribeAmt() {
		return minSubscribeAmt;
	}

	public void setMinSubscribeAmt(Double minSubscribeAmt) {
		this.minSubscribeAmt = minSubscribeAmt;
	}

	public Double getMinSubsequenceSubscribeAmt() {
		return minSubsequenceSubscribeAmt;
	}

	public void setMinSubsequenceSubscribeAmt(Double minSubsequenceSubscribeAmt) {
		this.minSubsequenceSubscribeAmt = minSubsequenceSubscribeAmt;
	}

	public Double getMinRedemptionAmt() {
		return minRedemptionAmt;
	}

	public void setMinRedemptionAmt(Double minRedemptionAmt) {
		this.minRedemptionAmt = minRedemptionAmt;
	}

	public Double getMinRetainAmt() {
		return minRetainAmt;
	}

	public void setMinRetainAmt(Double minRetainAmt) {
		this.minRetainAmt = minRetainAmt;
	}

	public String getMedianProjectedReturn() {
		return medianProjectedReturn;
	}

	public void setMedianProjectedReturn(String medianProjectedReturn) {
		this.medianProjectedReturn = medianProjectedReturn;
	}

	public OptionItem getFundingType() {
		return fundingType;
	}

	public void setFundingType(OptionItem fundingType) {
		this.fundingType = fundingType;
	}
	
	public OptionItem getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(OptionItem portfolioType) {
		this.portfolioType = portfolioType;
	}
		
}

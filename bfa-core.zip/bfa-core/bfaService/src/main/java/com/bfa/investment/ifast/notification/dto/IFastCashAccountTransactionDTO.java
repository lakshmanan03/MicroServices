package com.bfa.investment.ifast.notification.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class IFastCashAccountTransactionDTO {
	
    private String transactionType;
    private String paymentMethod;
    private Double amount;
    private String currency;
    private Double conversionRate;
    private String contractNo;
    private String status;

    @JsonFormat(shape = JsonFormat.Shape.NUMBER)
    private Date timestamp;
    
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getConversionRate() {
		return conversionRate;
	}
	public void setConversionRate(Double conversionRate) {
		this.conversionRate = conversionRate;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Date getTimestamp() {
		return timestamp;
	}
	@JsonFormat(shape = JsonFormat.Shape.NUMBER)
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	
		
}

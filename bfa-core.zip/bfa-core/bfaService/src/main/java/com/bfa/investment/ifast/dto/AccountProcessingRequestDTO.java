package com.bfa.investment.ifast.dto;

public class AccountProcessingRequestDTO {

	private String nationality;
	private String identificationType;
	private String passportNumber;
	private String nricName;
	private String nric;
	private String countryOfIssue;
	private String passportExpiryDate;
	private String dob;
	private String gender;
	private String countryOfBirth;
	
	private AccountProccessingMainAcct mainAcct;

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getIdentificationType() {
		return identificationType;
	}

	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getNricName() {
		return nricName;
	}

	public void setNricName(String nricName) {
		this.nricName = nricName;
	}
 
	
	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getCountryOfIssue() {
		return countryOfIssue;
	}

	public void setCountryOfIssue(String countryOfIssue) {
		this.countryOfIssue = countryOfIssue;
	}

	public String getPassportExpiryDate() {
		return passportExpiryDate;
	}

	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public AccountProccessingMainAcct getMainAcct() {
		return mainAcct;
	}

	public void setMainAcct(AccountProccessingMainAcct mainAcct) {
		this.mainAcct = mainAcct;
	}

}


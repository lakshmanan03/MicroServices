package com.bfa.comprehensive.dto;

public class InsuranceAgentCallback {
	
	private Integer custId;
	
	private String custToken;
	
	private String constructedUrl;
	
	private boolean custConsent;
	
	private String customerGivenName;
	
	private String customerLastName;
	
	private String customerEmail;

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getCustToken() {
		return custToken;
	}

	public void setCustToken(String custToken) {
		this.custToken = custToken;
	}

	public String getConstructedUrl() {
		return constructedUrl;
	}

	public void setConstructedUrl(String constructedUrl) {
		this.constructedUrl = constructedUrl;
	}

	public boolean isCustConsent() {
		return custConsent;
	}

	public void setCustConsent(boolean custConsent) {
		this.custConsent = custConsent;
	}

	public String getCustomerGivenName() {
		return customerGivenName;
	}

	public void setCustomerGivenName(String customerGivenName) {
		this.customerGivenName = customerGivenName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	
	

}

/**
 * 
 */
package com.bfa.common.entity;

/**
 * @author GajendraK
 *
 */
public class WelcomeMailRequest {

	private String mobileNumber;
	
	private String emailAddress;
	
	private String hostedServerName;
	
	private String callbackUrl;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}	

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getHostedServerName() {
		return hostedServerName;
	}

	public void setHostedServerName(String hostedServerName) {
		this.hostedServerName = hostedServerName;
	}
}

package com.bfa.common.dto;

public class ComprehensiveDependentsDTO {
	
	private int customerId;

	private int enquiryId;

	private String name;

	private String relationship;

	private String gender;

	private String dateOfBirth;

	private String nation;
	
	private int dependentId;

	private String location;
	
	private int age;

	private String educationCourse;

	private Double endowmentMaturityAmount;

	private int endowmentMaturityYears;
	
	private int calculatedChildEducationDependencyYear;
	
	private double universityFees;
	
	private double livingExpenses;
	
	private int protectedDependencyYear;
	
	private double childEducationAmount;
	
	private boolean isInsuranceNeeded;


	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public int getDependentId() {
		return dependentId;
	}

	public void setDependentId(int dependentId) {
		this.dependentId = dependentId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEducationCourse() {
		return educationCourse;
	}

	public void setEducationCourse(String educationCourse) {
		this.educationCourse = educationCourse;
	}

	public Double getEndowmentMaturityAmount() {
		return endowmentMaturityAmount;
	}

	public void setEndowmentMaturityAmount(Double endowmentMaturityAmount) {
		this.endowmentMaturityAmount = endowmentMaturityAmount;
	}

	public int getEndowmentMaturityYears() {
		return endowmentMaturityYears;
	}

	public void setEndowmentMaturityYears(int endowmentMaturityYears) {
		this.endowmentMaturityYears = endowmentMaturityYears;
	}

	public double getUniversityFees() {
		return universityFees;
	}

	public void setUniversityFees(double universityFees) {
		this.universityFees = universityFees;
	}

	public double getLivingExpenses() {
		return livingExpenses;
	}

	public void setLivingExpenses(double livingExpenses) {
		this.livingExpenses = livingExpenses;
	}

	public int getCalculatedChildEducationDependencyYear() {
		return calculatedChildEducationDependencyYear;
	}

	public void setCalculatedChildEducationDependencyYear(int calculatedChildEducationDependencyYear) {
		this.calculatedChildEducationDependencyYear = calculatedChildEducationDependencyYear;
	}

	public int getProtectedDependencyYear() {
		return protectedDependencyYear;
	}

	public void setProtectedDependencyYear(int protectedDependencyYear) {
		this.protectedDependencyYear = protectedDependencyYear;
	}

	public double getChildEducationAmount() {
		return childEducationAmount;
	}

	public void setChildEducationAmount(double childEducationAmount) {
		this.childEducationAmount = childEducationAmount;
	}

	public boolean isInsuranceNeeded() {
		return isInsuranceNeeded;
	}

	public void setInsuranceNeeded(boolean isInsuranceNeeded) {
		this.isInsuranceNeeded = isInsuranceNeeded;
	}

	
	

}

SET foreign_key_checks = 0;
DROP TABLE customer_previlege;
CREATE TABLE customer_previlege (
  customer_id int(11) NOT NULL,
  previlege_id int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

alter table session_details modify column session_id varchar(1000);
alter table customer_issued_token modify column token varchar(1000);
/**
 * 
 */
package com.bfa.serviceimpl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.SecurityConstants;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.configuration.AccountServiceConfiguration;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.security.twofa.core.TwoFactorValidationRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pradheep
 *
 */
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure = false)
@ContextConfiguration
@SpringBootTest(classes = AccountServiceConfiguration.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TwoFactorAuthTest {

	@Autowired
	private MockMvc mockMvc;

	private final String sessionId = "51c3f8b5-feb0-4e2f-b98b-45cffceae575";

	@Autowired
	@Qualifier(value = "accountsDAO")
	private AccountsDao accountsDao;

	@Autowired
	private TokenProvider tokenProvider;

	private String header = "";

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	private CustomerContactVerification customerContactVerification = null;

	private Customer customer = null;

	private int customerId = 1;

	private String emailAddress = "test@email.com";

	private String mobileNumber = "87223311";

	String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";

	@Autowired
	private SecurityServiceImpl securityService;

	private final String otpString = "111111";

	private boolean isSessionLoaded = false;

	private void saveCustomer() {
		if (null == customer) {
			customer = new Customer();
			customer.setPassword("test".getBytes());
			customer.setDateOfBirth("1975-05-02");
			customer.setId(customerId);
			customer.setMobileNumber(mobileNumber);
			customer.setEmail(emailAddress);
			customer.setEmailVerified("Yes");
			customer.setOtpVerfied("Yes");
			customer.setGender("Male");
			customer.setGivenName("Test");
			customer.setLastUpdatedTime("");
			accountsDao.saveObject(customer);
		}
	}

	private void saveSessionDetails() {
		if (!isSessionLoaded) {
			String hql = "delete from SessionDetails";
			accountsDao.executeUpdate(hql);
			// -----------------------------------------//
			SessionDetails sessionDetails = new SessionDetails();
			sessionDetails.setBrowser("None");
			sessionDetails.setCaptcha("abc");
			sessionDetails.setDevice("None");
			sessionDetails.setSessionId(sessionId);
			accountsDao.saveObject(sessionDetails);
			System.out.println("-- Session details persisted --");
			isSessionLoaded = true;
		}
	}

	private void saveCustomerContactVerification(String otpVerifiedStatus, Timestamp timeIssued) {
		// ----- Clean the data --------//
		if (null == customerContactVerification) {
			customerContactVerification = new CustomerContactVerification();
			customerContactVerification.setActionType(ApplicationConstants.TWO_FA_ACTION_TYPE);
			customerContactVerification.setCustomer(customer);
			customerContactVerification.setCountryCode("+65");
			customerContactVerification.setEmail(emailAddress);
			customerContactVerification.setSessionId(sessionId);
			customerContactVerification.setMobileNumber(mobileNumber);
			customerContactVerification.setOtpTimeIssued(timeIssued);
			customerContactVerification.setOtpVerifiedTime(timeIssued);
			customerContactVerification.setOTPString(securityService.appendDateToOTP(otpString));
			customerContactVerification.setOtpVerifiedStatus(otpVerifiedStatus);
			accountsDao.saveOrUpdateObject(customerContactVerification);
		}
	}

	private void resetCustomerContactVerification() {
		String hql = "delete from CustomerContactVerification";
		accountsDao.executeUpdate(hql);
		customerContactVerification = null;
	}

	private String getAuthToken(String[] privileges) {
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		for (int i = 0; i < privileges.length; i++) {
			BFAGrandtedAuthority grantedAuthority = new BFAGrandtedAuthority(privileges[i]);
			authorities.add(grantedAuthority);
		}
		return tokenProvider.getTokenStringV2(customerId, authorities);
	}

	@Before
	@Sql(scripts = { "classpath:BFA-1686/prepare-data.sql" })
	public void init() {
		saveSessionDetails();
		Customer customerObj = accountsDao.getCustomerById(100);
		if (null == customerObj) {
			saveCustomer();
		} else {
			customer = customerObj;
		}
		String[] privileges = new String[] { "ROLE_USER", "ROLE_SIGNED_USER" };
		header = getAuthToken(privileges);
		System.out.println("------------- Begining the test ------------------");
	}

	public void prepareSuccessData() {
		saveCustomerContactVerification("Yes", new Timestamp(new Date().getTime()));
	}

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	public void prepareFailureData(String status) {
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		calendar.add(Calendar.MINUTE, -10);
		saveCustomerContactVerification(status, new Timestamp(calendar.getTime().getTime()));
	}

	@Test
	public void testD() {
		System.out.println("Testing sendTwoFA OTP");
		try {
			prepareSuccessData();
			String APIName = APIConstants.API_SEND_2FA_OTP;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "6000").exists());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testE() {
		System.out.println("Testing sendTwoFA OTP - Invalid Session");
		try {
			prepareSuccessData();
			String APIName = APIConstants.API_SEND_2FA_OTP;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header("Authorization", header)).andExpect(status().isOk())
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testF() {
		System.out.println("Testing send 2factor OTP request -- Security test");
		try {
			prepareSuccessData();
			String APIName = APIConstants.API_SEND_2FA_OTP;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId)).andExpect(status().isForbidden());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// --------- TWO factor validation tests -------------------//

	@Test
	public void testH() {
		System.out.println("Testing Validate OTP - Failure Test");
		try {
			resetCustomerContactVerification();
			prepareSuccessData();
			TwoFactorValidationRequest request = new TwoFactorValidationRequest();
			request.setTwoFactorOtpString("123456");
			String APIName = APIConstants.API_VALIDATE_2FA;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED).exists());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testI() {
		System.out.println("Testing Validate OTP - Failure Test");
		try {
			prepareSuccessData();
			TwoFactorValidationRequest request = new TwoFactorValidationRequest();
			request.setTwoFactorOtpString("123456");
			String APIName = APIConstants.API_VALIDATE_2FA;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId)).andExpect(status().isForbidden());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testJ() {
		System.out.println("-- Performing Customer Profile API Test  --");
		try {
			prepareSuccessData();
			String APIName = APIConstants.API_ACCOUNT_CUSTOMER_PROFILE;
			ResultActions result = mockMvc
					.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
							.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
							.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testA() {
		System.out.println("-- Performing is2FAuthenticated API Test  --");
		try {
			prepareSuccessData();
			String APIName = APIConstants.API_IS_TWO_FACT_AUTHENTICATED;
			ResultActions result = mockMvc
					.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
							.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
							.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.TWO_FACTOR_AUTH_SUCCESS).exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testB() {
		System.out.println("-- Performing is2FAuthenticated API invalid header Test  --");
		try {
			resetCustomerContactVerification();
			prepareSuccessData();
			String APIName = APIConstants.API_IS_TWO_FACT_AUTHENTICATED;
			ResultActions result = mockMvc
					.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
							.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1).header("Authorization",
									header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testC() {
		System.out.println("-- Performing is2FAuthenticated API Failure Test  --");
		try {
			resetCustomerContactVerification();
			prepareFailureData("No");
			String APIName = APIConstants.API_IS_TWO_FACT_AUTHENTICATED;
			ResultActions result = mockMvc
					.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
							.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
							.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED).exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testK() {
		System.out.println("-- Performing is2FAuthenticated API Failure Time exceed test  --");
		try {
			resetCustomerContactVerification();
			prepareFailureData("Yes");
			String APIName = APIConstants.API_IS_TWO_FACT_AUTHENTICATED;
			ResultActions result = mockMvc
					.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
							.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
							.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.TWO_FACTOR_AUTH_TIME_EXCEEDED).exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testL() {
		System.out.println("Testing Validate OTP - Failure Test - OTP Expired");
		try {
			resetCustomerContactVerification();
			prepareFailureData("No");
			TwoFactorValidationRequest request = new TwoFactorValidationRequest();
			request.setTwoFactorOtpString("123456");
			String APIName = APIConstants.API_VALIDATE_2FA;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.OTP_EXPIRED).exists());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testM() {
		System.out.println("Testing Validate OTP - Failure Test - Default OTP");
		try {
			resetCustomerContactVerification();
			prepareFailureData("No");
			TwoFactorValidationRequest request = new TwoFactorValidationRequest();
			request.setTwoFactorOtpString(otpString);
			String APIName = APIConstants.API_VALIDATE_2FA;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.OTP_EXPIRED).exists());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testN() {
		System.out.println("Testing invalid session id");
		try {
			// -------- Prepare data for testing ------
			String invalidSessionId = "xyz-tyio-opwnj-ijswder";
			resetCustomerContactVerification();
			prepareFailureData("No");
			TwoFactorValidationRequest request = new TwoFactorValidationRequest();
			request.setTwoFactorOtpString(otpString);
			// -------------------------------------------//
			String APIName = APIConstants.API_VALIDATE_2FA;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, invalidSessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());

			APIName = APIConstants.API_IS_TWO_FACT_AUTHENTICATED;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, invalidSessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());

			APIName = APIConstants.API_ACCOUNT_CUSTOMER_PROFILE;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, invalidSessionId).header("Authorization", header))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());

			APIName = APIConstants.API_SEND_2FA_OTP;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, invalidSessionId).header("Authorization", header))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());

			APIName = APIConstants.API_ACCOUNT_UPDATE_PERSONAL_DETAILS;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(getSampleContactDetailsDto()))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, invalidSessionId).header("Authorization", header))
					.andExpect(jsonPath(responseMessage, ErrorCodes.INVALID_SESSION_ID).exists());

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testO() {
		System.out.println("Testing for ROLE_SIGNED_USER privileges.");
		try {
			String testHeader = getAuthToken(new String[] { "ROLE_USER" });
			// -------- Prepare data for testing ------- //
			resetCustomerContactVerification();
			prepareFailureData("No");
			TwoFactorValidationRequest request = new TwoFactorValidationRequest();
			request.setTwoFactorOtpString(otpString);
			// -------------------------------------------//
			String APIName = APIConstants.API_VALIDATE_2FA;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", testHeader))
					.andExpect(status().isForbidden());

			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(request))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk());
			// ---------------------------------------------//
			APIName = APIConstants.API_IS_TWO_FACT_AUTHENTICATED;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk());

			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", testHeader))
					.andExpect(status().isForbidden());
			// ---------------------------------------------//
			APIName = APIConstants.API_ACCOUNT_CUSTOMER_PROFILE;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", testHeader))
					.andExpect(status().isForbidden());

			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk());
			// ---------------------------------------------//
			APIName = APIConstants.API_SEND_2FA_OTP;
			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", testHeader))
					.andExpect(status().isForbidden());

			mockMvc.perform(get(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk());
			// ---------------------------------------------//

			APIName = APIConstants.API_ACCOUNT_UPDATE_PERSONAL_DETAILS;
			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(getSampleContactDetailsDto()))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", testHeader))
					.andExpect(status().isForbidden());

			mockMvc.perform(post(APIName).contentType(this.APPLICATION_JSON_UTF8)
					.content(this.convertObjectToJsonBytes(getSampleContactDetailsDto()))
					.requestAttr(SecurityConstants.CUSTOMER_ID_IN_REQUEST.toString(), 1)
					.header(ApplicationConstants.SESSION_ID, sessionId).header("Authorization", header))
					.andExpect(status().isOk());
			// ----------------------------------------------//
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@After
	public void printLine() {
		System.out.println("------------------------- End of Test ------------------------------------");
	}

	private ContactDetailsDTO getSampleContactDetailsDto() {
		ContactDetailsDTO contactDetailsDto = new ContactDetailsDTO();
		contactDetailsDto.setCallbackUrl("http://localhost:8080/sample");
		contactDetailsDto.setCountryCode("+65");
		contactDetailsDto.setCustomerId(customerId);
		contactDetailsDto.setEmailId("sample@test-mail.com");
		contactDetailsDto.setMobileNumber("76902211");
		return contactDetailsDto;
	}

}

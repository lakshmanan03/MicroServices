package com.bfa.investment.ifast.dto;

import com.bfa.util.AMLVerificationStatus;

public class IFastResponse<T> {

	private Object additionalErrorInfo;

	private AMLVerificationStatus amlVerificationStatus;

	public AMLVerificationStatus getAmlVerificationStatus() {
		return amlVerificationStatus;
	}

	public void setAmlVerificationStatus(AMLVerificationStatus amlVerificationStatus) {
		this.amlVerificationStatus = amlVerificationStatus;
	}

	private IFastServerStatus serverStatus;

	public IFastServerStatus getServerStatus() {
		return this.serverStatus;
	}

	public void setServerStatus(IFastServerStatus serverStatus) {
		this.serverStatus = serverStatus;
	}

	private T data;

	public T getData() {
		return this.data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Object getAdditionalErrorInfo() {
		return additionalErrorInfo;
	}

	public void setAdditionalErrorInfo(Object additionalErrorInfo) {
		this.additionalErrorInfo = additionalErrorInfo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("IFastResponse [additionalErrorInfo=");
		builder.append(additionalErrorInfo);
		builder.append(", amlVerificationStatus=");
		builder.append(amlVerificationStatus);
		builder.append(", serverStatus=");
		builder.append(serverStatus);
		builder.append(", data=");
		builder.append(data);
		builder.append("]");
		return builder.toString();
	}

	

	 
	
	
}

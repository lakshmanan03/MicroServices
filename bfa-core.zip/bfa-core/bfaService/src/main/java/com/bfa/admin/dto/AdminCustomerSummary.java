package com.bfa.admin.dto;

import java.util.List;

import com.bfa.common.entity.CustomerAssessmentDetails;
import com.bfa.investment.dto.CustomerInvestmentObjectiveDTO;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.PortfolioTransaction;
import com.bfa.investment.ifast.dto.DPMSHoldingsSummary;

public class AdminCustomerSummary {

	private AdminCustomerDetails customerDetails;
	private List<CustomerAssessmentDetails> customerAssessmentDetails;
	private DPMSHoldingsSummary dpmsHolding;
	private List<AdminCustomerPortfolioDetailsSummary> portfolios;
	private CustomerInvestmentObjective customerInvestmentObjective;
	private PortfolioTransaction portfolioTransaction;
	private Double investmentPortfolioValue;
	private Double investmentCashAccountBalance;
	private Double wisesaverPortfolioValue;
	private Double wisesaverCashAccountBalance;
	private Double overallPortfolioValue;
	private Double overallCashAccountBalance;

	

	public List<AdminCustomerPortfolioDetailsSummary> getPortfolios() {
		return portfolios;
	}

	public void setPortfolios(List<AdminCustomerPortfolioDetailsSummary> portfolios) {
		this.portfolios = portfolios;
	}
	
	public PortfolioTransaction getPortfolioTransaction() {
		return portfolioTransaction;
	}

	public void setPortfolioTransaction(PortfolioTransaction portfolioTransaction) {
		this.portfolioTransaction = portfolioTransaction;
	}

	public AdminCustomerDetails getCustomerDetails() {
		return customerDetails;
	}

	public void setCustomerDetails(AdminCustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}

	public List<CustomerAssessmentDetails> getCustomerAssessmentDetails() {
		return customerAssessmentDetails;
	}

	public void setCustomerAssessmentDetails(List<CustomerAssessmentDetails> customerAssessmentDetails) {
		this.customerAssessmentDetails = customerAssessmentDetails;
	}

	public DPMSHoldingsSummary getDpmsHolding() {
		return dpmsHolding;
	}

	public void setDpmsHolding(DPMSHoldingsSummary dpmsHolding) {
		this.dpmsHolding = dpmsHolding;
	}

	public CustomerInvestmentObjective getCustomerInvestmentObjective() {
		return customerInvestmentObjective;
	}

	public void setCustomerInvestmentObjective(CustomerInvestmentObjective customerInvestmentObjective) {
		this.customerInvestmentObjective = customerInvestmentObjective;
	}

	public Double getInvestmentPortfolioValue() {
		return investmentPortfolioValue;
	}

	public void setInvestmentPortfolioValue(Double investmentPortfolioValue) {
		this.investmentPortfolioValue = investmentPortfolioValue;
	}

	public Double getInvestmentCashAccountBalance() {
		return investmentCashAccountBalance;
	}

	public void setInvestmentCashAccountBalance(Double investmentCashAccountBalance) {
		this.investmentCashAccountBalance = investmentCashAccountBalance;
	}

	public Double getWisesaverPortfolioValue() {
		return wisesaverPortfolioValue;
	}

	public void setWisesaverPortfolioValue(Double wisesaverPortfolioValue) {
		this.wisesaverPortfolioValue = wisesaverPortfolioValue;
	}

	public Double getWisesaverCashAccountBalance() {
		return wisesaverCashAccountBalance;
	}

	public void setWisesaverCashAccountBalance(Double wisesaverCashAccountBalance) {
		this.wisesaverCashAccountBalance = wisesaverCashAccountBalance;
	}

	public Double getOverallPortfolioValue() {
		return overallPortfolioValue;
	}

	public void setOverallPortfolioValue(Double overallPortfolioValue) {
		this.overallPortfolioValue = overallPortfolioValue;
	}

	public Double getOverallCashAccountBalance() {
		return overallCashAccountBalance;
	}

	public void setOverallCashAccountBalance(Double overallCashAccountBalance) {
		this.overallCashAccountBalance = overallCashAccountBalance;
	}

	
	
}

/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.Base64;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.application.core.BundleMailChimpRequest;
import com.bfa.application.core.MailChimpBundleRequestParameters;
import com.bfa.application.core.MailChimpModel;
import com.bfa.application.corporate.CoporateLeadGenMergeFields;
import com.bfa.application.corporate.CorporateLeadGenRequest;
import com.bfa.application.corporate.CorporateLeadGenModel;
import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.promotion.model.PromotionBundleModel;
import com.bfa.service.BundleService;
import com.bfa.service.MailChimpService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

/**
 * @author pradheep
 *
 */
public class MailChimpServiceImpl extends DiscoveryHelper implements MailChimpService {

	private final String apikey_prefix = "apikey:";

	@Autowired
	private Environment environment;

	@Autowired
	private ApplicationLoggerBean applicationLogger;

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@Autowired
	private BFAHttpClient bfaHttpClient;

	// Based on the discussion with Grace the default status of the Bundle
	// promotion would be subscribed //
	private final String subscribed = "subscribed";

	@Autowired
	private SecurityConstants constants;

	private Gson gson = new Gson();

	private Logger getLogger() {
		return this.applicationLogger.getLogBean(this.getClass());
	}

	@Override
	public void subscribeForMarketingEmails(String firstName, String lastName, String emailAddress, long initialDelay) {
		UpdateMailSubscriptionThread updateMailSubscriptionThread = new UpdateMailSubscriptionThread(firstName,
				lastName, emailAddress);
		threadPoolTaskExecutor.execute(updateMailSubscriptionThread, initialDelay);
	}

	private String getMailChimpSubscriptionBody(MailChimpModel obj, String ipaddress) {
		getLogger().info("Constructing the request body for making the mailchimp request body");
		if (obj instanceof PromotionBundleModel) {
			PromotionBundleModel model = (PromotionBundleModel) obj;
			getLogger().info("Printing the data " + model.toString());
			BundleMailChimpRequest bundleMailChimpRequest = new BundleMailChimpRequest();
			MailChimpBundleRequestParameters requestParameters = new MailChimpBundleRequestParameters();
			requestParameters.setDOB(model.getDateOfBirth());
			requestParameters.setFNAME(model.getFirstName());
			requestParameters.setGENDER(model.getGender());
			requestParameters.setLNAME(model.getLastName());
			requestParameters.setPHONE(model.getContactNumber());
			bundleMailChimpRequest.setStatus(subscribed);
			bundleMailChimpRequest.setEmail_address(model.getEmailAddress());
			bundleMailChimpRequest.setEmail_type("html");
			bundleMailChimpRequest.setMerge_fields(requestParameters);
			bundleMailChimpRequest.setIp_signup(ipaddress);
			String requestBody = gson.toJson(bundleMailChimpRequest);
			getLogger().info("Printing the mail chimp request body- bundle model " + requestBody);
			return requestBody;
		}
		else if(obj instanceof CorporateLeadGenRequest){
			/* BFA-1840 API Enhancements for Moneyowl Corporate Page */
			CorporateLeadGenRequest corporateModel = (CorporateLeadGenRequest) obj;
			
			CoporateLeadGenMergeFields mergeFields = new CoporateLeadGenMergeFields();			
			mergeFields.setCOMPANY(corporateModel.getCompanyName());
			mergeFields.setCOMSIZE(corporateModel.getCompanySize());
			mergeFields.setFNAME(corporateModel.getFirstName());
			mergeFields.setJOB(corporateModel.getJobFunction());
			mergeFields.setLNAME(corporateModel.getLastName());
			mergeFields.setPHONE(corporateModel.getPhoneNumber());
			mergeFields.setEMAIL(corporateModel.getEmailAddress());
			
			CorporateLeadGenModel model = new CorporateLeadGenModel();
			model.setEmail_type("html");
			model.setEmail_address(corporateModel.getEmailAddress());
			model.setIp_signup(ipaddress);
			model.setStatus(subscribed);
			model.setMerge_fields(mergeFields);
			String requestBody = gson.toJson(model);
			getLogger().info("Printing the mail chimp request body- Corporate:" + requestBody);
			return requestBody;
		}
		return "";
	}

	private String getBaseURLForMailChimp(MailChimpModel model) {
		String apiBaseUrl = environment.getProperty("mailchimp.base.url");
		String subscriptionKey = "";
		/* Changes for BFA-1643 & BFA-1647 */
		if (model.getEnquiryType().toLowerCase().equals(BundleService.CHILD_BUNDLE_PRO_TYPE_ENQ)) {
			subscriptionKey = environment.getProperty("mailchimp.child.protection.bundle.subscription.key");
		} else if (model.getEnquiryType().toLowerCase().equals(BundleService.CHILD_BUNDLE_EDU_TYPE_ENQ)) {
			subscriptionKey = environment.getProperty("mailchimp.child.education.bundle.subscription.key");
		} else if (model.getEnquiryType().toLowerCase().equals(BundleService.RETIREMENT_BUNDLE_TYPE_ENQ)) {
			/* BFA-1701 */
			subscriptionKey = environment.getProperty("mailchimp.retirement.bundle.subscription.key");
		} else if(model.getEnquiryType().equals(ApplicationConstants.CORPORATE_BIZ)){
			subscriptionKey = environment.getProperty("mailchimp.corporate.subscription.key");
		}
		else if (model.getEnquiryType().toLowerCase().contains("adult")) {
			subscriptionKey = environment.getProperty("mailchimp.adult.bundle.subscription.key");
		}		
		apiBaseUrl = apiBaseUrl.replace("<key>", subscriptionKey);
		getLogger().info("Printing the API Base URL " + apiBaseUrl);
		return apiBaseUrl;
	}

	private String getHeaderForMailChimpCall() {
		// -- Construct the header for the API call -- //
		String apiKey = apikey_prefix + environment.getProperty("mailchimp.apikey");
		String authHeader = "Basic " + Base64.getEncoder().encodeToString(apiKey.getBytes());
		getLogger().info("Printing the header " + authHeader);
		return authHeader;
	}

	private void setEnvironmentSpace() {
		super.setEnvironment(environment);
		loadSecurityHeader(constants.TOKEN_NAME);
	}

	class UpdateMailSubscriptionThread implements Runnable {

		private String firstName;
		private String lastName;
		private String email;

		private final long twoMinutes = 2 * 60 * 1000L;

		public UpdateMailSubscriptionThread(String firstName, String lastName, String email) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.email = email;
		}

		@Override
		public void run() {
			getLogger().info("--Waiting for the bundle subscription in the mailchimp -- ");
			try {
				// This sleep is introduced so that the mail chimp registers for
				// the bundle packages first. Then the mail subscription will be
				// done later.
				Thread.sleep(twoMinutes);
				getLogger().info("Updating the marketing email subscriptions ");
			} catch (InterruptedException e) {
				getLogger().error("Error while waiting - Update marketing email subscription ", e);
			}
			receiveMarketingMaterials();
		}

		private void receiveMarketingMaterials() {
			setEnvironmentSpace();
			getLogger().info(this.firstName + " Intrested in marketing materials");
			int delay = 0;
			String jobName = "update-marketing-notifications";
			String requestBody = getRequestBody(this.firstName, this.lastName, this.email);
			final String apiName = "/api/mailinglist/subscribe";
			String baseUrl = getBaseUrl(ServiceNames.PRODUCT_MICROSERVICE) + apiName;
			baseUrl = removePortNumbers(baseUrl);
			addJobToQueue(baseUrl, requestBody, jobName, delay);
		}

		private String getRequestBody(String firstName, String lastName, String emailAddress) {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("emailAddress", emailAddress);
			map.put("firstName", firstName);
			map.put("lastName", lastName);
			return gson.toJson(map);
		}
	}

	@Override
	public void subscribeInMailChimp(MailChimpModel obj, String ipaddress) {
		getLogger().info("--- Making a subscription in the mail chimp --- ");
		String requestBody = getMailChimpSubscriptionBody(obj, ipaddress);
		String URL = getBaseURLForMailChimp(obj);
		getLogger().info("Printing the base URL for debugging" + URL);
		getLogger().info("Printing the request body for debugging" + requestBody);
		String authHeader = getHeaderForMailChimpCall();
		HashMap<String, String> header = new HashMap<String, String>();
		header.put("Authorization", authHeader);
		header.put("Content-Type", "application/json");
		BFAHttpResponse response = bfaHttpClient.doPostCall(requestBody, URL, header, null);
		getLogger().info(
				"Printing the response code " + response.getResponseCode() + " Body :" + response.getResponseBody());
		if (response.getResponseCode() == 200) {
			getLogger().info("Successfully made the API call to mail chimp ");
		} else {
			getLogger().error("Error in making the mailchimp API call for : ");
		}
	}

}

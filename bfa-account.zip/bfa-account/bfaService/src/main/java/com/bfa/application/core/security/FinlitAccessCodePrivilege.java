/**
 * 
 */
package com.bfa.application.core.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep
 * @since Robo3-lite
 */
@Entity
@Table(name="finlit_access_code_privilege")
public class FinlitAccessCodePrivilege {	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="finlit_access_code_id")
	private Integer finlitAccessCodeId;
	
	@Column(name="privilege_id")
	private Integer privilegeId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFinlitAccessCodeId() {
		return finlitAccessCodeId;
	}

	public void setFinlitAccessCodeId(Integer finlitAccessCodeId) {
		this.finlitAccessCodeId = finlitAccessCodeId;
	}

	public Integer getPrivilegeId() {
		return privilegeId;
	}

	public void setPrivilegeId(Integer privilegeId) {
		this.privilegeId = privilegeId;
	}	
}

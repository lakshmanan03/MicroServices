package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.product.ProductList;

public class UpdateCustomerSelectedProductsRequest {
	
	private String customerId;
	
	private String enquiryId;

	private List<ProductList> selectedProducts;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(String enquiryId) {
		this.enquiryId = enquiryId;
	}

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}	

}

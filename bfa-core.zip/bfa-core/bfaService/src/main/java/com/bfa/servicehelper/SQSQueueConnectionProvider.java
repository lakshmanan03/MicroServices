/**
 * 
 */
package com.bfa.servicehelper;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

/**
 * Manager to establish the connection to a AWS SQS Queue.
 * @author pradheep.p
 *
 */
public class SQSQueueConnectionProvider {	
	
	public AmazonSQS initConnection(String accessKey,String secretKey){
		/*String accessKey = "AKIAJV3LWHKLA2U4JRQA"
		String secretKey = "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"*/
		BasicAWSCredentials bAWSc = new BasicAWSCredentials(accessKey, secretKey);
		final AmazonSQS sqs = AmazonSQSClientBuilder.standard().withRegion(Regions.AP_SOUTH_1)
				.withCredentials(new AWSStaticCredentialsProvider(bAWSc)).build();
		System.out.println("Initializing the connection to SQS" + sqs.toString());
		return sqs;
	}
}

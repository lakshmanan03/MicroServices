/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.core.PersistCustomerDetails;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.ResponseList;
import com.bfa.service.AccountsService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ServiceNames;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author pradheep
 *
 */
public class CreateHubspotContactService {
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	private PersistCustomerDetails discoveryHelper;
	
	@Autowired
	private BFAHttpClient bfaHttpClient;
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private AccountsService accountsServiceImpl;	
	
	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(getClass());
	}
	
	@PostConstruct
	public void init(){
		discoveryHelper.setEnvironment(environment);
		objectMapper.setSerializationInclusion(Include.NON_NULL);
	}

	/**
	 * This method helps in creating a contact in hubspot with basic
	 * information.
	 * 
	 * Use: This is called when the user request for a promo code for
	 * comprehensive journey.
	 * 
	 * This is a asynchronous call to avoid blocking the API request.
	 * 
	 * @param customerObj
	 */
	@Async
	public Integer updateCustomerInformationInHubspot(Customer customerObj, JourneyTypeEnum journeyType) {
		Integer hubspotReference = 0;
		try {
			getLogger().info("Trying to create a contact in hubspot [Customer Id]:" + customerObj.getId()
					+ ", Journey Type:" + journeyType.getValue());
			//-- Build authorities for service call --//
			List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			authorities.add(new BFAGrandtedAuthority(SecurityConstants.ROLE_USER));
			authorities.add(new BFAGrandtedAuthority("ROLE_SERVICE_CALL"));
			// -- Copy the necessary properties to customer object -- //
			Customer custObj = new Customer();
			custObj.setEmail(customerObj.getEmail());
			custObj.setMobileNumber(customerObj.getMobileNumber());
			custObj.setSurName(customerObj.getSurName());
			custObj.setGivenName(customerObj.getGivenName());
			custObj.setId(customerObj.getId());
			// -------------------------------------------------------//			
			BFAHttpResponse response = makeHTTPPostCall(objectMapper.writeValueAsString(custObj), authorities,
					ServiceNames.CRM_MICROSERVICE, APIConstants.CREATE_UPDATE_CONTACT_IN_HUBSPOT,
					"journeyType=" + journeyType.getValue());
			if (null != response && null != response.getResponseBody()) {
				getLogger().info("Sucessfully made entry in hubspot " + response.getResponseBody());
				ResponseList responseListObj = objectMapper.readValue(response.getResponseBody(), ResponseList.class);
				if (responseListObj.getResponseMessage().getResponseCode() == ErrorCodes.SUCCESSFUL_RESPONSE) {
					Object obj = responseListObj.getObjectList().get(0);
					HashMap hubspotDataMap = (HashMap) obj;
					String value = hubspotDataMap.get(ApplicationConstants.HUBSPOT_REFERENCE).toString();
					if (!value.isEmpty()) {
						hubspotReference = Integer.parseInt(value);
						customerObj.setHubspotReference(hubspotReference);
						accountsServiceImpl.updateCustomer(customerObj);
						getLogger().info("Updated the hubspot reference :" + hubspotReference + " for [Customer ID]:"
								+ customerObj.getId() + " Successfully");
					}
				} else {
					getLogger().error("API call to CRM " + APIConstants.CREATE_UPDATE_CONTACT_IN_HUBSPOT
						+ " failed, [Customer Id]:" + customerObj.getId());
				}
			} else {				
					getLogger().error("Unable to get a response from " + APIConstants.CREATE_UPDATE_CONTACT_IN_HUBSPOT
							+ " [Customer Id]:" + customerObj.getId());
				}
			return hubspotReference;
		} catch (Exception err) {
			getLogger().error("Error while creating a hubspot contact", err);
		}
		return hubspotReference;
	}
	
	public BFAHttpResponse makeHTTPPostCall(String requestBody, List<GrantedAuthority> authorities, String serviceName,
			String APIName, String queryParam) {
		String baseUrl = discoveryHelper.getBaseUrl(serviceName) + APIName;
		if (null != queryParam && !queryParam.isEmpty()) {
			baseUrl = baseUrl + "?" + queryParam;
		}
		baseUrl = discoveryHelper.removePortNumbers(baseUrl);
		discoveryHelper.loadSecurityHeader(SecurityConstants.TOKEN_NAME, authorities);
		getLogger().info("Header:" + discoveryHelper.header.get(SecurityConstants.TOKEN_NAME));
		getLogger().info("Request body:" + requestBody);
		getLogger().info("Printing the base URL" + baseUrl);
		return bfaHttpClient.doPostCall(requestBody, baseUrl, discoveryHelper.header, null);
	}
}

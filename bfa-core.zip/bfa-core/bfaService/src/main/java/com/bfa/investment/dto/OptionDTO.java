package com.bfa.investment.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class OptionDTO {
	private int id;
	private String text;
	private String description;
    private String optionType;
    private Integer questionOptionId;
    private String customUserInput;
    private Object additionalInfo;
    private int listingOrder;
    
    
    public Object getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(Object additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	public String getCustomUserInput() {
		return customUserInput;
	}
	public void setCustomUserInput(String customUserInput) {
		this.customUserInput = customUserInput;
	}
	public String getOptionType() {
		return optionType;
	}
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}
	public Integer getQuestionOptionId() {
		return questionOptionId;
	}
	public void setQuestionOptionId(Integer questionOptionId) {
		this.questionOptionId = questionOptionId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	public int getListingOrder() {
		return listingOrder;
	}
	public void setListingOrder(int listingOrder) {
		this.listingOrder = listingOrder;
	}
	
}

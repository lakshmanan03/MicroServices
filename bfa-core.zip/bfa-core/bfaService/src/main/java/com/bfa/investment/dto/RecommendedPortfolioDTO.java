package com.bfa.investment.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bfa.investment.entity.AnnualFeeDetail;
import com.bfa.investment.entity.RiskProfile;
import com.bfa.investment.entity.Sector;
import com.bfa.investment.ifast.dto.DPMSPortfolio;
import com.fasterxml.jackson.annotation.JsonFormat;

public class RecommendedPortfolioDTO {

	private Integer investmentPeriod;
	private Double projectedValue;
	private String portfolioId;
	private Integer customerPortfolioId;
	private String portfolioName;
	private String tenure;
	private Double projectedReturnsHighEnd;
	private Double projectedReturnsMedian;
	private String reviewedProjectedReturnsMedian;
	private Double projectedReturnsLowEnd;
	private String portfolioType;
	private String portfolioStatus;
	private String portfolioMaturityYear;
	private Double initialInvestment;
	private double monthlyInvestment;
	private Double accountBalance;
	private String referenceCode;
	private RiskProfile riskProfile;
	List<AnnualFeeDetail> feeDetails;
	private Double capitalInvested;
	private PendingRequestDTO pendingRequestDTO;
	private PortfolioActionBean entitlements;
	private Boolean showTotalReturn;
	private DPMSPortfolio dPMSPortfolio;
	private String accountCreatedDate;
	private String fundingTypeValue;
	private Integer fundingTypeId;
	private Integer enquiryId;
	
	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	/**
	 * @return the fundingTypeId
	 */
	public Integer getFundingTypeId() {
		return fundingTypeId;
	}

	/**
	 * @param fundingTypeId the fundingTypeId to set
	 */
	public void setFundingTypeId(Integer fundingTypeId) {
		this.fundingTypeId = fundingTypeId;
	}

	public String getFundingTypeValue() {
		return fundingTypeValue;
	}

	public void setFundingTypeValue(String fundingTypeValue) {
		this.fundingTypeValue = fundingTypeValue;
	}

	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date statementCreatedDate;
	/**
	 * @return the dPMSPortfolio
	 */
	public DPMSPortfolio getdPMSPortfolio() {
		return dPMSPortfolio;
	}

	public String getAccountCreatedDate() {
		return accountCreatedDate;
	}

	public void setAccountCreatedDate(String accountCreatedDate) {
		this.accountCreatedDate = accountCreatedDate;
	}

	public Date getStatementCreatedDate() {
		return statementCreatedDate;
	}

	public void setStatementCreatedDate(Date statementCreatedDate) {
		this.statementCreatedDate = statementCreatedDate;
	}

	/**
	 * @param dPMSPortfolio the dPMSPortfolio to set
	 */
	public void setdPMSPortfolio(DPMSPortfolio dPMSPortfolio) {
		this.dPMSPortfolio = dPMSPortfolio;
	}

	public Boolean getShowTotalReturn() {
		return showTotalReturn;
	}

	public void setShowTotalReturn(Boolean showTotalReturn) {
		this.showTotalReturn = showTotalReturn;
	}

	/**
	 * @return the pendingRequestDTO
	 */
	public PendingRequestDTO getPendingRequestDTO() {
		return pendingRequestDTO;
	}

	/**
	 * @param pendingRequestDTO the pendingRequestDTO to set
	 */
	public void setPendingRequestDTO(PendingRequestDTO pendingRequestDTO) {
		this.pendingRequestDTO = pendingRequestDTO;
	}

	/**
	 * @return the entitlements
	 */
	public PortfolioActionBean getEntitlements() {
		return entitlements;
	}

	/**
	 * @param entitlements the entitlements to set
	 */
	public void setEntitlements(PortfolioActionBean entitlements) {
		this.entitlements = entitlements;
	}

	private List<Sector> sectorAllocations;
	
	private ArrayList<FundDTO> funds = new ArrayList<>();


	public Integer getInvestmentPeriod() {
		return investmentPeriod;
	}

	public List<AnnualFeeDetail> getFeeDetails() {
		return feeDetails;
	}

	public void setFeeDetails(List<AnnualFeeDetail> feeDetails) {
		this.feeDetails = feeDetails;
	}

	public ArrayList<FundDTO> getFunds() {
		return funds;
	}

	public void setFunds(ArrayList<FundDTO> funds) {
		this.funds = funds;
	}

	public List<Sector> getSectorAllocations() {
		return sectorAllocations;
	}

	/**
	 * @return the customerPortfolioId
	 */
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	/**
	 * @param customerPortfolioId the customerPortfolioId to set
	 */
	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

	public void setSectorAllocations(List<Sector> sectorAllocations) {
		this.sectorAllocations = sectorAllocations;
	}

	public void setInvestmentPeriod(Integer investmentPeriod) {
		this.investmentPeriod = investmentPeriod;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public RiskProfile getRiskProfile() {
		return riskProfile;
	}

	public void setRiskProfile(RiskProfile riskProfile) {
		this.riskProfile = riskProfile;
	}

	public Double getInitialInvestment() {
		return initialInvestment;
	}

	public void setInitialInvestment(Double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}

	public double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public String getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(String portfolioType) {
		this.portfolioType = portfolioType;
	}

	public String getPortfolioMaturityYear() {
		return portfolioMaturityYear;
	}

	public void setPortfolioMaturityYear(String portfolioMaturityYear) {
		this.portfolioMaturityYear = portfolioMaturityYear;
	}

	public Double getProjectedReturnsHighEnd() {
		return projectedReturnsHighEnd;
	}

	public void setProjectedReturnsHighEnd(Double projectedReturnsHighEnd) {
		this.projectedReturnsHighEnd = projectedReturnsHighEnd;
	}

	public Double getProjectedReturnsMedian() {
		return projectedReturnsMedian;
	}

	public void setProjectedReturnsMedian(Double projectedReturnsMedian) {
		this.projectedReturnsMedian = projectedReturnsMedian;
	}

	
	public String getReviewedProjectedReturnsMedian() {
		return reviewedProjectedReturnsMedian;
	}

	public void setReviewedProjectedReturnsMedian(String reviewedProjectedReturnsMedian) {
		this.reviewedProjectedReturnsMedian = reviewedProjectedReturnsMedian;
	}

	public Double getProjectedReturnsLowEnd() {
		return projectedReturnsLowEnd;
	}

	public void setProjectedReturnsLowEnd(Double projectedReturnsLowEnd) {
		this.projectedReturnsLowEnd = projectedReturnsLowEnd;
	}

	public Double getProjectedValue() {
		return projectedValue;
	}

	public void setProjectedValue(Double projectedValue) {
		this.projectedValue = projectedValue;
	}

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getTenure() {
		return tenure;
	}

	public void setTenure(String tenure) {
		this.tenure = tenure;
	}

	public Double getCapitalInvested() {
		return capitalInvested;
	}

	public void setCapitalInvested(Double capitalInvested) {
		this.capitalInvested = capitalInvested;
	}

	/**
	 * @return the accountBalance
	 */
	public Double getAccountBalance() {
		return accountBalance;
	}
	/**
	 * @param accountBalance the accountBalance to set
	 */
	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}
	/**
	 * @return the referenceCode
	 */
	public String getReferenceCode() {
		return referenceCode;
	}
	/**
	 * @param referenceCode the referenceCode to set
	 */
	public void setReferenceCode(String referenceCode) {
		this.referenceCode = referenceCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RecommendedPortfolioDTO [investmentPeriod=");
		builder.append(investmentPeriod);
		builder.append(", projectedValue=");
		builder.append(projectedValue);
		builder.append(", portfolioId=");
		builder.append(portfolioId);
		builder.append(", customerPortfolioId=");
		builder.append(customerPortfolioId);
		builder.append(", portfolioName=");
		builder.append(portfolioName);
		builder.append(", tenure=");
		builder.append(tenure);
		builder.append(", projectedReturnsHighEnd=");
		builder.append(projectedReturnsHighEnd);
		builder.append(", projectedReturnsMedian=");
		builder.append(projectedReturnsMedian);
		builder.append(", reviewedProjectedReturnsMedian=");
		builder.append(reviewedProjectedReturnsMedian);
		builder.append(", projectedReturnsLowEnd=");
		builder.append(projectedReturnsLowEnd);
		builder.append(", portfolioType=");
		builder.append(portfolioType);
		builder.append(", portfolioStatus=");
		builder.append(portfolioStatus);
		builder.append(", portfolioMaturityYear=");
		builder.append(portfolioMaturityYear);
		builder.append(", initialInvestment=");
		builder.append(initialInvestment);
		builder.append(", monthlyInvestment=");
		builder.append(monthlyInvestment);
		builder.append(", accountBalance=");
		builder.append(accountBalance);
		builder.append(", referenceCode=");
		builder.append(referenceCode);
		builder.append(", riskProfile=");
		builder.append(riskProfile);
		builder.append(", feeDetails=");
		builder.append(feeDetails);
		builder.append(", capitalInvested=");
		builder.append(capitalInvested);
		builder.append(", pendingRequestDTO=");
		builder.append(pendingRequestDTO);
		builder.append(", entitlements=");
		builder.append(entitlements);
		builder.append(", showTotalReturn=");
		builder.append(showTotalReturn);
		builder.append(", dPMSPortfolio=");
		builder.append(dPMSPortfolio);
		builder.append(", accountCreatedDate=");
		builder.append(accountCreatedDate);
		builder.append(", fundingTypeValue=");
		builder.append(fundingTypeValue);
		builder.append(", fundingTypeId=");
		builder.append(fundingTypeId);
		builder.append(", enquiryId=");
		builder.append(enquiryId);
		builder.append(", statementCreatedDate=");
		builder.append(statementCreatedDate);
		builder.append(", sectorAllocations=");
		builder.append(sectorAllocations);
		builder.append(", funds=");
		builder.append(funds);
		builder.append("]");
		return builder.toString();
	}
	

}

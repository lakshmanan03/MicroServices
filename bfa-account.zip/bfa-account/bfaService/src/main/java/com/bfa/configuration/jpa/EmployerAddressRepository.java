package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.EmployerAddress;

public interface EmployerAddressRepository extends CrudRepository<EmployerAddress, String> {
	
	Optional<EmployerAddress>  findFirstByEmployerId(Integer employerId);
	

}

package com.bfa.comprehensive.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AssetsInvestmentSet implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer assetId;

	@JsonIgnore
	private Integer customerId;
	
	@JsonIgnore
	private Integer enquiryId;
	
    private String typeOfInvestment;
    
    private Double investmentAmount;


	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getTypeOfInvestment() {
		return typeOfInvestment;
	}

	public void setTypeOfInvestment(String typeOfInvestment) {
		this.typeOfInvestment = typeOfInvestment;
	}

	public Double getInvestmentAmount() {
		return investmentAmount;
	}

	public void setInvestmentAmount(Double investmentAmount) {
		this.investmentAmount = investmentAmount;
	}
	
	public Integer getAssetId() {
		return assetId;
	}

	public void setAssetId(Integer assetId) {
		this.assetId = assetId;
	}

	@Override
	public String toString() {
		return "AssetsInvestmentSet [assetId=" + assetId + ", customerId=" + customerId + ", enquiryId=" + enquiryId
				+ ", typeOfInvestment=" + typeOfInvestment + ", investmentAmount=" + investmentAmount + "]";
	}

}

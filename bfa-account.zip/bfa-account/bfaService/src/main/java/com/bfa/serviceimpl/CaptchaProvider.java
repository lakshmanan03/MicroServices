/**
 * 
 */
package com.bfa.serviceimpl;

/**
 * @author pradheep.p
 *
 */
public class CaptchaProvider {
	
	private char data[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u',
			'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'S',
			'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '2', '3', '4', '5', '6', '7', '8', '9' };

	public String getCaptchaString() {
		String captcha = "";
		for (int c = 0; c < 5; c++) {
			Double d = new Double(Math.random() * data.length - 1);
			int index = d.intValue();
			captcha = captcha + data[index];
		}
		return captcha;
	}
}

/**
 * 
 */
package com.bfa.request.entity;

import com.bfa.common.dto.ComprehensiveInsurancePlanningDTO;
import com.bfa.common.dto.ComprehensiveRetirementPlanningDTO;
import com.bfa.common.dto.HospitalPlanListDTO;

public class ComprehensiveInsuranceNeedsPostResponse {
	
	ComprehensiveInsurancePlanningDTO comprehensiveInsurancePlanningDTO;
	
	ComprehensiveRetirementPlanningDTO comprehensiveRetirementPlanningDTO;
	
	HospitalPlanListDTO hospitalPlanListDTO;

	public HospitalPlanListDTO getHospitalPlanListDTO() {
		return hospitalPlanListDTO;
	}

	public void setHospitalPlanListDTO(HospitalPlanListDTO hospitalPlanListDTO) {
		this.hospitalPlanListDTO = hospitalPlanListDTO;
	}

	public ComprehensiveInsurancePlanningDTO getComprehensiveInsurancePlanningDTO() {
		return comprehensiveInsurancePlanningDTO;
	}

	public void setComprehensiveInsurancePlanningDTO(ComprehensiveInsurancePlanningDTO comprehensiveInsurancePlanningDTO) {
		this.comprehensiveInsurancePlanningDTO = comprehensiveInsurancePlanningDTO;
	}

	public ComprehensiveRetirementPlanningDTO getComprehensiveRetirementPlanningDTO() {
		return comprehensiveRetirementPlanningDTO;
	}

	public void setComprehensiveRetirementPlanningDTO(
			ComprehensiveRetirementPlanningDTO comprehensiveRetirementPlanningDTO) {
		this.comprehensiveRetirementPlanningDTO = comprehensiveRetirementPlanningDTO;
	}	

}

package com.bfa.application.core;

import com.bfa.util.ResponseMessage;

public class UpdateMobileNumberResponse  extends ResponseMessage {
	
	private boolean isUpdated;
	
	private String customerRef;
	
	public boolean isUpdated() {
		return isUpdated;
	}

	public void setUpdated(boolean isUpdated) {
		this.isUpdated = isUpdated;
	}

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}
}

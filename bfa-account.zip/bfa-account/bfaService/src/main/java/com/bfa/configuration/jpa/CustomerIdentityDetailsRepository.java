package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.CustomerIdentityDetails;

public interface CustomerIdentityDetailsRepository extends CrudRepository<CustomerIdentityDetails, String> {
	Optional<CustomerIdentityDetails>  findFirstBycustomer_id(Integer customerId);

}

package com.bfa.application.security;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

public class JWTAuthToken extends AbstractAuthenticationToken {
	private static final long serialVersionUID = 1L;
	private final Object principal;
	private Object details;

	Collection<GrantedAuthority> authorities;

	public JWTAuthToken(String jwtToken) {
		super(null);
		super.setAuthenticated(true);
		principal = jwtToken;
	}

	public Object getCredentials() {
		return "";
	}

	public Object getPrincipal() {
		return principal;
	}
	
	@Override
	public Collection<GrantedAuthority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Collection<GrantedAuthority> authorities) {
		this.authorities = authorities;
	}
}

package com.bfa.util;

public class DAOResponse {
	
	private boolean success;
	private String message;
	private Integer responseCode;
	private Object responseObject;
	private Exception exceptionObject;
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}
	public Object getResponseObject() {
		return responseObject;
	}
	public void setResponseObject(Object responseObject) {
		this.responseObject = responseObject;
	}
	public Exception getExceptionObject() {
		return exceptionObject;
	}
	public void setExceptionObject(Exception exceptionObject) {
		this.exceptionObject = exceptionObject;
	}
	
	
}

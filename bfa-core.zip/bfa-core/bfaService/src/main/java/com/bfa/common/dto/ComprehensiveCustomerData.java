package com.bfa.common.dto;

public class ComprehensiveCustomerData {
	
	private double totalLivingExpenses;
	
	private int longestDependencyYear;
	
	private double childEducationAmountTotal;
	
	private double incomeReplacement;
	
	private double totalLiabilities;
	
	private double coverageNeeded;
	
	private double existingCoverage;
	
	private double totalAssets;
	
	private double totalInvestment;
	
	private double coverageAmount;
	
	private double netAssets;
	
	private double homeMarketValue;
	

	public double getTotalLivingExpenses() {
		return totalLivingExpenses;
	}

	public void setTotalLivingExpenses(double totalLivingExpenses) {
		this.totalLivingExpenses = totalLivingExpenses;
	}

	public int getLongestDependencyYear() {
		return longestDependencyYear;
	}

	public void setLongestDependencyYear(int longestDependencyYear) {
		this.longestDependencyYear = longestDependencyYear;
	}

	public double getChildEducationAmountTotal() {
		return childEducationAmountTotal;
	}

	public void setChildEducationAmountTotal(double childEducationAmountTotal) {
		this.childEducationAmountTotal = childEducationAmountTotal;
	}

	public double getIncomeReplacement() {
		return incomeReplacement;
	}

	public void setIncomeReplacement(double incomeReplacement) {
		this.incomeReplacement = incomeReplacement;
	}

	public double getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(double totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public double getCoverageNeeded() {
		return coverageNeeded;
	}

	public void setCoverageNeeded(double coverageNeeded) {
		this.coverageNeeded = coverageNeeded;
	}

	public double getExistingCoverage() {
		return existingCoverage;
	}

	public void setExistingCoverage(double existingCoverage) {
		this.existingCoverage = existingCoverage;
	}

	public double getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(double totalAssets) {
		this.totalAssets = totalAssets;
	}

	public double getTotalInvestment() {
		return totalInvestment;
	}

	public void setTotalInvestment(double totalInvestment) {
		this.totalInvestment = totalInvestment;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public double getNetAssets() {
		return netAssets;
	}

	public void setNetAssets(double netAssets) {
		this.netAssets = netAssets;
	}

	public double getHomeMarketValue() {
		return homeMarketValue;
	}

	public void setHomeMarketValue(double homeMarketValue) {
		this.homeMarketValue = homeMarketValue;
	}
	
	

}

package com.bfa.investment.dto;

import com.bfa.common.entity.Occupation;
import com.bfa.insurance.core.EmploymentStatus;

public class CustomerEmploymentInfo {
	private EmploymentStatus employmentStatus;
	private Occupation occupation;
	private String otherOccupation;
	private EmployerDetailsDTO employerDetails;
	
	
	
	public String getOtherOccupation() {
		return otherOccupation;
	}
	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}
	public EmploymentStatus getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(EmploymentStatus employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	public Occupation getOccupation() {
		return occupation;
	}
	public void setOccupation(Occupation occupation) {
		this.occupation = occupation;
	}
	public EmployerDetailsDTO getEmployerDetails() {
		return employerDetails;
	}
	public void setEmployerDetails(EmployerDetailsDTO employerDetails) {
		this.employerDetails = employerDetails;
	}
	

	
}

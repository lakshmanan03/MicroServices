package com.bfa.investment.ifast.dto;

public class DPMSPortfolioAllocationDisplay {
	
	private String dpmsPortfolioId;
	private String updateDate;
	private String approvedDate;
	public String getDpmsPortfolioId() {
		return dpmsPortfolioId;
	}
	public void setDpmsPortfolioId(String dpmsPortfolioId) {
		this.dpmsPortfolioId = dpmsPortfolioId;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	
	
	

}

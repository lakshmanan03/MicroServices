/**
 * 
 */
package com.bfa.insurance.core;


import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
public class DependentMapping implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private int id;
	
	private int customerId;
	
	private int enquiryId;

	private String gender;

	private String relationship;

	private String age;

	private DependentProtectionNeeds dependentProtectionNeeds;

	public DependentProtectionNeeds getDependentProtectionNeeds() {
		return dependentProtectionNeeds;
	}

	public void setDependentProtectionNeeds(DependentProtectionNeeds dependentProtectionNeeds) {
		this.dependentProtectionNeeds = dependentProtectionNeeds;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}	

}

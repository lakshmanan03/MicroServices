/**
 * 
 */
package com.bfa.service;

import com.bfa.insurance.core.Customer;

/**
 * This class has the methods to be used for commuicating by Email or by SMS.
 * 
 * @author pradheep.p
 *
 */
public interface CommunicationService {
	
	public static String EMAIL_VERIFICATION_REQUEST_SUCCESSFUL = "Email verification request sent successfully";
	
	public static String WELCOME_EMAIL_SUCCESSFUL_COMPRE = "Welcome Email sent successfully";
	
	public static String EMAIL_VERIFICATION_REQUEST_FAILED = "Unable to initiate the email verification request";
	
	public static String WELCOME_EMAIL_FAILED = "Unable to initiate the welcome email";
	
	public static String EMAIL_VERIFICATION_REQUEST_FAILED_NO_SUCH_CUSTOMER = "The email address/mobile number you entered is already in use. Please login to your account.  If you did not create an account previously, please contact ClientSupport@moneyowl.com.sg for assistance.";
	
	public static String WELCOME_EMAIL_FAILED_NO_SUCH_CUSTOMER = "The email address/mobile number you entered is already in use. Please login to your account.  If you did not create an account previously, please contact ClientSupport@moneyowl.com.sg for assistance.";
	
	public static String ILLEGAL_ARGUMENTS = "Illegal arguments passed.";

	/**
	 * This method sends the email communication for the user to verify his
	 * email address. The email is sent based on mobile number or email address
	 * provided. These arguments are provided by the user during login
	 * procedure. BFA-1343
	 * 
	 * @param mobileNumber
	 * @param emailAddress
	 * 
	 *            Returns 1 if the email was resend using mobile number. 
	 *            Returns 2 if the email was resend using email address.
	 *            Returns -1 if the arguments passed where wrong.
	 *            Returns 0 if the user is not found.
	 */
	public Integer resendVerificationEmail(String mobileNumber, String emailAddress, String callBackUrl,String hostedServerName)
			throws Exception;
	
	public Integer sendWelcomeEmailComprehensive(String mobileNumber, String emailAddress, String callBackUrl,String hostedServerName)
			throws Exception;	
	
}

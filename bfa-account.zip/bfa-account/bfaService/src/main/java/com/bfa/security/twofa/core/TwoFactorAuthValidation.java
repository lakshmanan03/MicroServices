/**
 * 
 */
package com.bfa.security.twofa.core;

/**
 * @author pradheep
 *
 */
public class TwoFactorAuthValidation {	
	
	private Boolean isValidated = false;	
	
	private Integer returnCode;
	
	public Boolean getIsValidated() {
		return isValidated;
	}

	public void setIsValidated(Boolean isValidated) {
		this.isValidated = isValidated;
	}	

	public Integer getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}
	
}

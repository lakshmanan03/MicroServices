/**
 * 
 */
package com.bfa.application.core;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author pradheep
 *
 */
public class MailChimpModel {
	
	@NotBlank(message = "enquiry type cannot be blank")
	public String enquiryType;

	public String getEnquiryType() {
		return enquiryType;
	}

	public void setEnquiryType(String enquiryType) {
		this.enquiryType = enquiryType;
	}
	
}

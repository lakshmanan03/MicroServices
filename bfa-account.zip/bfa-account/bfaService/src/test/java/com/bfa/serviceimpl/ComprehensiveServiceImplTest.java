package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.reflect.Whitebox;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.bfa.application.core.PromoCode;
import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.ComprehensiveHouseHoldDTO;
import com.bfa.common.dto.ComprehensiveResult;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.comprehensive.core.ComprehensiveHouseHold;
import com.bfa.comprehensive.core.DependentEducationPreferences;
import com.bfa.comprehensive.core.DependentEntity;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;
import com.bfa.comprehensive.dto.InsuranceAgentCallback;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.dao.ComprehensiveDao;
import com.bfa.insurance.core.ComprehensiveDependentMapping;
import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;
import com.bfa.insurance.core.Customer;
import com.bfa.investment.account.dto.ComprehensivePricingDTO;
import com.bfa.investment.entity.ComprehensivePricing;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.entity.CustomerRiskAssessment;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.request.entity.ValidatePromoCodeRequest;
import com.bfa.util.ApplicationConstants;
import com.bfa.investment.entity.CustomerIFastAccount;


@RunWith(SpringRunner.class)
public class ComprehensiveServiceImplTest {
	
	@InjectMocks
	ComprehensiveServiceImpl comprehensiveServiceImpl;
	
//	@Autowired
//	ComprehensiveServiceImpl comprehensiveServiceImpl;
	
	@MockBean
	ComprehensiveEnquiryPreferencesHelper mComprehensiveEnquiryPreferencesHelper;
	
	@Mock
	ComprehensiveEndowmentPlanMapping mComprehensiveEndowmentPlanMapping;

	@MockBean
	private ComprehensiveDao mComprehensiveDAO;
	
	@MockBean
	private PromoCodeRepository mPromoCodeRepos;
	
	@MockBean
	private AccountsDao mAccountsDao;
	
	@Mock
	private UpdateCustomerBasicInfo mUpdateCustomerBasicInfo;
	
	@Mock
	private List<Object> mObjectList ;
	
	@Mock
	private Customer mCustomer;
	
	@Mock
	private PromoCode mPromoCode;
	
	@Mock
	private DependentEntity mDependentEntity;
	
	@Mock
	List<ComprehensiveEndowmentPlanMapping> mChildEndowmentPlanning;
	
	List<DependentEntity>dependentEntityList = new ArrayList<>();
	
	List<ComprehensiveEndowmentPlanMapping> childEndowmentPlanning = new ArrayList<>();
	
	@Rule
    public ExpectedException thrown = ExpectedException.none();
	
	@Mock
	CustomerIFastAccount mCustomerIfastAccountObj;
	
	@Mock
	List<Object> dbObjectList;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private ComprehensivePricing mComprehensivePricing;
	
	
	int enqId=1;
	
	int cusId=1;
	
	String hasEndowments = "2";
	
	String promoCodeCategory="COMPRE";
	
	String journeyType=ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE;
	
	@Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	 
    }

	@Test
	public void testUpdateCustomerBasicDetails() {
		when(mObjectList.isEmpty()).thenReturn(false);
		when(mObjectList.get(0)).thenReturn(mCustomer);
		when(mComprehensiveDAO.getObjectByHql("from Customer where id=1")).thenReturn(mObjectList);
		comprehensiveServiceImpl.updateCustomerBasicDetails(mUpdateCustomerBasicInfo, cusId);
	}
	
	@Test
	public void testRequestPromoCodeDetails(){
		when(mObjectList.isEmpty()).thenReturn(false);
		when(mObjectList.get(0)).thenReturn(mCustomer);
		when(mComprehensiveDAO.getObjectByHql("from Customer where id=1")).thenReturn(mObjectList);
		when(mPromoCodeRepos.findByCategoryAndIsDefault(promoCodeCategory, "Y")).thenReturn(mPromoCode);
		ComprehensiveResult response = comprehensiveServiceImpl.requestPromoCodeDetails(cusId, promoCodeCategory);
		assertNotNull(response);
	}
	
	@Test(expected = NullPointerException.class)
	public void testValidatePromoCodeByUser() {
		String str = "2015-03-31";
		String str1 = "2025-03-31";
		Date startDate = Date.valueOf(str);
		Date endDate = Date.valueOf(str1);
		ValidatePromoCodeRequest validatePromoCodeRequest = new ValidatePromoCodeRequest();
		validatePromoCodeRequest.setComprehensivePromoCodeToken("MOACCT");
		validatePromoCodeRequest.setEnquiryId(enqId);
		validatePromoCodeRequest.setPromoCodeCat("COMPRE");
		when(mPromoCodeRepos.findByCodeAndCategory("MOACCT", "COMPRE")).thenReturn(mPromoCode);
		when(mPromoCode.getStatus()).thenReturn("A");
		when(mPromoCode.getStartDate()).thenReturn(startDate);
		when(mPromoCode.getEndDate()).thenReturn(endDate);
		boolean response=comprehensiveServiceImpl.validatePromoCodeByUser(validatePromoCodeRequest, cusId);
		assertNotNull(response);
	}

	@Test(expected = NullPointerException.class)
	public void testGetCustomerBasicDetails() {
		when(mCustomer.getGivenName()).thenReturn("abc");
		when(mCustomer.getSurName()).thenReturn("s");
		when(mCustomer.getEmail()).thenReturn("abc@ntuc.com");
		when(mCustomer.getDobUpdatedBy()).thenReturn("Investment");
		when(mObjectList.get(0)).thenReturn(mCustomer);
		when(dbObjectList.get(0)).thenReturn(mCustomerIfastAccountObj);
		when(mComprehensiveDAO.getObjectByHql("from Customer where id=1")).thenReturn(mObjectList);
		when(mComprehensiveDAO.getObjectByHql("from CustomerIFastAccount where customer=1")).thenReturn(dbObjectList);
		BaseProfileDTO response=comprehensiveServiceImpl.getCustomerBasicDetails(cusId,journeyType);
		assertNotNull(response);
	}
	
	@Test
	public void testUpdateDependentsForInsuranceNeed() {

		ComprehensiveEndowmentPlanMapping endPlan = new ComprehensiveEndowmentPlanMapping();
		endPlan.setDependentId(1);
		endPlan.setEducationCourse("medical");
		endPlan.setEndowmentMaturityAmount(10000.0);
		endPlan.setEndowmentMaturityYears(10);
		endPlan.setLocation("singapore");
		endPlan.setEnquiryId(enqId);
		childEndowmentPlanning.add(endPlan);
		dependentEntityList.add(mDependentEntity);
		when(mDependentEntity.getId()).thenReturn(1);
		when(mComprehensiveDAO.getDependentDetails(cusId,enqId)).thenReturn(dependentEntityList);
		comprehensiveServiceImpl.updateDependentsForInsuranceNeed(childEndowmentPlanning, 1,enqId, hasEndowments);
	}

	@Test
	public void testUpdateDependentsForInsuranceNeedException() {
		when(mComprehensiveDAO.getDependentDetails(cusId,enqId)).thenThrow(new RuntimeException());
		comprehensiveServiceImpl.updateDependentsForInsuranceNeed(childEndowmentPlanning, 1, enqId,hasEndowments);
	}

	@Test
	public void testGenerateCustomerToken() {

		when(mCustomer.getEmail()).thenReturn("abc@ntuc.com");
		when(mCustomer.getGivenName()).thenReturn("abc");
		when(mObjectList.get(0)).thenReturn(mCustomer);
		when(mAccountsDao.getObjectsById(Customer.class, "id", cusId)).thenReturn(mObjectList);
		InsuranceAgentCallback response = comprehensiveServiceImpl.generateCustomerToken(1);
		assertNotNull(response);
	}
	
	@Test(expected=RuntimeException.class)
	public void testGenerateCustomerTokenException() {

		when(mCustomer.getGivenName()).thenThrow(new RuntimeException());
		when(mObjectList.get(0)).thenReturn(mCustomer);
		when(mAccountsDao.getObjectsById(Customer.class, "id", cusId)).thenReturn(mObjectList);
		InsuranceAgentCallback response = comprehensiveServiceImpl.generateCustomerToken(1);
		assertNotNull(response);
	}

	@Test(expected=DatabaseAccessException.class)
	public void testGetDependentEducationPreferences(){
		when(mComprehensiveDAO.getDependentEducationPreferences(enqId, cusId)).thenThrow(new DatabaseAccessException());
		comprehensiveServiceImpl.getDependentEducationPreferences(enqId, cusId);
	}
	
	@Test(expected=DatabaseAccessException.class)
	public void testGetDependentDetailList() {
		when(mComprehensiveDAO.getDependentDetails(cusId,enqId)).thenThrow(new DatabaseAccessException());
		comprehensiveServiceImpl.getDependentDetailList(cusId,enqId);
	}
	@Test(expected=DatabaseAccessException.class)
	public void testSaveChildEndowmentPlanDetails() {
		when(mChildEndowmentPlanning.isEmpty()).thenThrow(new DatabaseAccessException());
		comprehensiveServiceImpl.saveChildEndowmentPlanDetails(mChildEndowmentPlanning, hasEndowments, cusId);
	}
	
	@Test
	public void saveComprehensiveHouseHoldTest(){
		 
		 ComprehensiveHouseHold houseHoldEntiry = new ComprehensiveHouseHold();
		 houseHoldEntiry.setCustomerId(1);
		 houseHoldEntiry.setEnquiryId(1);
		 houseHoldEntiry.setHouseHoldIncome("500");
		 houseHoldEntiry.setNoOfYears(3);
		 
		 ComprehensiveHouseHoldDTO mockComprehensiveHouseHoldDTO = mock(ComprehensiveHouseHoldDTO.class);
		 mockComprehensiveHouseHoldDTO.setCustomerId(1);
		 
		 when(mComprehensiveDAO.getComprehensiveHouseHold(mockComprehensiveHouseHoldDTO.getCustomerId(),enqId)).thenReturn(houseHoldEntiry);
		 comprehensiveServiceImpl.saveComprehensiveHouseHold(mockComprehensiveHouseHoldDTO,enqId);
		 
		 verify(mComprehensiveDAO, times(1)).saveOrUpdateObject(houseHoldEntiry);
	}
	
	@Test
	public void saveComprehensiveHouseHoldTestNull(){
		 
		 ComprehensiveHouseHold houseHoldEntiry = new ComprehensiveHouseHold();
		 houseHoldEntiry.setCustomerId(1);
		 houseHoldEntiry.setEnquiryId(1);
		 houseHoldEntiry.setHouseHoldIncome("500");
		 houseHoldEntiry.setNoOfHouseholdMembers(2);
		 houseHoldEntiry.setNoOfYears(3);
		 
		 ComprehensiveHouseHoldDTO mockComprehensiveHouseHoldDTO = mock(ComprehensiveHouseHoldDTO.class);
		 mockComprehensiveHouseHoldDTO.setCustomerId(1);
		 
		 when(mComprehensiveDAO.getComprehensiveHouseHold(mockComprehensiveHouseHoldDTO.getCustomerId(),enqId)).thenReturn(null);
		 comprehensiveServiceImpl.saveComprehensiveHouseHold(mockComprehensiveHouseHoldDTO,enqId);
	}
	
	@Test
	public void getComprehensiveHouseHoldTest() {
		
		ComprehensiveHouseHold comprehensiveHouseHold = new ComprehensiveHouseHold();
		comprehensiveHouseHold.setCustomerId(1);
		comprehensiveHouseHold.setEnquiryId(1);
		comprehensiveHouseHold.setHouseHoldIncome("500");
		comprehensiveHouseHold.setNoOfYears(3);
		
		
		when(mComprehensiveDAO.getComprehensiveHouseHold(1,enqId)).thenReturn(comprehensiveHouseHold);
		ComprehensiveHouseHoldDTO response = comprehensiveServiceImpl.getComprehensiveHouseHold(1,enqId);
		
		assertNotNull(response);
	}
	
	@Test(expected = NullPointerException.class)
	public void getDependentDetailListTest(){
		
		List<DependentEntity> entityList = new ArrayList<DependentEntity>();
		
		DependentEntity dependentEntity1 = new DependentEntity();
		dependentEntity1.setCustomerId(1);
		dependentEntity1.setEnquiryId(1);
		dependentEntity1.setGender("male");
		
		DependentEntity dependentEntity2 = new DependentEntity();
		dependentEntity2.setCustomerId(2);
		dependentEntity2.setEnquiryId(2);
		dependentEntity2.setGender("female");
		
		entityList.add(dependentEntity1);
		entityList.add(dependentEntity2);
		
		when(mComprehensiveDAO.getDependentDetails(1,enqId)).thenReturn(entityList);
		List<DependentDTO> response = comprehensiveServiceImpl.getDependentDetailList(1,enqId);
		
		assertNotNull(response);
	}
	
	@Test
	public void updateCustomerBasicDetailsTest() throws Exception {
		
		final ComprehensiveServiceImpl spiedCompService = PowerMockito.spy(comprehensiveServiceImpl);
		
		UpdateCustomerBasicInfo updateCustomerBasicInfo = new UpdateCustomerBasicInfo();
		updateCustomerBasicInfo.setCustomerId(1);
		updateCustomerBasicInfo.setGender("male");
		updateCustomerBasicInfo.setDateOfBirth("10-09-1999");
		updateCustomerBasicInfo.setNationalityStatus("Singapoorean");
		
		Customer customer = new Customer();
		customer.setId(1);
		
		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		comprehensiveEnquiryDTO.setCustomerId(1);
		comprehensiveEnquiryDTO.setReportStatus("Submitted");
		
		ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = new ComprehensiveEnquiryPostResponse();
		comprehensiveEnquiryPostResponse.setComprehensiveEnquiry(comprehensiveEnquiryDTO);
	
		ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();
		comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);

		when(mComprehensiveEnquiryPreferencesHelper.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest)).thenReturn(comprehensiveEnquiryPostResponse);
		
		comprehensiveServiceImpl.updateCustomerBasicDetails(updateCustomerBasicInfo, 1);
	}
	
	@Test(expected = NullPointerException.class)
	public void saveDependentsTest(){
		
		List<ComprehensiveDependentMapping> dependentMappingList = new ArrayList<ComprehensiveDependentMapping>();
		
		ComprehensiveDependentMapping comprehensiveDependentMapping = new ComprehensiveDependentMapping();
		comprehensiveDependentMapping.setCustomerId(1);
		comprehensiveDependentMapping.setEnquiryId(1);
		comprehensiveDependentMapping.setGender("Male");
		
		ComprehensiveDependentMapping comprehensiveDependentMapping1 = new ComprehensiveDependentMapping();
		comprehensiveDependentMapping1.setCustomerId(2);
		comprehensiveDependentMapping1.setEnquiryId(2);
		comprehensiveDependentMapping1.setGender("Female");
		
		dependentMappingList.add(comprehensiveDependentMapping);
		dependentMappingList.add(comprehensiveDependentMapping1);
		
		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		comprehensiveEnquiryDTO.setCustomerId(1);
		comprehensiveEnquiryDTO.setReportStatus("Submitted");
		
		ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = new ComprehensiveEnquiryPostResponse();
		comprehensiveEnquiryPostResponse.setComprehensiveEnquiry(comprehensiveEnquiryDTO);
	
		ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();
		comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);

		when(mComprehensiveEnquiryPreferencesHelper.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest)).thenReturn(comprehensiveEnquiryPostResponse);
		
		comprehensiveServiceImpl.saveDependents(dependentMappingList, 1, true);
	}
	
	@Test
	public void saveDependentsNoDependentsTest(){
		
		List<ComprehensiveDependentMapping> dependentMappingList = new ArrayList<ComprehensiveDependentMapping>();
		
		ComprehensiveDependentMapping comprehensiveDependentMapping = new ComprehensiveDependentMapping();
		comprehensiveDependentMapping.setCustomerId(1);
		comprehensiveDependentMapping.setEnquiryId(1);
		comprehensiveDependentMapping.setGender("Male");
		
		ComprehensiveDependentMapping comprehensiveDependentMapping1 = new ComprehensiveDependentMapping();
		comprehensiveDependentMapping1.setCustomerId(2);
		comprehensiveDependentMapping1.setEnquiryId(2);
		comprehensiveDependentMapping1.setGender("Female");
		
		dependentMappingList.add(comprehensiveDependentMapping);
		dependentMappingList.add(comprehensiveDependentMapping1);
		
		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		comprehensiveEnquiryDTO.setCustomerId(1);
		comprehensiveEnquiryDTO.setReportStatus("Submitted");
		
		ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = new ComprehensiveEnquiryPostResponse();
		comprehensiveEnquiryPostResponse.setComprehensiveEnquiry(comprehensiveEnquiryDTO);
	
		ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();
		comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);

		when(mComprehensiveEnquiryPreferencesHelper.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest)).thenReturn(comprehensiveEnquiryPostResponse);
		
		comprehensiveServiceImpl.saveDependents(dependentMappingList, 1, false);
	}
	
	@Test
	public void getExistingEntityTest() throws Exception{
		
		List<DependentEntity> activeList = new ArrayList<DependentEntity>();
		
		DependentEntity dependentEntity = new DependentEntity();
		dependentEntity.setCustomerId(1);
		dependentEntity.setEnquiryId(1);
		activeList.add(dependentEntity);
		
		List<DependentEntity> inActiveList = new ArrayList<DependentEntity>();
		
		DependentEntity dependentEntity2 = new DependentEntity();
		dependentEntity2.setCustomerId(1);
		dependentEntity2.setEnquiryId(1);
		inActiveList.add(dependentEntity2);
	
		DependentEntity dependentEntityResponse = Whitebox.invokeMethod(comprehensiveServiceImpl, "getExistingEntity", activeList, inActiveList, 1);
		
		assertNotNull(dependentEntityResponse);
	}
	
	@Test
	public void saveChildEndowmentPlanDetailsTest(){
		
		ComprehensiveEndowmentPlanMapping endPlan = new ComprehensiveEndowmentPlanMapping();
		endPlan.setDependentId(1);
		endPlan.setEducationCourse("medical");
		endPlan.setEndowmentMaturityAmount(10000.0);
		endPlan.setEndowmentMaturityYears(10);
		endPlan.setLocation("singapore");
		endPlan.setEnquiryId(enqId);
		childEndowmentPlanning.add(endPlan);
		
		comprehensiveServiceImpl.saveChildEndowmentPlanDetails(childEndowmentPlanning, hasEndowments, cusId);
		
	}
	
	@Test
	public void getDependentEducationPreferencesTest(){
		
		List<DependentEducationPreferencesDTO> responseList = comprehensiveServiceImpl.getDependentEducationPreferences(cusId, enqId);
		assertNotNull(responseList);
	}
	
	@Test
	public void getDependentEducationPreferencesNotNullTest(){
		
		List<DependentEducationPreferences> depList = new ArrayList<DependentEducationPreferences>();
		
		DependentEducationPreferences dependentEducationPreferences = new DependentEducationPreferences();
		dependentEducationPreferences.setCustomerId(1);
		dependentEducationPreferences.setEnquiryId(1);
		depList.add(dependentEducationPreferences);
		
		when(mComprehensiveDAO.getDependentEducationPreferences(cusId, enqId)).thenReturn(depList);
		
		List<DependentEducationPreferencesDTO> responseList = comprehensiveServiceImpl.getDependentEducationPreferences(cusId, enqId);
		assertNotNull(responseList);
	}
	
	@Test
	public void notifyUserForPromoCodeTest() throws Exception{
		
		Customer cusObj = new Customer();
		cusObj.setAdvisorId(1);
		cusObj.setId(1);
		cusObj.setGivenName("Raj");
		cusObj.setSurName("Kumar");
		
		Boolean response = Whitebox.invokeMethod(comprehensiveServiceImpl, "notifyUserForPromoCode", cusObj, "MOACCT", promoCodeCategory);
		assertNotNull(response);
	}
	
	@Test
	public void testGetComprehensiveProductPricingIf() throws Exception{
		try {
			List<ComprehensivePricing> productPricing=new ArrayList<>();
			when(mComprehensivePricing.getPrice()).thenReturn(200);
			when(mComprehensivePricing.getIncludingGst()).thenReturn(false);
			when(mComprehensivePricing.getGstPercentage()).thenReturn(7.0);
			productPricing.add(mComprehensivePricing);
			when(mComprehensiveDAO.getComprehensiveProductPricing("Comprehensive", "ROLE_COMPRE_DISCOUNT")).thenReturn(productPricing);
			ComprehensivePricingDTO getComprehensiveProductPricing = comprehensiveServiceImpl.getComprehensiveProductPricing("Comprehensive", "ROLE_COMPRE_DISCOUNT");
			assertNotNull(getComprehensiveProductPricing);
		} catch (Exception e) {

		}
	}
	@Test
	public void testGetComprehensiveProductPricingElse() throws Exception{
		try {
			when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);
			List<ComprehensivePricing> productPricing=null;
			when(mComprehensiveDAO.getComprehensiveProductPricing("Comprehensive", "ROLE_COMPRE_DISCOUNT")).thenReturn(productPricing);
			ComprehensivePricingDTO getComprehensiveProductPricing = comprehensiveServiceImpl.getComprehensiveProductPricing("Comprehensive", "ROLE_COMPRE_DISCOUNT");
			assertNotNull(getComprehensiveProductPricing);
		} catch (Exception e) {

		}
	}
	
	@Test
	public void testGetComprehensiveProductPricingException() throws DatabaseAccessException{
		try {
			when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);
			when(mComprehensiveDAO.getComprehensiveProductPricing("Comprehensive", "ROLE_COMPRE_DISCOUNT")).
			thenThrow(
					new DatabaseAccessException("Exception occured in testGetComprehensiveProductPricingException" ));
			comprehensiveServiceImpl.getComprehensiveProductPricing("Comprehensive", "ROLE_COMPRE_DISCOUNT");
			
		} catch (Exception e) {

		}
	}
	
}

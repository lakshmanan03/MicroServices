/**
 * 
 */
package com.bfa.controllers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bfa.application.corporate.CorporateLeadGenRequest;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.promotion.model.PromotionBundleModel;
import com.bfa.service.AccountsService;
import com.bfa.service.BundleService;
import com.bfa.service.MailChimpService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ResponseMessageList;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class has the API end points related to the promotional content.
 * 
 * Introduced during : BFA-1565
 * 
 * @author pradheep
 * 
 */
@RestController
@Api(value = "/api")
public class PromotionalFunctionsController extends BaseController {

	@Autowired
	private BundleService bundleService;		
	
	@Autowired
	private AccountsService accountsService;
	
	@Autowired
	private MailChimpService mailChimpService;

	@PostMapping(API_REGISTER_BUNDLE)	
	@Produces({ "application/xml", "application/json" })
	@Path(API_REGISTER_BUNDLE)
	@ApiOperation(value = "Registers the bundle enquiry and then sends notification to marketing team.", notes = "Registers the bundle enquiry and then sends notification to marketing team.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList registerEnquiryBundle(@Valid @RequestBody PromotionBundleModel requestObj,HttpServletRequest httpServletRequest) {		
		getLogger(this.getClass())
				.info("Registering the enquiry bundle : " + new Date() + ": Payload-" + requestObj.toString());
		ResponseMessageList responseMessageList = getDefaultMessageList();
		try {
			String response = bundleService.notifyBundleEnquiry(requestObj,httpServletRequest);
			bundleService.updateBundleDataInCRM(requestObj);
			if (response.equalsIgnoreCase("success")) {
				getLogger(this.getClass()).info("--Registration of enquiry was successful--");
				return responseMessageList;
			} else {
				responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				responseMessageList.getResponseMessage().setResponseDescription(response);
				getLogger(this.getClass()).error("# Unable to register the enquiry #  " + requestObj.toString());
				return responseMessageList;
			}
		} catch (Exception err) {
			getLogger(this.getClass()).error("Error while handling the enquiry", err);
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			return responseMessageList;
		}
	}
	
	
	@PostMapping(APIConstants.CORP_BIZ_LEAD_GEN)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.CORP_BIZ_LEAD_GEN)
	@ApiOperation(value = "Registers the corporate data with mail chimp ", notes = "Registers the corporate data with mail chimp", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList registerCorpLeadGen(@Valid @RequestBody CorporateLeadGenRequest requestObj,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass())
				.info("Registering the corporate lead gen : " + new Date() + ": Payload-" + requestObj.toString());
		ResponseMessageList responseMessageList = getDefaultMessageList();
		try {
			SessionDetails sessionDetails = accountsService.saveSessionDetails(httpServletRequest);
			requestObj.setEnquiryType(ApplicationConstants.CORPORATE_BIZ);
			mailChimpService.subscribeInMailChimp(requestObj, sessionDetails.getIpAddress());
			return responseMessageList;
		} catch (Exception err) {
			getLogger(this.getClass()).error("Error while handling the enquiry", err);
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			return responseMessageList;
		}
}
}

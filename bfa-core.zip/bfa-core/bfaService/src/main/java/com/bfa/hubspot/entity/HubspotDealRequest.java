/**
 * 
 */
package com.bfa.hubspot.entity;

import java.util.ArrayList;
import java.util.List;

import com.bfa.common.ProtectionTypeEnum;
import com.bfa.insurance.product.ProductList;

/**
 * @author pradheep
 *
 */
public class HubspotDealRequest {
	
	private ProtectionTypeEnum protectionTypeEnum;
	
	private List<ProductList> productList = new ArrayList<ProductList>();
	
	private String category;

	public ProtectionTypeEnum getProtectionTypeEnum() {
		return protectionTypeEnum;
	}

	public void setProtectionTypeEnum(ProtectionTypeEnum protectionTypeEnum) {
		this.protectionTypeEnum = protectionTypeEnum;
	}

	public List<ProductList> getProductList() {
		return productList;
	}

	public void setProductList(List<ProductList> productList) {
		this.productList = productList;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
}

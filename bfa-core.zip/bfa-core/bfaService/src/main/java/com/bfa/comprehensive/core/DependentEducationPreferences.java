/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "dependent_education_preference")
public class DependentEducationPreferences {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "dependent_id")
	private int dependentId;
	
	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name="location")
	private String location;

	@Column(name = "education_course")
	private String educationCourse;	
	
	@Column(name = "endowment_maturity_amount")
	private Double endowmentMaturityAmount;

	@Column(name = "maturity_years")
	private int endowmentMaturityYears;
	
	@Column(name = "education_spend_share")
	private int educationSpendingShare;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDependentId() {
		return dependentId;
	}

	public void setDependentId(int dependentId) {
		this.dependentId = dependentId;
	}
	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getEducationCourse() {
		return educationCourse;
	}

	public void setEducationCourse(String educationCourse) {
		this.educationCourse = educationCourse;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Double getEndowmentMaturityAmount() {
		return endowmentMaturityAmount;
	}

	public void setEndowmentMaturityAmount(Double endowmentMaturityAmount) {
		this.endowmentMaturityAmount = endowmentMaturityAmount;
	}

	public int getEndowmentMaturityYears() {
		return endowmentMaturityYears;
	}

	public void setEndowmentMaturityYears(int endowmentMaturityYears) {
		this.endowmentMaturityYears = endowmentMaturityYears;
	}

	public int getEducationSpendingShare() {
		return educationSpendingShare;
	}

	public void setEducationSpendingShare(int educationSpendingShare) {
		this.educationSpendingShare = educationSpendingShare;
	}

	

	
}

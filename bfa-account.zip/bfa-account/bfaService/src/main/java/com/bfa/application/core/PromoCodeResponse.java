/**
 * 
 */
package com.bfa.application.core;

/**
 * @author kianann
 *
 */
public class PromoCodeResponse {

	private String promoCode;

	/**
	 * @return the promoCode
	 */
	public String getPromoCode() {
		return promoCode;
	}

	/**
	 * @param promoCode the promoCode to set
	 */
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
}

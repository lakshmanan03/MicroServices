package com.bfa.investment.dto;

public class FeaturePromotionsDTO {

	private int oneTimeInvestmentMinimum;
	private int monthlyInvestmentMinimum;
	/**
	 * @return the oneTimeInvestmentMinimum
	 */
	public int getOneTimeInvestmentMinimum() {
		return oneTimeInvestmentMinimum;
	}
	/**
	 * @param oneTimeInvestmentMinimum the oneTimeInvestmentMinimum to set
	 */
	public void setOneTimeInvestmentMinimum(int oneTimeInvestmentMinimum) {
		this.oneTimeInvestmentMinimum = oneTimeInvestmentMinimum;
	}
	/**
	 * @return the monthlyInvestmentMinimum
	 */
	public int getMonthlyInvestmentMinimum() {
		return monthlyInvestmentMinimum;
	}
	/**
	 * @param monthlyInvestmentMinimum the monthlyInvestmentMinimum to set
	 */
	public void setMonthlyInvestmentMinimum(int monthlyInvestmentMinimum) {
		this.monthlyInvestmentMinimum = monthlyInvestmentMinimum;
	}
	
}

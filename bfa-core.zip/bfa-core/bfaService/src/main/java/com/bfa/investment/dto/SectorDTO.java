package com.bfa.investment.dto;

import java.util.ArrayList;

public class SectorDTO {
	private String id;
	private String name;
	private String type;
	private double riskRating;
	private int totalPercentage;
	private ArrayList<FundDTO> funds = new ArrayList<>();
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getRiskRating() {
		return riskRating;
	}
	public void setRiskRating(double riskRating) {
		this.riskRating = riskRating;
	}
	public int getTotalPercentage() {
		return totalPercentage;
	}
	public void setTotalPercentage(int totalPercentage) {
		this.totalPercentage = totalPercentage;
	}
	public ArrayList<FundDTO> getFunds() {
		return funds;
	}
	public void setFunds(ArrayList<FundDTO> funds) {
		this.funds = funds;
	}
	
	
}

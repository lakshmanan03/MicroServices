/**
 * 
 */
package com.bfa.service;

import com.bfa.serviceimpl.RetirementServiceImpl;

/**
 * Contains the functions required for AdServices. 
 * 
 * @author pradheep
 * 
 * @since Release 4.0
 * 
 * @see RetirementServiceImpl
 */
public interface RetirementLeadService {
	
	public static final String PROTECTION_TYPE = "Retirement Plan";
	
	public static final String RETIREMENT_PLAN_CATEGORY = "Retirement Lead via Ads";
	
	public static final String RETIREMENT_PLAN_EMAIL_SUBJECT = "Retirement lead generation form";
	
	public void updateDataInCRM(Object obj);
	
	public void notifyAdvisors(Object obj);
	
	public void updateRetirementPlanningData(Object obj);
	
}

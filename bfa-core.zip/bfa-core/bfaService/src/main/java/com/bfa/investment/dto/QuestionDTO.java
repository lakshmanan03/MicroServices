package com.bfa.investment.dto;

import java.util.ArrayList;
import java.util.List;

public class QuestionDTO {

    private int id;
  
    private String description;
    
    private String text;
    
    public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	private List<OptionDTO> options = new ArrayList<>();
    
    private int listOrder;

	public int getListOrder() {
		return listOrder;
	}
	public void setListOrder(int listOrder) {
		this.listOrder = listOrder;
	}
	
	public List<OptionDTO> getOptions() {
		return options;
	}
	public void setOptions(List<OptionDTO> options) {
		this.options = options;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
    
    
	
}

/**
 * 
 */
package com.bfa.insurance.core;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author RethinavelMoorthy.S
 *
 */
@Entity
@Table(name = "customer_previlege")
public class CustomerPrevilege {

	@JsonIgnore
	@Id
	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "previlege_id")
	private int previlegetId;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="id")
	private Set<PrevilageMaster> previleges;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getPrevilegetId() {
		return previlegetId;
	}

	public void setPrevilegetId(int previlegetId) {
		this.previlegetId = previlegetId;
	}

	public Set<PrevilageMaster> getPrevileges() {
		return previleges;
	}

	public void setPrevileges(Set<PrevilageMaster> previleges) {
		this.previleges = previleges;
	}

}

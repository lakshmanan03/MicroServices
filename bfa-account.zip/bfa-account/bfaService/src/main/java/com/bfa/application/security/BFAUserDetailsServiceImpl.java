/**
 * 
 */
package com.bfa.application.security;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.exception.NoSuchUserException;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.dao.AccountsDao;

/**
 * @author pradheep.p
 *
 */
public class BFAUserDetailsServiceImpl implements BFAUserDetailsService, Serializable {

	@Autowired
	private AccountsDao accountsDao;
	
	@Override
	public BFAUserDetails loadUserByEmail(String email) throws DatabaseAccessException, NoSuchUserException {
		return accountsDao.loadUserByEmail(email);
	}

	@Override
	public BFAUserDetails loadUserByMobile(String mobileNumber) {
		return accountsDao.loadUserByMobile(mobileNumber);
	}

	@Override
	public BFAUserDetails loadAdminByEmail(String email) {
		// TODO Auto-generated method stub
		return accountsDao.loadAdminByEmail(email);
	}

}

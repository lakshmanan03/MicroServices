/**
 * 
 */
package com.bfa.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ComprehensiveSpendingRequest {

	@JsonIgnore
	private int customerId;

	private Integer enquiryId;

	private Double monthlyLivingExpenses;

	private Double adHocExpenses;

	@JsonProperty("HLMortgagePaymentUsingCPF")
	private Double HLMortgagePaymentUsingCPF;

	@JsonProperty("HLMortgagePaymentUsingCash")
	private Double HLMortgagePaymentUsingCash;

	@JsonProperty("HLtypeOfHome")
	private String HLtypeOfHome;

	private Integer homeLoanPayOffUntil;

	private Double mortgagePaymentUsingCPF;

	private Double mortgagePaymentUsingCash;

	private String mortgageTypeOfHome;

	private Integer mortgagePayOffUntil;

	private Double carLoanPayment;
	
	private Integer carLoanPayoffUntil;

	private Double otherLoanPayment;

	private Integer otherLoanPayoffUntil;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getMonthlyLivingExpenses() {
		return monthlyLivingExpenses;
	}

	public void setMonthlyLivingExpenses(Double monthlyLivingExpenses) {
		this.monthlyLivingExpenses = monthlyLivingExpenses;
	}

	public Double getAdHocExpenses() {
		return adHocExpenses;
	}

	public void setAdHocExpenses(Double adHocExpenses) {
		this.adHocExpenses = adHocExpenses;
	}

	@JsonProperty("HLMortgagePaymentUsingCPF")
	public Double getHLMortgagePaymentUsingCPF() {
		return HLMortgagePaymentUsingCPF;
	}

	public void setHLMortgagePaymentUsingCPF(Double hLMortgagePaymentUsingCPF) {
		HLMortgagePaymentUsingCPF = hLMortgagePaymentUsingCPF;
	}

	@JsonProperty("HLMortgagePaymentUsingCash")
	public Double getHLMortgagePaymentUsingCash() {
		return HLMortgagePaymentUsingCash;
	}

	public void setHLMortgagePaymentUsingCash(Double hLMortgagePaymentUsingCash) {
		HLMortgagePaymentUsingCash = hLMortgagePaymentUsingCash;
	}

	@JsonProperty("HLtypeOfHome")
	public String getHLtypeOfHome() {
		return HLtypeOfHome;
	}

	public void setHLtypeOfHome(String hLtypeOfHome) {
		HLtypeOfHome = hLtypeOfHome;
	}

	
	public Double getMortgagePaymentUsingCPF() {
		return mortgagePaymentUsingCPF;
	}

	public void setMortgagePaymentUsingCPF(Double mortgagePaymentUsingCPF) {
		this.mortgagePaymentUsingCPF = mortgagePaymentUsingCPF;
	}

	public Double getMortgagePaymentUsingCash() {
		return mortgagePaymentUsingCash;
	}

	public void setMortgagePaymentUsingCash(Double mortgagePaymentUsingCash) {
		this.mortgagePaymentUsingCash = mortgagePaymentUsingCash;
	}

	public Double getCarLoanPayment() {
		return carLoanPayment;
	}

	public void setCarLoanPayment(Double carLoanPayment) {
		this.carLoanPayment = carLoanPayment;
	}
	
	public Integer getCarLoanPayoffUntil() {
		return carLoanPayoffUntil;
	}

	public void setCarLoanPayoffUntil(Integer carLoanPayoffUntil) {
		this.carLoanPayoffUntil = carLoanPayoffUntil;
	}

	public Double getOtherLoanPayment() {
		return otherLoanPayment;
	}

	public void setOtherLoanPayment(Double otherLoanPayment) {
		this.otherLoanPayment = otherLoanPayment;
	}	

	public String getMortgageTypeOfHome() {
		return mortgageTypeOfHome;
	}

	public void setMortgageTypeOfHome(String mortgageTypeOfHome) {
		this.mortgageTypeOfHome = mortgageTypeOfHome;
	}

	public Integer getHomeLoanPayOffUntil() {
		return homeLoanPayOffUntil;
	}

	public void setHomeLoanPayOffUntil(Integer homeLoanPayOffUntil) {
		this.homeLoanPayOffUntil = homeLoanPayOffUntil;
	}

	public Integer getMortgagePayOffUntil() {
		return mortgagePayOffUntil;
	}

	public void setMortgagePayOffUntil(Integer mortgagePayOffUntil) {
		this.mortgagePayOffUntil = mortgagePayOffUntil;
	}

	public Integer getOtherLoanPayoffUntil() {
		return otherLoanPayoffUntil;
	}

	public void setOtherLoanPayoffUntil(Integer otherLoanPayoffUntil) {
		this.otherLoanPayoffUntil = otherLoanPayoffUntil;
	}	
}

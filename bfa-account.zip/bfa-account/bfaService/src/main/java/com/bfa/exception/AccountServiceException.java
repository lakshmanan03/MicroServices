package com.bfa.exception;

public class AccountServiceException extends Exception{
	
	public AccountServiceException(String exceptionMessage) {
		super(exceptionMessage);
	}

}

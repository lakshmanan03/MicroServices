package com.bfa.admin.dto;

import com.bfa.common.entity.AdvisorList;

public class AddAdvisorRequestDTO {

	private int advisorId;
	private String customerId;

	

	public int getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(int advisorId) {
		this.advisorId = advisorId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	

	

}

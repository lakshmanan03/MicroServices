package com.bfa.investment.dto;

public class FinancialDetailsDTO {

	private Double annualIncome;
	private Double percentageOfSaving;
	private Double totalAssets;
	private Double totalLoans;
	private String incomeRange;
	
	

	public String getIncomeRange() {
		return incomeRange;
	}
	public void setIncomeRange(String incomeRange) {
		this.incomeRange = incomeRange;
	}
	public Double getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(Double annualIncome) {
		this.annualIncome = annualIncome;
	}
	public Double getPercentageOfSaving() {
		return percentageOfSaving;
	}
	public void setPercentageOfSaving(Double percentageOfSaving) {
		this.percentageOfSaving = percentageOfSaving;
	}
	public Double getTotalAssets() {
		return totalAssets;
	}
	public void setTotalAssets(Double totalAssets) {
		this.totalAssets = totalAssets;
	}
	public Double getTotalLoans() {
		return totalLoans;
	}
	public void setTotalLoans(Double totalLoans) {
		this.totalLoans = totalLoans;
	}
	
	
	
	
}

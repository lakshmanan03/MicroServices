/**
 * 
 */
package com.bfa.controllers;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bfa.service.SecurityService;
import com.bfa.serviceimpl.CaptchaProvider;

/**
 * @author pradheep.p
 *
 */

@Controller
public class CaptchaController extends BaseController {

	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private CaptchaProvider captchaProvider;
	
	Random r = new Random();

	@GetMapping("/getCaptcha")
	public void redrawCaptcha(HttpServletRequest request, HttpServletResponse response, ModelAndView model) {
		
		getLogger(this.getClass()).debug("Inside get captcha method ");
		Color bgColor = new Color(0, 167, 167);
		int width = 115;
		int height = 72;		

		BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

		Graphics2D g2d = bufferedImage.createGraphics();

		Font font = new Font("Georgia", Font.BOLD, 17);
		g2d.setFont(font);
		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHints(rh);
		// Fill the background Color //
		BufferedImage patternImage = getPatternImage();
		TexturePaint tp = null;
		if (patternImage != null) {
			tp = new TexturePaint(patternImage, new Rectangle(0, 0, 16, 16));
		}
		if (tp != null) {
			g2d.setPaint(tp);
		} else {
			g2d.setPaint(bgColor);
		}
		g2d.fillRect(0, 0, width, height);
		g2d.setColor(new Color(0, 0, 0));

		String captcha = captchaProvider.getCaptchaString();
		getLogger(this.getClass()).info("Printing the captcha " + captcha);
		String sessionId = request.getParameter("code");
		getLogger(this.getClass()).info("Printing the sesison id " + sessionId);
		securityService.saveSessionCaptchaDetails(request, sessionId, captcha);

		int x = 0;
		int y = 0;
		
		for (int i = 0; i < 5; i++) {
			x += 10 + (Math.abs(Math.random() * 8) % 15);
			y = 30 + Math.abs(r.nextInt()) % 20;
			g2d.drawChars(captcha.toCharArray(), i, 1, x, y);
		}		
		g2d.dispose();
		response.setContentType("image/png");
		OutputStream os;
		try {
			os = response.getOutputStream();
			ImageIO.write(bufferedImage, "png", os);
			os.close();
		} catch (IOException e) {
			getLogger(this.getClass()).error("Error while setting captcha", e);
		}		
	}

	private BufferedImage getPatternImage() {
		String fileName = "pattern_background.jpg";
		Resource res = new ClassPathResource(fileName);
		InputStream inputStream;
		try {
			inputStream = res.getInputStream();
			return ImageIO.read(inputStream);
		} catch (IOException e) {
			getLogger(this.getClass()).error("Error while get pattern image", e);
		}
		return null;
	}

}

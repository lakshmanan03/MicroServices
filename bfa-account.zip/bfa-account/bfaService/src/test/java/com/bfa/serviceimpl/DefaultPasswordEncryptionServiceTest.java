package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;

@RunWith(SpringJUnit4ClassRunner.class)
public class DefaultPasswordEncryptionServiceTest {

	@InjectMocks
	private DefaultPasswordEncryptionService mDefaultPwdEncryptionService;
	
	@Mock
	private AccountsDao mAccountsDAO;
	
	@Mock
	private Customer mCustomer;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	int cusId = 1;
	
	String pwd = "IMXYlDmP4f4=";
	
	String sessionId = "517879a9-f65e-4f65-a0a3-0234a54be704";
	
	@Test
	public void testSavePassword() {
		when(mAccountsDAO.getCustomerById(cusId)).thenReturn(mCustomer);
		String response = mDefaultPwdEncryptionService.savePassword(cusId, pwd, sessionId);
		assertNotNull(response);
	}

	@Test(expected = NullPointerException.class)
	public void testGetEncryptedPassword() {
		String response = mDefaultPwdEncryptionService.getEncryptedPassword(pwd, sessionId);
		assertNotNull(response);
	}

	@Test
	public void testCheckPassword() {
		when(mAccountsDAO.getCustomerById(cusId)).thenReturn(mCustomer);
		String response = mDefaultPwdEncryptionService.checkPassword(cusId, pwd, sessionId);
		assertNotNull(response);
	}

	@Test(expected = NullPointerException.class)
	public void testGetSecurityUtility() {
		String response = mDefaultPwdEncryptionService.decryptAndHash(pwd, sessionId);
		assertNotNull(response);
	}

}

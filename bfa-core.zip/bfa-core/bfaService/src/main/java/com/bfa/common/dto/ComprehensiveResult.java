package com.bfa.common.dto;

/**
 * 
 * @author GajendraK
 *
 */

public class ComprehensiveResult {
	
	private String notificationSentTo;
	
	private boolean validatePromoCode;
	
	private String reason;
	
	private Integer enquiryId;

	/**
	 * @return the enquiryId
	 */
	public Integer getEnquiryId() {
		return enquiryId;
	}

	/**
	 * @param enquiryId the enquiryId to set
	 */
	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}


	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public boolean isValidatePromoCode() {
		return validatePromoCode;
	}

	public void setValidatePromoCode(boolean validatePromoCode) {
		this.validatePromoCode = validatePromoCode;
	}

	public String getNotificationSentTo() {
		return notificationSentTo;
	}

	public void setNotificationSentTo(String notificationSentTo) {
		this.notificationSentTo = notificationSentTo;
	}

}

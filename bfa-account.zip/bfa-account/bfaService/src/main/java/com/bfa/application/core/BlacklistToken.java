/**
 * 
 */
package com.bfa.application.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * BFA-1233
 * @author pradheep.p
 *
 */
@Entity
@Table(name="blacklisted_token")
public class BlacklistToken {		
	
	@Id
	@Column(name = "token")
	private String tokenValue;
	
	@Column(name="eject_time")
	private Date ejectTime;
	
	@Column(name = "reason")
	private String reason;

	public String getTokenValue() {
		return tokenValue;
	}

	public void setTokenValue(String tokenValue) {
		this.tokenValue = tokenValue;
	}

	public Date getEjectTime() {
		return ejectTime;
	}

	public void setEjectTime(Date ejectTime) {
		this.ejectTime = ejectTime;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	
}

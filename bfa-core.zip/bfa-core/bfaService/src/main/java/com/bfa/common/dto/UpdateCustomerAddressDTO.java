package com.bfa.common.dto;

public class UpdateCustomerAddressDTO {

	private AddressDTO homeAddress;
	private AddressDTO mailingAddress;
	private String mailingAddressReason;
	private Boolean sameAsMailingAddress;


	public AddressDTO getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(AddressDTO homeAddress) {
		this.homeAddress = homeAddress;
	}

	public AddressDTO getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(AddressDTO mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public String getMailingAddressReason() {
		return mailingAddressReason;
	}

	public void setMailingAddressReason(String mailingAddressReason) {
		this.mailingAddressReason = mailingAddressReason;
	}

	public Boolean getSameAsMailingAddress() {
		return sameAsMailingAddress;
	}

	public void setSameAsMailingAddress(Boolean sameAsMailingAddress) {
		this.sameAsMailingAddress = sameAsMailingAddress;
	}

	

}

/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comprehensive_retirement_income")
public class ComprehensiveRetirementIncome {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name = "monthly_payout")
	private Integer monthlyPayout;
	
	@Column(name = "payout_start_age")
	private Integer payoutStartAge;
	
	@Column(name = "payout_duration")
	private String payoutDuration;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="retirement_planning_id", nullable = false)
	ComprehensiveRetirementPlanning comprehensiveRetirementPlanning;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getMonthlyPayout() {
		return monthlyPayout;
	}

	public void setMonthlyPayout(Integer monthlyPayout) {
		this.monthlyPayout = monthlyPayout;
	}

	public Integer getPayoutStartAge() {
		return payoutStartAge;
	}

	public void setPayoutStartAge(Integer payoutStartAge) {
		this.payoutStartAge = payoutStartAge;
	}

	public String getPayoutDuration() {
		return payoutDuration;
	}

	public void setPayoutDuration(String payoutDuration) {
		this.payoutDuration = payoutDuration;
	}

	public ComprehensiveRetirementPlanning getComprehensiveRetirementPlanning() {
		return comprehensiveRetirementPlanning;
	}

	public void setComprehensiveRetirementPlanning(ComprehensiveRetirementPlanning comprehensiveRetirementPlanning) {
		this.comprehensiveRetirementPlanning = comprehensiveRetirementPlanning;
	}
	
}

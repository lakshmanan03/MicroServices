package com.bfa.controllers;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bfa.admin.dto.AddAdvisorRequestDTO;
import com.bfa.insurance.core.Customer;
import com.bfa.service.AccountsService;
import com.bfa.util.APIResponse;
import com.bfa.util.PublicUtility;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AccountsController.class })
@Ignore
public class AccountsControllerPowerMockTest {

	@InjectMocks
	private AccountsController mAccountsController;

	@Mock
	private AddAdvisorRequestDTO mAddAdvisorRequestDTO;

	@Mock
	private AccountsService mAccountsService;

	@Mock
	private PublicUtility mUtility;

	@Mock
	private Customer mCustomer;

	int enqId = 1;

	int cusId = 1;

	int advisorId = 1;

	String cusIdString = "1";

	@Before
	public void setUp() {

		String appKey = "IMXYlDmP4f4=";

		PublicUtility utility = PublicUtility.getInstance(appKey);

		PowerMockito.mockStatic(utility.getClass());
		PowerMockito.when(utility.DecryptText(mAddAdvisorRequestDTO.getCustomerId())).thenReturn(cusIdString);

	}

	@Test
	public void testPowerMockitoAddAdvisor() {

		when(mAddAdvisorRequestDTO.getAdvisorId()).thenReturn(1);

		AddAdvisorRequestDTO addAdvisorRequestDTOObj = new AddAdvisorRequestDTO();
		addAdvisorRequestDTOObj.setCustomerId(cusIdString);

		when(mUtility.DecryptText(mAddAdvisorRequestDTO.getCustomerId())).thenReturn(cusIdString);

		when(mAddAdvisorRequestDTO.getCustomerId()).thenReturn(cusIdString);

		when(mAccountsService.addAdvisor(cusId, advisorId)).thenReturn(mCustomer);
		when(mCustomer.getAdvisorId()).thenReturn(1);
		APIResponse<Customer> response = mAccountsController.addAdvisor(addAdvisorRequestDTOObj);
		assertNotNull(response);
	}

}

package com.bfa.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.core.CustomerPreference;
import com.bfa.application.core.Tracker;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.TrackingMasterDao;
import com.bfa.util.PublicUtility;

@Transactional
@Repository
public class TrackingMasterDaoImpl extends BaseDaoImpl implements TrackingMasterDao {

	@Autowired
	private ApplicationLoggerBean loggerBean;
	
	protected Logger getLogger() {
		return loggerBean.getLogBean(this.getClass());
	}

	@Autowired
	private SecurityConstants securityConstants;

	private String appKey = "IMXYlDmP4f4=";

	private PublicUtility utility = PublicUtility.getInstance(appKey);
	
	@Override
	public Boolean trackCodeExists(String trackCode) {
		Map<String, String> parameters = new HashMap<String, String>();
		System.out.println(trackCode);
		parameters.put("trackCode", trackCode);
		List<Tracker> trackingMaster = getList("FROM Tracker where track_code = :trackCode", parameters);
		if(trackingMaster != null && trackingMaster.size() > 0) {
			return true;
		}
		return false;
	}
	
	
}

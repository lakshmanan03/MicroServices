package com.bfa.common.dto;

import javax.validation.constraints.Size;

public class AddressDTO {
	private String reasonForOthers;
	private Integer reasonId;

	private Integer id;

	private Integer countryId;

	@Size(min = 3, message = "Please enter a valid state name")
	private String state;

	private String postalCode;

	private String addressLine1;

	private String addressLine2;

	private String unitNumber;

	private String townName;

	private String city;

	private String floor;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTownName() {
		return townName;
	}

	public void setTownName(String townName) {
		this.townName = townName;
	}

	public Integer getCountryId() {
		return this.countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getUnitNumber() {
		return unitNumber;
	}

	public void setUnitNumber(String unitNo) {
		this.unitNumber = unitNo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getReasonForOthers() {
		return reasonForOthers;
	}

	public void setResonForOthers(String reasonForOthers) {
		this.reasonForOthers = reasonForOthers;
	}

	public Integer getReasonId() {
		return reasonId;
	}

	public void setReasonId(Integer reasonId) {
		this.reasonId = reasonId;
	}

	

	
	
}

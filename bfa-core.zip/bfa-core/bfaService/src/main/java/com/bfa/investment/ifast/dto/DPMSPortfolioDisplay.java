package com.bfa.investment.ifast.dto;

public class DPMSPortfolioDisplay {
	 private String dpmsCategoryId;
	 private String dpmsPortfolioId;
	 private String portfolioName;
	 private String riskLevel;
	 private String launchedDate;
	 private String buyEnabled;
	 private String sellEnabled;
	 private String rspEnabled;
	 private Double minFeeRate;
	 private Double maxFeeRate;
	 private Double minSubscribeAmt;
	 private Double minSubsequenceSubscribeAmt;
	 private Double minRspAmt;
	 private Double minRedemptionAmt;
	 private Double minRetainAmt;
	public String getDpmsCategoryId() {
		return dpmsCategoryId;
	}
	public void setDpmsCategoryId(String dpmsCategoryId) {
		this.dpmsCategoryId = dpmsCategoryId;
	}
	public String getDpmsPortfolioId() {
		return dpmsPortfolioId;
	}
	public void setDpmsPortfolioId(String dpmsPortfolioId) {
		this.dpmsPortfolioId = dpmsPortfolioId;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public String getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}
	public String getLaunchedDate() {
		return launchedDate;
	}
	public void setLaunchedDate(String launchedDate) {
		this.launchedDate = launchedDate;
	}
	public String getBuyEnabled() {
		return buyEnabled;
	}
	public void setBuyEnabled(String buyEnabled) {
		this.buyEnabled = buyEnabled;
	}
	public String getSellEnabled() {
		return sellEnabled;
	}
	public void setSellEnabled(String sellEnabled) {
		this.sellEnabled = sellEnabled;
	}
	public String getRspEnabled() {
		return rspEnabled;
	}
	public void setRspEnabled(String rspEnabled) {
		this.rspEnabled = rspEnabled;
	}
	public Double getMinFeeRate() {
		return minFeeRate;
	}
	public void setMinFeeRate(Double minFeeRate) {
		this.minFeeRate = minFeeRate;
	}
	public Double getMaxFeeRate() {
		return maxFeeRate;
	}
	public void setMaxFeeRate(Double maxFeeRate) {
		this.maxFeeRate = maxFeeRate;
	}
	public Double getMinSubscribeAmt() {
		return minSubscribeAmt;
	}
	public void setMinSubscribeAmt(Double minSubscribeAmt) {
		this.minSubscribeAmt = minSubscribeAmt;
	}
	public Double getMinSubsequenceSubscribeAmt() {
		return minSubsequenceSubscribeAmt;
	}
	public void setMinSubsequenceSubscribeAmt(Double minSubsequenceSubscribeAmt) {
		this.minSubsequenceSubscribeAmt = minSubsequenceSubscribeAmt;
	}
	public Double getMinRspAmt() {
		return minRspAmt;
	}
	public void setMinRspAmt(Double minRspAmt) {
		this.minRspAmt = minRspAmt;
	}
	public Double getMinRedemptionAmt() {
		return minRedemptionAmt;
	}
	public void setMinRedemptionAmt(Double minRedemptionAmt) {
		this.minRedemptionAmt = minRedemptionAmt;
	}
	public Double getMinRetainAmt() {
		return minRetainAmt;
	}
	public void setMinRetainAmt(Double minRetainAmt) {
		this.minRetainAmt = minRetainAmt;
	}
	 

}

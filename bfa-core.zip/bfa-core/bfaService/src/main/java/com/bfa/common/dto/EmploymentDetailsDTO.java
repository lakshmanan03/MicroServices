package com.bfa.common.dto;

public class EmploymentDetailsDTO {
	private int employmentStatusId;
	private int industryId;
	private String otherIndustry;
	private int occupationId;
	private String otherOccupation;
	private String employerName;
	private String contactNumber;
	private String unemployedReason;
	private AddressDTO employerAddress;
	
	
	
	
	public String getOtherIndustry() {
		return otherIndustry;
	}
	public void setOtherIndustry(String otherIndustry) {
		this.otherIndustry = otherIndustry;
	}
	public String getOtherOccupation() {
		return otherOccupation;
	}
	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}
	public String getUnemployedReason() {
		return unemployedReason;
	}
	public void setUnemployedReason(String unemployedReason) {
		this.unemployedReason = unemployedReason;
	}
	public AddressDTO getEmployerAddress() {
		return employerAddress;
	}
	public void setEmployerAddress(AddressDTO employerAddress) {
		this.employerAddress = employerAddress;
	}
	public int getEmploymentStatusId() {
		return employmentStatusId;
	}
	public void setEmploymentStatusId(int employmentStatusId) {
		this.employmentStatusId = employmentStatusId;
	}
	public int getIndustryId() {
		return industryId;
	}
	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}
	public int getOccupationId() {
		return occupationId;
	}
	public void setOccupationId(int occupationId) {
		this.occupationId = occupationId;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
}

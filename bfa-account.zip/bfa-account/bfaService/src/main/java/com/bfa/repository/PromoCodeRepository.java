/**
 * 
 */
package com.bfa.repository;

import org.springframework.data.repository.CrudRepository;

import com.bfa.application.core.PromoCode;

/**
 * @author kianann
 *
 */
public interface PromoCodeRepository extends CrudRepository<PromoCode, Integer> {
	
	/**
	 * Retrieves the Promo Code based on code and category
	 * @param promoCode
	 * @param category
	 * @return
	 */
	PromoCode findByCodeAndCategory(String promoCode, String category);
	
	/**
	 * Retrieves the default Promo Code based on code and category
	 * @param category
	 * @param isDefault
	 * @return
	 */
	PromoCode findByCategoryAndIsDefault(String category, String isDefault);
}

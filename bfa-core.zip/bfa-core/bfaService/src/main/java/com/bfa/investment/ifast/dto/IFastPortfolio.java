package com.bfa.investment.ifast.dto;

import java.util.Date;

public class IFastPortfolio {
	private String dpmsCategoryId;
	private String dpmsPortfolioId;
	private String portfolioName;
	private String riskLevel;
	private Date launchedDate;
	private String buyEnabled;
	private String sellEnabled;
	private String rspEnabled;
	public String getDpmsCategoryId() {
		return dpmsCategoryId;
	}
	public void setDpmsCategoryId(String dpmsCategoryId) {
		this.dpmsCategoryId = dpmsCategoryId;
	}
	public String getDpmsPortfolioId() {
		return dpmsPortfolioId;
	}
	public void setDpmsPortfolioId(String dpmsPortfolioId) {
		this.dpmsPortfolioId = dpmsPortfolioId;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public String getRiskLevel() {
		return riskLevel;
	}
	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}
	public Date getLaunchedDate() {
		return launchedDate;
	}
	public void setLaunchedDate(Date launchedDate) {
		this.launchedDate = launchedDate;
	}
	public String getBuyEnabled() {
		return buyEnabled;
	}
	public void setBuyEnabled(String buyEnabled) {
		this.buyEnabled = buyEnabled;
	}
	public String getSellEnabled() {
		return sellEnabled;
	}
	public void setSellEnabled(String sellEnabled) {
		this.sellEnabled = sellEnabled;
	}
	public String getRspEnabled() {
		return rspEnabled;
	}
	public void setRspEnabled(String rspEnabled) {
		this.rspEnabled = rspEnabled;
	}
	
	

}

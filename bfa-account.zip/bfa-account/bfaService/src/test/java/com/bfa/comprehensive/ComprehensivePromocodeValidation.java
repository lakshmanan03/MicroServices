/**
 * 
 */
package com.bfa.comprehensive;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Date;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.bfa.application.core.PromoCode;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.serviceimpl.ComprehensiveServiceImpl;

@RunWith(SpringRunner.class)
public class ComprehensivePromocodeValidation {

	@Mock
	private static PromoCodeRepository promoCodeRepository;

	@InjectMocks
	private ComprehensiveServiceImpl comprehensiveServiceImpl;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	private int customerId = 2;// 74058
	
	private String promoCode = "MOACCT";

	private PromoCode buildPromoCode() {
		
		LocalDate startDate = LocalDate.now();
		
		LocalDate endDate = LocalDate.now().plusDays(2);
		
		Date sDate = java.sql.Date.valueOf(startDate);
		
		Date eDate = java.sql.Date.valueOf(endDate);

		PromoCode promoCodeObj = new PromoCode();
		promoCodeObj.setCategory("COMPREHENSIVE");
		promoCodeObj.setId(1);
		promoCodeObj.setCode("MOACCT");
		promoCodeObj.setDescription("Existing clients will get promo code via email");
		promoCodeObj.setCreatedBy("SYSTEM");
		promoCodeObj.setStatus("A");
		
		promoCodeObj.setStartDate(sDate);
		promoCodeObj.setEndDate(eDate);

		return promoCodeObj;
	}

	@Test
	public void saveCustomerPromoCodeTest() {
		
		when(promoCodeRepository.findByCodeAndCategory(promoCode, "COMPREHENSIVE")).thenReturn(buildPromoCode());
		comprehensiveServiceImpl.setPromoCodeRepository(promoCodeRepository);
		try {
			comprehensiveServiceImpl.requestPromoCodeDetails(customerId, "COMPREHENSIVE");
		} catch (Exception e) {
			mLogger.error("Exception occured during saveCustomerPromoCodeTest:" + e);
		}
	}

}

package com.bfa.daoimpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.core.CustomerAndPrevilegeV2;
import com.bfa.application.core.SMSGatewayProperties;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.exception.NoSuchUserException;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.AdvisorPrevilege;
import com.bfa.common.entity.BFAGrantedAuthority;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerAssessmentDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.CustomerDetailsEditHistory;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.CustomerOverview;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.common.entity.EmployerAddress;
import com.bfa.common.entity.EmployerDetails;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.CustomerPrevilege;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.DependentProtectionNeeds;
import com.bfa.insurance.core.Dependents;
import com.bfa.insurance.core.EmploymentStatusMaster;
import com.bfa.insurance.core.LoginRetryCount;
import com.bfa.insurance.core.PrevilageMaster;
import com.bfa.insurance.core.Profile;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.PublicUtility;

@Transactional
@Repository
public class AccountsDaoImpl<T extends Object> extends BaseDaoImpl implements AccountsDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private ApplicationLoggerBean loggerBean;

	@Autowired
	private SecurityConstants securityConstants;

	private String appKey = "IMXYlDmP4f4=";

	private PublicUtility utility = PublicUtility.getInstance(appKey);

	public List<CustomerBankDetail> getCustomerBankDetails(Integer customerId) {
		Session session = null;
		List<CustomerBankDetail> customerBankDetailList = null;
		try {
			session = sessionFactory.openSession();
			String hql = "FROM CustomerBankDetail where customerId =:customerId";
			Query query = session.createQuery(hql).setParameter("customerId", customerId);
			customerBankDetailList = query.list();
			return customerBankDetailList;
		} catch (Exception ex) {
			getLogger().error("Error while obtaining the customer bank details ", ex);
		} finally {
			session.clear();
			session.close();
		}
		return null;
	}
	
	@Override
	public CustomerSrsAccount getCustomerSrsBankDetails(Integer customerId) {

		Session session = null;
		List customerBankDetailList = null;
		try {
			session = sessionFactory.openSession();
			String hql = "FROM CustomerSrsAccount where customerId =:customerId";
			Query query = session.createQuery(hql).setParameter("customerId", customerId);
			customerBankDetailList = query.list();
		} catch (Exception ex) {
			getLogger().error("Error while obtaining the customer bank details ", ex);
		} finally {
			session.clear();
			session.close();
		}
		if (customerBankDetailList == null || customerBankDetailList.isEmpty()) {
			return null;
		}
		return (CustomerSrsAccount)customerBankDetailList.get(0);
	}


	public Customer getCustomerById(Integer customerId) {
		 Session session = null;
		List customerList = null;
		try {
			session = sessionFactory.openSession();
			String hql = "FROM Customer c where c.id =:id";
			Query query = session.createQuery(hql).setParameter("id", customerId);
			customerList = query.list();
		} catch (Exception err) {
			getLogger().error("Error while getting the customer by id " + customerId);
		}
		finally{
			session.clear();
			session.close();			
		}
		if (customerList == null || customerList.isEmpty()) {
			return null;
		}
		return (Customer) customerList.get(0);
	}

	public List<Profile> getProfileList() throws DatabaseAccessException {
		List<Profile> profiles;
		try {
			profiles = (List<Profile>) getObjectsAsList(Profile.class);
		} catch (Exception err) {
			getLogger().error("Exception caught in getProfileList(): " +  err);
			throw new DatabaseAccessException();
		}
		return profiles == null ? Collections.emptyList() : profiles;
	}

	@Override
	public List<EmploymentStatusMaster> getEmploymentList() throws DatabaseAccessException {
		List<EmploymentStatusMaster> employmentStatusMaster;
		try {
			employmentStatusMaster = (List<EmploymentStatusMaster>) getObjectsAsList(EmploymentStatusMaster.class);
		} catch (Exception err) {
			getLogger().error("Exception at getEmploymentList: " + err);
			throw new DatabaseAccessException();
		}
		return employmentStatusMaster == null ? Collections.emptyList() : employmentStatusMaster;
	}

	public LoginRetryCount incrementRetryCount(String userId) {
		LoginRetryCount retryCount = getRetryCountInfo(userId);
		if (retryCount != null) {
			retryCount.setRetryCount(retryCount.getRetryCount() + 1);
			retryCount.setLastModifiedDate(PublicUtility.getCurrentUTC());
			update(retryCount);
		}
		return retryCount;
	}

	public LoginRetryCount resetRetryCount(String userId, int retryCount) {
		LoginRetryCount retryCountObj = getRetryCountInfo(userId);
		if (retryCountObj != null) {
			retryCountObj.setRetryCount(retryCount);
			retryCountObj.setLastModifiedDate(PublicUtility.getCurrentUTC());
			update(retryCountObj);
		}
		return retryCountObj;
	}

	public LoginRetryCount getRetryCountInfo(String userId) {
		if (userId == null || userId.isEmpty())
			return null;

		List<LoginRetryCount> retryCount;
		try {
			Map<String,String> parameters = new HashMap<String,String>();
			parameters.put("userId", userId);
			retryCount = getList("FROM LoginRetryCount lrc WHERE lrc.userId = :userId ",parameters);
		} catch (Exception err) {
			getLogger().error("Exception at getRetryCountInfo: " + err);
			throw new DatabaseAccessException();
		}
		return (retryCount == null || retryCount.isEmpty()) ? null : retryCount.get(0);
	}

	public LoginRetryCount createRetryCount(String userId) {
		LoginRetryCount retryCount = new LoginRetryCount();
		retryCount.setRetryCount(2);
		retryCount.setUserId(userId);
		retryCount.setLastModifiedDate(PublicUtility.getCurrentUTC());
		save(retryCount);
		return retryCount;
	}

	@Override
	public BFAUserDetails loadUserByEmail(String emailAddress) throws DatabaseAccessException, NoSuchUserException {
		getLogger().info("Getting the BFAUserDetails by email :" + emailAddress);
		BFAUserDetails bfaUser = null;
		Customer customer = getCustomerFromEmail(emailAddress);
		if (customer != null) {			
			List<BFAGrantedAuthority> authorities = buildAuthoritiesV2(customer.getId());
			bfaUser = createUserDetailsFromCustomer(customer);
			if (bfaUser != null) {
				bfaUser.setAuthorities(authorities);
				bfaUser.setMobileNumber(customer.getMobileNumber());
			}
		}
		return bfaUser;
	}

	@Override
	public BFAUserDetails loadUserById(Integer customerId) throws DatabaseAccessException, NoSuchUserException {
		BFAUserDetails bfaUser = null;
		Customer customer = getCustomerById(customerId);
		getLogger().debug("Printing the customer:" + customer);
		if (customer != null) {
			List<CustomerPrevilege> previleges = getCustomerPrevileges(customer.getId());
			List<BFAGrantedAuthority> authorities = buildAuthorities(previleges);
			bfaUser = createUserDetailsFromCustomer(customer);
			if (bfaUser != null) {
				bfaUser.setAuthorities(authorities);
			}
		}
		return bfaUser;
	}

	public BFAUserDetails loadUserByMobile(String mobileNumber) throws DatabaseAccessException, NoSuchUserException {
		BFAUserDetails bfaUser = null;
		Customer customer = getCustomerFromMobile(mobileNumber);
		System.out.println("Found the customer:" + customer.getId() + " Mobile: " + customer.getMobileNumber());
		if (customer != null) {			
			List<BFAGrantedAuthority> authorities = buildAuthoritiesV2(customer.getId());
			bfaUser = createUserDetailsFromCustomer(customer);
			if (bfaUser != null) {
				bfaUser.setAuthorities(authorities);
				bfaUser.setMobileNumber(mobileNumber);
			}
		}
		return bfaUser;
	}

	private List<BFAGrantedAuthority> buildAuthorities(List<CustomerPrevilege> customerPrevileges) {
		ArrayList<BFAGrantedAuthority> authorities = new ArrayList<BFAGrantedAuthority>();
		for (CustomerPrevilege previlege : customerPrevileges) {
			String prevName = getprevilegeId(previlege.getPrevilegetId());
			BFAGrantedAuthority bfaAuthority = new BFAGrantedAuthority(prevName);
			authorities.add(bfaAuthority);
			authorities.add(new BFAGrantedAuthority(getprevilegeId(2)));
		}
		return authorities;
	}

	private List<BFAGrantedAuthority> buildAuthoritiesForAdvisor(List<AdvisorPrevilege> advisorPrevileges) {
		ArrayList<BFAGrantedAuthority> authorities = new ArrayList<BFAGrantedAuthority>();
		for (AdvisorPrevilege previlege : advisorPrevileges) {
			String prevName = getprevilegeId(previlege.getAdminPrevilege().getId());
			BFAGrantedAuthority bfaAuthority = new BFAGrantedAuthority(prevName);
			authorities.add(bfaAuthority);
			authorities.add(new BFAGrantedAuthority(getprevilegeId(3)));

		}
		return authorities;
	}

	private String getprevilegeId(int previlegeId) {
		String previlegeName = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("FROM PrevilageMaster pm WHERE pm.previlegeId =:previlegeId").setParameter("previlegeId", previlegeId);
			@SuppressWarnings("unchecked")
			List<PrevilageMaster> list = query.list();
			if (list != null && !list.isEmpty()) {
				previlegeName = list.get(0).getPrvilegeName();
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched in AccountsDaoImpl.getCustomerPrevileges(): " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return previlegeName;
	}

	private List<CustomerPrevilege> getCustomerPrevileges(int customerId) {
		List<CustomerPrevilege> previleges = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("FROM CustomerPrevilege cp WHERE cp.customerId=:customerId").setParameter("customerId", customerId);
			@SuppressWarnings("unchecked")
			List<CustomerPrevilege> list = query.list();
			previleges = list;
		} catch (Exception ex) {
			getLogger().error("Exception catched in AccountsDaoImpl.getCustomerPrevileges(): " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return previleges;
	}

	private BFAUserDetails createUserDetailsFromCustomer(Customer customer) {
		BFAUserDetails bfaUser = null;
		try {
			bfaUser = new BFAUserDetails();
			bfaUser.setUsername(customer.getEmail());
			bfaUser.setId(customer.getId());
			if (customer.getPassword() != null && customer.getPassword().length > 0) {
				byte[] passwordArray = customer.getPassword();
				String password;
				password = new String(passwordArray, "UTF-8");
				// ---------------- BFA-1552 ---------------------				
				if(customer.getUniqueId() != null){
					String unsaltedPassword = utility.decryptTextWithKey(password, customer.getUniqueId());
					password = unsaltedPassword;
				}
				else{
				//---------------------------------------------------
				password = utility.DecryptText(password);
				}
				bfaUser.setPassword(password);
			}

			if (customer.getEmailVerified() != null && "yes".equalsIgnoreCase(customer.getEmailVerified())) {
				bfaUser.setEmailVerified(true);
			}
			if (customer.getOtpVerfied() != null && "yes".equalsIgnoreCase(customer.getOtpVerfied())) {
				bfaUser.setMobileVerified(true);
			}

		} catch (Exception e) {
			getLogger().error("Exception catched in AccountsDaoImpl.createUserDetailsFromCustomer(): " + e);
		}
		return bfaUser;
	}

	private Customer getCustomerFromEmail(String emailAddress) {
		Customer customer = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("FROM Customer c WHERE c.email = :emailAddress ").setParameter("emailAddress", emailAddress);
			@SuppressWarnings("unchecked")
			List<Customer> list = query.list();
			if (list != null && !list.isEmpty())
				customer = list.get(0);
		} catch (Exception ex) {
			getLogger().error("Exception catched in AccountsDaoImpl.getCustomerFromEmail(): " + ex.fillInStackTrace());
			getLogger().error("Exception while getCustomerFromEmail: " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return customer;
	}

	@Override
	public Customer getCustomerFromMobile(String mobileNumber) {
		Customer customer = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("FROM Customer c WHERE c.mobileNumber =  :mobileNumber ").setParameter("mobileNumber", mobileNumber);
			@SuppressWarnings("unchecked")
			List<Customer> list = query.list();
			if (list != null && !list.isEmpty())
				customer = list.get(0);
		} catch (Exception ex) {
			getLogger().error("Exception while get Customer detaiils from the respective mobile number(): " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return customer;
	}

	/*private Logger getLogger() {
		return loggerBean.getLogBean(this.getClass());
	}*/

	@Override
	public List<T> getObjectsAsList(Class T) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(T);
		List<T> collection = criteria.list();
		return collection;
	}

	@Override
	public Object saveOrUpdateObject(Object obj) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.saveOrUpdate(obj);
			session.flush();
			transaction.commit();
			return obj;
		} catch (Exception err) {
			getLogger().error("Error while saving the entity", err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	@Override
	public void saveDependentList(List dependents) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction trx = session.beginTransaction();
			Iterator<DependentMapping> dep = dependents.iterator();
			while (dep.hasNext()) {
				DependentMapping mapping = dep.next();
				if (mapping.getGender() == null) {
					getLogger().error("Gender cannot be null for a dependent");
					continue;
				}
				Dependents dependent = new Dependents();
				dependent.setId(mapping.getId());
				dependent.setCustomerId(mapping.getCustomerId());
				dependent.setEnquiryId(mapping.getEnquiryId());
				dependent.setGender(mapping.getGender());
				dependent.setAge(mapping.getAge());
				dependent.setRelationship(mapping.getRelationship());
				session.save(dependent);
				int dependentId = dependent.getId();
				DependentProtectionNeeds dependentProtectionNeeds = mapping.getDependentProtectionNeeds();
				dependentProtectionNeeds.setDependentId(dependentId);
				dependentProtectionNeeds.setEnquiryId(mapping.getEnquiryId());
				session.save(dependentProtectionNeeds);
			}
			trx.commit();
		} catch (Exception e) {
			getLogger().error("Error while saving the dependents data", e);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	private PrevilageMaster getIdForRole(String role) {
		List<Object> objects = getObjectsByRef(PrevilageMaster.class, "PrvilegeName", role);
		if (null != objects && !objects.isEmpty()) {
			return (PrevilageMaster) objects.get(0);
		}
		return null;
	}

	private List<CustomerPrevilege> createPrevilleges(Customer customer) {
		getLogger().info("Saving the user previlleges : " + customer.getId());
		List<CustomerPrevilege> previlleges = new ArrayList<>();
		CustomerPrevilege previllege1 = new CustomerPrevilege();
		previllege1.setCustomerId(customer.getId());
		previllege1.setPrevilegetId(SecurityConstants.ROLE_SIGNED_USER_ID);
		if (!doesPrevilegesExists(SecurityConstants.ROLE_SIGNED_USER_ID, customer.getId())) {
			saveObject(previllege1);
		} else {
			getLogger().info("Previlege already exists for customer " + customer.getId() + " previlege id :"
					+ SecurityConstants.ROLE_SIGNED_USER_ID);
		}
		Set<PrevilageMaster> previlageMasterSet1 = new HashSet<>();
		PrevilageMaster previlageMaster1 = new PrevilageMaster();
		previlageMaster1.setPrevilegeId(SecurityConstants.ROLE_SIGNED_USER_ID);
		previlageMaster1.setPrvilegeName(SecurityConstants.ROLE_SIGNED_USER);
		previlageMasterSet1.add(previlageMaster1);
		previllege1.setPrevileges(previlageMasterSet1);

		CustomerPrevilege previllege2 = new CustomerPrevilege();
		previllege2.setCustomerId(customer.getId());
		previllege2.setPrevilegetId(SecurityConstants.ROLE_USER_ID);
		if (!doesPrevilegesExists(SecurityConstants.ROLE_USER_ID, customer.getId())) {
			saveObject(previllege2);
		} else {
			getLogger().info("Previlege already exists for customer " + customer.getId() + " previlege id :"
					+ SecurityConstants.ROLE_USER_ID);
		}

		Set<PrevilageMaster> previlageMasterSet2 = new HashSet<>();
		PrevilageMaster previlageMaster2 = new PrevilageMaster();
		previlageMaster2.setPrevilegeId(SecurityConstants.ROLE_USER_ID);
		previlageMaster2.setPrvilegeName(SecurityConstants.ROLE_USER);
		previlageMasterSet2.add(previlageMaster2);
		previllege2.setPrevileges(previlageMasterSet2);
		previlleges.add(previllege1);
		previlleges.add(previllege2);
		return previlleges;
	}

	private boolean doesPrevilegesExists(Integer previlegeId, Integer customerId) {
		String hql = "from CustomerPrevilege cp where cp.customerId=:customerId AND cp.previlegetId =:previlegeId";
		String[] paramNames = new String[]{"customerId","previlegeId"};
		Integer[] values = new Integer[]{customerId,previlegeId}; 
		List collection = getObjectByHql(hql,paramNames,values);
		if (collection == null || collection.isEmpty()) {
			return false;
		}
		return true;
	}

	@Override
	public CustomerAndPrevilege signup(CustomerCreationPostRequest customerCreationPostRequest)
			throws DatabaseAccessException {
		Customer customerDetails;

		List<CustomerPrevilege> customerPrevileges = null;
		getLogger().info("Persisting the customer details ...");
		try {

			customerDetails = customerCreationPostRequest.getCustomer();
			// To stop updating user when userid is 0
			if (customerDetails.getId() == 0) {
				customerDetails.setId(null);
			}
			int enquiryId = customerDetails.getVerificationEnquiryId();
			Customer targetCustomer = null;
			if (enquiryId == 0 || enquiryId == -1) {
				getLogger().info("No such enquiry id " + enquiryId);
			} else {
				targetCustomer = lookForExisingRecords(enquiryId);
			}
			if (targetCustomer != null) {
				getLogger().info("found existing customer : " + targetCustomer.getId());
				int customerId = targetCustomer.getId();
				BeanUtils.copyProperties(customerDetails, targetCustomer);
				targetCustomer.setId(customerId);
				targetCustomer.setLastUpdatedBy("user");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				targetCustomer.setLastUpdatedTime(sdf.format(new Date()));
				targetCustomer.setVerificationEnquiryId(enquiryId);
				customerDetails = (Customer) saveOrUpdateObject(targetCustomer);
				customerPrevileges = getExistingPrevileges(customerId);
				if (customerPrevileges == null) {
					customerPrevileges = createPrevilleges(customerDetails);
				}
			} else {
				getLogger().info("Creting a new customer ");
				customerDetails.setCreatedBy("system");
				customerDetails.setCreatedDate(new Date());
				customerDetails.setVerificationEnquiryId(enquiryId);
				customerDetails = (Customer) saveObject(customerDetails);
				customerPrevileges = createPrevilleges(customerDetails);
			}
			CustomerAndPrevilege customerAndPrevilege = new CustomerAndPrevilege();
			customerAndPrevilege.setCustomer(customerDetails);
			customerAndPrevilege.setPrevileges(customerPrevileges);
			return customerAndPrevilege;
		} catch (Exception e) {
			getLogger().error("Exception catched while updating the customer information in AccountsDaoImpl.signup()" + e.fillInStackTrace());
			getLogger().error("Error while updating the customer information", e);
			throw new DatabaseAccessException();
		}
	}

	private List<CustomerPrevilege> getExistingPrevileges(int customerId) {
		Session session = sessionFactory.openSession();
		try{
		session = sessionFactory.openSession();
		String hql = "from CustomerPrevilege where customerId =:customerId";
		Query query = session.createQuery(hql).setParameter("customerId", customerId);
		List collection = query.list();
		if (collection != null && !collection.isEmpty()) {
			return collection;
		}
		}
		catch(Exception err){
			getLogger().error("Error while getting the existing previleges ",err);
		}
		finally{
		session.clear();
		session.close();			
		}
		return null;
	}

	private Customer lookForExisingRecords(int enquiryId) {
		String hql = "from Customer where verificationEnquiryId =:enquiryId";
		String[] paramNames = new String[]{"enquiryId"};
		Object[] paramValues = new Object[]{enquiryId};
		List collection = getObjectByHql(hql,paramNames,paramValues);
		if (collection != null && !collection.isEmpty()) {
			return (Customer) collection.get(0);
		}
		return null;
	}
	
	

	private Customer lookForExistingCustomer(String mobileNumber, String emailAddress, Integer enquiryId) {
		getLogger().info("Look for customer with mobile: " + mobileNumber + "email :" + emailAddress + " enquiryId : " + enquiryId);
		String hql = "from Customer where ";	
		
		List params = new ArrayList<String>();
		if (null != emailAddress && !emailAddress.isEmpty()) {
			params.add("email");
		}
		if (null != mobileNumber && !mobileNumber.isEmpty()) {
			params.add("mobileNumber");
		}
		if (null != enquiryId) {
			if (enquiryId > 0) {
				params.add("verificationEnquiryId");
			}
		}
		if(params.isEmpty()){
			return null;
		}		
		Iterator<String> iter = params.iterator();
		while (iter.hasNext()) {
			String value = iter.next();
			if (value.equals("email")) {
				hql = hql + " email=:emailAddress ";
			}
			if (value.equals("mobileNumber")) {
				hql = hql + " mobileNumber=:mobileNumber ";
			}
			if (value.equals("verificationEnquiryId")) {
				hql = hql + " verificationEnquiryId=:enquiryId ";
			}
			if (iter.hasNext()) {
				hql = hql + " OR ";
			}
		}
		hql = hql.trim();
		getLogger().info("Printing the HQL :" + hql);
		Session session = null;
		List collection = null;
		try {			
			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			if (params.contains("email")) {
				query.setParameter("emailAddress", emailAddress);
			}
			if (params.contains("mobileNumber")) {
				query.setParameter("mobileNumber", mobileNumber);
			}
			if (params.contains("verificationEnquiryId")) {
				query.setParameter("enquiryId", enquiryId);
			}
			collection = query.list();
			// - No such user in system- allow creation of account.
			if (collection == null || collection.isEmpty()) {
				getLogger().info("User with mobile " + mobileNumber + " Email :" + emailAddress + " Not found ");
				return null;
			}
			Iterator userCollectionIterator = collection.iterator();
			while (userCollectionIterator.hasNext()) {
				Customer customerObj = (Customer) userCollectionIterator.next();
				return customerObj;
			}
		}
		catch(Exception err){
			getLogger().error("Error while looking for existing customer " , err);
		}
		finally{
			session.clear();
			session.close();
		}
		return null;
	}

	@Override
	public Object saveObject(Object obj) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.save(obj);
			transaction.commit();
			return obj;
		} catch (Exception err) {
			getLogger().error("Error while saving the entity", err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	@Override
	public List getObjectsById(Class T, String reference, int value) throws DatabaseAccessException {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(T);
			criteria.add(Restrictions.eq(reference, value));
			List<T> collection = criteria.list();
			return collection;
		} catch (Exception err) {
			getLogger().error("Error while getting the objects by id", err);
		}
		return Collections.emptyList();
	}

	@Override
	public List getObjectsByRef(Class T, String reference, String value) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(T);
			criteria.add(Restrictions.eq(reference, value));
			List<T> collection = criteria.list();

			return collection;
		} catch (Exception err) {
			getLogger().error("Error while getting the objects by id", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return Collections.emptyList();
	}

	@Override
	@Deprecated
	public List<T> getObjectByHql(String hqlString) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hqlString);
			return query.list();
		} catch (Exception err) {
			getLogger().error("Error while fetching the records ", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return Collections.emptyList();
	}

	@Override
	public String getActiveSMSGatewayProvider() {

		String activeSMSGatewayProvider = "primary";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("from SMSGatewayProperties ");
			List<SMSGatewayProperties> list = query.list();
			Iterator<SMSGatewayProperties> iter = list.iterator();
			while (iter.hasNext()) {
				SMSGatewayProperties smsGatewayPropertiesObj = iter.next();
				if (smsGatewayPropertiesObj.getParameterName()
						.equalsIgnoreCase(ApplicationConstants.SMS_GATEWAY_PROVIDER)) {
					activeSMSGatewayProvider = smsGatewayPropertiesObj.getParameterValue();
					return activeSMSGatewayProvider;
				}
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched in AccountsDaoImpl.getActiveSMSGatewayProvider(): " + ex.fillInStackTrace());
			getLogger().error("Exception while getActiveSMSGatewayProvider(): " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return activeSMSGatewayProvider;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List getObjectByHql(String hqlString, String param, String value) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setParameter(param, value);
		return query.list();
	}

	@Override
	public List getObjectByHqlAndLimit(String hqlString, int numberOfRecords) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setMaxResults(numberOfRecords);
		return query.list();
	}
	
	@Override
	public List getObjectByHqlAndLimit(String hqlString,String param,String value,int numberOfRecords) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setParameter(param, value);
		query.setMaxResults(numberOfRecords);
		return query.list();
	}

	@Override
	public int executeUpdate(String hqlString) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Query query = session.createQuery(hqlString);
			int code = query.executeUpdate();
			transaction.commit();
			return code;
		} catch (Exception err) {
			getLogger().error("Error while executing and update", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return 0;
	}

	@Override
	public Customer getCustomerDetails(String email) throws DatabaseAccessException {
		return getCustomerFromEmail(email);
	}

	@Override
	public CustomerEmploymentInformation getCustomerEmploymentInformation(Integer customerId) {
		CustomerEmploymentInformation employmentInfo = new CustomerEmploymentInformation();
		CustomerEmploymentDetails employmentDetails = null;
		EmployerDetails employerDetails = null;
		EmployerAddress employerAddress = null;

		try {
			// Get employment details
			List<CustomerEmploymentDetails> employmentInfoList = getList(
					"FROM CustomerEmploymentDetails where customerId = '" + customerId + "'");
			if (employmentInfoList != null && !employmentInfoList.isEmpty()) {
				employmentDetails = employmentInfoList.get(0);
			}
			// Get employer details
			if (employmentDetails != null) {
				List<EmployerDetails> employerDetailsList = getList(
						"FROM EmployerDetails where id = '" + employmentDetails.getEmployerId() + "'");
				if (employerDetailsList != null && !employerDetailsList.isEmpty()) {
					employerDetails = employerDetailsList.get(0);
				}

				List<EmployerAddress> employerAddressList = getList(
						"FROM EmployerAddress where employerId = '" + employmentDetails.getEmployerId() + "'");
				if (employerAddressList != null && !employerAddressList.isEmpty()) {
					employerAddress = employerAddressList.get(0);
				}
			}
			if (employerDetails != null)

				employmentInfo.setCustomerEmploymentDetails(employmentDetails);
			employmentInfo.setEmployerDetails(employerDetails);
			employmentInfo.setEmployerAddress(employerAddress);
		} catch (Exception ex) {
			getLogger().error("Exception while getCustomerEmploymentInformation() : " + ex);
		}
		return employmentInfo;
	}
	
	private List getListWithParameters(String hql, Map<String, Integer> parameters) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			Iterator keysetIterator = parameters.keySet().iterator();
			while(keysetIterator.hasNext()){
				String key = keysetIterator.next().toString();
				Integer value = parameters.get(key);
				query.setParameter(key, value);
			}			
			return query.list();
		} catch (Exception err) {
			getLogger().error("Error while invoking getListWithParameters method ", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return null;
	}	

	public CustomerBankDetail getCustomerBankDetail(Integer bankId, Integer customerId) {
		Map<String,Integer> parameters = new HashMap<String,Integer>();
		parameters.put("id", bankId);
		parameters.put("customerId", customerId);
		//Review with praveen//
		List customerBankList = getListWithParameters("FROM CustomerBankDetail WHERE id=:id  AND customerId =:customerId",parameters);
		if(customerBankList.isEmpty() || customerBankList == null) {
			return null;
		}
		CustomerBankDetail bank = (CustomerBankDetail) customerBankList.get(0);
		return bank;
	}

	public void deleteCustomerBankDetail(Integer bankId, Integer customerId) {
		Map<String,Integer> parametersMap = new HashMap<String,Integer>();
		parametersMap.put("id",bankId);
		parametersMap.put("customerId",customerId);
		//Review with praveen //
		delete("FROM CustomerBankDetail WHERE id=:id AND customerId =:customerId", parametersMap, null);
	}

	@Override
	public CustomerAdditionalDetails getAdditionalDetails(Integer customerId) {
		CustomerAdditionalDetails additionalDetailsById = null;
		Map<String,Integer> parameters = new HashMap<String,Integer>();
		parameters.put("customerId",customerId);
		//Review with praveen //
		List<CustomerAdditionalDetails> additionalDetails = getListWithParameters("FROM CustomerAdditionalDetails where customer.id =:customerId",parameters);
		if (additionalDetails != null && additionalDetails.size() > 0) {
			additionalDetailsById = additionalDetails.get(0);
		}

		return additionalDetailsById;
	}

	@Override
	@Deprecated
	public CustomerContactVerification getCustomerVerificationDetailsbyId(Integer customerId) {
		CustomerContactVerification userDetailsById = new CustomerContactVerification();
		Map<String,Integer> parameters = new HashMap<String,Integer>();
		parameters.put("customerId", customerId);
		List<CustomerContactVerification> userDetails = getListWithParameters("FROM CustomerContactVerification where customer_id =:customerId",parameters);
		if (userDetails != null && userDetails.size() > 0) {
			userDetailsById = userDetails.get(0);
		}
		return userDetailsById;
	}	

	public List<CustomerOverview> findCustomers(AdminSearchRequestDTO searchRequest) {
		List<CustomerOverview> customers = null;
		List<String> conditions = new ArrayList<>();

		if (searchRequest.getMobileNumber() != null && !searchRequest.getMobileNumber().isEmpty()) {
			conditions.add("mobileNumber = '" + searchRequest.getMobileNumber() + "'");
		}

		if (searchRequest.getEmailId() != null && !searchRequest.getEmailId().isEmpty()) {
			conditions.add("email = '" + searchRequest.getEmailId() + "'");
		}
		if (searchRequest.getCustomerName() != null && !searchRequest.getCustomerName().isEmpty()) {
			conditions.add("customerName = '" + searchRequest.getCustomerName() + "'");
		}

		if (searchRequest.getMoCustomerId() != null && searchRequest.getMoCustomerId() > 0) {
			conditions.add("id= '" + searchRequest.getMoCustomerId() + "'");
		}

		if (searchRequest.getAdvisorId() != null && searchRequest.getAdvisorId() > 0) {
			conditions.add("advisorId= '" + searchRequest.getAdvisorId() + "'");
		}

		String whereClause = "";
		for (String cond : conditions) {
			if (whereClause != "") {
				whereClause += " AND ";
			}
			whereClause += cond;

		}

		List<CustomerOverview> customerIFastDetailsList = null;

		try {
			if (whereClause != null && !whereClause.isEmpty()) {
				customerIFastDetailsList = getPagedList("FROM CustomerOverview where " + whereClause,
						searchRequest.getPageNumber(), searchRequest.getRecordsPerPage());
			} else {
				int startingIndex = searchRequest.getPageNumber() - 1;
				startingIndex *= searchRequest.getRecordsPerPage();
				customerIFastDetailsList = getPagedList("FROM CustomerOverview", startingIndex,
						searchRequest.getRecordsPerPage());
			}
			return customerIFastDetailsList;
		} catch (Exception ex) {
			getLogger().error("Exception while get customer ifast details list: " + ex);
		}
		return customers;
	}

	@Override
	public Customer getCustomerByAdvisor(Integer customerId, Integer advisorId) {
		List<Customer> customer = null;
		Customer customerdetails = null;
		try {
			//Review with Praveen //
			Map<String,Integer> parameters = new HashMap<String,Integer>();
			parameters.put("advisorId",advisorId);
			parameters.put("id",customerId);
			customer = getListWithParameters("FROM Customer c where c.advisorId =:advisorId and c.id =:id",parameters);
			if (customer != null && customer.size() > 0) {
				customerdetails = customer.get(0);

			}

			return customerdetails;
		} catch (Exception ex) {
			getLogger().error("Exception while get customer By Advisor: " + ex);
		}
		return customerdetails;
	}

	@Override
	public List assessmentDetails(Integer customerId) {
		List<CustomerAssessmentDetails> customerAssessmentList = null;
		try {
			Map<String,Integer> parameters = new HashMap<String,Integer>();
			parameters.put("customerId", customerId);
			customerAssessmentList = getListWithParameters("FROM CustomerAssessmentDetails where customerId =:customerId",parameters);
			return customerAssessmentList;
		}
		catch(Exception e) {
			getLogger().error("Exception while get assessment details for the customer: " + customerId + " ====> " + e);
		}
		return customerAssessmentList;
	}

	@Override
	public Advisor getAdvisorById(Integer custId) {
		//To be reviewed by praveen //
		Map<String,Integer> parameters = new HashMap<String,Integer>();
		parameters.put("id",custId);
		List advisorList = getListWithParameters("FROM Advisor where id =:id",parameters);
		if(advisorList == null || advisorList.isEmpty()){
			return null;
		}
		return (Advisor) advisorList.get(0);
	}

	@Override
	public CustomerAndPrevilegeV2 signupV2(Customer customerDetails) throws DatabaseAccessException {
		List<CustomerPrevilege> customerPrevileges = null;
		getLogger().info("Persisting the customer details ...");
		try {
			Integer enquiryId = customerDetails.getVerificationEnquiryId();

			Customer existingCustomer = lookForExistingCustomer(customerDetails.getMobileNumber(),
					customerDetails.getEmail(),enquiryId);
			if (existingCustomer != null) {
				getLogger().info("Updating the existing customer :" + existingCustomer.getEmail() + " Mobile :"
						+ existingCustomer.getMobileNumber());
				int customerId = existingCustomer.getId();
				BeanUtils.copyProperties(customerDetails, existingCustomer);
				existingCustomer.setId(customerId);
				getLogger().info("Printing the customer id :" + customerId);
				existingCustomer.setLastUpdatedBy("User");
				existingCustomer.setPassword(customerDetails.getPassword());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				existingCustomer.setLastUpdatedTime(sdf.format(new Date()));
				existingCustomer.setVerificationEnquiryId(enquiryId);
				customerDetails = (Customer) saveOrUpdateObject(existingCustomer);
				customerPrevileges = getExistingPrevileges(customerId);
				if (customerPrevileges == null) {
					customerPrevileges = createPrevilleges(existingCustomer);
				}
			} else {
				getLogger().info("Creating a new customer ");
				customerDetails.setCreatedBy("system");
				customerDetails.setCreatedDate(new Date());
				customerDetails.setVerificationEnquiryId(enquiryId);
				customerDetails = (Customer) saveOrUpdateObject(customerDetails);
				customerPrevileges = createPrevilleges(customerDetails);
			}
			CustomerAndPrevilegeV2 customerAndPrevilegev2 = new CustomerAndPrevilegeV2();
			customerAndPrevilegev2.setCustomer(customerDetails);
			customerAndPrevilegev2.setPrevileges(customerPrevileges);
			return customerAndPrevilegev2;
		} catch (Exception e) {
			getLogger().error("Error while updating the customer information", e);
			throw new DatabaseAccessException();
		}
	}
	
	@Override
	public Object updateObject(Object obj) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.update(obj);
			transaction.commit();
			session.flush();
			return obj;
		} catch (Exception err) {
			getLogger().error("Error while saving the entity", err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	@Override
	public BFAUserDetails loadAdminByEmail(String email) {
		BFAUserDetails bfaUser = null;
		Advisor advisor = getAdvisorFromEmail(email);
		if (advisor != null) {
			List<AdvisorPrevilege> previleges = getAdvisorPrevileges(advisor.getId());
			List<BFAGrantedAuthority> authorities = buildAuthoritiesForAdvisor(previleges);
			bfaUser = createUserDetailsFromAdvisor(advisor);
			bfaUser.setAuthorities(authorities);
			if (advisor.getMobileNumber() != null) {
				bfaUser.setMobileNumber(advisor.getMobileNumber());
			}
		}
		return bfaUser;
	}

	private BFAUserDetails createUserDetailsFromAdvisor(Advisor advisor) {
		BFAUserDetails bfaUser = null;
		try {
			bfaUser = new BFAUserDetails();
			bfaUser.setUsername(advisor.getEmailId());
			bfaUser.setId(advisor.getId());
			if (advisor.getPassword() != null && advisor.getPassword().length > 0) {
				byte[] passwordArray = advisor.getPassword();
				String password;
				password = new String(passwordArray, "UTF-8");
				password = utility.DecryptText(password);
				bfaUser.setPassword(password);
			}
			bfaUser.setEmailVerified(true);
			bfaUser.setMobileVerified(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return bfaUser;
	}

	private List<AdvisorPrevilege> getAdvisorPrevileges(Integer advisorId) {
		List<AdvisorPrevilege> previleges = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("FROM AdvisorPrevilege WHERE advisor.id =:advisorId").setParameter("advisorId", advisorId);
			@SuppressWarnings("unchecked")
			List<AdvisorPrevilege> list = query.list();
			previleges = list;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return previleges;
	}

	private Advisor getAdvisorFromEmail(String email) {
		Advisor advisor = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("FROM Advisor WHERE emailId = :email").setParameter("email", email);
			@SuppressWarnings("unchecked")
			List<Advisor> list = query.list();
			if (list != null && list.size() > 0)
				advisor = list.get(0);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			session.clear();
			session.close();
		}
		return advisor;
	}

	@Override
	public List getObjectByHql(String hqlString, String param, Integer value) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setParameter(param, value);
		return query.list();
	}
	
	/**
	 * BFA-1637 
	 * @param hqlString
	 * @param paramNames
	 * @param values
	 * @return
	 * @throws DatabaseAccessException
	 */
	@Override
	public List<T> getObjectByHql(String hqlString,String[] paramNames,Object[] values) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hqlString);
			for(int i=0;i<paramNames.length ;i++){
				query.setParameter(paramNames[i],values[i]);
			}
			return query.list();
		} catch (Exception err) {
			err.printStackTrace();
			getLogger().error("Error while fetching the records ", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return Collections.emptyList();
	}
	
	private List<BFAGrantedAuthority> buildAuthoritiesV2(Integer customerId) {
		ArrayList<BFAGrantedAuthority> authorities = new ArrayList<BFAGrantedAuthority>();
		List<String> privilegeNames = getPrevilegesForCustomer(customerId);
		privilegeNames.forEach(x -> {
			BFAGrantedAuthority authority = new BFAGrantedAuthority(x);
			getLogger().info("Printing the Previlege Name:" + x);
			authorities.add(authority);
		});
		return authorities;
	}	
	
	public List<Integer> getExistingPrivileges(Integer customerId) {
		String hql = "select cp.previlegetId from CustomerPrevilege cp where customerId=:customerId";
		List privilegeIds = getObjectByHql(hql, "customerId", customerId);
		return privilegeIds;
	}	

	public List<Customer> getCustomerByEmail(String email){
		String hql = "from Customer where email=:email";
		List customers = getObjectByHql(hql, "email", email);
		return customers;
	}
	
	public List<Customer> getCustomerByMobile(String mobileNumber){
		String hql = "from Customer where mobileNumber=:mobileNumber";
		List customers = getObjectByHql(hql, "mobileNumber", mobileNumber);
		return customers;
	}
	
	public List<String> getPrevilegesForCustomer(Integer customerId){
		String privilegesHql = "select pm.PrvilegeName from PrevilageMaster pm, CustomerPrevilege cp where cp.previlegetId = pm.previlegeId and cp.customerId=:customerId";
		List<String> roles = (List<String>) getObjectByHql(privilegesHql, "customerId", customerId);
		return roles;
	}

	@Override
	public CustomerDetailsEditHistory getAddressHistory(Integer customerId, String field, String addressType) {
		 Map<String, Object> parameters = new HashMap<>();
		 CustomerDetailsEditHistory customerDetailsEditHistory = null;
	     parameters.put("customerId", customerId);
	     parameters.put("field",field);
	     parameters.put("addressType",addressType);
	     List<CustomerDetailsEditHistory> addressEditHistoryList =  getList("FROM CustomerDetailsEditHistory WHERE customer.id = :customerId"
	     		+ " and columnName = :field and tableName= :addressType ORDER BY modifiedDate DESC",parameters);
	     if (addressEditHistoryList != null && !addressEditHistoryList.isEmpty()) {
	    	 customerDetailsEditHistory= addressEditHistoryList.get(0);
			} 
	     
		return customerDetailsEditHistory;
	}

}

package com.bfa.investment.entity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "sector_master")
public class Sector {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "sector_id")
	private String sectorId;
	
	@OneToOne
	@JoinColumn(name = "sector_type_master_id")
	private SectorType type;
	
	@Column(name = "risk_rating")
	private double riskRating;
	
	@Transient
	private List<SectorAllocationRiskProfile> sectorAllocations;
	

	@Transient
	@JsonProperty("allocationPercentage")
	private Double allocationPercentage;
	
	
	
	  @Transient
	  @JsonProperty("holdingsCount") 
	  private Integer holdings;
	  
	  @JsonProperty("holdingsCount") 
	  public Integer getHoldings() {
		  return holdings; 
		  }
	  
	  public void setHoldings(Integer holdings) { 
		  this.holdings = holdings; 
		  }
	 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	@JsonProperty("allocationPercentage")
	public Double getAllocationPercentage() {
		return allocationPercentage;
	}

	public void setAllocationPercentage(Double allocationPercentage) {
		this.allocationPercentage = allocationPercentage;
	}

	public Map<String,List<SectorAllocationRiskProfile>> getGroupedAllocationDetails() {
		if (getAllocationDetails() != null) {
			Map<String,List<SectorAllocationRiskProfile>> sectors = getAllocationDetails().stream()
					.collect((Collectors.groupingBy(SectorAllocationRiskProfile::getSectorTitle)));
			
			return sectors.entrySet().stream().sorted((e1,e2)-> e1.getValue().get(0).getListingOrder().compareTo(e2.getValue().get(0).getListingOrder()))
						.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
		}
		else {
			return null;
		}
	}
	
	
	
	
	@JsonIgnore
	public List<SectorAllocationRiskProfile> getAllocationDetails() {
		return sectorAllocations;
	}

	public void setSectorAllocationDetails(List<SectorAllocationRiskProfile> allocations) {
		this.sectorAllocations = allocations;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSectorId() {
		return sectorId;
	}

	public void setSectorId(String sectorId) {
		this.sectorId = sectorId;
	}

	public SectorType getType() {
		return type;
	}

	public void setType(SectorType type) {
		this.type = type;
	}

	public double getRiskRating() {
		return riskRating;
	}

	public void setRiskRating(double riskRating) {
		this.riskRating = riskRating;
	}
	
	@JsonIgnore
	public String getSectorTypeName() {
		return this.type != null ? this.type.getType() : "";
	}
	
	
}

/**
 * 
 */
package com.bfa.comprehensive.core;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "comprehensive_assets_investment")
public class ComprehensiveAssetsInvestment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "investment_type")
	private String typeOfInvestment;

	@Column(name = "investment_amount")
	private Double investmentAmount;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="asset_id", nullable = false)
    ComprehensiveAssets comprehensiveAssets;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getTypeOfInvestment() {
		return typeOfInvestment;
	}

	public void setTypeOfInvestment(String typeOfInvestment) {
		this.typeOfInvestment = typeOfInvestment;
	}

	public Double getInvestmentAmount() {
		return investmentAmount;
	}

	public void setInvestmentAmount(Double investmentAmount) {
		this.investmentAmount = investmentAmount;
	}


	public ComprehensiveAssets getComprehensiveAssets() {
		return comprehensiveAssets;
	}

	public void setComprehensiveAssets(ComprehensiveAssets comprehensiveAssets) {
		this.comprehensiveAssets = comprehensiveAssets;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	

	
	

}

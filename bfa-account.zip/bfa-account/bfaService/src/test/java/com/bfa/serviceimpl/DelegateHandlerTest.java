package com.bfa.serviceimpl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.core.UpdateEnquiryIdInWills;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.CRMCustomerUpdateRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;

@RunWith(SpringJUnit4ClassRunner.class)
public class DelegateHandlerTest {

	@InjectMocks
	private DelegateHandler mDelegateHandler;
	
	@Mock
	private CRMCustomerUpdateRequest mCrmCustomerUpdateRequest;
	
	@Mock
	private CustomerCreationPostRequestV2 mCustomerCreationPostRequestV2;
	
	@Mock
	private UploadingContent mUploadingContent;
	
	int enqId=1;
	
	int cusId=1;
	
	String journeyType="will";
	
	String customerRef ="IMXYlDmP4f4=";
	
	String token = "517879a9-f65e-4f65-a0a3-0234a54be704";
	
	List<UploadingContent> uploadConentList = new ArrayList<>();
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private UpdateEnquiryIdInWills mUpdateEnquiryIdInWills;
	
	@Mock
	private ApplicationContext mApplicationContext;
	
	@Mock
	private UploadService mUploadService;
	
	@Mock
	private CRMServiceUpdater mCRMServiceUpdater;
	
	@Mock
	private Customer mCustomer;
	
	private List<ProductList> selectedProductList = new ArrayList<>();
	
	@Mock
	ProductList mProductList;
	
	@Mock
	private ReissueOTPRunnable mReissueOTPRunnable;
	
	@Mock
	private UserAuthTokenUpdater mUserAuthTokenUpdater;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	@Test(expected = NullPointerException.class)
	public void testUpdateCRMDetails() {
		when((CRMServiceUpdater) this.mApplicationContext.getBean("crmServiceUpdater")).thenReturn(mCRMServiceUpdater);
		when(mCrmCustomerUpdateRequest.getCustomer()).thenReturn(mCustomer);
		when(mCrmCustomerUpdateRequest.getEnquiryId()).thenReturn(1);
		selectedProductList.add(mProductList);
		when(mCrmCustomerUpdateRequest.getSelectedProducts()).thenReturn(selectedProductList);
		mDelegateHandler.updateCRMDetails(mCrmCustomerUpdateRequest, true);
	}

	@Test(expected = NullPointerException.class)
	public void testMaintainAuthTokenState() {
		when((UserAuthTokenUpdater) this.mApplicationContext.getBean("userAuthTokenUpdater")).thenReturn(mUserAuthTokenUpdater);
		mDelegateHandler.maintainAuthTokenState(token, cusId);
	}

	@Test(expected = NullPointerException.class)
	public void testSaveDocument() {
		uploadConentList.add(mUploadingContent);
		when((UploadService) this.mApplicationContext.getBean("uploadService")).thenReturn(mUploadService);
		mDelegateHandler.saveDocument(cusId, uploadConentList);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateCustomerIdForWills() {
		when((UpdateEnquiryIdInWills) mApplicationContext.getBean("updateEnquiryIdInWills")).thenReturn(mUpdateEnquiryIdInWills);
		mDelegateHandler.updateCustomerIdForWills(enqId, cusId);
	}

	@Test(expected = NullPointerException.class)
	public void testReIssueOTP() {
		when((ReissueOTPRunnable) this.mApplicationContext.getBean("reissueOTPRunnable")).thenReturn(mReissueOTPRunnable);
		mDelegateHandler.reIssueOTP(customerRef);
	}

	@Test(expected=NullPointerException.class)
	public void testHandlePostSignupProcess() {
		when(mCustomerCreationPostRequestV2.getJourneyType()).thenReturn("will");
		when(mCustomerCreationPostRequestV2.getEnquiryId()).thenReturn(enqId);
		mDelegateHandler.handlePostSignupProcess(mCustomerCreationPostRequestV2, cusId);
	}

	@Test(expected = NullPointerException.class)
	public void testHandlePostLoginProcess() {
		mDelegateHandler.handlePostLoginProcess(enqId, cusId, journeyType);
	}

}

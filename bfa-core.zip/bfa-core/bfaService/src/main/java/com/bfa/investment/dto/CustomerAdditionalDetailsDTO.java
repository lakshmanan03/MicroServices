package com.bfa.investment.dto;

public class CustomerAdditionalDetailsDTO {
	
	private Boolean isPoliticallyExposed;
	private Boolean beneficialOwner;
	private Boolean connectedToInvestmentFirm;
	private Boolean isSingaporePR;
	
	public Boolean getIsSingaporePR() {
		return isSingaporePR;
	}
	public void setIsSingaporePR(Boolean isSingaporePR) {
		this.isSingaporePR = isSingaporePR;
	}
	public Boolean getIsPoliticallyExposed() {
		return isPoliticallyExposed;
	}
	public void setIsPoliticallyExposed(Boolean isPoliticallyExposed) {
		this.isPoliticallyExposed = isPoliticallyExposed;
	}
	public Boolean getBeneficialOwner() {
		return beneficialOwner;
	}
	public void setBeneficialOwner(Boolean beneficialOwner) {
		this.beneficialOwner = beneficialOwner;
	}
	public Boolean getConnectedToInvestmentFirm() {
		return connectedToInvestmentFirm;
	}
	public void setConnectedToInvestmentFirm(Boolean connectedToInvestmentFirm) {
		this.connectedToInvestmentFirm = connectedToInvestmentFirm;
	}
	
	
	

}

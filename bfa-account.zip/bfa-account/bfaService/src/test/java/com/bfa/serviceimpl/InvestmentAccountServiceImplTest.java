package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.common.dto.AddressDTO;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.dto.CustomerTaxDetailsDTO;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.HouseholdDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.common.entity.Household;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.insurance.core.Customer;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.account.dto.PersonalDetailsDTO;
import com.bfa.investment.dto.FinancialDetailsDTO;
import com.bfa.investment.dto.PEPAdditionalDeclarationDTO;
import com.bfa.investment.dto.PersonalDeclarationDTO;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.util.ServiceResponse;
@RunWith(SpringJUnit4ClassRunner.class)
public class InvestmentAccountServiceImplTest {

	@InjectMocks
	InvestmentAccountServiceImpl mInvestmentAccountServiceImpl;
	
	@Mock
	private MultipartFile mUploadedFile;
	
	@Mock
	private CustomerDetailsDTO mCustomerDetailsDTO;
	
	@Mock
	private Customer mCustomer;
	
	@Mock
	private PersonalDetailsDTO mPersonalDetailsDTO;
	
	@Mock
	private PersonalDeclarationDTO mPersonalDeclarationDTO;
	
	@Mock
	private PEPAdditionalDeclarationDTO mPEPAdditionalDeclarationDTO;
	
	@Mock
	private List<CustomerTaxDetailsDTO> mCustList;
	
	@Mock
	private CustomerTaxDetailsDTO mCustomerTaxDetailsDTO;
	
	@Mock
	private FinancialDetailsDTO mFinancialDetailsDTO;
	
	@Mock
	private HouseholdDTO mHouseholdDTO;
	
	@Mock
	private Household  mHousehold;
	
	@Mock
	private CustomerEmploymentInformation mCusEmploymentInfo;
	
	@Mock
	private EmploymentDetailsDTO mEmploymentDetailsDTO;
	
	@Mock
	private AddressDTO mAddressDTO;
	
	@Mock
	private CustomerEmploymentDetails mCustEmpDetails;
	
	@Mock
	private Address mAddress;
	
	@Mock
	Date mDate;
	
	int cusId = 1;
	
	int enqId=1;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private InvestmentAccountDao mInvestmentAccountDao;
	
	List<CustomerTaxDetails> taxDetails = new ArrayList<>();
	
	@Mock
	CustomerIdentityDetails details;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	@Test
	public void testGetIFastParameters() {
		DetailedCustomerSummary response =	mInvestmentAccountServiceImpl.getIFastParameters(cusId);
		assertNotNull(response);
	}

	@Test
	public void testSaveDocument() {
		when(mUploadedFile.getOriginalFilename()).thenReturn("uploadfile.txt");
		ServiceResponse<Map<String,String>> response = mInvestmentAccountServiceImpl.saveDocument(cusId, mUploadedFile, "type");
		assertNotNull(response);
	
	}

	@Test
	public void testDeleteDocument() {

		boolean res = mInvestmentAccountServiceImpl.deleteDocument(cusId, ".txt");
		assertTrue(res);
	}

	@Test
	public void testSaveInvestmentAccountDetails() {
	
		ServiceResponse<Map<String,String>> response = mInvestmentAccountServiceImpl.saveInvestmentAccountDetails(mCustomerDetailsDTO, cusId);
		assertNotNull(response);
	}

	@Test
	public void testGetCustomer() {
	
	}

	@Test
	public void testSaveCustomerInformations() throws Exception {
		
			when(mPersonalDetailsDTO.getDateOfBirth()).thenReturn(mDate);
			when(mPersonalDetailsDTO.getBirthCountryId()).thenReturn(1);
			when(mCustomerDetailsDTO.getPersonalInfo()).thenReturn(mPersonalDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveCustomerInformations",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test
	public void testsaveCustomerIdentityDetails() throws Exception {
		
			when(mPersonalDetailsDTO.getDateOfBirth()).thenReturn(mDate);
			when(mPersonalDetailsDTO.getBirthCountryId()).thenReturn(1);
			when(mCustomerDetailsDTO.getPersonalInfo()).thenReturn(mPersonalDetailsDTO);
			when(mInvestmentAccountDao.getCustomerIdentityDetails(mCustomer.getId())).thenReturn(details);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveCustomerIdentityDetails",mCustomerDetailsDTO,mCustomer);

	}
	
	@Test
	public void testsaveAdditionsDetails() throws Exception {
		
			when(mPersonalDetailsDTO.getDateOfBirth()).thenReturn(mDate);
			when(mPersonalDetailsDTO.getBirthCountryId()).thenReturn(1);
			when(mCustomer.getId()).thenReturn(1);
			when(mPersonalDeclarationDTO.getPepDeclaration()).thenReturn(mPEPAdditionalDeclarationDTO);
			when(mCustomerDetailsDTO.getPersonalDeclarations()).thenReturn(mPersonalDeclarationDTO);
			when(mCustomerDetailsDTO.getPersonalDeclarations().isPoliticallyExposed()).thenReturn(true);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveAdditionsDetails",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test(expected = NullPointerException.class)
	public void testSaveTaxDetails() throws Exception {
		
			when(mPersonalDetailsDTO.getDateOfBirth()).thenReturn(mDate);
			when(mPersonalDetailsDTO.getBirthCountryId()).thenReturn(1);
			mCustList.add(mCustomerTaxDetailsDTO);
			when(mCustomerDetailsDTO.getTaxDetails()).thenReturn(mCustList);
			when(mInvestmentAccountDao.getCustomerTaxDetails(mCustomer.getId())).thenReturn(taxDetails);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveTaxDetails",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test
	public void testSaveAssetLiabilitiesDetails() throws Exception {
		
			when(mCustomerDetailsDTO.getFinancialDetails()).thenReturn(mFinancialDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveAssetLiabilitiesDetails",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test
	public void testSaveFinancialDetails() throws Exception {
		
			when(mCustomerDetailsDTO.getFinancialDetails()).thenReturn(mFinancialDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveFinancialDetails",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test
	public void testSaveHouseholdDetails() throws Exception {
		
		when(mCustomerDetailsDTO.getHouseholdDetails()).thenReturn(mHouseholdDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveHouseholdDetails",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test
	public void testSaveHouseholdDetailsExcep() throws Exception {
		
			when(mCustomer.getHouseHoldDetail()).thenReturn(mHousehold);
			when(mHouseholdDTO.getHouseHoldIncomeId()).thenReturn(1);
			when(mCustomerDetailsDTO.getHouseholdDetails()).thenReturn(mHouseholdDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "saveHouseholdDetails",mCustomerDetailsDTO,mCustomer);
	}
	
	@Test
	public void testUpdateEmployerAddress() throws Exception {
		
			when(mEmploymentDetailsDTO.getEmployerAddress()).thenReturn(mAddressDTO);
			when(mCustomerDetailsDTO.getEmploymentDetails()).thenReturn(mEmploymentDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "updateEmployerAddress",mCusEmploymentInfo,mCustomerDetailsDTO);
	}
	
	@Test
	public void testUpdateCustomerEmploymentDetails() throws Exception {
		
			when(mCustomerDetailsDTO.getEmploymentDetails()).thenReturn(mEmploymentDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "updateCustomerEmploymentDetails",cusId,enqId,mCustomerDetailsDTO);
	}
	
	@Test
	public void testUpdateEmployerDetails() throws Exception {
		
			when(mCustEmpDetails.getEmployerId()).thenReturn(1442);
			when(mEmploymentDetailsDTO.getEmployerName()).thenReturn("hcl");
			when(mCusEmploymentInfo.getCustomerEmploymentDetails()).thenReturn(mCustEmpDetails);
			when(mCustomerDetailsDTO.getEmploymentDetails()).thenReturn(mEmploymentDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "updateEmployerDetails",mCusEmploymentInfo,mCustomerDetailsDTO);
	}
	
	@Test
	public void testUpdateEmployerContactDetails() throws Exception {
		
		int empId = 442;
		int empAddId=52;

			when(mEmploymentDetailsDTO.getContactNumber()).thenReturn("6123648");
			when(mCustomerDetailsDTO.getEmploymentDetails()).thenReturn(mEmploymentDetailsDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "updateEmployerContactDetails", cusId, empId,empAddId,mCustomerDetailsDTO);
	}
	
	@Test
	public void testupdateCustomerAddressResid() throws Exception {
		
			when(mCustomerDetailsDTO.getResidentialAddress()).thenReturn(mAddressDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "updateCustomerAddress",mCustomer,mCustomerDetailsDTO);
	}

	@Test
	public void testupdateCustomerAddressMailing() throws Exception {
		
			when(mCustomerDetailsDTO.getMailingAddress()).thenReturn(mAddressDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "updateCustomerAddress",mCustomer,mCustomerDetailsDTO);
	}
	
	@Test
	public void testCopyAddress() throws Exception {
		
			when(mCustomerDetailsDTO.getMailingAddress()).thenReturn(mAddressDTO);
			Whitebox.invokeMethod(mInvestmentAccountServiceImpl, "copyAddress",mAddressDTO,mAddress);
	}
	
}

package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "question_option")
public class QuestionOption {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@OneToOne
	@JoinColumn(name = "question_id")
	private Question question;
	
	@OneToOne
	@JoinColumn(name = "option_id")
	private Option option;
	
	@Column(name = "additional_input")
	private String additionalInput;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public Option getOption() {
		return option;
	}

	public void setOption(Option option) {
		this.option = option;
	}

	public String getAdditionalInput() {
		return additionalInput;
	}

	public void setAdditionalInput(String additionalInput) {
		this.additionalInput = additionalInput;
	}
	
	
}

package com.bfa.util;

public class ApplicationConstants {

	public static final String DELIMITER = "###";

	public static final String SUPPORT_HELP_CONTACT = "admin@ntuclink.com.sg";

	public static final String INTERNAL_SERVER_ERROR = "We are unable to process the request";

	public static final String SUCCESSFUL_RESPONSE = "Successful response";

	public static final String INVALID_INPUT = "Invalid user input";

	public static final String AML_VERIFICATION_FAILED = "AML verification failed";

	public static final String AML_VERIFICATION_REJECTED = "AML verification rejected";

	public static final String NO_INPUT_PARAMETERS_FOUND = "No input parameters found";

	public static final String DATABASE_COMMUNICATION_FAILURE = "Database communication failure";

	public static final String INVALID_CAPTCHA = "Please enter a valid captcha";

	public static final String USER_ACCOUNT_CREATED = "User Account created successfully";

	public static final String USER_OPT_VERIFIED_SUCCESSFULLY = "User OTP verified successfully";

	public static final String USER_OTP_EXPIRED = "User OTP expired after 2 Mins";

	public static final String NO_SUCH_USER = "User not found or not verified";

	public static final String INVALID_SECRET_CODE = "Invalid secret key";

	public static final String VALIDATION_ERROR_MOBILE_EXISTS = "Validation error: Mobile number is already in use - Please contact MoneyOwl at ClientSupport@moneyowl.com.sg if you need help with account opening.";

	public static final String VALIDATION_ERROR_EMAIL_EXISTS = "Validation error:Email address is already in use - Please contact MoneyOwl at ClientSupport@moneyowl.com.sg if you need help with account opening.";

	public static final String VALIDATION_ERROR_INVALID_EMAIL = "Validation error:Invalid Email id";

	public static final String VALIDATION_ERROR_INVALID_MOBILE = "Validation error:Invalid Mobile Number";

	public static final String VALIDATION_ERROR_INVALID_MOBILE_NUM = "Validation error:Expected Numeric Mobile Number";

	public static final String VALIDATION_ERROR_INVALID_GENDER = "Validation error:Expected gender";

	public static final String EMAIL_VERIFICATION_FAILED = "Email verification failed";

	public static final String VALIDATION_ERROR_INVALID_CREDENTIALS = "User ID and/or password does not match.";

	public static final String VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED = "Unverified Email and Mobile";

	public static final String VALIDATION_ERROR_EMAIL_UNVERIFIED = "To proceed, please verify your email address. A verification link was sent to your email address during the sign up process.";

	public static final String VALIDATION_ERROR_MOBILE_UNVERIFIED = "Unverified Mobile number";

	public static final String VALIDATION_ERROR_INVALID_PROMO_CODE = "Invalid Promo Code";

	public static final String CREDENTIAL_USED_FOR_5_TIMES = "You cannot reuse your last 5 passwords";
	
	public static final String MISSING_PARTNERID = "Missing partnerId";
	
	public static final String MISSING_APIKEY = "Missing apiKey";
	
	public static final String INVALID_APIKEY_OR_PARTNERID = "Invalid apiKey or partnerId"; 
	
	public static final String INVALID_REQUEST = "Invalid request"; 
	
	public static final String INVALID_SESSION = "Invalid sessionId";
	
	public static final String INVALID_AUTHORIZATION = "Invalid Authorization";
	
    public static String UNABLE_TO_FIND_THE_CUSTOMER = "Unable to find the customer details, please login again";

	// ------------------------------------------------------------------------------------------//
	public static final String VALIDATION_SUCCESS = "Validation success";

	public static final String CRM_NOTIFICATION = "Successfully sent to CRM";

	public static final String SESSION_TIME_OUT = "Internal Error: Session timed out";

	public static final String USER_OTP_VALIDATION_FAILED = "User OTP validation failed";

	public static final String USER_OPT_ALREADY_VERIFIED = "User OTP already verified";

	public static final String INVALID_SESSION_ID = "Invalid request";

	public static final String NO_MATCHING_RECORDS_FOUND = "No matching records found";

	// -------------------------------------------------------------------------------------------//

	public static final String SMS_GATEWAY_PROVIDER = "default_sms_gateway_provider";
	
	//-------------------------------------------------------------------------------------------//
	
	public static final String USER_NOT_FOUND = "Unable to find the customer details";
	
	public static final String LINK_EXPIRED_CREDENTIAL = "Password link already expired";
	
	public static final String LINK_ALREADY_USED_CREDENTIAL = "Password link already used";
	
	public static final String LINK_VALID_CREDENTIAL = "Valid";
	
	public static final String ALREADY_LOGOUT_FROM_ANOTHERTAB = "Your session has unexpectedly expired. Please login again";
	
	public static final String SESSION_TIMEOUT_LOGOUT = "Your session expired due to inactivity. Please login again";
	
	public static final String UNABLE_TO_PROCESS_REQUEST = "Unable to process your request";
	
		// --- Comprehensive Journey Constants ------------- //

	public static final String INVALID_COMPREHENSIVE_PROMO_CODE = "Invalid promo code";

	public static final String COMPREHENSIVE_PROMO_CODE_ALREADY_APPLIED = "Promo code already applied";

	public static final String COMPREHENSIVE_PROMO_CODE_VALID = "Valid promo code";
		
	public static final String WEBUSER = "web-user";
	
	public static final String HAS_ENDOWMENTS = "1";
	
	public static final String HAS_NO_ENDOWMENTS = "0";
	
	public static final int JOURNEY_NOT_STARTED = 0;
	
	public static final int MAXIMUM_INPUT_STEP_COMPLETION = 4;
	
	public static final String VALIDATE_STEP_COMPLETED = "Step completed updated successfully";
	
	public static final String VALIDATE_STEP_COMPLETED_FAILED = "Unable to update the step completion";
	
	public static final String CUSTOMER_ID = "customerId";
	
	public static final int RETIREMENT_AGE = 55;
	
	public static final int RETIREMENT_INVESTMENT_MIN_PERIOD_LITE = 10;
	
	public static final int RETIREMENT_INVESTMENT_MAX_PERIOD_LITE = 40;

	// ---------------------------------------------------------------------------------------//
	
	public static final String VALIDATION_ERROR_MOBILE_ALREADY_VERIFIED = "Validation error: Mobile Number Already Verified";
	
	public static final String VALIDATION_ERROR_EMAIL_ALREADY_VERIFIED = "Validation error:Email Address Already Verified";
	
	public static final String VALIDATION_ERROR_EMAIL_MOBILE_ALREADY_VERIFIED = "Validation error: Mobile Number And Email Address Already Verified";
	
	public static final String IFAST_SERVICE_DOWN = "Oops! something went wrong. Please try again later.";
	
	public static final String NEW_CONSTANT = "new";
	
	public static final String SUBMITTED_CONSTANT = "submitted";
	
	public static final String INVALID_DATE_FORMAT = "Invalid date format - expected format :";
	
	public enum comprehensive_report{
		submitted,ready,edit,error
	};
	

	
	public static final String RECOMM_NO_MATCHING_RECORDS_FOUND = "Sorry, there is no matching product for your search criteria. You may wish to contact our advisers at enquiries@moneyowl.com.sg or 6329 9188 to help you find a suitable product.";
	
	
	public static final String COMPREHENSIVE_ERROR = "Comprehensive Exception occured!";

	public static final String INVESTMENT_JOURNEY_TYPE = "Investment";
	
	public static final String NO_UNLOCK_DETAILS ="Please provide customerId , islocked value & enquiry id";
	
	public static final String LOCK_FEATURE_NOT_ALLOWED = "Not allowed to lock this feature";

	public static final String ACCOUNT_ALREADY_EXISTS = "An account already exists - but not yet verified";
	
	public static final String RSP_TIME_COULD_NOT_BE_UPDATED = "RSP Timings could not be updated";
	
	public static final String EMAIL_LINK_EXPIRED = " Email link expired";
	
	public static final String ERROR_IN_EXISTING_PASSWORD = "Existing password entered is wrong.";
	
	public static final String COMPREHENSIVE_JOURNEY_TYPE = "Comprehensive";
	
	public static final String COMPREHENSIVE_LITE_JOURNEY_TYPE = "Comprehensive-Lite";
	
	public static final String NO_PREVILEGE ="User Doesn't have this previlege";
	
	public static final String NO_RECOMMENDED_PORTFOLIO = "No Recommended Portfolio";
	
	public static final String NO_RISK_ASSESSMENTANSWER = "No Risk assessment answer available";
	
	public static final String PORTFOLIO_NAME_ALREADY_EXISTS = "Portfolio name already exists";
	
	public static final String NO_RECORDS_FOUND = "No Details Found";
	
	public static final String PORTFOLIO_ALREADY_ACCEPTED = "Portfolio Already Accepted";
	
	public static final String CRM_REQUEST_SUBJECT = "Thanks for using MoneyOwl Application.";
	
	public static final String CORPORATE_BIZ = "Corporate Business";
	
	public static final String ONE_TIME_INVESTMENT_MINIMUM = "ONE_TIME_INVESTMENT_MINIMUM";
	
	public static final String MONTHLY_INVESTMENT_MINIMUM = "MONTHLY_INVESTMENT_MINIMUM";
	
	public static final String ROLE_INVEST_10_AUTHORITY = "ROLE_INVEST_10";
	
	public static final String NEW = "NEW";
	
	public static final String GENERATED = "GENERATED";
	
	public static final int QUESTION_COUNT = 4;
	
	public static final String PORTFOLIO_FUNDING_METHOD = "portfolioFundingMethod";
	
	public static final String CASH = "Cash";
	
	// -------------------------------------------- //
	
	public static final int NUMBER_ONE = 1;
	
	public static final String MY_INFO = "MY-INFO";
	
	public static final String IFAST_UPDATE_FAILED = "Failed to update Address to iFAST ";
	
	public static final String ADDRESS_UPDATE_FAILED = "Failed to update Address";

	public static final String IS_TWOFA_VALIDATED = "IS_2FA_VALIDATED";

	public static final String SESSION_ID = "sessionId";

	public static final String TWO_FA_ACTION_TYPE = "2FA";

	public static final String TWO_FA_SUCCEEDED = "2F authentication succeeded";

	public static final String TWO_FA_FAILED = "2F authentication failed";

	public static final String TWO_FA_EXCEEDED_TIME = "2F authentication exceeded time limit";
	
	public static final String ADMIN_EDIT = "Edit";
	
	public static final String CUSTOMER_UPDATE_TYPE = "Update Contact";
	
	// ----------------Email template Business days values---------------------------- //
	
	public static final String SUCCESFUL_PORTFOLIO_BUSINESSDAYS_INVESTMENT = "5";
	
	public static final String SUCCESFUL_PORTFOLIO_BUSINESSDAYS_WISESAVER = "4";
	
	public static final String REDEMPTION_REQ_TO_CASH_ACC_BUSINESSDAYS_INVESTMENT = "7";
	
	public static final String REDEMPTION_REQ_TO_CASH_ACC_BUSINESSDAYS_WISESAVER = "1";
	
	public static final String REDEMPTION_RECEIVED_TO_BANK_BUSINESSDAYS_INVESTMENT = "8";
	
	public static final String REDEMPTION_RECEIVED_TO_BANK_BUSINESSDAYS_WISESAVER = "1-2";
	
	public static final String REDEMPTION_REQ_TO_SRS_ACC_BUSINESSDAYS_INVESTMENT = "8";
	
	public static final String REDEMPTION_REQ_TO_SRS_ACC_BUSINESSDAYS_WISESAVER = "3";
	
	public static final String HUBSPOT_REFERENCE = "hubspotReference";
}

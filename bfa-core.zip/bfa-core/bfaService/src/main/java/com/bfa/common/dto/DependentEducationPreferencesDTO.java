/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class DependentEducationPreferencesDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private int id;

	private int dependentId;
	
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int customerId;

	private int enquiryId;

	private String location;

	private String educationCourse;

	private Double endowmentMaturityAmount;

	private int endowmentMaturityYears;
	
	private int educationSpendingShare;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDependentId() {
		return dependentId;
	}

	public void setDependentId(int dependentId) {
		this.dependentId = dependentId;
	}
	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getEducationCourse() {
		return educationCourse;
	}

	public void setEducationCourse(String educationCourse) {
		this.educationCourse = educationCourse;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Double getEndowmentMaturityAmount() {
		return endowmentMaturityAmount;
	}

	public void setEndowmentMaturityAmount(Double endowmentMaturityAmount) {
		this.endowmentMaturityAmount = endowmentMaturityAmount;
	}

	public int getEndowmentMaturityYears() {
		return endowmentMaturityYears;
	}

	public void setEndowmentMaturityYears(int endowmentMaturityYears) {
		this.endowmentMaturityYears = endowmentMaturityYears;
	}

	public int getEducationSpendingShare() {
		return educationSpendingShare;
	}

	public void setEducationSpendingShare(int educationSpendingShare) {
		this.educationSpendingShare = educationSpendingShare;
	}

	

	
}

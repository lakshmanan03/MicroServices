/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.application.core.BlacklistToken;
import com.bfa.application.security.LogoutService;
import com.bfa.dao.AccountsDao;

/**
 * @author pradheep.p
 *
 */
public class AccountLogoutService implements LogoutService {

	@Autowired
	private AccountsDao accountsDAO;
	
	@Override
	public String isTokenBlackListed(String token) throws Exception {
		String hql = "from BlacklistToken where tokenValue=:token";
		List<BlacklistToken> collection = accountsDAO.getObjectByHql(hql, "token", token);
		if(collection == null || collection.isEmpty()){
			return this.NOT_BLACKLISTED;
		}
		else{
			BlacklistToken bToken = collection.get(0);
			return bToken.getReason();			
		}
	}

}

/**
 * 
 */
package com.bfa.request.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.LogManager;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.application.event.BFAApplicationEvent;
import com.bfa.util.BFALoggerBean;

/**
 * @author pradheep.p
 *
 */
public class QueueProcessorController<T extends ProcessorCommand> implements ApplicationListener, InitializingBean,ApplicationContextAware {

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@Autowired
	private ApplicationProcessorQueue<T> queue;
	
	private ApplicationContext applicationContext;	

	private static final Logger log = Logger.getLogger(QueueProcessorController.class);
	

	public synchronized void addJobToQueue(T obj) {
		log.info("<--------------synchronized() from QueueProcessorController------------>");
		System.out.println("Added job to queue...");
		queue.addJob(obj);
		startProcessingQueue();		
	}

	public  int getOpenJobsSize() {
		return queue.size();
	}

	public void removeJobFromQueue(ProcessorCommand command) {
		queue.remove(command);
	}

	protected  List<T> getPendingJobs() {
		List<T> pendingJobs = new ArrayList<>();
		queue.addAll(pendingJobs);
		return pendingJobs;
	}

	private void startProcessingQueue() {		
		ProcessorCommand command = (ProcessorCommand) queue.poll();
		threadPoolTaskExecutor.execute(command);
		System.out.println("#Starting processing queue #");
		System.out.println("Processing command : " + command.getCommandName());
	}

	@Override
	public void onApplicationEvent(ApplicationEvent event) {
		if (event instanceof BFAApplicationEvent) {
			System.out.println("Received Event...");
			ProcessorCommand command = (ProcessorCommand) event.getSource();
			addJobToQueue((T) command);
		}
		else{
			//System.out.println(event.getClass().getName());
		}
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Setting the shutdown hook");
		Runtime.getRuntime().addShutdownHook(new ShutdownHookHandlerThread(this));
	}	

	class ShutdownHookHandlerThread extends Thread {

		public QueueProcessorController controller;

		public ShutdownHookHandlerThread(QueueProcessorController controller) {
			this.controller = controller;
		}

		public void run() {
			List pendingJobs = controller.getPendingJobs();
			System.out.println("Found : " + pendingJobs.size() + " Jobs");
			for (Object obj : pendingJobs) {
				if (obj instanceof ProcessorCommand) {
					ProcessorCommand command = (ProcessorCommand) obj;
					command.writeToFile();
				}
			}
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {		
		this.applicationContext = context;
	}
	
	public ApplicationContext getApplicationContext(){
		return this.applicationContext;
	}

}

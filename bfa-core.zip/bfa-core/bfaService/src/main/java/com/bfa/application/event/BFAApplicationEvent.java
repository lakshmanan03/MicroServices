/**
 * 
 */
package com.bfa.application.event;

import org.springframework.context.ApplicationEvent;

/**
 * @author pradheep.p
 *
 */
public class BFAApplicationEvent extends ApplicationEvent {
	
	public BFAApplicationEvent(Object source) {
		super(source);		
	}
}

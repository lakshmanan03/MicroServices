/**
 * 
 */
package com.bfa.application.security;

import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author pradheep
 *
 */
public class SecurityInfo {

	public String securityToken;

	public String sessionId;

	public String customerId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public Collection<? extends GrantedAuthority> roles;

	public SecurityInfo(String token, String sessionId, String customerId) {
		this.securityToken = token;
		this.sessionId = sessionId;
		this.customerId = customerId;
	}

	public SecurityInfo(String token, String sessionId, String customerId,
			Collection<? extends GrantedAuthority> roles) {
		this(token, sessionId, customerId);
		this.roles = roles;
	}
}
/**
 * 
 */
package com.bfa.components;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This annotaion will be used to validate the captch text agains the given session id.
 * 
 * How to use:
 * In case if you need to validate a particular captcha for the given session id , use this validation.
 * 
 * Never give a invalid session id throws a Runtime exception.
 * 
 * @author pradheep
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface ValidateCaptcha {

}

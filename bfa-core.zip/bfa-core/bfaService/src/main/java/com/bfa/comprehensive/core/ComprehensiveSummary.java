/**
 * 
 */
package com.bfa.comprehensive.core;

import java.io.Serializable;
import java.util.List;

import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveAssetsDTO;
import com.bfa.common.dto.ComprehensiveDownOnLuckDTO;
import com.bfa.common.dto.ComprehensiveEarningsDTO;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.ComprehensiveInsurancePlanningDTO;
import com.bfa.common.dto.ComprehensiveLiabilitiesDTO;
import com.bfa.common.dto.ComprehensiveRegularSavingsDTO;
import com.bfa.common.dto.ComprehensiveRetirementPlanningDTO;
import com.bfa.common.dto.ComprehensiveSpendingDTO;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.common.dto.DependentSummaryDTO;
import com.bfa.investment.dto.RecommendedPortfolioDTO;
import com.bfa.investment.dto.RiskAssessmentAnswerDTO;

/**
 * @author pradheep.p
 *
 */
public class ComprehensiveSummary implements Serializable {

	private static final long serialVersionUID = 1L; 

	private ComprehensiveEnquiryDTO comprehensiveEnquiry;

	private BaseProfileDTO baseProfile;
	
	private DependentSummaryDTO dependentsSummaryList;

	private List<DependentEducationPreferencesDTO> dependentEducationPreferencesList;

	private ComprehensiveEarningsDTO comprehensiveIncome;

	private ComprehensiveSpendingDTO comprehensiveSpending;

	private List<ComprehensiveRegularSavingsDTO> comprehensiveRegularSavingsList;

	private ComprehensiveDownOnLuckDTO comprehensiveDownOnLuck;

	private ComprehensiveAssetsDTO comprehensiveAssets;

	private ComprehensiveLiabilitiesDTO comprehensiveLiabilities;

	private ComprehensiveInsurancePlanningDTO comprehensiveInsurancePlanning;
	
	private ComprehensiveRetirementPlanningDTO comprehensiveRetirementPlanning;
	
	private RecommendedPortfolioDTO recommendedPortfolio;
	
	private RiskAssessmentAnswerDTO riskAssessmentAnswer;
	

	public RecommendedPortfolioDTO getRecommendedPortfolio() {
		return recommendedPortfolio;
	}

	public void setRecommendedPortfolio(RecommendedPortfolioDTO recommendedPortfolio) {
		this.recommendedPortfolio = recommendedPortfolio;
	}

	public RiskAssessmentAnswerDTO getRiskAssessmentAnswer() {
		return riskAssessmentAnswer;
	}

	public void setRiskAssessmentAnswer(RiskAssessmentAnswerDTO riskAssessmentAnswer) {
		this.riskAssessmentAnswer = riskAssessmentAnswer;
	}

	public ComprehensiveEnquiryDTO getComprehensiveEnquiry() {
		return comprehensiveEnquiry;
	}

	public void setComprehensiveEnquiry(ComprehensiveEnquiryDTO comprehensiveEnquiry) {
		this.comprehensiveEnquiry = comprehensiveEnquiry;
	}

	public BaseProfileDTO getBaseProfile() {
		return baseProfile;
	}

	public void setBaseProfile(BaseProfileDTO baseProfile) {
		this.baseProfile = baseProfile;
	}

	public List<DependentEducationPreferencesDTO> getDependentEducationPreferencesList() {
		return dependentEducationPreferencesList;
	}

	public void setDependentEducationPreferencesList(
			List<DependentEducationPreferencesDTO> dependentEducationPreferencesList) {
		this.dependentEducationPreferencesList = dependentEducationPreferencesList;
	}

	public ComprehensiveEarningsDTO getComprehensiveIncome() {
		return comprehensiveIncome;
	}

	public void setComprehensiveIncome(ComprehensiveEarningsDTO comprehensiveIncome) {
		this.comprehensiveIncome = comprehensiveIncome;
	}

	public ComprehensiveSpendingDTO getComprehensiveSpending() {
		return comprehensiveSpending;
	}

	public void setComprehensiveSpending(ComprehensiveSpendingDTO comprehensiveSpending) {
		this.comprehensiveSpending = comprehensiveSpending;
	}

	public List<ComprehensiveRegularSavingsDTO> getComprehensiveRegularSavingsList() {
		return comprehensiveRegularSavingsList;
	}

	public void setComprehensiveRegularSavingsList(List<ComprehensiveRegularSavingsDTO> comprehensiveRegularSavingsList) {
		this.comprehensiveRegularSavingsList = comprehensiveRegularSavingsList;
	}

	public ComprehensiveDownOnLuckDTO getComprehensiveDownOnLuck() {
		return comprehensiveDownOnLuck;
	}

	public void setComprehensiveDownOnLuck(ComprehensiveDownOnLuckDTO comprehensiveDownOnLuck) {
		this.comprehensiveDownOnLuck = comprehensiveDownOnLuck;
	}

	public ComprehensiveAssetsDTO getComprehensiveAssets() {
		return comprehensiveAssets;
	}

	public void setComprehensiveAssets(ComprehensiveAssetsDTO comprehensiveAssets) {
		this.comprehensiveAssets = comprehensiveAssets;
	}

	public ComprehensiveLiabilitiesDTO getComprehensiveLiabilities() {
		return comprehensiveLiabilities;
	}

	public void setComprehensiveLiabilities(ComprehensiveLiabilitiesDTO comprehensiveLiabilities) {
		this.comprehensiveLiabilities = comprehensiveLiabilities;
	}

	public ComprehensiveInsurancePlanningDTO getComprehensiveInsurancePlanning() {
		return comprehensiveInsurancePlanning;
	}

	public void setComprehensiveInsurancePlanning(ComprehensiveInsurancePlanningDTO comprehensiveInsurancePlanning) {
		this.comprehensiveInsurancePlanning = comprehensiveInsurancePlanning;
	}
	public ComprehensiveRetirementPlanningDTO getComprehensiveRetirementPlanning() {
		return comprehensiveRetirementPlanning;
	}

	public void setComprehensiveRetirementPlanning(ComprehensiveRetirementPlanningDTO comprehensiveRetirementPlanning) {
		this.comprehensiveRetirementPlanning = comprehensiveRetirementPlanning;
	}

	public DependentSummaryDTO getDependentsSummaryList() {
		return dependentsSummaryList;
	}

	public void setDependentsSummaryList(DependentSummaryDTO dependentsSummaryList) {
		this.dependentsSummaryList = dependentsSummaryList;
	}
	

}

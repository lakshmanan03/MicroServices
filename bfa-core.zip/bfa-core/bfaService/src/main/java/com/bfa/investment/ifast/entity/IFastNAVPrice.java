/**
 * 
 */
package com.bfa.investment.ifast.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author DivakarU
 *
 */

@Entity
@Table(name = "vw_nav_price")
public class IFastNAVPrice {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	private String fundId;
	
	private Integer fundRefId;

	private Date navDate;

	private String actualNavDate;
	
	private Double latestNavPrice;
	
	private Date createdDate;

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFundId() {
		return fundId;
	}

	public void setFundId(String productId) {
		this.fundId = productId;
	}

	public String getLatestNavDate() {
		return actualNavDate;
	}

	public void setLatestNavDate(String latestNavDate) {
		this.actualNavDate = latestNavDate;
	}

	public Double getLatestNavPrice() {
		return latestNavPrice;
	}

	public void setLatestNavPrice(Double latestNavPrice) {
		this.latestNavPrice = latestNavPrice;
	}
	
	

	/**
	 * @return the navDate
	 */
	public Date getNavDate() {
		return navDate;
	}

	/**
	 * @param navDate the navDate to set
	 */
	public void setNavDate(Date navDate) {
		this.navDate = navDate;
	}

	/**
	 * @return the actualNavDate
	 */
	public String getActualNavDate() {
		return actualNavDate;
	}

	/**
	 * @param actualNavDate the actualNavDate to set
	 */
	public void setActualNavDate(String actualNavDate) {
		this.actualNavDate = actualNavDate;
	}

	@Override
	public String toString() {
		return "IFastNAVPrice [id=" + id + ", fundId=" + fundId + ", navDate=" + navDate + ", actualNavDate="
				+ actualNavDate + ", latestNavPrice=" + latestNavPrice + ", createdDate=" + createdDate + "]";
	}

	public Integer getFundRefId() {
		return fundRefId;
	}

	public void setFundRefId(Integer fundRefId) {
		this.fundRefId = fundRefId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */


}


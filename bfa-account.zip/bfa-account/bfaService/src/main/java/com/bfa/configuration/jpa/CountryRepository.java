package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.Country;

public interface CountryRepository extends CrudRepository<Country, String> {
	
	Optional<Country>  findFirstByNationalityCode(String nattionalityCode);
	

}

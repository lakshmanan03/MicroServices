package com.bfa.investment.dto;

import java.util.List;

public class PendingRequestDTO {

	private int numberOfPendingRequests;
	private List<TransactionDetailsDTO> transactionDetailsDTO;
	/**
	 * @return the numberOfPendingRequests
	 */
	public int getNumberOfPendingRequests() {
		return numberOfPendingRequests;
	}
	/**
	 * @param numberOfPendingRequests the numberOfPendingRequests to set
	 */
	public void setNumberOfPendingRequests(int numberOfPendingRequests) {
		this.numberOfPendingRequests = numberOfPendingRequests;
	}
	/**
	 * @return the transactionDetailsDTO
	 */
	public List<TransactionDetailsDTO> getTransactionDetailsDTO() {
		return transactionDetailsDTO;
	}
	/**
	 * @param transactionDetailsDTO the transactionDetailsDTO to set
	 */
	public void setTransactionDetailsDTO(List<TransactionDetailsDTO> transactionDetailsDTO) {
		this.transactionDetailsDTO = transactionDetailsDTO;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PendingRequestDTO [numberOfPendingRequests=");
		builder.append(numberOfPendingRequests);
		builder.append(", transactionDetailsDTO=");
		builder.append(transactionDetailsDTO);
		builder.append("]");
		return builder.toString();
	}
	
	
}


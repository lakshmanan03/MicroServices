/**
 * 
 */
package com.bfa.insurance;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.bfa.application.core.EnquiryByEmail;
import com.bfa.application.core.ValidateCaptchaBean;
import com.bfa.common.dto.ResetPasswordDTO;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.Dependents;
import com.bfa.insurance.core.DependentsProtectionNeedsJoined;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.insurance.product.ProductList;
import com.bfa.service.PasswordResetStatus;
import com.bfa.serviceimpl.CommunicationServiceImpl;
import com.bfa.serviceimpl.DefaultEnquiryService;
import com.bfa.serviceimpl.SecurityServiceImpl;

/**
 * @author pradheep.p
 *
 */

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure = false)
public class DAOImplTest {	
	
	@Mock
	private AccountsDao accountsDAO;
	
//	@Mock
	private MockMvc mockMvc;
	
	@InjectMocks
	private CommunicationServiceImpl communicationServiceImpl;
	
	@Mock
	private DefaultEnquiryService defaultEnquiryService;
	
	@InjectMocks
	private SecurityServiceImpl securityServiceImpl;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	private List sessionDetailList = new ArrayList<>();
	
	@Mock
	private List customers;

	@Mock
	private Customer mCustomer;
	
	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}


	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	/* Test for communication service Impl : BFA-1637 */
	@Test
	public void testCommunicationServiceImpl(){
		System.out.println("-- Testing Communication Service Impl ---");
		Customer customerObj = getSampleCustomer();
		accountsDAO.saveObject(customerObj);	
		
//		customers.add(1);
//		customers.add(2);
		Customer custObj = new Customer();
		customers.add(custObj);
		when(accountsDAO.getObjectByHql("from Customer where mobileNumber =:mobileNumber","mobileNumber",80000001)).thenReturn(customers);
		when((Customer) customers.get(0)).thenReturn(mCustomer);
		int testByMobile = communicationServiceImpl.resendVerificationEmail(customerObj.getMobileNumber(), "", "http://bfa-dev.ntucbfa.cloud/accounts/resend-test.html", "localhost");
		int testByEmail = communicationServiceImpl.resendVerificationEmail("", customerObj.getEmail(), "http://bfa-dev.ntucbfa.cloud/accounts/resend-test.html", "localhost");
		Assert.assertTrue(testByMobile == 0);
		System.out.println(" Printing the value :" + testByMobile);	
	}
	
	/* BFA-1637 */
	@Test
	public void testDefaultEnquiryService(){
		System.out.println("--- Testing the default enquiry service ---");		
		SessionDetails sessionDetail = new SessionDetails();
		String sessionId = "456-78df-bhjqAs-4590-ws321";
		sessionDetail.setSessionId(sessionId);
		sessionDetail.setCaptcha("abc123");
		sessionDetail.setBrowser("Chrome");
		sessionDetail.setDevice("Mobile");
		sessionDetail.setIpAddress("0.0.0.0");
		accountsDAO.saveObject(sessionDetail);
		
		ValidateCaptchaBean validateCaptchaBean  = new ValidateCaptchaBean();
		validateCaptchaBean.setCaptcha("abc123");
		validateCaptchaBean.setSessionId(sessionId);		
		EnquiryByEmail sampleEnquiryByEmail =  getSampleEnquiryByEmail();
		sampleEnquiryByEmail.setValidateCaptchaBean(validateCaptchaBean);
		String result = defaultEnquiryService.updateSelectedProductsByEmail(validateCaptchaBean, sampleEnquiryByEmail);
		System.out.println("Printing the results :" + result);
		
		//---------------------------------------------//
		Dependents dependent = new Dependents();
		dependent.setAge("12");
		dependent.setEnquiryId(1);
		dependent.setGender("male");
		dependent.setId(1);
		dependent.setRelationship("Child");
		accountsDAO.saveObject(dependent);
		//----------------------------------------------//
		DependentsProtectionNeedsJoined dependentProtectionNeeds = new DependentsProtectionNeedsJoined();
		dependentProtectionNeeds.setCountryOfEducation("Singapore");
		dependentProtectionNeeds.setDependentId(1);
		dependentProtectionNeeds.setEducationCourse("medicine");
		dependentProtectionNeeds.setEnquiryId(1);
		dependentProtectionNeeds.setMonthlySupportAmount(500.45);
		dependentProtectionNeeds.setNationality("Singaporean");
		dependentProtectionNeeds.setPremiumWaiver(false);
		dependentProtectionNeeds.setUniversityEntryAge(18);
		dependentProtectionNeeds.setYearsNeeded(20);		
		accountsDAO.saveObject(dependentProtectionNeeds);
		//---------------------------------------------//
		List<DependentMapping> dependentMappingList = defaultEnquiryService.getDependentDetails(1);
		Assert.assertNotNull(dependentMappingList);
	}
	
	private EnquiryByEmail getSampleEnquiryByEmail(){
		EnquiryByEmail enquiryByEmail = new EnquiryByEmail();
		enquiryByEmail.setAcceptMarketingEmails(false);
		enquiryByEmail.setContactViaMobile(true);
		enquiryByEmail.setEmail("testemail@testdomain.co.sg");
		enquiryByEmail.setEnquiryId(1);
		enquiryByEmail.setFirstName("Kevin");
		enquiryByEmail.setLastName("Goh");
		enquiryByEmail.setMobileNumber("85630012");
		List<ProductList> selectedProducts = new ArrayList<ProductList>();
		ProductList productList = new ProductList();
		productList.setAuthorised(true);
		productList.setBrochureLink("http://link.com/1/");
		productList.setCashPayoutFrequency("Monthly");
		selectedProducts.add(productList);
		enquiryByEmail.setSelectedProducts(selectedProducts);
		return enquiryByEmail;
	}
	
	/* SecurityServiceImpl test for BFA-1637*/
	@Test
	public void testAccountsServiceImpl(){
		System.out.println("--- Testing accounts service impl tests ---");
		// Test getPromoCode method test // 
		Enquiry enqObj = new Enquiry();
		enqObj.setId(1);
		enqObj.setPromoCodeId("1");
		accountsDAO.saveObject(enqObj);
		securityServiceImpl.savePromocode(1, 1);
		
		// Test getSessionDetailsBySessionId Method //
		SessionDetails sessionDetail = new SessionDetails();
		String sessionId = "456-78df-bhjqAs-4590-ws321";
		sessionDetail.setSessionId(sessionId);
		sessionDetail.setCaptcha("abc123");
		sessionDetail.setBrowser("Chrome");
		sessionDetail.setDevice("Mobile");
		sessionDetail.setIpAddress("0.0.0.0");
	//	accountsDAO.saveObject(sessionDetail);
		String hql = "from SessionDetails where sessionId =:sessionId";
	//	sessionDetailList.add(1);
	//	sessionDetailList.add(2);
		sessionDetailList.add(sessionDetail);
		when(accountsDAO.getObjectByHql(hql,"sessionId",sessionId)).thenReturn(sessionDetailList);
		SessionDetails obj = securityServiceImpl.getSessionDetailsBySessionId(sessionId);
		Assert.assertEquals(obj.getSessionId(), sessionId);
		Assert.assertNotNull(obj);
		
		/* Test for reset password - BFA-1673 */
		//{"password":"U2FsdGVkX19e4hPcS01Wnda/Fs/tmPaPsRakGR5tm46uDw/5ClQNThgCTSrloiTJhWJNp/lH976gQgACUPP4sVmrb8cfGBjzPi1cxiyIqVvhoOUV4KpNhXSpnIl6xmSBnuUHRrUMz2GSg7eN3wwS5pF2zFH/Y7LkSwsrEmTg6571mGXDIDY2qwZeOvrr9gxLXwKdp4N7ETOOgUWPTpLtjw==","resetKey":"Cjmbf9nZ642fVDPkt12tFmniFsTgf_W4urBP68UiB26cmS8VvHNhMWcwTIEp8heslIyL0AIiSnGN8zkNMNj8b32-1DFMwQOyekqNyPKbxdTmz9H2m_fgqb8NH7QbBsluGcAxGMoLxlAc7Ma7bkcF8fYR0l7sU5PhmSOWi5t9hUx2VoSTqoANNnLxjR1sGFHMLX9i3t3LRmO_UEpFVeaMUMjodfEiSSwoTmJvywq1YJ_oIsxGxVrlpQ","sessionId":"8ae14fa5-9ad3-4b9b-8981-375fe57665f8"}
		Customer customerObj = getSampleCustomer();
		customerObj.setEmail("mat.cat@yopmail.com");		
		accountsDAO.saveObject(customerObj);
		String password = "U2FsdGVkX19e4hPcS01Wnda/Fs/tmPaPsRakGR5tm46uDw/5ClQNThgCTSrloiTJhWJNp/lH976gQgACUPP4sVmrb8cfGBjzPi1cxiyIqVvhoOUV4KpNhXSpnIl6xmSBnuUHRrUMz2GSg7eN3wwS5pF2zFH/Y7LkSwsrEmTg6571mGXDIDY2qwZeOvrr9gxLXwKdp4N7ETOOgUWPTpLtjw==";
		String resetKey = "Cjmbf9nZ642fVDPkt12tFmniFsTgf_W4urBP68UiB26cmS8VvHNhMWcwTIEp8heslIyL0AIiSnGN8zkNMNj8b32-1DFMwQOyekqNyPKbxdTmz9H2m_fgqb8NH7QbBsluGcAxGMoLxlAc7Ma7bkcF8fYR0l7sU5PhmSOWi5t9hUx2VoSTqoANNnLxjR1sGFHMLX9i3t3LRmO_UEpFVeaMUMjodfEiSSwoTmJvywq1YJ_oIsxGxVrlpQ"; 
		String sessionIdNew = "8ae14fa5-9ad3-4b9b-8981-375fe57665f8";
		ResetPasswordDTO resetPasswordDTO = new ResetPasswordDTO();
		resetPasswordDTO.setPassword(password);
		resetPasswordDTO.setSessionId(sessionIdNew);
		resetPasswordDTO.setResetKey(resetKey);
		resetPasswordDTO.setIsAdmin(false);
		
		PasswordResetStatus passwordResetStatus = securityServiceImpl.resetPassword(resetPasswordDTO);
		Assert.assertNotNull(passwordResetStatus);
	}
	
	/* Test for SecurityServiceImpl - BFA-1637 */
	//@Test
	public void testUpdateCRMPostCreation(){
		System.out.println("Testing - SecurityServiceImpl - UpdateCRMPostCustomerCreation .");
		Enquiry enqObj = new Enquiry();
		enqObj.setId(1);
		enqObj.setPromoCodeId("1");
		accountsDAO.saveObject(enqObj);
		
		List<ProductList> selectedProducts = new ArrayList<ProductList>();
		ProductList productList = new ProductList();
		productList.setAuthorised(true);
		productList.setBrochureLink("http://link.com/1/");
		productList.setCashPayoutFrequency("Monthly");
		selectedProducts.add(productList);
		//securityServiceImpl.updateCRMPostCustomerCreation("1", selectedProducts, false, 1);
		//securityServiceImpl.updateCRMEnqByEmail("1", selectedProducts, false, 1, "Wei", "Hong");
	}
	
	private Customer getSampleCustomer() {
		Customer customerObj = new Customer();
		customerObj.setEmail("test@email.com");
		customerObj.setGender("male");
		customerObj.setSurName("test");
		customerObj.setGivenName("testuser");
		customerObj.setMobileNumber("80000001");
		customerObj.setSmoker(true);
		customerObj.setEmailVerified("Yes");
		customerObj.setOtpString("11111");
		customerObj.setOtpVerfied("Yes");
		customerObj.setCreatedDate(new Date());
		customerObj.setDateOfBirth("18/04/1990");
		customerObj.setCountryCode("65");
		customerObj.setVerificationEnquiryId(100);
		return customerObj;
	}

}
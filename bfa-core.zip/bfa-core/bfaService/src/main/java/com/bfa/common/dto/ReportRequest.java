package com.bfa.common.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
/**
 * 
 * @author weihao
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"reportId",
"enquiryId",
"customerId",
"reportType",
})
public class ReportRequest {
	
	@JsonProperty("reportId")
	private Integer reportId;
	@JsonProperty("enquiryId")
	private Integer enquiryId;
	@JsonProperty("customerId")
	private Integer customerId;
	@JsonProperty("reportType")
	private String reportType;
	
	/**
	 * @return the reportId
	 */
	public Integer getReportId() {
		return reportId;
	}
	/**
	 * @param reportId the reportId to set
	 */
	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}
	public Integer getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
	
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	public String getReportType() {
		return reportType;
	}
	public void setReportTpye(String reportType) {
		this.reportType = reportType;
	}
	@Override
	public String toString() {
		return "ReportRequest [enquiryId=" + enquiryId + ", customerId=" + customerId + ", reportType=" + reportType +"]";
	}
	

}

/**
 * 
 */
package com.bfa.comprehensive.core;

import java.io.Serializable;
import java.util.List;

import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveAssetsDTO;
import com.bfa.common.dto.ComprehensiveDownOnLuckDTO;
import com.bfa.common.dto.ComprehensiveEarningsDTO;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.ComprehensiveInsurancePlanningDTO;
import com.bfa.common.dto.ComprehensiveLiabilitiesDTO;
import com.bfa.common.dto.ComprehensiveRegularSavingsDTO;
import com.bfa.common.dto.ComprehensiveRetirementPlanningDTO;
import com.bfa.common.dto.ComprehensiveSpendingDTO;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.common.dto.DependentSummaryDTO;

/**
 * 
 * @author GajendraK
 *
 */
public class ComprehensiveStatusSummary implements Serializable {

	private static final long serialVersionUID = 1L; 

	private ComprehensiveEnquiryDTO comprehensiveEnquiry;

	private BaseProfileDTO baseProfile;

	public ComprehensiveEnquiryDTO getComprehensiveEnquiry() {
		return comprehensiveEnquiry;
	}

	public void setComprehensiveEnquiry(ComprehensiveEnquiryDTO comprehensiveEnquiry) {
		this.comprehensiveEnquiry = comprehensiveEnquiry;
	}

	public BaseProfileDTO getBaseProfile() {
		return baseProfile;
	}

	public void setBaseProfile(BaseProfileDTO baseProfile) {
		this.baseProfile = baseProfile;
	}
	
}

package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"customer_id"
})

public class CustomerSrsPopStatusRequest {
	
	@JsonProperty("customer_id")
	private Integer customerId;
	
	@JsonProperty("check")
	private Boolean check;

	@JsonProperty("customer_id")
	public Integer getCustomerId() {
		return customerId;
	}

	@JsonProperty("customer_id")
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	@JsonProperty("check")
	public Boolean getCheck() {
		return check;
	}
	
	@JsonProperty("check")
	public void setCheck(Boolean check) {
		this.check = check;
	}
	
	
	
}

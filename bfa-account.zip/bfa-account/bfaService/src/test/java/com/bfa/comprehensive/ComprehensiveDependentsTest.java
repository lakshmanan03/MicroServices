package com.bfa.comprehensive;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.BeanUtils;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.DependentDTO;
import com.bfa.comprehensive.core.ComprehensiveEnquiry;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.daoimpl.ComprehensiveDaoImpl;
import com.bfa.insurance.core.ComprehensiveDependentMapping;
import com.bfa.insurance.core.Customer;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.serviceimpl.ComprehensiveServiceImpl;
import com.bfa.util.ApplicationConstants;

import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
public class ComprehensiveDependentsTest extends TestCase {

	private int customerId =  74058;

	private int enquiryId = 92696;

	@Mock
	private ComprehensiveServiceImpl comprehensiveServiceImpl;

	@Mock
	private ComprehensiveDaoImpl comprehensiveDAO;

	@Mock
	private AccountsDao accountsDAO;
	
	@Mock
	ComprehensiveEnquiryPreferencesHelper comprehensiveEnquiryPreferencesHelper;	
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Mock
	private Customer cObj;
	
	
	protected Logger getLogger() {
		return mApplicationLoggerBean.getLogBean(this.getClass());
	}
	
	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	     
	}
	
	ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();
	
	ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = new ComprehensiveEnquiryPostResponse();

	@Transactional
	public void createUser() { // Sonar: Non-public methods should not be "@Transactional"

		
		getLogger().info("--- Inserting customer in createUser---");
		Customer customerObj = new Customer();
		customerObj.setEmail("test@email.com");
		customerObj.setGender("male");
		customerObj.setSurName("test");
		customerObj.setGivenName("testuser");
		customerObj.setMobileNumber("80000001");
		customerObj.setSmoker(true);
		customerObj.setEmailVerified("Yes");
		customerObj.setOtpString("11111");
		customerObj.setOtpVerfied("Yes");
		customerObj.setCreatedDate(new Date());
		customerObj.setDateOfBirth("1990-04-18");
		customerObj.setCountryCode("65");
		customerObj.setVerificationEnquiryId(100);
		when((Customer) accountsDAO.saveObject(customerObj)).thenReturn(cObj);
		getLogger().info("Printing the ID :" + cObj.getId());
		when(cObj.getId()).thenReturn(customerId);

		ComprehensiveEnquiry comprehensiveEnquiry = new ComprehensiveEnquiry();
		comprehensiveEnquiry.setCustomerId(customerId);
		comprehensiveEnquiry.setEnquiryId(enquiryId);
		comprehensiveEnquiry.setSessionTrackerId(0);
		comprehensiveEnquiry.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
		comprehensiveEnquiry.setCreatedBy(ApplicationConstants.WEBUSER);
		comprehensiveEnquiry.setCreatedTimeStamp(new Date());
		comprehensiveEnquiry.setHasComprehensive(false);

		comprehensiveDAO = mock(ComprehensiveDaoImpl.class);
		
		comprehensiveEnquiryPreferencesHelper = mock(ComprehensiveEnquiryPreferencesHelper.class);
		
		comprehensiveServiceImpl.setComprehensiveEnquiryPreferencesHelper(comprehensiveEnquiryPreferencesHelper);

		//Mockito.doNothing().when(comprehensiveDAO).saveComprehensiveEnquiry(comprehensiveEnquiry)
		
		Mockito.doNothing().when(comprehensiveEnquiryPreferencesHelper).saveComprehensiveEnquiry(comprehensiveEnquiryPostRequest);
				
		when(comprehensiveEnquiryPreferencesHelper.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest)).thenReturn(buildComprehensiveEnquiryResponse());

	}
	
	private ComprehensiveEnquiryDTO buildComprehensiveEnquiryDTO(){
		
		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();
		
		comprehensiveEnquiryDTO.setCustomerId(customerId);
		comprehensiveEnquiryDTO.setEnquiryId(enquiryId);
		comprehensiveEnquiryDTO.setSessionTrackerId(0);
		comprehensiveEnquiryDTO.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);		
		comprehensiveEnquiryDTO.setHasComprehensive(false);
		
		return comprehensiveEnquiryDTO;
	}
	
	private ComprehensiveEnquiryPostResponse buildComprehensiveEnquiryResponse(){
		
		comprehensiveEnquiryPostResponse.setComprehensiveEnquiry(buildComprehensiveEnquiryDTO());
		
		return comprehensiveEnquiryPostResponse;
	}

	private List<ComprehensiveDependentMapping> buildDependentsList() {

		getLogger().info("***Building Dependents List...");

		List<ComprehensiveDependentMapping> dependentsList = new ArrayList<>();

		ComprehensiveDependentMapping dependentObject1 = new ComprehensiveDependentMapping();
		dependentObject1.setId(0);
		dependentObject1.setCustomerId(customerId);
		dependentObject1.setEnquiryId(enquiryId);
		dependentObject1.setName("Kamal");
		dependentObject1.setGender("Male");
		dependentObject1.setDateOfBirth("1980-01-20");
		dependentObject1.setNation("Indian");
		dependentObject1.setRelationship("Father");
		dependentObject1.setNoOfHouseholdMembers(2);
		dependentObject1.setHouseHoldIncome("2000 to 4000");

		ComprehensiveDependentMapping dependentObject2 = new ComprehensiveDependentMapping();
		dependentObject2.setId(0);
		dependentObject2.setCustomerId(customerId);
		dependentObject2.setEnquiryId(enquiryId);
		dependentObject2.setName("Kavitha");
		dependentObject2.setGender("Female");
		dependentObject2.setDateOfBirth("1992-05-16");
		dependentObject2.setNation("Indian");
		dependentObject2.setRelationship("Wife");
		dependentObject2.setNoOfHouseholdMembers(2);
		dependentObject2.setHouseHoldIncome("2000 to 4000");

		ComprehensiveDependentMapping dependentObject3 = new ComprehensiveDependentMapping();
		dependentObject3.setId(0);
		dependentObject3.setCustomerId(customerId);
		dependentObject3.setEnquiryId(enquiryId);
		dependentObject3.setName("Arjun");
		dependentObject3.setGender("Male");
		dependentObject3.setDateOfBirth("25-10-2013");
		dependentObject3.setNation("Indian");
		dependentObject3.setRelationship("Son");
		dependentObject3.setNoOfHouseholdMembers(2);
		dependentObject3.setHouseHoldIncome("2000 to 4000");

		dependentsList.add(dependentObject1);
		dependentsList.add(dependentObject2);
		dependentsList.add(dependentObject3);

		return dependentsList;
	}

	private List<ComprehensiveDependentMapping> buildUpdateDependentsList(List<DependentDTO> dtoList) {

		List<ComprehensiveDependentMapping> dependentsList = new ArrayList<>();

		ComprehensiveDependentMapping dependentObject = null;

		for (DependentDTO dto : dtoList) {

			dependentObject = new ComprehensiveDependentMapping();

			BeanUtils.copyProperties(dto, dependentObject);

			dependentsList.add(dependentObject);

		}

		return dependentsList;
	}

	@Test
	public void saveDependentsListTest() {
		getLogger().info("****************Testing Save Dependents List...");
		List<ComprehensiveDependentMapping> dependentsList = buildDependentsList();
		try {
			createUser();
			comprehensiveServiceImpl.saveDependents(dependentsList, customerId, true);
			
			getLogger().info("****************Successfully Saved !!!...");
			
		} catch (DatabaseAccessException e) {

			getLogger().error("Exception occured during saving dependents:" + e);

		}
	}

	@Test
	public void deleteDependentsListTest() {
		getLogger().info("****************Testing Delete Dependents List...");
		List<ComprehensiveDependentMapping> dependentsList = buildDependentsList();
		try {
			createUser();

			comprehensiveServiceImpl.saveDependents(dependentsList, customerId, false);
			
			getLogger().info("****************Successfully Deleted !!!...");

			List<DependentDTO> dependentsDTOList = comprehensiveServiceImpl.getDependentDetailList(customerId,enquiryId);

			getLogger().info("Dependents List Size: " + dependentsDTOList.size());

			assertThat(dependentsDTOList, hasSize(0));

		} catch (DatabaseAccessException e) {

			getLogger().error("Exception occured during deleting dependents:" + e);

		}
	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void getDependentsListTest() {

		getLogger().info("****************Testing Get Dependents List...");

		List<ComprehensiveDependentMapping> dependentsList = buildDependentsList();

		ComprehensiveDependentMapping inputObj = dependentsList.get(0);

		inputObj.setCustomerId(customerId);

		List<ComprehensiveDependentMapping> inputList = new ArrayList<>();

		inputList.add(inputObj);

		try {

			comprehensiveServiceImpl.saveDependents(inputList, customerId, true);

			List<DependentDTO> outputList = comprehensiveServiceImpl.getDependentDetailList(customerId,enquiryId);

			getLogger().info("Output List Size: " + outputList.size());

			assertThat(outputList, hasSize(0));

			DependentDTO outputObj = outputList.get(0);

			detailsComparision(inputObj, outputObj);

		} catch (DatabaseAccessException e) {

			getLogger().error("Exception occured during getting dependents:" + e);

		}
	}

	private void detailsComparision(ComprehensiveDependentMapping inputObj, DependentDTO output) {

		assertEquals(inputObj.getCustomerId(), output.getCustomerId());
		assertEquals(inputObj.getEnquiryId(), output.getEnquiryId());
		assertEquals(inputObj.getName(), output.getName());
		assertEquals(inputObj.getGender(), output.getGender());
		assertEquals(inputObj.getRelationship(), output.getRelationship());
		assertEquals(inputObj.getDateOfBirth(), output.getDateOfBirth());
		assertEquals(inputObj.getNation(), output.getNation());	

	}

	@Test(expected = IndexOutOfBoundsException.class)
	public void updateDependentsListTest() {
		getLogger().info("****************Testing Update Dependents List...");
		List<ComprehensiveDependentMapping> dependentsList = buildDependentsList();
		try {
			createUser();

			comprehensiveServiceImpl.saveDependents(dependentsList, customerId, true);

			List<DependentDTO> dependentsDTOList = comprehensiveServiceImpl.getDependentDetailList(customerId,enquiryId);

			getLogger().info("Dependents List Size: " + dependentsDTOList.size());

			List<ComprehensiveDependentMapping> dependentNewList = buildDependentsList();

			List<ComprehensiveDependentMapping> dependentUpdateList = buildUpdateDependentsList(dependentsDTOList);
			dependentUpdateList.remove(0);

			dependentNewList.addAll(dependentUpdateList);

			getLogger().info("Dependents New List Size: " + dependentNewList.size());

			comprehensiveServiceImpl.saveDependents(dependentNewList, customerId, true);

			List<DependentDTO> dependentsDTOList1 = comprehensiveServiceImpl.getDependentDetailList(customerId,enquiryId);

			getLogger().info("Dependents Final List Size: " + dependentsDTOList1.size());

			assertThat(dependentsDTOList1, hasSize(5));

		} catch (DatabaseAccessException e) {

			getLogger().error("Exception occured during updating dependents:" + e);

		}
	}

}

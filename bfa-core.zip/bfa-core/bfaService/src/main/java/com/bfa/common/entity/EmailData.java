/**
 * 
 */
package com.bfa.common.entity;

/**
 * @author pradheep.p
 *
 */
import java.util.List;
import java.util.Map;

import com.bfa.common.dto.ComprehensivePromoCodeDTO;
import com.bfa.comprehensive.dto.InsuranceAgentCallback;
import com.bfa.investment.dto.FundInvestmentDTO;
import com.bfa.investment.dto.PendingTransactionDTO;
import com.bfa.investment.entity.PortfolioTransactionDetails;

public class EmailData {

	private CustomerData customer;

	private Common common;

	private FailureReasons failureReasons;

	private CustomerInvestmentDetails customerInvestmentDetailsObj;

	private PortfolioTransactionDetails portfolioDetailsObj;

	private CustomerTransactionDetails customerTransactionDetails;

	private List<PendingTransactionDTO> pendingTxnObj;

	private List<FundInvestmentDTO> fundInvestObj;

	private Map<String, Object> additionalInfo;
	private ComprehensivePromoCodeDTO comprehensivePromoCode;

	private InsuranceAgentCallback insuranceCallbackAgent;

	public CustomerData getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerData customer) {
		this.customer = customer;
	}

	public Common getCommon() {
		return common;
	}

	public void setCommon(Common common) {
		this.common = common;
	}

	public FailureReasons getFailureReasons() {
		return failureReasons;
	}

	public void setFailureReasons(FailureReasons failureReasons) {
		this.failureReasons = failureReasons;
	}

	public CustomerInvestmentDetails getCustomerInvestmentDetailsObj() {
		return customerInvestmentDetailsObj;
	}

	public void setCustomerInvestmentDetailsObj(CustomerInvestmentDetails customerInvestmentDetailsObj) {
		this.customerInvestmentDetailsObj = customerInvestmentDetailsObj;
	}

	public PortfolioTransactionDetails getPortfolioDetailsObj() {
		return portfolioDetailsObj;
	}

	public void setPortfolioDetailsObj(PortfolioTransactionDetails portfolioDetailsObj) {
		this.portfolioDetailsObj = portfolioDetailsObj;
	}

	public CustomerTransactionDetails getCustomerTransactionDetails() {
		return customerTransactionDetails;
	}

	public void setCustomerTransactionDetails(CustomerTransactionDetails customerTransactionDetails) {
		this.customerTransactionDetails = customerTransactionDetails;
	}

	public List<PendingTransactionDTO> getPendingTxnObj() {
		return pendingTxnObj;
	}

	public void setPendingTxnObj(List<PendingTransactionDTO> pendingTxnObj) {
		this.pendingTxnObj = pendingTxnObj;
	}

	public List<FundInvestmentDTO> getFundInvestObj() {
		return fundInvestObj;
	}

	public void setFundInvestObj(List<FundInvestmentDTO> fundInvestObj) {
		this.fundInvestObj = fundInvestObj;
	}

	public ComprehensivePromoCodeDTO getComprehensivePromoCode() {
		return comprehensivePromoCode;
	}

	public void setComprehensivePromoCode(ComprehensivePromoCodeDTO comprehensivePromoCode) {
		this.comprehensivePromoCode = comprehensivePromoCode;
	}

	public InsuranceAgentCallback getInsuranceCallbackAgent() {
		return insuranceCallbackAgent;
	}

	public void setInsuranceCallbackAgent(InsuranceAgentCallback insuranceCallbackAgent) {
		this.insuranceCallbackAgent = insuranceCallbackAgent;
	}

	public Map<String, Object> getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(Map<String, Object> additonalInfo) {
		this.additionalInfo = additonalInfo;
	}

}

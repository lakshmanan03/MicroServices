package com.bfa.common.entity;

public class Common {
	
	private String contactEmail;

	private String advisorynumber;

	private String generalenquiry;
	
	private String contactNumber;
	
	private String loginUrl;
	
	private String faqUrl;

	
	private String companyUrl;
	
	private String baseUrl;

	private String domainUrl;

	public String getFaqUrl() {
		return faqUrl;
	}

	public void setFaqUrl(String faqUrl) {
		this.faqUrl = faqUrl;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
		
	public String getAdvisorynumber() {
		return advisorynumber;
	}

	public void setAdvisorynumber(String advisorynumber) {
		this.advisorynumber = advisorynumber;
	}

	public String getGeneralenquiry() {
		return generalenquiry;
	}

	public void setGeneralenquiry(String generalenquiry) {
		this.generalenquiry = generalenquiry;
	}

	public String getLoginUrl() {
		return loginUrl;
	}

	public void setLoginUrl(String loginUrl) {
		this.loginUrl = loginUrl;
	}

	public String getCompanyUrl() {
		return companyUrl;
	}

	public void setCompanyUrl(String companyUrl) {
		this.companyUrl = companyUrl;
	}	
	
	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getDomainUrl() {
		return domainUrl;
	}

	public void setDomainUrl(String domainUrl) {
		this.domainUrl = domainUrl;
	}
	
	
	
}

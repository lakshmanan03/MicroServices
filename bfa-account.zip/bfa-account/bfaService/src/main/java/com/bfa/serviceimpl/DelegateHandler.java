/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.bfa.application.core.PersistCustomerDetails;
import com.bfa.application.core.PersistCustomerIDForEnquiry;
import com.bfa.application.core.PersistCustomerSelectedProducts;
import com.bfa.application.core.PersistEmailEnqDetails;
import com.bfa.application.core.UpdateEnquiryIdInWills;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.serviceimpl.CreateHubspotContactService;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.ResponseList;
import com.bfa.insurance.product.ProductList;
import com.bfa.notification.messenger.EmailHelper;
import com.bfa.notification.messenger.MessengerDelegate;
import com.bfa.notification.messenger.SMSInitiator;
import com.bfa.notification.messenger.VerifyEmailInitiator;
import com.bfa.notification.messenger.WelcomeEmailInitiator;
import com.bfa.notification.messenger.templates.SMSDetails;
import com.bfa.promotion.model.PromotionBundleModel;
import com.bfa.request.entity.CRMCustomerUpdateRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.request.entity.UpdateCustomerRequest;
import com.bfa.request.entity.UpdateCustomerRequestByEmail;
import com.bfa.request.entity.ads.RetirementPlanningModel;
import com.bfa.request.processor.ProcessorCommand;
import com.bfa.request.processor.QueueProcessorController;
import com.bfa.service.AccountsService;
import com.bfa.service.RetirementLeadService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ServiceNames;
import com.bfa.util.ServiceResponse;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pradheep.p
 *
 */
public class DelegateHandler implements ApplicationContextAware {

	@Autowired
	private QueueProcessorController<ProcessorCommand> queueProcessorController;

	private ApplicationContext applicationContext;

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@Autowired
	private MessengerDelegate messengerDelegate;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	private CreateHubspotContactService createHubspotContactService;

	@Override
	public void setApplicationContext(ApplicationContext obj) throws BeansException {
		this.applicationContext = obj;
	}

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(getClass());
	}

	public void updateCustomerIdAndProducts(UpdateCustomerRequest updateCustomerRequest, List<ProductList> selectedProducts) {
		getLogger().info("Updating the selected products : For customer: " + updateCustomerRequest.getCustomerId() + ", Enquiry Id:" + updateCustomerRequest.getEnquiryId() + " Products :" + selectedProducts.size());
		PersistCustomerSelectedProducts persistCustomerSelectedProducts = (PersistCustomerSelectedProducts) this.applicationContext
				.getBean("persistCustomerSelectedProducts");
		persistCustomerSelectedProducts.setUpdateCustomerRequest(updateCustomerRequest);
		persistCustomerSelectedProducts.setSelectedProducts(selectedProducts);
		threadPoolTaskExecutor.execute(persistCustomerSelectedProducts);
		/* Fix for BFA-1717 */
		updateCustomerId(updateCustomerRequest);
	}

	public void updateCRMDetails(CRMCustomerUpdateRequest crmCustomerUpdateRequest, boolean newCustomer) {
		CRMServiceUpdater crmUpdater = (CRMServiceUpdater) this.applicationContext.getBean("crmServiceUpdater");
		crmUpdater.setCustomerObj(crmCustomerUpdateRequest.getCustomer());
		crmUpdater.setSelectedProducts(crmCustomerUpdateRequest.getSelectedProducts());
		crmUpdater.setEnquiryId(crmCustomerUpdateRequest.getEnquiryId());
		crmUpdater.setNewCustomer(newCustomer);
		threadPoolTaskExecutor.execute(crmUpdater);
	}
	
	public void updateCRMForEnquiryByEmail(String firstName,String lastName,String email, List<ProductList> selectedProducts,Integer enquiryId,boolean isNewCustomer,int emailEnquiryId,String mobileNumber){
		CRMUpdateThreadForEmailRequest crmUpdater = (CRMUpdateThreadForEmailRequest) this.applicationContext.getBean("crmUpdateThreadForEmailRequest");		
		crmUpdater.setSelectedProducts(selectedProducts);
		crmUpdater.setEnquiryId(enquiryId);
		crmUpdater.setNewCustomer(isNewCustomer);
		crmUpdater.setFirstName(firstName);
		crmUpdater.setLastName(lastName);
		crmUpdater.setEmailAddress(email);
		crmUpdater.setEmailEnquiryId(emailEnquiryId);
		crmUpdater.setMobileNumber(mobileNumber);
		threadPoolTaskExecutor.execute(crmUpdater);
	}

	public void sendOTPRequest(SMSDetails smsDetails) {
		SMSInitiator communicator = (SMSInitiator) this.applicationContext.getBean("communicator");
		communicator.setSmsDetails(smsDetails);
		threadPoolTaskExecutor.execute(communicator);
	}

	public void sendVerificationEmail(Customer customer, CustomerContactVerification contactVerification,
			String callbackUrl, String hostedServerName) {
		VerifyEmailInitiator communicator = (VerifyEmailInitiator) this.applicationContext
				.getBean("verifyEmailInitiator");
		communicator.setCustomer(customer);
		communicator.setCallBackUrl(callbackUrl);
		communicator.setHostedServerName(hostedServerName);
		communicator.setContactVerification(contactVerification);
		threadPoolTaskExecutor.execute(communicator);
	}
	
	public void sendWelcomeEmailComprehensive(Customer customer, String callbackUrl, String hostedServerName) {
		
		WelcomeEmailInitiator communicator = (WelcomeEmailInitiator) this.applicationContext.getBean("welcomeEmailInitiator");

		communicator.setCustomer(customer);
		communicator.setCallBackUrl(callbackUrl);
		communicator.setHostedServerName(hostedServerName);
		
		threadPoolTaskExecutor.execute(communicator);
		createHubspotContactService.updateCustomerInformationInHubspot(customer,JourneyTypeEnum.Comprehensive);
	}

	public void sendEmail(String fromEmail, String toEmail, String subject, String templateName,
			Map<String, String> params) {
		try {
		EmailHelper helper = (EmailHelper) this.applicationContext.getBean("emailHelper");
		helper.setEmailDetails(fromEmail, toEmail, subject, templateName);
		for (Map.Entry<String, String> entry : params.entrySet()) {
			helper.setParam(entry.getKey(), entry.getValue());
		}
		threadPoolTaskExecutor.execute(helper);
		}
		catch (Exception e) {
			getLogger().error("Error while password reset ", e);
		}
	}
	
	public void sendEmail(String fromEmail, String toEmail, String subject, String templateName,
			Map<String, String> params,String[] ccList) {
		try {
		EmailHelper helper = (EmailHelper) this.applicationContext.getBean("emailHelper");
		helper.setCcList(ccList);
		helper.setEmailDetails(fromEmail, toEmail, subject, templateName);
		for (Map.Entry<String, String> entry : params.entrySet()) {
			helper.setParam(entry.getKey(), entry.getValue());
		}
		threadPoolTaskExecutor.execute(helper);
		}
		catch (Exception e) {
			getLogger().error("Error while password reset ", e);
		}
	}

	public EnquiryServiceUpdater getEnquiryServiceUpdater() {
		return (EnquiryServiceUpdater) this.applicationContext.getBean("enquiryServiceUpdater");
	}

	public void maintainAuthTokenState(String token, int customerId) {
		getLogger().info("Maintain authentication token state ");
		UserAuthTokenUpdater userAuthTokenUpdater = (UserAuthTokenUpdater) this.applicationContext
				.getBean("userAuthTokenUpdater");
		userAuthTokenUpdater.setCustomerId(customerId);
		userAuthTokenUpdater.setToken(token);
		threadPoolTaskExecutor.execute(userAuthTokenUpdater);
	}

	public List saveDocument(Integer customerId, List<UploadingContent> uploadingContent) {
		List<Callable<Object>> tasks = new ArrayList<>();
		int counter = 0;
		List<ServiceResponse<Map<String, String>>> aggregator = new ArrayList();
		uploadingContent.forEach(x -> {
			UploadService uploaderService = (UploadService) this.applicationContext.getBean("uploadService");
			FileUploader fileUploader = getFileUploader();
			fileUploader.setResultsAggregator(aggregator);
			fileUploader.setUploadService(uploaderService);
			fileUploader.setCustomerId(customerId);
			fileUploader.setDocumentType(x.getDocumentType());
			fileUploader.setMultiPartFile(x.getMultiPartFile());
			tasks.add(Executors.callable(fileUploader));
		});
		try {
			List<Future<Object>> futures = threadPoolTaskExecutor.getThreadPoolExecutor().invokeAll(tasks);
			return aggregator;
		} catch (IllegalStateException e) {
			getLogger().error("IllegalStateException while save document : " +  e);
		} catch (InterruptedException e) {
			getLogger().error("InterruptedException while save document: " + e);
			// Restore interrupted state... 
			Thread.currentThread().interrupt(); // Sonar: "InterruptedException" should not be ignored
		}
		return null;
	}

	public FileUploader getFileUploader() {
		FileUploader fileUploader = (FileUploader) this.applicationContext.getBean("fileUploader");
		return fileUploader;
	}

	/**
	 * This method is called during the signup process.
	 * 
	 * @param updateCustomerRequest
	 */
	public void updateCustomerId(UpdateCustomerRequest updateCustomerRequest) {
		PersistCustomerDetails persistCustomerDetails = (PersistCustomerDetails) this.applicationContext
				.getBean("persistCustomerDetails");
		persistCustomerDetails.setUpdateCustomerRequest(updateCustomerRequest);		
		threadPoolTaskExecutor.execute(persistCustomerDetails);
	}

	public void updateCustomerIdForWills(Integer enquiryId, Integer customerId) {
		getLogger().info("Updating the customer id:" + customerId + " for the given enquiry id:" + enquiryId
				+ " - Wills journey");
		if (enquiryId == null || customerId == null) {
			getLogger().error("Cannot update enquiry id for customer id : invalid enquiry id / customer id");
			return;
		}
		UpdateEnquiryIdInWills updateEnquiryIdInWills = (UpdateEnquiryIdInWills) applicationContext
				.getBean("updateEnquiryIdInWills");
		updateEnquiryIdInWills.setCustomerId(customerId);
		updateEnquiryIdInWills.setEnquiryId(enquiryId);
		threadPoolTaskExecutor.execute(updateEnquiryIdInWills);
	}

	public void reIssueOTP(String customerRef) {
		getLogger().info("Delegate handler : - Reissue OTP");
		ReissueOTPRunnable reissueOTP = (ReissueOTPRunnable) this.applicationContext.getBean("reissueOTPRunnable");
		reissueOTP.setCustomerRef(customerRef);
		threadPoolTaskExecutor.execute(reissueOTP);
	}

	/**
	 * This method handles the process required for handling after signup
	 * process.
	 */
	public void handlePostSignupProcess(CustomerCreationPostRequestV2 customerCreationPostRequest, Integer customerId) {
		getLogger().info("--- Inside post signup process ---");
		if(customerCreationPostRequest.getJourneyType() != null) {
		//------- HANDLE WILLS AFTER SIGNUP PROCESS -------//
		if (customerCreationPostRequest.getJourneyType().toLowerCase().contains("will")) {
			Integer enquiryId = customerCreationPostRequest.getEnquiryId();
			updateWillsData(enquiryId,customerId);
		}
		}
		else {
			getLogger().error("journey type not specified ! - Cannot make a decision on post process.");
		}
	}

	/**
	 * This method handles the process required after login procedure.
	 */
	public void handlePostLoginProcess(Integer enquiryId,Integer customerId, String journeyType) {
		getLogger().info("Inside post login process.");
		if(null != journeyType) {
		if(journeyType.toLowerCase().contains("will")) {
			updateWillsData(enquiryId,customerId);
		}
		}
		else {
			getLogger().error("Journey type not specified ! - cannot make a post login process.");
		}
	}
	
	/**
	 * This is a common method for updating the wills data from post login process and post signup process.
	 * @param enquiryId
	 * @param customerId
	 */
	private void updateWillsData(Integer enquiryId,Integer customerId) {
		/* Update the customer id - enquiry id */		
		if(enquiryId == null || customerId == null) {
			getLogger().error("Customer id / Enquiry id cannot be null : cannot update wills data");
			return;
		}
		getLogger().info("Handling the wills update process.");
		UpdateEnquiryIdInWills updateEnquiryIdInWills = (UpdateEnquiryIdInWills) this.applicationContext
				.getBean("updateEnquiryIdInWills");
		updateEnquiryIdInWills.setCustomerId(customerId);
		updateEnquiryIdInWills.setEnquiryId(enquiryId);
		threadPoolTaskExecutor.execute(updateEnquiryIdInWills);
		// --------------------------------------------//
		/* Update the customer in enquiry table */
		getLogger().info("Updating the customer id in enquiry table ");
		PersistCustomerIDForEnquiry persistCustomerIdForEnquiry = (PersistCustomerIDForEnquiry) this.applicationContext
				.getBean("persistCustomerIdForEnquiry");
		UpdateCustomerRequest updateCustomerRequest = new UpdateCustomerRequest();
		updateCustomerRequest.setCustomerId(customerId);
		updateCustomerRequest.setEnquiryId(enquiryId);
		persistCustomerIdForEnquiry.setUpdateCustomerRequest(updateCustomerRequest);
		threadPoolTaskExecutor.execute(persistCustomerIdForEnquiry);
		//----------------------------------------------//
	}
	
	public void updateCustomerIdAndEmailEnqId(UpdateCustomerRequestByEmail updateCustomerRequestByEmail) {
		PersistEmailEnqDetails persistEmailEnqDetails = (PersistEmailEnqDetails) this.applicationContext
				.getBean("persistEmailEnqDetails");
		persistEmailEnqDetails.setUpdateCustomerRequestByEmail(updateCustomerRequestByEmail);
		threadPoolTaskExecutor.execute(persistEmailEnqDetails);
	}
	
	public void updateCRMForRetirementLeads(RetirementPlanningModel retirementPlanningModel) {
		getLogger().info("--- Delegate handler updating the CRM records ---");
		CRMUpdaterForRetirementLeads crmUpdaterForRetirementLeads = (CRMUpdaterForRetirementLeads) this.applicationContext.getBean("updateCRMForRetirementLeads");
		crmUpdaterForRetirementLeads.setRetirementPlanningModel(retirementPlanningModel);
		crmUpdaterForRetirementLeads.setProtectionPlan(RetirementLeadService.PROTECTION_TYPE);
		threadPoolTaskExecutor.execute(crmUpdaterForRetirementLeads);
	}
	
	public void updateBundleInformationInCRM(PromotionBundleModel bundleModel){
		getLogger().debug("About to execue the bundle information into CRM ");
		CRMBundleUpdater crmBundleUpdater = (CRMBundleUpdater) this.applicationContext.getBean("crmBundleUpdater");
		crmBundleUpdater.setPromotionBundleModel(bundleModel);
		threadPoolTaskExecutor.execute(crmBundleUpdater);		
	}
}

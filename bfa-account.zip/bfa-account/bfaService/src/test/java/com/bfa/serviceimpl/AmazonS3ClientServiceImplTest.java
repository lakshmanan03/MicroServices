package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.configuration.AccountServiceConfiguration;
import com.bfa.util.AmazonS3ClientServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
public class AmazonS3ClientServiceImplTest {

	@InjectMocks
	private AmazonS3ClientServiceImpl mAmazonS3ClientServiceImpl;
	
	@Mock
	private File mFile;
	
	@Mock
	private MultipartFile mMultipartFile;
	
	String fileName ="abc";
	
	String bucketName = "amazon";
	
	@Test
	public void testUploadStringFile() {
		String response = mAmazonS3ClientServiceImpl.upload(bucketName, fileName, mFile);
		assertNotNull(response);
	}

	@Test(expected=NullPointerException.class)
	public void testUploadStringMultipartFile() throws IOException {
		String str = "PANKAJ";
		byte[] byteArr = str.getBytes();
		when(mMultipartFile.getBytes()).thenReturn(byteArr);
		String response = mAmazonS3ClientServiceImpl.upload(bucketName, fileName, mMultipartFile);
		assertNotNull(response);
	
	}

	@Test
	public void testUploadFileToS3Bucket() throws IOException {
		String str = "PANKAJ";
		byte[] byteArr = str.getBytes();
		when(mMultipartFile.getBytes()).thenReturn(byteArr);
		when(mMultipartFile.getOriginalFilename()).thenReturn("abc");
		String response = mAmazonS3ClientServiceImpl.uploadFileToS3Bucket(bucketName, mMultipartFile);
		assertNotNull(response);
	}

	@Test
	public void testDeleteFileFromS3Bucket() {
		String response = mAmazonS3ClientServiceImpl.deleteFileFromS3Bucket(fileName);
		assertNotNull(response);
	}

}

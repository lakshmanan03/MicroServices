/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.UpdateCustomerRequest;
import com.bfa.request.entity.UpdateCustomerSelectedProductsRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

/**
 * @author pradheep
 *
 */
public class PersistCustomerSelectedProducts extends DiscoveryHelper implements Runnable {

	private UpdateCustomerRequest updateCustomerRequest;

	private List<ProductList> selectedProducts;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private Environment environment;

	@Autowired
	private SecurityConstants constants;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@Override
	public void run() {
		getLogger().info("Updating the customer selected product details ");
		setEnvironment(environment);
		loadSecurityHeader(constants.TOKEN_NAME);
		updateSelectedProductStatus();
	}

	private void updateSelectedProductStatus() {
		getLogger().info("Trying to update the selected products in recommendation service");
		String apiName = APIConstants.UPDATE_SELECTED_PRODUCTS;
		String baseUrl = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE) + apiName;
		baseUrl = removePortNumbers(baseUrl);
		String requestBody = getRequestBodyForSelectedProducts();
		getLogger().info("Updating the recommendations service :" + requestBody);
		getLogger().info("Printing the base url " + baseUrl);
		addJobToQueue(baseUrl, requestBody, "update-selected-products-recommendations", 0);
	}

	private String getRequestBodyForSelectedProducts() {
		UpdateCustomerSelectedProductsRequest updateSelectedProduct = new UpdateCustomerSelectedProductsRequest();
		updateSelectedProduct.setCustomerId(String.valueOf(updateCustomerRequest.getCustomerId()));
		updateSelectedProduct.setEnquiryId(String.valueOf(updateCustomerRequest.getEnquiryId()));
		updateSelectedProduct.setSelectedProducts(this.selectedProducts);
		Gson gson = new Gson();
		String requestBody = gson.toJson(updateSelectedProduct);
		return requestBody;
	}

	public UpdateCustomerRequest getUpdateCustomerRequest() {
		return updateCustomerRequest;
	}

	public void setUpdateCustomerRequest(UpdateCustomerRequest updateCustomerRequest) {
		this.updateCustomerRequest = updateCustomerRequest;
	}

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

}

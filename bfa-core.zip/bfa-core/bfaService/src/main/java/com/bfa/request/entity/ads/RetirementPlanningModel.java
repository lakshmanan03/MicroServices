/**
 * 
 */
package com.bfa.request.entity.ads;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @author pradheep
 * @since Release 4.0
 */
public class RetirementPlanningModel implements Serializable {

	@NotNull(message = "First name cannot be null")
	private String firstName;

	@NotNull(message = "Last name cannot be null")
	private String lastName;

	@NotNull(message = "Mobile number cannot be null")
	private String mobileNumber;

	@NotNull(message = "Email address cannot be null")
	private String emailAddress;

	@NotNull(message = "retirement age cannot be null")
	@Min(0)
	private Integer retirementAge;

	@NotNull(message = "monthly retirement income cannot be null")
	@Digits(integer=1000, fraction=2)
	private Double monthlyRetirementIncome;

	@NotNull(message = "date of birth cannot be null")
	private String dateOfBirth;

	@NotNull(message = "Lumpsum amount cannot be null")
	@Digits(integer=1000, fraction=2)
	private Double lumpSumAmount;

	@NotNull(message = "Monthly amount cannot be null")
	@Digits(integer=1000, fraction=2)
	private Double monthlyAmount;

	private List<String> retirementSchemeList;

	private boolean receiveMarketingMaterials;

	private boolean contactedByMobile;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Integer getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(Integer retirementAge) {
		this.retirementAge = retirementAge;
	}

	public Double getMonthlyRetirementIncome() {
		return monthlyRetirementIncome;
	}

	public void setMonthlyRetirementIncome(Double monthlyRetirementIncome) {
		this.monthlyRetirementIncome = monthlyRetirementIncome;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Double getLumpSumAmount() {
		return lumpSumAmount;
	}

	public void setLumpSumAmount(Double lumpSumAmount) {
		this.lumpSumAmount = lumpSumAmount;
	}

	public Double getMonthlyAmount() {
		return monthlyAmount;
	}

	public void setMonthlyAmount(Double monthlyAmount) {
		this.monthlyAmount = monthlyAmount;
	}

	public List<String> getRetirementSchemeList() {
		return retirementSchemeList;
	}

	public void setRetirementSchemeList(List<String> retirementSchemeList) {
		this.retirementSchemeList = retirementSchemeList;
	}

	public boolean isReceiveMarketingMaterials() {
		return receiveMarketingMaterials;
	}

	public void setReceiveMarketingMaterials(boolean receiveMarketingMaterials) {
		this.receiveMarketingMaterials = receiveMarketingMaterials;
	}

	public boolean isContactedByMobile() {
		return contactedByMobile;
	}

	public void setContactedByMobile(boolean contactedByMobile) {
		this.contactedByMobile = contactedByMobile;
	}	
	
	public String toString() {
		return "First Name:" + getFirstName() + " Last Name:" + getLastName() + " Mobile Number:" + getMobileNumber()
		+ " Email address:" + getEmailAddress() + " Retirement at: " + getRetirementAge()
		+ " Monthly retirement income:" + getMonthlyRetirementIncome() + " Date of birth:" + getDateOfBirth()
		+ " Lumpsum Amount " + getLumpSumAmount() + " Monthly Income :" + getMonthlyAmount()
		+ " Retirement scheme:" + getRetirementSchemeList().toString() + " Receive Marketing Emails: "
		+ isReceiveMarketingMaterials() + " Can contacted by mobile:" + isContactedByMobile();
	}
}

package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.common.entity.Address;
import com.bfa.common.entity.Occupation;
import com.bfa.common.entity.OptionItem;
import com.bfa.insurance.core.Customer;

@Entity
@Table(name = "customer_pep_details")
public class CustomerPEPDetails implements java.io.Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@OneToOne
	@JoinColumn(name="customer_id")
	private Customer customer;

	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="company_name")
	private String companyName;
	
	@OneToOne
	@JoinColumn(name="occupation_id")
	private Occupation occupation;
	
	@Column(name="other_occupation")
	private String otherOccupation;
	
	@OneToOne
	@JoinColumn(name="address_id")
	private Address pepAddress;
	
	@Column(name="expected_number_of_transactions")
	private Integer expectedNumberOfTransactions;
	
	@Column(name="expected_amount_per_transaction")
	private Double expectedAmountPerTransactions;
	
	
	@OneToOne
	@JoinColumn(name="investment_source_id")
	private OptionItem investmentSourceId;

	
	@Column(name="additional_info")
	private String additionalInfo;
	
	@Column(name="investment_period")
	private String investmentPeriod;
	
	@OneToOne
	@JoinColumn(name="investment_period_id")
	private OptionItem investmentPeriodId;
	

	@OneToOne
	@JoinColumn(name="earnings_generated_from_id")
	private OptionItem earningsGeneratedFromId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	

	public String getOtherOccupation() {
		return otherOccupation;
	}

	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Occupation getOccupation() {
		return occupation;
	}

	public void setOccupation(Occupation occupation) {
		this.occupation = occupation;
	}

	public Address getPepAddress() {
		return pepAddress;
	}

	public void setPepAddress(Address pepAddress) {
		this.pepAddress = pepAddress;
	}

	public Integer getExpectedNumberOfTransactions() {
		return expectedNumberOfTransactions;
	}

	public void setExpectedNumberOfTransactions(Integer expectedNumberOfTransactions) {
		this.expectedNumberOfTransactions = expectedNumberOfTransactions;
	}

	public Double getExpectedAmountPerTransactions() {
		return expectedAmountPerTransactions;
	}

	public void setExpectedAmountPerTransactions(Double expectedAmountPerTransactions) {
		this.expectedAmountPerTransactions = expectedAmountPerTransactions;
	}

	public OptionItem getInvestmentSourceId() {
		return investmentSourceId;
	}

	public void setInvestmentSourceId(OptionItem investmentSourceId) {
		this.investmentSourceId = investmentSourceId;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public OptionItem getInvestmentPeriodId() {
		return investmentPeriodId;
	}

	public void setInvestmentPeriodId(OptionItem investmentPeriodId) {
		this.investmentPeriodId = investmentPeriodId;
	}

	public OptionItem getEarningsGeneratedFromId() {
		return earningsGeneratedFromId;
	}

	public void setEarningsGeneratedFromId(OptionItem earningsGeneratedFromId) {
		this.earningsGeneratedFromId = earningsGeneratedFromId;
	}

	public String getInvestmentPeriod() {
		return investmentPeriod;
	}

	public void setInvestmentPeriod(String investmentPeriod) {
		this.investmentPeriod = investmentPeriod;
	}
	
	
	
	
}


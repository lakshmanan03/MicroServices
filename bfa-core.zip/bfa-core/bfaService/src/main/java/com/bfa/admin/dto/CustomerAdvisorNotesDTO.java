package com.bfa.admin.dto;

import java.util.Date;

public class CustomerAdvisorNotesDTO {

	private int id;
	private Integer advisorId;
	private Integer customerId;
	private String advisorComments;
	private Date createdDate;
	private String createdBy;
	private Boolean isDeleteAccessible;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Integer getAdvisorId() {
		return advisorId;
	}
	
	public void setAdvisorId(Integer advisorId) {
		this.advisorId = advisorId;
	}
	
	public Integer getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	public String getAdvisorComments() {
		return advisorComments;
	}

	public void setAdvisorComments(String advisorComments) {
		this.advisorComments = advisorComments;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public Boolean getIsDeleteAccessible() {
		return isDeleteAccessible;
	}
	
	public void setIsDeleteAccessible(Boolean isDeleteAccessible) {
		this.isDeleteAccessible = isDeleteAccessible;
	}

}

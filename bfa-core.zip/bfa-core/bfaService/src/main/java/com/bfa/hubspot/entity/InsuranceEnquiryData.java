/**
 * 
 */
package com.bfa.hubspot.entity;

import com.bfa.request.entity.UpdateCustomerRequest;

/**
 * @author pradheep
 *
 */
public class InsuranceEnquiryData extends UpdateCustomerRequest {
	
	private Boolean emailEnquiryRequest;

	public Boolean getEmailEnquiryRequest() {
		return emailEnquiryRequest;
	}

	public void setEmailEnquiryRequest(Boolean emailEnquiryRequest) {
		this.emailEnquiryRequest = emailEnquiryRequest;
	}
}

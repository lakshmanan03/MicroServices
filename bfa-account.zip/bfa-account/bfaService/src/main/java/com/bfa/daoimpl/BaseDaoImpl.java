package com.bfa.daoimpl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.support.QuerydslRepositorySupport;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.Industry;
import com.bfa.investment.entity.QuestionOption;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.BaseDao;

@Transactional
@Repository
public class BaseDaoImpl<T> implements BaseDao {
	
	@Autowired
	protected SessionFactory sessionFactory;
	
	@Autowired
	private ApplicationLoggerBean loggerBean;
	
	public <T> List<T> getList(Class<T> class1) {
		List<T> retList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria query = session.createCriteria(class1);
			@SuppressWarnings("unchecked")
			List<T> list = query.list();
			retList = list;
		} catch (Exception err) {
			getLogger().error("Exception occured in BaseDaoImpl.getList: " + err);
			throw new DatabaseAccessException("DatabaseAccessException in BaseDaoImpl.getList(): " + err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return retList;
	}

	
	public <T> void update(T object) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.update(object);
			transaction.commit();
		} catch (Exception err) {
			getLogger().error("Exception occured in BaseDaoImpl.update(): " + err);
			throw new DatabaseAccessException();
		}finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}
	
	public <T> void update(List<T> objects) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			for(T object : objects) {
				session.update(object);
			}
			transaction.commit();
		} catch (Exception err) {
			getLogger().error("Exception occured while BaseDaoImpl.update(): " + err);
			throw new DatabaseAccessException();
		}finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}
	
	public <T> void save(List<T> objects) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			for(T object : objects) {
				session.save(object);
			}
			transaction.commit();
		} catch (Exception err) {
			getLogger().error("Exception occured while BaseDaoImpl.save(): " + err);
			throw new DatabaseAccessException();
		}finally { 
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	public void save(Object object) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.save(object);
			transaction.commit();
		} catch (Exception err) {
			getLogger().error("Exception occured while BaseDaoImpl.save(): " + err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}
	
	public void saveOrUpdate(Object object) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.saveOrUpdate(object);
			transaction.commit();
		} catch (Exception err) {
			getLogger().error("Exception occured while BaseDaoImpl.saveOrUpdate(): " + err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}
	
	public <T> List<T> getList(String queryString,String[][] params) {
		Map<String, String> myMap = null;
		if (params != null) {
			myMap = new HashMap<> ();
			for (int i = 0; i < params.length; i++) {
			    myMap.put(params[i][0], params[i][1]);
			}			
		}
		return getList(queryString,myMap,null);
	}
	
	public <T> List<T> getList(String queryString) {
		return getList(queryString,null,null);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T getFirst(String queryString) {
		List<T> retList =  getList(queryString,null,null);
		if (retList != null && !retList.isEmpty())
			return (T) retList.get(0);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public <T> T getFirst(String queryString, Map<String, Object> parameters) {
		List<T> retList = getList(queryString, parameters, null, null, 1);
		if ((retList != null) && !(retList.isEmpty()))
			return retList.get(0);
		return null;
	}
	
	public <T> List<T> getList(String queryString,Map<String,String> parameters) {
		return getList(queryString,parameters,null);
	}
	
	
	
	
	
	public <T> List<T> getList(String queryString, Map<String,String> parameters, Map<String,Collection> listParameters) {
		List<T> retList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(queryString);
			if (parameters != null ) {
			    for (Map.Entry<String, String> entry : parameters.entrySet()) {
			        String key = entry.getKey();
			        Object value = entry.getValue();
			        query.setParameter(key, value);
			    }				
			}
			if (listParameters != null) {
			    for (Map.Entry<String, Collection> entry : listParameters.entrySet()) {
			        String key = entry.getKey();
			        Collection value = entry.getValue();
			        query.setParameterList(key, value);
			    }
			}
			@SuppressWarnings("unchecked")
			List<T> list = query.list();
			retList = list;
		}
		catch (Exception ex) {
			getLogger().error("Exception occured while BaseDaoImpl.getList(): " + ex);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		
		return retList;
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
	public <T> List<T> getList(String queryString, Map<String, Object> parameters,
			Map<String, Collection> listParameters, Consumer<List<T>> action, int limitRows) {
		List<T> retList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(queryString);
			if (parameters != null) {
				addParameters(parameters, query);
			}
			if (listParameters != null) {
				for (Map.Entry<String, Collection> entry : listParameters.entrySet()) {
					String key = entry.getKey();
					Collection value = entry.getValue();
					query.setParameterList(key, value);
				}
			}
			query.setMaxResults(limitRows);
			@SuppressWarnings("unchecked")
			List<T> list = query.list();
			retList = list;
			if (action != null) {
				action.accept(list);
			}
		} catch (Exception ex) {
			
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return retList;
	}

	protected void addParameters(Map<String, Object> parameters, Query query) {
		if (parameters != null) {
			for (Map.Entry<String, Object> entry : parameters.entrySet()) {
				String key = entry.getKey();
				Object value = entry.getValue();
				if (value instanceof Collection) {
					query.setParameterList(key, (Collection) value);
				}
				else
					query.setParameter(key, value);
			}
		}
	}

	
	@Override
	public List<T> getObjectsAsList(Class T) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(T);
		List<T> collection = criteria.list();
		return collection;
	}
	
	public <T> List<T> getPagedList(String queryString, Integer firstResult, Integer maxResults) {
		List<T> retList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(queryString);
			query.setFirstResult(firstResult);
			query.setMaxResults(maxResults);
			@SuppressWarnings("unchecked")
			List<T> list = query.list();
			retList = list;
		} catch (Exception ex) {
			getLogger().error("Exception caught in BaseDaoImpl.getPagedList(): " + ex);
			throw new DatabaseAccessException("DatabaseAccessException in getPagedList(): " + ex.getMessage());
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		
		return retList;
	}
	
	
	
	public void delete(String queryString, Map<String,Integer> parameters, Map<String,Collection> listParameters) {
		List retList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Query query = session.createQuery(queryString);
			if (parameters != null ) {
			    for (Map.Entry<String, Integer> entry : parameters.entrySet()) {
			        String key = entry.getKey();
			        Integer value = entry.getValue();
			        query.setParameter(key, value);
			    }				
			}
			if (listParameters != null) {
				for (Map.Entry<String, Collection> entry : listParameters.entrySet()) {
					String key = entry.getKey();
					Collection value = entry.getValue();
					query.setParameterList(key, value);
				}
			}
			@SuppressWarnings("unchecked")
			List list = query.list();
			if (list != null && !list.isEmpty()) {
				session.delete(list.get(0));
			}
			transaction.commit();
		} catch (Exception ex) {
			getLogger().error("Exception caught in BaseDaoImpl.delete(): " + ex);
			throw new DatabaseAccessException("Exception: " + ex.getMessage());
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
			
		}

	}
	
	@Override
	public Object saveOrUpdateObject(Object obj) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.saveOrUpdate(obj);
			transaction.commit();
			session.flush();
			return obj;
		} catch (Exception err) {
			getLogger().error("Error while saving the entity", err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	protected Logger getLogger() {
		return loggerBean.getLogBean(this.getClass());
	}
	
	@Override
	public Object saveObject(Object obj) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.save(obj);
			transaction.commit();
			return obj;
		} catch (Exception err) {
			getLogger().error("Error while saving the entity", err);
			throw new DatabaseAccessException();
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
	}

	@Override
	public List getObjectsById(Class T, String reference, int value) throws DatabaseAccessException {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(T);
			criteria.add(Restrictions.eq(reference, value));
			List<T> collection = criteria.list();
			return collection;
		} catch (Exception err) {
			getLogger().error("Error while getting the objects by id", err);
		}
		return Collections.emptyList();
	}

	@Override
	public List getObjectsByRef(Class T, String reference, String value) throws DatabaseAccessException {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(T);
			criteria.add(Restrictions.eq(reference, value));
			List<T> collection = criteria.list();
			return collection;
		} catch (Exception err) {
			getLogger().error("Error while getting the objects by id", err);
		}
		return Collections.emptyList();
	}

	@Override
	public List<T> getObjectByHql(String hqlString) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hqlString);
			return query.list();
		} catch (Exception err) {
			getLogger().error("Error while fetching the records ", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return Collections.emptyList();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List getObjectByHql(String hqlString, String param, String value) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setParameter(param, value);
		return query.list();
	}

	@Override
	public List getObjectByHqlAndLimit(String hqlString, int numberOfRecords) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setMaxResults(numberOfRecords);
		return query.list();
	}

	@Override
	public int executeUpdate(String hqlString) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hqlString);
			return query.executeUpdate();
		} catch (Exception err) {
			getLogger().error("Error while executing and update", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return 0;
	}
	
	public List getObjectByHql(String hqlString, String[] paramNames, Object[] values) throws DatabaseAccessException {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hqlString);
			for (int i = 0; i < paramNames.length; i++) {
				query.setParameter(paramNames[i], values[i]);
			}
			return query.list();
		} catch (Exception err) {
			err.printStackTrace();
			getLogger().error("Error while fetching the records ", err);
		} finally {
			if (session != null) {
				session.clear();
				session.close();
			}
		}
		return Collections.emptyList();
	}

	public List getObjectByHql(String hqlString, String param, Integer value) throws DatabaseAccessException {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery(hqlString);
		query.setParameter(param, value);
		return query.list();
	}

}

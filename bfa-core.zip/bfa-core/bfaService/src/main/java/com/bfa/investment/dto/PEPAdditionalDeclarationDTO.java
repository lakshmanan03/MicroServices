package com.bfa.investment.dto;

import com.bfa.common.dto.AddressDTO;

public class PEPAdditionalDeclarationDTO {
	private String firstName;
	private String lastName;
	private String companyName;
	private Integer occupationId;
	private String otherOccupation;
	private AddressDTO pepAddress;
	private Integer expectedNumberOfTransactions;
	private Double expectedAmountPerTransaction;
	private Integer investmentSourceId;
	private String additionalInfo;
	private String investmentDuration;
	private Integer earningSourceId;
	
	
	
	
	public String getOtherOccupation() {
		return otherOccupation;
	}
	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getOccupationId() {
		return occupationId;
	}
	public void setOccupationId(Integer occupationId) {
		this.occupationId = occupationId;
	}
	public AddressDTO getPepAddress() {
		return pepAddress;
	}
	public void setPepAddress(AddressDTO pepAddress) {
		this.pepAddress = pepAddress;
	}
	public Integer getExpectedNumberOfTransactions() {
		return expectedNumberOfTransactions;
	}
	public void setExpectedNumberOfTransactions(Integer expectedNumberOfTransactions) {
		this.expectedNumberOfTransactions = expectedNumberOfTransactions;
	}
	public Double getExpectedAmountPerTransaction() {
		return expectedAmountPerTransaction;
	}
	public void setExpectedAmountPerTransaction(Double expectedAmountPerTransaction) {
		this.expectedAmountPerTransaction = expectedAmountPerTransaction;
	}
	public Integer getInvestmentSourceId() {
		return investmentSourceId;
	}
	public void setInvestmentSourceId(Integer investmentSourceId) {
		this.investmentSourceId = investmentSourceId;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	
	public Integer getEarningSourceId() {
		return earningSourceId;
	}
	public void setEarningSourceId(Integer earningSourceId) {
		this.earningSourceId = earningSourceId;
	}
	public String getInvestmentDuration() {
		return investmentDuration;
	}
	public void setInvestmentDuration(String investmentDuration) {
		this.investmentDuration = investmentDuration;
	}

	
	
	
}

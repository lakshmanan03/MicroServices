/**
 * 
 */
package com.bfa.insurance.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "objective")
public class Objective {

	
	@Id
	@GenericGenerator(name="bfa" , strategy="increment")
	@GeneratedValue(generator="bfa")
	@Column(name = "objective_id")
	private int objectiveId;
	
	@Column(name="objective_name")
	private String objectiveName;
	
	@Column(name="last_update")
	private Date lastUpdateDate;

	public int getObjectiveId() {
		return objectiveId;
	}

	public void setObjectiveId(int objectiveId) {
		this.objectiveId = objectiveId;
	}

	public String getObjectiveName() {
		return objectiveName;
	}

	public void setObjectiveName(String objectiveName) {
		this.objectiveName = objectiveName;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
}

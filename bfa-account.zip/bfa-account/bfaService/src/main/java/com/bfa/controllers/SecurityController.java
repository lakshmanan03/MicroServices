package com.bfa.controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bfa.application.core.AuthenticationRequest;
import com.bfa.application.core.AuthenticationResponse;
import com.bfa.application.core.EmailLinkValidityRequest;
import com.bfa.application.core.EmailResponse;
import com.bfa.application.core.OTPRequest;
import com.bfa.application.core.OTPVerificationResponse;
import com.bfa.application.core.PasswordRequest;
import com.bfa.application.core.ResendOTP;
import com.bfa.application.core.SessionDetailsResponse;
import com.bfa.application.core.VerifyEmailRequest;
import com.bfa.application.core.security.FinlitAuthenticationRequest;
import com.bfa.application.security.SecurityInfo;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.ForgotPasswordDTO;
import com.bfa.common.dto.ResetPasswordDTO;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.ResendEmailVerificationRequest;
import com.bfa.common.entity.TokenValidityRequest;
import com.bfa.common.entity.TokenValidityResponse;
import com.bfa.common.entity.WelcomeMailRequest;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.PrevilageMaster;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.security.twofa.core.TwoFactorValidationRequest;
import com.bfa.service.AccountsService;
import com.bfa.service.CommunicationService;
import com.bfa.service.FinlitService;
import com.bfa.service.PasswordResetStatus;
import com.bfa.service.SecurityService;
import com.bfa.serviceimpl.AccountLogoutService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessage;
import com.bfa.util.ResponseMessageList;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "/api")
public class SecurityController extends BaseController {

	static {
		System.out.println("Loading the Security Controller..");
	}

	@Autowired
	private SecurityService securityService;

	@Autowired
	private AccountsService accountService;

	@Autowired
	private AccountLogoutService accountLogoutService;

	@Autowired
	private CommunicationService communicationService;

	@Autowired
	private FinlitService finlitService;
	
	private String appKey = "IMXYlDmP4f4=";						
	
	private PublicUtility utility = PublicUtility.getInstance(appKey);

	@PostMapping("/authenticate")
	@Path("/authenticate")
	@ApiOperation(value = "", notes = "Authenticates the user for the given secret key", response = AuthenticationResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList authenticateUser(@RequestBody AuthenticationRequest authenticationRequest,
			HttpServletRequest requestObj) {
		try {
			getLogger(this.getClass()).info("Authenticating user..");
			getLogger(this.getClass()).info("Printing the current thread name " + Thread.currentThread().getName());
			if (authenticationRequest.isAdminUser()) {
				return securityService.authenticateAdvisor(requestObj, authenticationRequest);
			} else {
				return securityService.authenticateRequest(requestObj, authenticationRequest,true);
			}
		} catch (Exception ex) {
			getLogger(this.getClass())
					.error("Error occured in SecurityController.authenticate(): " + ex.fillInStackTrace());
			getLogger(this.getClass()).error("Error catched in controller: " + ex);
			StackTraceElement[] traces = ex.getStackTrace();
			for (StackTraceElement trace : traces) {
				getLogger(this.getClass())
						.error(trace.getClassName() + ": " + trace.getMethodName() + ": " + trace.getLineNumber());
			}

			ResponseMessageList defaultMessageList = getDefaultMessageList();
			defaultMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CREDENTIALS);
			defaultMessageList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_CREDENTIALS);

			return defaultMessageList;
		}

	}

	@PostMapping("/api/verifyOTP")
	@Path("/api/verifyOTP")
	@ApiOperation(value = "Verify the OTP", notes = "Verify the one time password ", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList verifyOTP(@RequestBody OTPRequest otpRequest,
			HttpServletRequest requestObj) {
		getLogger(this.getClass()).info("Verifying the OTP of the user");
		getLogger(this.getClass()).info("Printing the thread name " + Thread.currentThread().getName());
		OTPVerificationResponse otpVerificationResponse = securityService.verifyOTP(otpRequest);
		ResponseMessageList responseMessageList = getDefaultMessageList();
		List objectList = new ArrayList();
		objectList.add(otpVerificationResponse);
		responseMessageList.setObjectList(objectList);
		// ------------------------------------------------------------------//
		if (otpVerificationResponse.isVerified()) {
			ResponseMessage responseMsg = new ResponseMessage();
			responseMsg.setResponseCode(ErrorCodes.OPT_VERIFICATION_SUCCESSFUL);
			responseMsg.setResponseDescription(ApplicationConstants.USER_OPT_VERIFIED_SUCCESSFULLY);
			responseMessageList.setResponseMessage(responseMsg);
		} else {
			if (otpVerificationResponse.getResetCode().equals(ApplicationConstants.USER_OPT_ALREADY_VERIFIED)) {
				ResponseMessage responseMsg = new ResponseMessage();
				responseMsg.setResponseCode(ErrorCodes.OTP_VALIDATION_ALREADY_DONE);
				responseMsg.setResponseDescription(ApplicationConstants.USER_OPT_ALREADY_VERIFIED);
				responseMessageList.setResponseMessage(responseMsg);
			} else if (otpVerificationResponse.getResetCode().equals(ApplicationConstants.USER_OTP_EXPIRED)) {
				ResponseMessage responseMsg = new ResponseMessage();
				responseMsg.setResponseCode(ErrorCodes.OTP_EXPIRED);
				responseMsg.setResponseDescription(ApplicationConstants.USER_OTP_EXPIRED);
				responseMessageList.setResponseMessage(responseMsg);
			} else {
				ResponseMessage responseMsg = new ResponseMessage();
				responseMsg.setResponseCode(ErrorCodes.OTP_VALIDATION_FAILED);
				responseMsg.setResponseDescription(ApplicationConstants.USER_OTP_VALIDATION_FAILED);
				responseMessageList.setResponseMessage(responseMsg);
			}
		}
		return responseMessageList;
	}

	@PostMapping("/api/setPassword")
	@Path("/api/setPassword")
	@ApiOperation(value = "Set the user password", notes = "Set the password /reset for the user", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList setPassword(@RequestBody PasswordRequest passwordRequest,
			HttpServletRequest requestObj) {
		getLogger(this.getClass()).info("Authenticating user..");
		getLogger(this.getClass()).info("Printing the thread name " + Thread.currentThread().getName());
		boolean flag = securityService.setPassword(passwordRequest, requestObj);
		if ("insurance".equalsIgnoreCase(passwordRequest.getJourneyType())) {
			securityService.updateCRMPostDuringSignup(passwordRequest, true);
		}
		ResponseMessageList messageList = getDefaultMessageList();
		if (flag) {
			getLogger(this.getClass()).info("password set successfully");
		} else {
			getLogger(this.getClass()).error("unable to set password");
			ResponseMessage responseMessage = new ResponseMessage();
			responseMessage.setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessage.setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			messageList.setResponseMessage(responseMessage);
		}
		return messageList;
	}

	@PostMapping("/api/saveSessionDetails")
	@POST
	@Path("/api/saveSessionDetails")
	@ApiOperation(value = "", notes = "Saves the session details of the user", response = SessionDetailsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList saveSessionDetails(HttpServletRequest request) {
		getLogger(this.getClass()).info("Save session details");
		SessionDetails sessionDetails = securityService.saveSessionDetails("", request);
		ResponseMessageList responseMessageList = getDefaultMessageList();
		List<Object> objectList = new ArrayList<>();
		objectList.add(sessionDetails);
		responseMessageList.setObjectList(objectList);
		return responseMessageList;
	}

	@PostMapping("/api/getSessionDetailsById")
	@Path("/api/getSessionDetailsById")
	@ApiOperation(value = "", notes = "Retrives the session details by ID", response = SessionDetailsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody SessionDetails getSessionDetails(HttpServletRequest request) {
		getLogger(this.getClass()).info("Save session details");
		String sessionId = request.getParameter("session_id");
		return securityService.getSessionDetailsBySessionId(sessionId);
	}

	@PostMapping("/api/verifyEmail")
	@Path("/api/verifyEmail")
	@ApiOperation(value = "", notes = "Verify email address of the user", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList verifyEmailAddress(@RequestBody VerifyEmailRequest verifyEmailRequest,
			HttpServletRequest request) {
		getLogger(this.getClass()).info("Verifying the email address.");
		String response = securityService.verifyEmailAddress(verifyEmailRequest);
		ResponseMessageList responseMessageList = getDefaultMessageList();
		if (response.contains("Invalid")) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_VERIFICATION_FAILED);
			responseMessageList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.EMAIL_VERIFICATION_FAILED);
		}
		if (response.equals(ApplicationConstants.EMAIL_LINK_EXPIRED)) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_LINK_EXPIRED);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.EMAIL_LINK_EXPIRED);
			return responseMessageList;
		}
		if (response.equals(ApplicationConstants.VALIDATION_ERROR_EMAIL_ALREADY_VERIFIED)) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_LINK_ALREADY_VERIFIED);
			responseMessageList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_ALREADY_VERIFIED);
			return responseMessageList;
		}
		List<Object> objectList = new ArrayList<Object>();
		EmailResponse emailRes = new EmailResponse();
		emailRes.setEmail(response);
		objectList.add(emailRes);
		responseMessageList.setObjectList(objectList);
		return responseMessageList;
	}

	@PostMapping("/api/resendOTP")
	@Path("/api/resendOTP")
	@ApiOperation(value = "", notes = "Resend the OTP details for the user.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList resendOTP(@RequestBody ResendOTP resendOTPRequest,
			HttpServletRequest request) {
		Integer customerId = getCustomerIdFromAuthToken(request);		
		getLogger(this.getClass()).info("Resending the OTP for [Customer Id]:" + customerId);
		ResponseMessageList responseMessageList = getDefaultMessageList();
		String customerRef = resendOTPRequest.getCustomerRef();
		String isEditProfile = request.getParameter("isEditProfile");
		if(null != isEditProfile){
			getLogger(this.getClass()).info("isEditProfile option :" + isEditProfile);
			if (isEditProfile.equalsIgnoreCase("true")) {
				CustomerContactVerification customerContactVerification = securityService
						.getCustomerContactVerificationByCustomerIdAndType(customerId,
								ApplicationConstants.CUSTOMER_UPDATE_TYPE);
				if (null != customerContactVerification && null != customerContactVerification.getMobileNumber()
						&& null != customerContactVerification.getCountryCode()) {
					ContactDetailsDTO updateCustomercontact = new ContactDetailsDTO();
					updateCustomercontact.setMobileNumber(customerContactVerification.getMobileNumber());
					updateCustomercontact.setCountryCode(customerContactVerification.getCountryCode());
					accountService.editContactDetails(updateCustomercontact, customerId);
					return responseMessageList;
				}
				getLogger(this.getClass()).error("Unable to obtain the customer contact verification details for [Customer Id]:" + customerId);
				responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				responseMessageList.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
				return responseMessageList;
			}
		}
		boolean flag = accountService.reIssueOTP(customerRef,customerId);
		if (!flag) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error("Unable to send the OTP request for customer");
		}
		List<Object> objectList = new ArrayList<>();
		responseMessageList.setObjectList(objectList);
		return responseMessageList;
	}

	@PostMapping("/api/forgotPassword")
	@Path("/api/forgotPassword")
	@ApiOperation(value = "", notes = "Resend the password for the user.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList forgotPassword(@RequestBody ForgotPasswordDTO forgotPasswordDto,
			HttpServletRequest request) {
		getLogger(this.getClass()).info("Resending the OTP");
		ResponseMessageList responseMessageList = getDefaultMessageList();
		// -------------- Fix for BFA-1007 ------------------//
		String sessionId = forgotPasswordDto.getSessionId();
		String captcha = forgotPasswordDto.getCaptcha();
		getLogger(this.getClass()).error("Forgot Password: " + "-- Session Id:" + sessionId + "--Captcha" + captcha);
		boolean isValidCaptcha = securityService.isValidCaptcha(sessionId, captcha);
		getLogger(this.getClass()).error("Forgot Password: " + "-- isValidCaptcha" + isValidCaptcha);
		if (!isValidCaptcha) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CAPTCHA);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_CAPTCHA);
			return responseMessageList;
		}

		// --------------------------------------------------//
		String status = null;
		if (forgotPasswordDto.getIsAdmin() != null && forgotPasswordDto.getIsAdmin() == true) {
			status = securityService.generatePasswordResetMailForAdmin(forgotPasswordDto);
			getLogger(this.getClass()).error("Forgot Password: " + "-- status" + status);
		} else {
			status = securityService.generatePasswordResetMail(forgotPasswordDto);
			getLogger(this.getClass()).error("Forgot Password: " + "-- status" + status);
		}

		if (status.equals(ApplicationConstants.NO_SUCH_USER)) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			getLogger(this.getClass())
					.error("Unable to reset the password: No such user found !" + forgotPasswordDto.getEmail());
		}
		// ----------------- Fix for BFA-1128 ---------------------- //
		if (status.equals(ApplicationConstants.VALIDATION_ERROR_EMAIL_UNVERIFIED)) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_UNVERIFIED);
			responseMessageList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_UNVERIFIED);
			getLogger(this.getClass())
					.error("Unable to reset the password: Email not verified !" + forgotPasswordDto.getEmail());
		}
		if (status.equals(ApplicationConstants.VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED)) {
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseMessageList.getResponseMessage()
					.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_EMAIL_AND_MOBILE_UNVERIFIED);
			getLogger(this.getClass()).error(
					"Unable to reset the password: Email / Mobile not verified !" + forgotPasswordDto.getEmail());
		}
		// ------------------End of fix BFA-1128----------------------//
		List<Object> objectList = new ArrayList<>();
		responseMessageList.setObjectList(objectList);
		getLogger(this.getClass()).error("Forgot Password: " + "Object List" + "Status:" + status + "Response:"
				+ responseMessageList.getObjectList());
		return responseMessageList;
	}

	@PostMapping("/api/resetPassword")
	@Path("/api/resetPassword")
	@ApiOperation(value = "", notes = "Resend the password for the user.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList resetPassword(@RequestBody ResetPasswordDTO dto,
			HttpServletRequest request) {
		getLogger(this.getClass()).info("Inside resetting the password :" + dto.getPassword());
		ResponseMessageList responseMessageList = getDefaultMessageList();
		PasswordResetStatus status = null;
		if (dto.getIsAdmin() != null && dto.getIsAdmin() == true) {
			status = securityService.resetPasswordforAdmin(dto);
		} else {
			status = securityService.resetPassword(dto);
		}

		responseMessageList.getResponseMessage().setResponseCode(status.code);
		responseMessageList.getResponseMessage().setResponseDescription(status.message);
		return responseMessageList;
	}

	/**
	 * BFA-1233
	 * 
	 * @param request
	 * @return
	 */
	@GetMapping("/api/logout")
	@Path("/api/logout")
	@ApiOperation(value = "", notes = "Logout the user.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList logoutUser(HttpServletRequest request) {
		getLogger(this.getClass()).info("Logout the user ..");
		ResponseMessageList responseMessageList = getDefaultMessageList();
		String authToken = request.getHeader("Authorization");
		if (authToken == null) {
			getLogger(this.getClass()).info("Unable to find the Auth token");
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			return responseMessageList;
		}
		securityService.blackList(authToken, ApplicationConstants.ALREADY_LOGOUT_FROM_ANOTHERTAB);
		return responseMessageList;
	}

	/**
	 * BFA-1233
	 * 
	 * @param request
	 * @return
	 */
	@PostMapping("/api/isAlreadyLogout")
	@Path("/api/isAlreadyLogout")
	@ApiOperation(value = "", notes = "Find if the user already logged out", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList isAlreadyLoggedOut(@RequestBody TokenValidityRequest tokenValidityRequest,
			HttpServletRequest request) {
		getLogger(this.getClass()).info("Check the token validity");
		ResponseMessageList responseMessageList = getDefaultMessageList();
		String tokenToValidate = tokenValidityRequest.getToken();
		try {
			TokenValidityResponse tokenValidityResponse = new TokenValidityResponse();
			String response = accountLogoutService.isTokenBlackListed(tokenToValidate);
			tokenValidityResponse.setReason(response);
			List objectList = new ArrayList();
			objectList.add(tokenValidityResponse);
			responseMessageList.setObjectList(objectList);
		} catch (Exception e) {
			getLogger(this.getClass()).error("Error while checking the token in black list: " + e);
		}
		return responseMessageList;
	}

	/**
	 * Check if the email link provided is valid.
	 * 
	 * @param emailLinkValidityRequest
	 * @return
	 */
	@PostMapping("/api/emailValidityCheck")
	@Produces({ "application/xml", "application/json" })
	@Path("/api/emailValidityCheck")
	@ApiOperation(value = "Check the validity of the email link provided.", notes = "Check the validity of the email link provided.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList checkEmailLinkValidity(
			@RequestBody EmailLinkValidityRequest emailLinkValidityRequest) {
		getLogger(this.getClass()).info("Validating the email validity link:" + emailLinkValidityRequest.getResetKey());
		ResponseMessageList responseList = getDefaultMessageList();
		try {

			String isValid = securityService.isEmailLinkValid(emailLinkValidityRequest);
			if (isValid.equals(ApplicationConstants.LINK_VALID_CREDENTIAL)) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.PASSWORD_LINK_VALID);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.LINK_VALID_CREDENTIAL);
				return responseList;
			} else if (isValid.equals(ApplicationConstants.LINK_EXPIRED_CREDENTIAL)) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.PASSWORD_LINK_EXPIRED);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.LINK_EXPIRED_CREDENTIAL);
				return responseList;
			} else if (isValid.equals(ApplicationConstants.LINK_ALREADY_USED_CREDENTIAL)) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.PASSWORD_LINK_ALREADY_USED);
				responseList.getResponseMessage()
						.setResponseDescription(ApplicationConstants.LINK_ALREADY_USED_CREDENTIAL);
				return responseList;
			} else if (isValid.equals(ApplicationConstants.USER_NOT_FOUND)) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
				return responseList;
			}
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	/**
	 * This API is to resend the email for verifying the email address of the
	 * customer.
	 * 
	 * @param resendEmailRequest
	 * @return
	 */
	@PostMapping("/api/resendEmailVerification")
	@Path("/api/resendEmailVerification")
	@ApiOperation(value = "Sends the customer verification email.", notes = "Sends the customer verification email.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList resendEmailVerification(
			@RequestBody ResendEmailVerificationRequest resendEmailRequest) {
		getLogger(this.getClass()).info("Resending the email verification ");
		ResponseMessageList messageList = getDefaultMessageList();
		messageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_VERIFICATION_REQUEST_SUCCESS);
		messageList.getResponseMessage()
				.setResponseDescription(CommunicationService.EMAIL_VERIFICATION_REQUEST_SUCCESSFUL);
		try {
			Integer value = communicationService.resendVerificationEmail(resendEmailRequest.getMobileNumber(),
					resendEmailRequest.getEmailAddress(), resendEmailRequest.getCallbackUrl(),
					resendEmailRequest.getHostedServerName());
			if (value == 0) {
				messageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_VERIFICATION_REQUEST_FAILED);
				messageList.getResponseMessage().setResponseDescription(
						CommunicationService.EMAIL_VERIFICATION_REQUEST_FAILED_NO_SUCH_CUSTOMER);
				return messageList;
			} else if (value == -1) {
				messageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_VERIFICATION_REQUEST_FAILED);
				messageList.getResponseMessage().setResponseDescription(CommunicationService.ILLEGAL_ARGUMENTS);
				return messageList;
			}
		} catch (Exception e) {
			getLogger(this.getClass()).error("Unable to send the email verification request", e);
			messageList.getResponseMessage().setResponseCode(ErrorCodes.EMAIL_VERIFICATION_REQUEST_FAILED);
			messageList.getResponseMessage()
					.setResponseDescription(CommunicationService.EMAIL_VERIFICATION_REQUEST_FAILED);
		}
		return messageList;
	}

	/**
	 * This API is to sends the welcome email to customer mailId after signup
	 * process in Comprehensive Journey customer.
	 * 
	 * @param WelcomeMailRequest
	 * @return
	 */
	@PostMapping("/api/sendWelcomeMail")
	@Path("/api/sendWelcomeMail")
	@ApiOperation(value = "Sends the customer welcome email.", notes = "Sends the customer welcome email.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList sendWelcomeMailPostSignup(
			@RequestBody WelcomeMailRequest welcomeEmailRequest) {

		getLogger(this.getClass()).info("Sending welcome mail for Comprehensive journey ");

		ResponseMessageList messageList = getDefaultMessageList();
		messageList.getResponseMessage().setResponseCode(ErrorCodes.WELCOME_EMAIL_SUCCESS_COMPRE);
		messageList.getResponseMessage().setResponseDescription(CommunicationService.WELCOME_EMAIL_SUCCESSFUL_COMPRE);

		try {
			Integer valueFlag = communicationService.sendWelcomeEmailComprehensive(
					welcomeEmailRequest.getMobileNumber(), welcomeEmailRequest.getEmailAddress(),
					welcomeEmailRequest.getCallbackUrl(), welcomeEmailRequest.getHostedServerName());

			if (valueFlag == 0) {
				messageList.getResponseMessage().setResponseCode(ErrorCodes.WELCOME_EMAIL_FAILED_COMPRE);
				messageList.getResponseMessage()
						.setResponseDescription(CommunicationService.WELCOME_EMAIL_FAILED_NO_SUCH_CUSTOMER);
				return messageList;
			} else if (valueFlag == -1) {
				messageList.getResponseMessage().setResponseCode(ErrorCodes.WELCOME_EMAIL_FAILED_COMPRE);
				messageList.getResponseMessage().setResponseDescription(CommunicationService.ILLEGAL_ARGUMENTS);
				return messageList;
			}

		} catch (Exception e) {
			getLogger(this.getClass()).error("Unable to send the welcome email request", e);
			messageList.getResponseMessage().setResponseCode(ErrorCodes.WELCOME_EMAIL_FAILED_COMPRE);
			messageList.getResponseMessage().setResponseDescription(CommunicationService.WELCOME_EMAIL_FAILED);
		}
		return messageList;
	}

	@PostMapping(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION)
	@Path(APIConstants.FINLIT_WORKSHOP_AUTHENTICATION)
	@ApiOperation(value = "", notes = "Authenticates the user for the given secret key for finlit workshops", response = AuthenticationResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList authenticateUserForWorkshop(@RequestBody FinlitAuthenticationRequest finlitAuthenticationRequest, HttpServletRequest requestObj) {
		ResponseMessageList defaultMessageList = getDefaultMessageList();
		try {			
			// Step 1: Validate the inputs 
			finlitService.validateInputs(finlitAuthenticationRequest);			
			//---------------------------------------------------------//
			// Step 2: Authenticate the user 
			AuthenticationRequest authenticationRequest = new AuthenticationRequest();
			authenticationRequest.setAdminUser(false);
			authenticationRequest.setEmail(finlitAuthenticationRequest.getEmail());
			authenticationRequest.setMobile(finlitAuthenticationRequest.getMobile());
			authenticationRequest.setPassword(finlitAuthenticationRequest.getPassword());
			authenticationRequest.setSessionId(finlitAuthenticationRequest.getSessionId());
			authenticationRequest.setEnquiryId(-1);
			authenticationRequest.setJourneyType(JourneyTypeEnum.Workshop.getValue());
			defaultMessageList = securityService.authenticateRequest(requestObj, authenticationRequest,false);
			if(defaultMessageList.getResponseMessage().getResponseCode() != ErrorCodes.SUCCESSFUL_RESPONSE){
				getLogger(this.getClass())
						.error("Authentication failure :" + defaultMessageList.getResponseMessage().getResponseDescription()
								+ ",Code:" + defaultMessageList.getResponseMessage().getResponseCode());
				defaultMessageList.setObjectList(Collections.emptyList());
				return defaultMessageList;
			}
			//----------------------------------------------------------//			
			// Step 3: Check the access code
			String accessCode = finlitAuthenticationRequest.getAccessCode();
			boolean isAccessCodeValid = finlitService.isValidAccessCode(accessCode);
			if(!isAccessCodeValid){
				defaultMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_ACCESS_CODE);
				defaultMessageList.getResponseMessage().setResponseDescription(FinlitService.INVALID_ACCESS_CODE);
				defaultMessageList.setObjectList(Collections.emptyList());
				return defaultMessageList;
			}
			//----------------------------------------------------------//
			//Step 4: Parse the customer id //
			Integer customerId = -1;
			try {
				if (!defaultMessageList.getObjectList().isEmpty()) {
					Object obj = defaultMessageList.getObjectList().get(0);
					if (obj instanceof SecurityInfo) {
						SecurityInfo securityInfo = (SecurityInfo) obj;
						String encryptedCustomerId = securityInfo.customerId;
						String decrypt = utility.DecryptText(encryptedCustomerId);
						customerId = Integer.parseInt(decrypt);
						getLogger(this.getClass()).info("Printing the customer id:" + customerId);
					}
				}
			} catch (Exception err) {
				getLogger(this.getClass()).error("Error while processing the request ", err);
				defaultMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				defaultMessageList.getResponseMessage()
						.setResponseDescription("Internal server error - unable to find the customer");
				return defaultMessageList;
			}
			defaultMessageList.setObjectList(Collections.emptyList());
			//----------------------------------------------------------//
			// Step 5: Grant additional privileges
			List<PrevilageMaster> rolesToBeAssigned = finlitService.getRobo3LiteRolesByCode(accessCode);
			finlitService.assignFinlitRolesForCustomer(rolesToBeAssigned,customerId);
			//----------------------------------------------------------//
			//Step 6: Decorate the results with the new token.
			finlitService.provideJWTTokenAndSessionDetails(finlitAuthenticationRequest.getEmail(), finlitAuthenticationRequest.getMobile(), defaultMessageList, requestObj);
			return defaultMessageList;
			
		} catch (IllegalArgumentException ex) {
			getLogger(this.getClass()).error("Illegal arguments found", ex);
			defaultMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
			defaultMessageList.getResponseMessage().setResponseDescription(ex.getMessage());
			return defaultMessageList;

		} catch (Exception err) {
			getLogger(this.getClass()).error("Error while processing the request ", err);
			defaultMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			defaultMessageList.getResponseMessage().setResponseDescription(err.getMessage());
			return defaultMessageList;
		}
	}
	
	@GetMapping(APIConstants.API_IS_TWO_FACT_AUTHENTICATED)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_IS_TWO_FACT_AUTHENTICATED)
	@ApiOperation(value = "API to check if the session is 2Factor Authenticated", notes = "API to check if the session is 2Factor Authenticated", response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList is2FactorAuthenticated(HttpServletRequest httpServletRequest) {		
		String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
		return get2FAValidationMessage(sessionId);
	}
	
	@GetMapping(APIConstants.API_SEND_2FA_OTP)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_SEND_2FA_OTP)
	@ApiOperation(value = "API to send a 2 factor authentication SMS", notes = "API to send a 2 factor authentication SMS", response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList sendOTPFor2FA(HttpServletRequest httpServletRequest) {
		ResponseMessageList response = getDefaultMessageList();
		try {
			int customerId = getCustomerId(httpServletRequest);
			String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
			getLogger(this.getClass())
					.info("Sending OTP for 2FA for [Customer ID]:" + customerId + ",[Session id]:" + sessionId);
			if (!securityService.isValidSession(sessionId)) {
				response.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_SESSION);
				return response;
			}
			Customer customerObj = accountService.getDetailsByCustomerId(customerId);
			if (null == customerObj) {
				response.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_REQUEST);
				return response;
			}
			securityService.send2FAOTP(customerObj, sessionId);
		} catch (Exception err) {
			getLogger(this.getClass()).error("Error while sending OTP to customer",err);
			response.setResponseMessage(getInternalServerError());
		}
		return response;
	}
	
	@PostMapping(APIConstants.API_VALIDATE_2FA)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_VALIDATE_2FA)
	@ApiOperation(value = "API to validate 2 factor authentication", notes = "API to validate 2 factor authentication", response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList validate2FA(
			@RequestBody TwoFactorValidationRequest twoFactorValidationRequest, HttpServletRequest httpServletRequest) {
		ResponseMessageList response = getDefaultMessageList();
		try {
			int customerId = getCustomerId(httpServletRequest);
			String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
			getLogger(this.getClass())
					.info("Sending OTP for 2FA for [Customer ID]:" + customerId + ",[Session id]:" + sessionId);
			if (!securityService.isValidSession(sessionId)) {
				response.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_SESSION);
				return response;
			}			
			String twoFactorOtpString = twoFactorValidationRequest.getTwoFactorOtpString();
			Integer code = securityService.validate2FADetails(sessionId, twoFactorOtpString, customerId);
			getLogger(this.getClass()).info("Printing the 2FValidation response code:" + code);
			switch (code) {
			case ErrorCodes.TWO_FACTOR_AUTH_SUCCESS:
				response.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTH_SUCCESS);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_SUCCEEDED);
				break;
			case ErrorCodes.OTP_EXPIRED:
				response.getResponseMessage().setResponseCode(ErrorCodes.OTP_EXPIRED);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.USER_OTP_EXPIRED);
				break;
			case ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED:
				response.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_FAILED);
				break;
			}			
		} catch (Exception err) {
			getLogger(this.getClass()).error("Error while validating the two factor authentication.", err);
			response.setResponseMessage(getInternalServerError());
		}
		return response;
	}

}

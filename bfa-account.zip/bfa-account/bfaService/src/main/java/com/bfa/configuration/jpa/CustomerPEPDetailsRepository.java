package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.investment.entity.CustomerPEPDetails;

public interface CustomerPEPDetailsRepository extends CrudRepository<CustomerPEPDetails, String>{
	Optional<CustomerPEPDetails>  findFirstBycustomer_id(Integer customerId);
	

}

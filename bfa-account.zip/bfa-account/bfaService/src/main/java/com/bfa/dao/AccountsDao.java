package com.bfa.dao;

import java.util.List;

import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.exception.NoSuchUserException;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerAssessmentDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.CustomerDetailsEditHistory;
import com.bfa.common.entity.CustomerOverview;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.EmploymentStatusMaster;
import com.bfa.insurance.core.LoginRetryCount;
import com.bfa.insurance.core.Profile;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.application.core.CustomerAndPrevilegeV2;



public interface AccountsDao<T> {
	
	public List<Profile> getProfileList() throws DatabaseAccessException;

	public List<EmploymentStatusMaster> getEmploymentList() throws DatabaseAccessException;	
	
	public BFAUserDetails loadUserByEmail(String email) throws DatabaseAccessException,NoSuchUserException;
	
	public BFAUserDetails loadUserById(Integer customerId) throws DatabaseAccessException,NoSuchUserException;
	public LoginRetryCount incrementRetryCount(String userId);
	
	public LoginRetryCount resetRetryCount(String userId, int retryCount);
	
	public LoginRetryCount getRetryCountInfo(String userId);
	
	public LoginRetryCount createRetryCount(String userId);
	
	public BFAUserDetails loadUserByMobile(String mobileNumber) throws DatabaseAccessException,NoSuchUserException;
	
	public T saveOrUpdateObject(T obj) throws DatabaseAccessException;
	
	public T saveObject(T obj) throws DatabaseAccessException;

	public void saveDependentList(List<DependentMapping> dependents) throws DatabaseAccessException;
	
	public List<T> getObjectsById(Class T, String reference, int value) throws DatabaseAccessException;
	
	public List<T> getObjectsByRef(Class T, String reference, String value) throws DatabaseAccessException;
	
	public CustomerAndPrevilege signup(CustomerCreationPostRequest customer)throws DatabaseAccessException;
	
	public <T> List<T> getObjectsAsList(Class T) throws DatabaseAccessException;
	
	public List<T> getObjectByHql(String hqlString) throws DatabaseAccessException;
	
	public List<T> getObjectByHqlAndLimit(String hqlString,int numberOfRecords) throws DatabaseAccessException;
	
	public List<T> getObjectByHqlAndLimit(String hqlString,String paramName,String paramValue,int numberOfRecords) throws DatabaseAccessException;
	
	public List<T> getObjectByHql(String hqlString,String param,String value) throws DatabaseAccessException;
	
	public String getActiveSMSGatewayProvider();	
	
	public int executeUpdate(String hqlString);
	
	public Customer getCustomerDetails(String email) throws DatabaseAccessException;
	
	public Customer getCustomerById(Integer customerId) throws DatabaseAccessException;
	
	public CustomerEmploymentInformation getCustomerEmploymentInformation(Integer id);

	List<CustomerBankDetail> getCustomerBankDetails(Integer customerId);
	
	CustomerSrsAccount getCustomerSrsBankDetails(Integer customerId);
	
	CustomerBankDetail getCustomerBankDetail(Integer bankId, Integer customerId);
	
	void deleteCustomerBankDetail(Integer bankId, Integer customerId);

	public CustomerAdditionalDetails getAdditionalDetails(Integer customerId);

	@Deprecated
	public CustomerContactVerification getCustomerVerificationDetailsbyId(Integer customerId);	
	
	List<CustomerOverview> findCustomers(AdminSearchRequestDTO searchRequest);

	public Customer getCustomerByAdvisor(Integer customerId, Integer advisorId);
	
	List<CustomerAssessmentDetails> assessmentDetails (Integer customerId);

	public Advisor getAdvisorById(Integer custId);

	public CustomerAndPrevilegeV2 signupV2(Customer customerDetails)throws DatabaseAccessException;

	public Object updateObject(Object obj) throws DatabaseAccessException;

	public BFAUserDetails loadAdminByEmail(String email);
	
	public List<T> getObjectByHql(String hqlString,String[] paramNames,Object[] values) throws DatabaseAccessException;
	
	public List<T> getObjectByHql(String hqlString,String param,Integer value) throws DatabaseAccessException;
	
	public Customer getCustomerFromMobile(String mobileNumber);
	
	public List<Integer> getExistingPrivileges(Integer customerId);
	
	public List<Customer> getCustomerByEmail(String email);
	
	public List<Customer> getCustomerByMobile(String mobileNumber);
	
	public List<String> getPrevilegesForCustomer(Integer customerId);
	
	public CustomerDetailsEditHistory getAddressHistory(Integer customerId,String field, String addressType);

}
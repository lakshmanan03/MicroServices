package com.bfa.servicehelper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public class MOServiceRequest {
	private String url;
	private Object requestBody;
	private String serializedRequestBody;
	private Map<String,String> headers;
	private Map<String,String> formFields;
	private Map<String,MultipartFile> files;
	private String methodName;
	
	
	
	
	public String getSerializedRequestBody() {
		return serializedRequestBody;
	}

	public void setSerializedRequestBody(String serializedRequestBody) {
		this.serializedRequestBody = serializedRequestBody;
	}

	public Object getRequestBody() {
		return requestBody;
	}
	
	public void setRequestBody(Object requestBody) {
		this.requestBody = requestBody;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
	public Map<String, String> getFormFields() {
		return formFields;
	}
	public void setFormFields(Map<String, String> formFields) {
		this.formFields = formFields;
	}
	public Map<String, MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(Map<String, MultipartFile> files) {
		this.files = files;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	
	public void addHeader(String key, String value) {
		if (getHeaders() == null) {
			setHeaders(new HashMap<>());
		}
		getHeaders().put(key, value);
	}
	
	public void addFormField(String key, String value) {
		if (getFormFields() == null) {
			setFormFields(new HashMap<>());
		}
		getFormFields().put(key, value);
	}
	
	public void addFileField(String key, MultipartFile file) {
		if (getFiles() == null) {
			setFiles(new HashMap<>());
		}
		getFiles().put(key, file);
	}

	@Override
	public String toString() {
		return "MOServiceRequest [url=" + url + ", requestBody=" + requestBody + ", serializedRequestBody="
				+ serializedRequestBody + ", headers=" + headers + ", formFields=" + formFields + ", files=" + files
				+ ", methodName=" + methodName + "]";
	}
	
}

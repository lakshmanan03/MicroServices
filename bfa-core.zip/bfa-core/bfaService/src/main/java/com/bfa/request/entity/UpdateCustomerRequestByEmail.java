/**
 * 
 */
package com.bfa.request.entity;

import java.io.Serializable;

/**
 * @author pradheep
 *
 */
public class UpdateCustomerRequestByEmail extends UpdateCustomerRequest implements Serializable{
	
	private Integer emailEnquiryId;

	public Integer getEmailEnquiryId() {
		return emailEnquiryId;
	}

	public void setEmailEnquiryId(Integer emailEnquiryId) {
		this.emailEnquiryId = emailEnquiryId;
	}
	

}

/**
 * 
 */
package com.bfa.investment.ifast.dto;

import java.util.Date;

/**
 * @author 51772803
 * CashTransactionDTO.java Created on Jan 7, 2019 4:18:10 PM by Vimala Shan
 */
public class CashTransactionDTO {

	private Integer id;

	private Integer customer;

	private String contractNo;

	private String transactionType;

	private String amount;

	private String currency;

	private String conversionRate;

	private String transactionStatus;

	private Double accountBalance;

	private String refNo;

	private Date transactionCreatedDate;

	private Date transactionCompletedDate;
	
	private String paymentMethod;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the customer
	 */
	public Integer getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Integer customer) {
		this.customer = customer;
	}

	/**
	 * @return the contractNo
	 */
	public String getContractNo() {
		return contractNo;
	}

	/**
	 * @param contractNo the contractNo to set
	 */
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the conversionRate
	 */
	public String getConversionRate() {
		return conversionRate;
	}

	/**
	 * @param conversionRate the conversionRate to set
	 */
	public void setConversionRate(String conversionRate) {
		this.conversionRate = conversionRate;
	}

	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * @return the accountBalance
	 */
	public Double getAccountBalance() {
		return accountBalance;
	}

	/**
	 * @param accountBalance the accountBalance to set
	 */
	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the transactionCreatedDate
	 */
	public Date getTransactionCreatedDate() {
		return transactionCreatedDate;
	}

	/**
	 * @param transactionCreatedDate the transactionCreatedDate to set
	 */
	public void setTransactionCreatedDate(Date transactionCreatedDate) {
		this.transactionCreatedDate = transactionCreatedDate;
	}

	/**
	 * @return the transactionCompletedDate
	 */
	public Date getTransactionCompletedDate() {
		return transactionCompletedDate;
	}

	/**
	 * @param transactionCompletedDate the transactionCompletedDate to set
	 */
	public void setTransactionCompletedDate(Date transactionCompletedDate) {
		this.transactionCompletedDate = transactionCompletedDate;
	}

	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	
}
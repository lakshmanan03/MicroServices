/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "life_protection_needs")

public class LifeProtectionNeeds implements Serializable{

	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;	
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "coverage_amount")
	private double coverageAmount;
	
	@Column(name = "coverage_duration")
	private String coverageDuration;	
	
	@JsonProperty(value="isPremiumWaiver")
	@Column(name = "premium_waiver")
	private Boolean isPremiumWaiver = false;	
	
	@Column(name = "customer_id")
	private int customerId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	@JsonProperty(value="isPremiumWaiver")
	public Boolean isPremiumWaiver() {
		return isPremiumWaiver;
	}

	public void setIsPremiumWaiver(Boolean isPremiumWaiver) {
		this.isPremiumWaiver = isPremiumWaiver;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCoverageDuration() {
		return coverageDuration;
	}

	public void setCoverageDuration(String coverageDuration) {
		this.coverageDuration = coverageDuration;
	}
}

package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_customer_portfolio_details")
public class CustomerPortfolioDetails {
	
	@Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "id")
	  private int id;
	
	@Column(name = "portfolioid")
	private String portfolioid;
	
	@Column(name = "customerid")
	private Integer customerid;
	
	@Column(name = "portfoliostatus")
	private String portfolioStatus;
	
	@Column(name = "monthlyinvestment")
	private String monthlyinvestment;	
	
	@Column(name = "initialinvestment")
	private String initialinvestment;
	
	@Column(name = "investmentaccountreferencecode")
	private String investmentaccountreferencecode;	
	
	@Column(name = "counterpartyaccountnumber")
	private String counterpartyaccountnumber;	
	

	public String getPortfolioid() {
		return portfolioid;
	}

	public void setPortfolioid(String portfolioid) {
		this.portfolioid = portfolioid;
	}

	public Integer getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public String getMonthlyinvestment() {
		return monthlyinvestment;
	}

	public void setMonthlyinvestment(String monthlyinvestment) {
		this.monthlyinvestment = monthlyinvestment;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInitialinvestment() {
		return initialinvestment;
	}

	public void setInitialinvestment(String initialinvestment) {
		this.initialinvestment = initialinvestment;
	}

	public String getInvestmentaccountreferencecode() {
		return investmentaccountreferencecode;
	}

	public void setInvestmentaccountreferencecode(String investmentaccountreferencecode) {
		this.investmentaccountreferencecode = investmentaccountreferencecode;
	}

	public String getCounterpartyaccountnumber() {
		return counterpartyaccountnumber;
	}

	public void setCounterpartyaccountnumber(String counterpartyaccountnumber) {
		this.counterpartyaccountnumber = counterpartyaccountnumber;
	}
	
	

}


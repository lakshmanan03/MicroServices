/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.insurance.core.ProtectionType;

/**
 * @author pradheep.p
 *
 */
public interface ProtectionTypeRepository extends JpaRepository<ProtectionType, Integer> {

}

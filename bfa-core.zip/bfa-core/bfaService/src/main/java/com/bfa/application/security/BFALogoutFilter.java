/**
 * 
 */
package com.bfa.application.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author pradheep.p
 *
 */
public class BFALogoutFilter implements Filter {

	@Autowired
	private SecurityConstants constants;

	@Autowired
	private LogoutService logoutService;

	public String getHeaderName() {
		return SecurityConstants.TOKEN_NAME;
	}

	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String token = request.getHeader(getHeaderName());
		if (request.getRequestURL().toString().contains("authenticate")
				|| request.getRequestURL().toString().contains("TestApi")
				|| request.getRequestURL().toString().contains("testIFastAccountCreation")
				|| request.getRequestURL().toString().contains("processAMLStatus")
				|| request.getRequestURL().toString().contains("actuator")){
			filterChain.doFilter(request, response);
			return;
		}
		System.out.println("Printing the referer URL :" + request.getHeader("referer"));
		System.out.println("BFA Logout Filter :" + token);
		// ------------- BFA-1233 --------------
		// Check if the token provided is blacklisted already.
		System.out.println("Checking for blacklisted token :" + token);
		try {
			String reason = logoutService.isTokenBlackListed(token);
			if (!reason.equalsIgnoreCase(LogoutService.NOT_BLACKLISTED)) {
				System.out.println("Token already blacklisted.");
				response.sendError(HttpServletResponse.SC_FORBIDDEN, reason);
			} else {				
				filterChain.doFilter(request, response);
				System.out.println("Filter passed : The user token is not black listed..");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
		// created destroy method
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain fc) throws IOException, ServletException {
		// System.out.println("----------- Invoked BFA Logout Filter ----------");
		doFilterInternal((HttpServletRequest) req, (HttpServletResponse) res, fc);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// created init method
	}

}

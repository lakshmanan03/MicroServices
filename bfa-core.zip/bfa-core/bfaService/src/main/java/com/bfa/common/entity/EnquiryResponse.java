/**
 * 
 */
package com.bfa.common.entity;

/**
 * @author pradheep.p
 *
 */
public class EnquiryResponse {

	private int enquiryId;

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}
}

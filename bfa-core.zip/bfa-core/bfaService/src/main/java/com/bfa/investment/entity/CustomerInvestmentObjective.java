package com.bfa.investment.entity;





import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.bfa.common.entity.OptionItem;
import com.bfa.insurance.core.Enquiry;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "customer_investment_objective")
public class CustomerInvestmentObjective implements java.io.Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private Integer id;
	
	/*@OneToOne(targetEntity=Enquiry.class,cascade=CascadeType.ALL)
	@JoinColumn(name="enquiry_id",referencedColumnName="id")
	private int enquiryId;*/
	
	@OneToOne
	@JoinColumn(name = "enquiry_id")
	private Enquiry enquiry;
	
	@Column(name = "age")
	private int age;
	
	@Column(name = "monthly_expense")
	private double monthlyExpense;
	
	@Column(name = "monthly_income")
	private double monthlyIncome;
	
	@Column(name = "initial_investment")
	private double initialInvestment;
	
	@Column(name = "monthly_investment")
	private double monthlyInvestment;
	
	@Column(name = "min_expected_returns")
	private double minexpectedReturns;
	
	@Column(name = "max_expected_returns")
	private double maxexpectedReturns;
	
	@Column(name = "investment_period")
	private int investmentPeriod;
	
	@Column(name = "investment_objective_option_id")
	private String investmentObjectiveOptionId;
	
	@Column(name = "investment_objective_option_value")
	private int investmentObjectiveOptionValue;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	@Column(name = "created_date")
	private Date createdDate;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	@Column(name = "last_updated_time_stamp")
	private Date lastupdatedtimeStamp;
	
	@OneToOne
	@JoinColumn(name = "investment_source_id")
	private OptionItem investmentSource;
	
	@OneToOne
	@JoinColumn(name = "funding_type")
	private OptionItem fundingType;
	
	@OneToOne
	@JoinColumn(name = "portfolio_type")
	private OptionItem portfolioType;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	
	
	public OptionItem getInvestmentSource() {
		return investmentSource;
	}

	public void setInvestmentSource(OptionItem investmentSource) {
		this.investmentSource = investmentSource;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getMonthlyExpense() {
		return monthlyExpense;
	}

	public void setMonthlyExpense(double monthlyExpense) {
		this.monthlyExpense = monthlyExpense;
	}

	public double getMonthlyIncome() {
		return monthlyIncome;
	}

	public void setMonthlyIncome(double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}

	public double getInitialInvestment() {
		return initialInvestment;
	}

	public void setInitialInvestment(double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}

	public double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public double getMinexpectedReturns() {
		return minexpectedReturns;
	}

	public void setMinexpectedReturns(double minexpectedReturns) {
		this.minexpectedReturns = minexpectedReturns;
	}

	public double getMaxexpectedReturns() {
		return maxexpectedReturns;
	}

	public void setMaxexpectedReturns(double maxexpectedReturns) {
		this.maxexpectedReturns = maxexpectedReturns;
	}

	public int getInvestmentPeriod() {
		return investmentPeriod;
	}

	public void setInvestmentPeriod(int investmentPeriod) {
		this.investmentPeriod = investmentPeriod;
	}

	public String getInvestmentObjectiveOptionId() {
		return investmentObjectiveOptionId;
	}

	public void setInvestmentObjectiveOptionId(String investmentobjectiveoptionId) {
		this.investmentObjectiveOptionId = investmentobjectiveoptionId;
	}

	public int getInvestmentObjectiveOptionValue() {
		return investmentObjectiveOptionValue;
	}

	public void setInvestmentObjectiveOptionValue(int investmentobjectiveoptionValue) {
		this.investmentObjectiveOptionValue = investmentobjectiveoptionValue;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastupdatedtimeStamp() {
		return lastupdatedtimeStamp;
	}

	public void setLastupdatedtimeStamp(Date lastupdatedtimeStamp) {
		this.lastupdatedtimeStamp = lastupdatedtimeStamp;
	}

	public OptionItem getFundingType() {
		return fundingType;
	}

	public void setFundingType(OptionItem fundingType) {
		this.fundingType = fundingType;
	}

	
	public OptionItem getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(OptionItem portfolioType) {
		this.portfolioType = portfolioType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerInvestmentObjective [id=");
		builder.append(id);
		builder.append(", enquiry=");
		builder.append(enquiry);
		builder.append(", age=");
		builder.append(age);
		builder.append(", monthlyExpense=");
		builder.append(monthlyExpense);
		builder.append(", monthlyIncome=");
		builder.append(monthlyIncome);
		builder.append(", initialInvestment=");
		builder.append(initialInvestment);
		builder.append(", monthlyInvestment=");
		builder.append(monthlyInvestment);
		builder.append(", minexpectedReturns=");
		builder.append(minexpectedReturns);
		builder.append(", maxexpectedReturns=");
		builder.append(maxexpectedReturns);
		builder.append(", investmentPeriod=");
		builder.append(investmentPeriod);
		builder.append(", investmentObjectiveOptionId=");
		builder.append(investmentObjectiveOptionId);
		builder.append(", investmentObjectiveOptionValue=");
		builder.append(investmentObjectiveOptionValue);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", lastupdatedtimeStamp=");
		builder.append(lastupdatedtimeStamp);
		builder.append(", investmentSource=");
		builder.append(investmentSource);
		builder.append(", fundingType=");
		builder.append(fundingType);
		builder.append(", portfolioType=");
		builder.append(portfolioType);
		builder.append("]");
		return builder.toString();
	}

	
}

/**
 * 
 */
package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
public class AuthenticationErrorResponse {

	private String customerRef;
	
	private boolean isMobileVerified = false;

	private boolean isEmailVerified = false;

	/* This flag is to show if the user account is activated */
	private boolean isAccountAlreadyCreated = false;
	
	@JsonIgnore
	/* This flag is to show if the user account is already present but mobile number and email not verified .*/
	private boolean isAccountExists = false;

	@JsonIgnore
	private String errorMessage;

	public AuthenticationErrorResponse() {
		
	}

	public boolean isMobileVerified() {
		return isMobileVerified;
	}

	public void setMobileVerified(boolean isMobileVerified) {
		this.isMobileVerified = isMobileVerified;
	}

	public boolean isEmailVerified() {
		return isEmailVerified;
	}

	public void setEmailVerified(boolean isEmailVerified) {
		this.isEmailVerified = isEmailVerified;
	}

	public boolean isAccountAlreadyCreated() {
		return isAccountAlreadyCreated;
	}

	public void setAccountAlreadyCreated(boolean isAccountAlreadyCreated) {
		this.isAccountAlreadyCreated = isAccountAlreadyCreated;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isAccountExists() {
		return isAccountExists;
	}

	public void setAccountExists(boolean isAccountExists) {
		this.isAccountExists = isAccountExists;
	}

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}	
}

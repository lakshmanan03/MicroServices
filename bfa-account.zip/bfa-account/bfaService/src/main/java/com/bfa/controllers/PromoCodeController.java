/**
 * 
 */
package com.bfa.controllers;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bfa.application.core.CustomerPromo;
import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCode;
import com.bfa.application.core.PromoCodeRequest;
import com.bfa.application.core.PromoCodeResponse;
import com.bfa.repository.CustomerPromoRepository;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.service.PromoCodeService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ResponseMessageList;

import io.swagger.annotations.ApiOperation;

/**
 * Promo Code Controller to handle requests from UI 
 * 
 * @author kianann
 *
 */
@Controller
@RequestMapping(path="/api/promocode")
public class PromoCodeController extends BaseController {

	@Autowired
	private PromoCodeRepository promoCodeRepository;

	@Autowired
	private CustomerPromoRepository customerPromoRepository;

	@Autowired
	private PromoCodeService promoCodeService;

	@PostMapping(path="/validatePromoCode")
	@ApiOperation(value = "Validates the Promo Code entered by the user",
	notes = "Validates the Promo Code entered by the user",
	response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList validatePromoCode(@RequestBody Map<String, Object> promoCodeJson) {
		ResponseMessageList responseList = getDefaultMessageList();
		String promoCode = (String) promoCodeJson.get("promoCode");
		String promoCodeCategory = (String) promoCodeJson.get("promoCodeCat");
		PromoCodeRequest promoCodeRequest = null;
		EnquiryResponseMessage enquiryResponseMessage = null;
		boolean isExpired = true;
		// If SessionId is passed in, means the request is from frontend. If not, request is from Wills API.
		if (null != promoCodeJson.get("sessionId")) {
			promoCodeRequest = new PromoCodeRequest();
			String sessionId = (String) promoCodeJson.get("sessionId");
			promoCodeRequest.setSessionId(sessionId);

			switch(promoCodeCategory) 
			{ 
			case "INVEST": 
				promoCodeRequest.setRequestType("Investment");
				break; 
			default: 
				promoCodeRequest.setRequestType("will-writing");
			} 

		}
		PromoCode promoCodeObj = promoCodeRepository.findByCodeAndCategory(promoCode, promoCodeCategory);
		if (null != promoCodeObj && 
				null != promoCodeObj.getStartDate() && null != promoCodeObj.getEndDate() &&
				"A".equalsIgnoreCase(promoCodeObj.getStatus())) {
			LocalDate now = LocalDate.now();
			java.sql.Date startdate = (Date) promoCodeObj.getStartDate();
			java.sql.Date enddate = (Date) promoCodeObj.getEndDate();
			if((now.isAfter(startdate.toLocalDate()) || now.isEqual(startdate.toLocalDate())) &&
					(now.isBefore(enddate.toLocalDate()) || now.isEqual(enddate.toLocalDate()))) {
				isExpired = false;
				getLogger(this.getClass()).info("Setting Promo Code to valid");
			}
		}
		if (!isExpired) {
			if (null != promoCodeRequest) {
				getLogger(this.getClass()).info("Getting enquiry reference");
				promoCodeRequest.setPromoCodeId(promoCodeObj.getId());
				enquiryResponseMessage = promoCodeService.getEnquiryReference(promoCodeRequest);
				if (null != enquiryResponseMessage && null != enquiryResponseMessage.getObjectList() && !enquiryResponseMessage.getObjectList().isEmpty()) {
					getLogger(this.getClass()).info("Setting enquiry reference into Response");
					List objectList = new ArrayList();
					objectList = enquiryResponseMessage.getObjectList();
					responseList.setObjectList(objectList);
				}
			}
			responseList.getResponseMessage().setResponseCode(ErrorCodes.PROMO_CODE_VERIFICATION_SUCCESSFUL);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.VALIDATION_SUCCESS);
			return responseList;
		}
		getLogger(this.getClass()).info("Promo Code is invalid");
		responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_PROMO_CODE);
		responseList.getResponseMessage().setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_PROMO_CODE);
		return responseList;
	}

	@PostMapping(path="/saveCustomerPromoCode")
	@ApiOperation(value = "Saves the Promo Code entered by the user",
	notes = "Saves the Promo Code entered by the user",
	response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList saveCustomerPromoCode(@RequestBody Map<String, Object> customerPromoCodeJson) {

		ResponseMessageList responseList = getDefaultMessageList();

		try {
			Integer customerId = Integer.parseInt((String)customerPromoCodeJson.get("customerId"));
			String promoCode = (String) customerPromoCodeJson.get("promoCode");
			String promoCodeCategory = (String) customerPromoCodeJson.get("promoCodeCat");
			String promoCodeIdString = (String) customerPromoCodeJson.get("promoCodeId");
			boolean promoCodeIdExists = StringUtils.isNotBlank(promoCodeIdString);
			boolean promoCodeAndCatExists = StringUtils.isNotBlank(promoCode) && StringUtils.isNotBlank(promoCodeCategory);
			if (null != customerId && customerId >= 0 && (promoCodeAndCatExists || promoCodeIdExists)) {
				CustomerPromo customerPromoObj = null;
				Integer promoCodeId = null;

				if (promoCodeIdExists) {
					promoCodeId = Integer.parseInt(promoCodeIdString);
					Optional<PromoCode> promoCodeOpt = promoCodeRepository.findById(promoCodeId);
					if (promoCodeOpt.isPresent()) {
						PromoCode promoCodeObj = promoCodeOpt.get();
						promoCodeCategory = promoCodeObj.getCategory();
					} else if (StringUtils.isBlank(promoCodeCategory)) {
						promoCodeCategory = "WILLS";
					}
				} else {
					PromoCode promoCodeObj = promoCodeRepository.findByCodeAndCategory(promoCode, promoCodeCategory);
					if (null != promoCodeObj) {
						promoCodeId = promoCodeObj.getId();
					} else {
						throw new Exception("PromoCode not found - " + promoCode + ", " + promoCodeCategory);
					}
				}

				CustomerPromo customerPromoDB = customerPromoRepository.findByCustomerIdAndPromoCodeCategory(customerId, promoCodeCategory);
				if (null != customerPromoDB) {
					customerPromoDB.setPromoCodeId(promoCodeId);
					customerPromoObj = customerPromoDB;
				} else {
					customerPromoObj = new CustomerPromo();
					customerPromoObj.setCustomerId(customerId);
					customerPromoObj.setPromoCodeId(promoCodeId);
				}

				customerPromoRepository.save(customerPromoObj);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_REQUEST);
				getLogger(this.getClass()).error("saveCustomerPromoCode - " + ErrorCodes.INVALID_REQUEST + " - " + ApplicationConstants.INVALID_REQUEST);
				getLogger(this.getClass()).error("saveCustomerPromoCode - customerId: " + customerId == null ? "null" : customerId);
				getLogger(this.getClass()).error("saveCustomerPromoCode - promoCodeIdExists: " + promoCodeIdExists);
				getLogger(this.getClass()).error("saveCustomerPromoCode - promoCodeAndCatExists: " + promoCodeAndCatExists);
			}
		} catch (Exception e) {
			if (e.getMessage().contains("PromoCode not found - ")) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_MATCHING_RECORDS_FOUND);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_MATCHING_RECORDS_FOUND);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			}
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}

		return responseList;
	}

	@PostMapping(path="/getDefaultPromoCode")
	@ApiOperation(value = "Gets the default promo code", notes = "Gets the default promo code", response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList getDefaultEmailPromoCode(@RequestBody Map<String, Object> promoCodeJson) {

		ResponseMessageList responseList = getDefaultMessageList();

		try {
			String promoCodeCategory = (String) promoCodeJson.get("promoCodeCat");
			PromoCode promoCodeObj = promoCodeRepository.findByCategoryAndIsDefault(promoCodeCategory, "Y");
			List objectList = new ArrayList();
			if (null != promoCodeObj) {
				PromoCodeResponse response = new PromoCodeResponse();
				response.setPromoCode(promoCodeObj.getCode());
				objectList.add(response);
				responseList.setObjectList(objectList);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_MATCHING_RECORDS_FOUND);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_MATCHING_RECORDS_FOUND);
			}
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}

		return responseList;
	}

	@PostMapping(path="/getCustPromoCodeByCategory")
	@ApiOperation(value = "Gets the customer promo code by category", notes = "Gets the customer promo code by category", response = ResponseMessageList.class)
	public @ResponseBody ResponseMessageList getCustomerPromoCodeByCategory(HttpServletRequest httpServletRequest, @RequestBody Map<String, Object> promoCodeJson) {

		boolean hasPromo = false;
		ResponseMessageList responseList = getDefaultMessageList();

		try {
			getLogger(this.getClass()).info("Get Customer Promo Code by Category - start");
			int customerId = this.getCustomerId(httpServletRequest);
			if (-1 != customerId) {
				getLogger(this.getClass()).info("Get Customer Promo Code by Category - customer ID is " + customerId);
				String promoCodeCategory = (String) promoCodeJson.get("promoCodeCat");
				getLogger(this.getClass()).info("Get Customer Promo Code by Category - category is " + promoCodeCategory);
				CustomerPromo customerPromoDB = customerPromoRepository.findByCustomerIdAndPromoCodeCategory(customerId, promoCodeCategory);
				if (null != customerPromoDB) {
					Optional<PromoCode> promoCodeOpt = promoCodeRepository.findById(customerPromoDB.getPromoCodeId());
					if(promoCodeOpt.isPresent()) {
						PromoCode promoCode = promoCodeOpt.get();
						List objectList = new ArrayList();
						objectList.add(promoCode);
						responseList.setObjectList(objectList);
						hasPromo = true;
						getLogger(this.getClass()).info("Found 1 promo code " + promoCode.getCode() + " for customer ID " + customerId);
					}
				}
				
				if (!hasPromo) {
					getLogger(this.getClass()).info("No promo code found for customer ID " + customerId);
					responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_MATCHING_RECORDS_FOUND);
					responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_MATCHING_RECORDS_FOUND);
				}
				
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_REQUEST);
				getLogger(this.getClass()).error("Customer ID is -1");
			}
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}

		getLogger(this.getClass()).info("Get Customer Promo Code by Category - end");

		return responseList;
	}
}

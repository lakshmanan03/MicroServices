/**
 * 
 */
package com.bfa.components;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bfa.application.core.ValidateCaptchaBean;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.service.SecurityService;

/**
 * Validated the captcha for the given session id.
 * 
 * Throws a Runtime exception if a valid session is not passed to the method.
 * 
 * @author pradheep
 * @since release_2.12
 *
 */
@Aspect
@Component
public class CaptchaValidator {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	private SecurityService securityService;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@Before(value = "@annotation(ValidateCaptcha)")
	public void validateCaptcha(JoinPoint jp) {
		Object[] obj = jp.getArgs();
		int instanceFound = 0;
		for (int x = 0; x <= obj.length; x++) {
			Object instance = obj[x];
			if(instance instanceof ValidateCaptchaBean){
				instanceFound++;				
				ValidateCaptchaBean validateCaptchaBean = (ValidateCaptchaBean) instance;				
				String sessionId = validateCaptchaBean.getSessionId();
				String captcha = validateCaptchaBean.getCaptcha();
				validateCaptchaBean.isApplicable = isCaptchaApplicable(sessionId);
				if(validateCaptchaBean.isApplicable){
				if(sessionId == null || sessionId.isEmpty()){
					getLogger().error("Invalid session id passed , cannot validate the captcha");
					validateCaptchaBean.isValidCaptcha = false;
					return;
				}
				if(captcha == null || captcha.isEmpty()){
					getLogger().error("captcha string cannot be null");
					validateCaptchaBean.isValidCaptcha = false;
					return;
				}
				boolean flag = securityService.isValidCaptcha(sessionId, captcha);
				validateCaptchaBean.isValidCaptcha = flag;
				}
				break;
			}			
		}
		if(instanceFound == 0){
			getLogger().warn("Captcha validation was not done : check the method arguments, Use ValidateCaptchaBean");
		}
	}
	
	private boolean isCaptchaApplicable(String sessionId) throws RuntimeException{
		return securityService.isCaptchaApplicable(sessionId);
	}
}

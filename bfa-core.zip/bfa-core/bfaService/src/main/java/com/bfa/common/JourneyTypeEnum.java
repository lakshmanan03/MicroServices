/**
 * 
 */
package com.bfa.common;

import java.io.Serializable;

/**
 * 
 * This is used to set the journey type while making a CRM service call. * 

 * @author pradheep 
 * @since Release 3.0
 *
 */

public enum JourneyTypeEnum implements Serializable{

	Insurance_Guided ("Insurance Guided"),
	Insurance_Direct ("Insurance Direct"),
	Comprehensive("Comprehensive"),
	Comprehensive_Lite("Comprehensive Lite"),
	Child_Education_Bundle("Child Education Bundle"),
	Child_Protection_Bundle("Child Protection Bundle"),
	Retirewise_Bundle("Retirewise Bundle"),
	Young_Working_Adult_Bundle("Young Working Adult Bundle"),
	Retirement_LEAD_BY_ADS("Retirement Lead by Ads"),
	Workshop("Workshop");
	

	private String value;
	
	private JourneyTypeEnum(String value){
		this.value = value;
	}
	
	public String getValue(){
		return value;
	}

}

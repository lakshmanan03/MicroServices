package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author DivakarU
 *
 */
@Entity
@Table(name = "vw_fund_total_units_details")
public class VWTotalFundUnits {
	
	@Id
	@Column(name = "fis_id")
	private int fisId;
	
	@Column(name = "portfolio_transaction_id")
	private int portfolioTransactionId;
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "portfolio_id")
	private int portfolioId;
	
	@Column(name = "fund_id")
	private int fundId;
	
	
	@Column(name = "transaction_date")
	private Date transactionDate;
	
	@Column(name = "unit")
	private Double units;
	
	@Column(name = "amount")
	private Double amount;
	
	@Column(name = "total_units")
	private Double totalUnits;
	
	@Column(name = "str_fund_id")
	private String fundName;

	/**
	 * @return the portfolioTransactionId
	 */
	public int getPortfolioTransactionId() {
		return portfolioTransactionId;
	}

	/**
	 * @param portfolioTransactionId the portfolioTransactionId to set
	 */
	public void setPortfolioTransactionId(int portfolioTransactionId) {
		this.portfolioTransactionId = portfolioTransactionId;
	}

	/**
	 * @return the customerId
	 */
	public int getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the portfolioId
	 */
	public int getPortfolioId() {
		return portfolioId;
	}

	/**
	 * @param portfolioId the portfolioId to set
	 */
	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	/**
	 * @return the fundId
	 */
	public int getFundId() {
		return fundId;
	}

	/**
	 * @param fundId the fundId to set
	 */
	public void setFundId(int fundId) {
		this.fundId = fundId;
	}

	/**
	 * @return the transactionDate
	 */
	public Date getTransactionDate() {
		return transactionDate;
	}

	/**
	 * @param transactionDate the transactionDate to set
	 */
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	/**
	 * @return the units
	 */
	public Double getUnits() {
		return units;
	}

	/**
	 * @param units the units to set
	 */
	public void setUnits(Double units) {
		this.units = units;
	}

	/**
	 * @return the totalUnits
	 */
	public Double getTotalUnits() {
		return totalUnits;
	}

	/**
	 * @param totalUnits the totalUnits to set
	 */
	public void setTotalUnits(Double totalUnits) {
		this.totalUnits = totalUnits;
	}

	/**
	 * @return the fundName
	 */
	public String getFundName() {
		return fundName;
	}

	/**
	 * @param fundName the fundName to set
	 */
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	
	
	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VWTotalFundUnits [portfolioTransactionId=");
		builder.append(portfolioTransactionId);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", portfolioId=");
		builder.append(portfolioId);
		builder.append(", fundId=");
		builder.append(fundId);
		builder.append(", transactionDate=");
		builder.append(transactionDate);
		builder.append(", units=");
		builder.append(units);
		builder.append(", totalUnits=");
		builder.append(totalUnits);
		builder.append(", fundName=");
		builder.append(fundName);
		builder.append("]");
		return builder.toString();
	}

	public int getFisId() {
		return fisId;
	}

	public void setFisId(int fisId) {
		this.fisId = fisId;
	}
	
}


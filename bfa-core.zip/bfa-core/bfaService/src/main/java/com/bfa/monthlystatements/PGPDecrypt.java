//package com.bfa.monthlystatements;
//
//import java.io.BufferedOutputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.security.NoSuchProviderException;
//import java.util.Iterator;
//
//import org.apache.log4j.Logger;
//import org.bouncycastle.openpgp.PGPCompressedData;
//import org.bouncycastle.openpgp.PGPEncryptedDataList;
//import org.bouncycastle.openpgp.PGPException;
//import org.bouncycastle.openpgp.PGPLiteralData;
//import org.bouncycastle.openpgp.PGPObjectFactory;
//import org.bouncycastle.openpgp.PGPOnePassSignatureList;
//import org.bouncycastle.openpgp.PGPPrivateKey;
//import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
//import org.bouncycastle.openpgp.PGPSecretKey;
//import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
//import org.bouncycastle.openpgp.PGPUtil;
//
//public class PGPDecrypt {
//
//	private Logger logger;
//
//	public Logger getLogger() {
//		return logger;
//	}
//
//	public void setLogger(Logger logger) {
//		this.logger = logger;
//	}
//
//	public String decryptFile(InputStream encryptedFileStream, InputStream keyFileStream, char[] passwd, FileOutputStream decryptedFileStream) {
//		try {
//			BufferedOutputStream baos = null;
//			PGPObjectFactory pgpF = new PGPObjectFactory(PGPUtil.getDecoderStream(encryptedFileStream));
//			Object o = pgpF.nextObject();
//			PGPEncryptedDataList enc = o instanceof PGPEncryptedDataList ? (PGPEncryptedDataList) o
//					: (PGPEncryptedDataList) pgpF.nextObject();
//			Iterator it = enc.getEncryptedDataObjects();
//			PGPPrivateKey sKey = null;
//			PGPPublicKeyEncryptedData pbe = null;
//
//			while (sKey == null && it.hasNext()) {
//				pbe = (PGPPublicKeyEncryptedData) it.next();
//				sKey = findSecretKey(keyFileStream, pbe.getKeyID(), passwd);
//			}
//			if (sKey == null) {
//
//				throw new IllegalArgumentException("secret key for message not found.");
//			}
//
//			InputStream clear = pbe.getDataStream(sKey, "BC");
//			PGPObjectFactory plainFact = new PGPObjectFactory(clear);
//			Object message = plainFact.nextObject();
//			if (message instanceof PGPCompressedData) {
//				PGPCompressedData cData = (PGPCompressedData) message;
//				PGPObjectFactory pgpFact = new PGPObjectFactory(cData.getDataStream());
//				message = pgpFact.nextObject();
//			}
//			baos = new BufferedOutputStream(decryptedFileStream);
//			if (message instanceof PGPLiteralData) {
//				PGPLiteralData ld = (PGPLiteralData) message;
//				InputStream unc = ld.getInputStream();
//				int ch;
//				while ((ch = unc.read()) >= 0) {
//					baos.write(ch);
//				}
//			} else if (message instanceof PGPOnePassSignatureList) {
//				throw new PGPException("encrypted message contains a signed message - not literal data.");
//			} else {
//				throw new PGPException("message is not a simple encrypted file - type unknown.");
//			}
//
//			if (pbe.isIntegrityProtected()) {
//				if (!pbe.verify()) {
//					getLogger().info("message failed integrity check");
//				}
//			} else {
//				getLogger().info("no message integrity check");
//			}
//		} catch (IOException e) {
//			getLogger().error("IO Exception occured in PGPDecrypt.decryptFile() : " + e);
//		} catch (PGPException e) {
//			getLogger().error("PGPException occured in PGPDecrypt.decryptFile() : " + e);
//		} catch (NoSuchProviderException e) {
//			getLogger().error("NoSuchProviderException occured in PGPDecrypt.decryptFile() : " + e);
//		} catch (Exception e) {
//			getLogger().error("Exception occured in decryptFile: " + e);
//		}
//		return "File Decrypted Successfully!";
//	}
//
//	private PGPPrivateKey findSecretKey(InputStream keyIn, long keyID, char[] pass)
//			throws IOException, PGPException, NoSuchProviderException {
//		PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(keyIn));
//		getLogger().info("pgpSec size=" + pgpSec);
//		getLogger().info(keyID);
//		PGPSecretKey pgpSecKey = pgpSec.getSecretKey(keyID);
//		return pgpSecKey != null ? pgpSecKey.extractPrivateKey(pass, "BC") : null;
//	}
//
//}
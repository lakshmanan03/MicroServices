/**
 * 
 */
package com.bfa.notification.messenger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.notification.EmailMessageObject;
import com.bfa.notification.MessageObject;
import com.bfa.util.PublicUtility;

/**
 * @author pradheep.p
 *
 */
public class BFAMessenger implements Messenger {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private String appKey = "FUDq3FpzKW4=";
	
	private String email_user_primary = "";
	
	private String email_password_primary = "";
	
	private String basePath = "/opt/tomcat/conf/account/";

	private String propertiesFile = "email_settings_primary.properties";
	
	private Properties prop = null;

	@Override
	public Object communicate(MessageObject messageObject) {
		EmailMessageObject emailMessageObject = (EmailMessageObject) messageObject;
		return sendEmailMessage(emailMessageObject);		
	}

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	/**
	 * Returns true if the email has been sent successfully. Otherwise false.
	 * 
	 * @param emailMessageObject
	 * @return
	 */
	public boolean sendEmailMessage(EmailMessageObject emailMessageObject) {
		getLogger().info("Sending email to customer ..");
		boolean flag = false;// Not sent by default
		Properties prop = getPrimaryProperties();
		MimeMessage mimeMessage = establishPrimaryEmailConnection(prop);
		String body = emailMessageObject.getBodyOfMessage();
		String subject = emailMessageObject.getSubjectOfMessage();
		String[] toAddress = emailMessageObject.getToList();
		String[] ccAddress = emailMessageObject.getCcList();
		String[] bccAddress = emailMessageObject.getBccList();
		String fromAddress = emailMessageObject.getFromAddress();
		String senderAddress = prop.getProperty("mail.sender.from", fromAddress);
		getLogger().info("Printing the sender address " + senderAddress);
		getLogger().info("Printing the to address " + toAddress);

		try {
			getLogger().info("Mime message obj is : " + mimeMessage);
			if (mimeMessage != null) {
				mimeMessage.setContent(body, "text/html; charset=utf-8");
				mimeMessage.setSubject(subject);
				mimeMessage.setFrom(new InternetAddress(senderAddress));
				mimeMessage.setRecipients(MimeMessage.RecipientType.TO, getCommaSeperatedAddress(toAddress));
				if (ccAddress != null && ccAddress.length > 0) {
					mimeMessage.setRecipients(MimeMessage.RecipientType.CC, getCommaSeperatedAddress(ccAddress));
				}
				if (bccAddress != null && bccAddress.length > 0) {
					mimeMessage.setRecipients(MimeMessage.RecipientType.BCC, getCommaSeperatedAddress(bccAddress));
				}
				Transport.send(mimeMessage);
				getLogger().info("Email sent to recipient..");
				flag = true;
			}
		} catch (MessagingException e) {
			getLogger().error("Error while sending email",e);
			getLogger().error("Exception in BFAMessenger.sendEmailMessage(): " + e.fillInStackTrace());
			flag = false;
		}
		return flag;
	}

	private Address[] getCommaSeperatedAddress(String[] address) {
		Address[] mailAddress = new Address[address.length];
		int i = 0;
		for (String obj : address) {
			try {
				getLogger().info(">>-" + obj);
				if (obj == null) {
					continue;
				}
				mailAddress[i] = new InternetAddress(obj);
				i++;
			} catch (AddressException e) {
				getLogger().error("AddressException in getCommaSeperatedAddress(): " + e);
			}
		}
		return mailAddress;
	}

	private Properties getPrimaryProperties() {
		if(prop != null){
			return prop;
		}
		File f = new File(basePath + propertiesFile);
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(f);
		} catch (FileNotFoundException e1) {
			getLogger().error("FileNotFoundException while getPrimaryProperties(): " + e1);
		}

		prop = new Properties();		
		
		try {			
			prop.load(inputStream);
			getLogger().info("Loaded the properties for email..");
			PublicUtility utility = PublicUtility.getInstance(appKey);
			String password = prop.get("password").toString();
			String newpass = utility.DecryptText(password);
			prop.setProperty("password", newpass);
		} catch (IOException e) {
			getLogger().error("IOException while loading Properties: " + e);
		}
		return prop;
	}

	private MimeMessage establishPrimaryEmailConnection(Properties prop) {
		try {
			getLogger().info("Printing the properties " + prop);
			email_user_primary = prop.getProperty("username").toString();
			email_password_primary = prop.getProperty("password").toString();
			Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(email_user_primary, email_password_primary);
				}
			});
			MimeMessage mimeMessage = new MimeMessage(session);
			getLogger().info("Establishing a session for sending an email..");
			return mimeMessage;
		} catch (Exception err) {
			getLogger().error("Exception while establishPrimaryEmailConnection(): " + err);
		}
		return null;
	}

	public static void main(String[] args) {
		BFAMessenger messenger = new BFAMessenger();
		messenger.testEmail();
	}

	public void testEmail() {
		EmailMessageObject email = new EmailMessageObject();
		email.setBodyOfMessage("Test Email - Do not Reply");
		email.setFooterInformation("-MoneyOwl");
		email.setSubjectOfMessage("Test Email");
		email.setFromAddress("notifications@moneyowl.sg");

		List<String> emails = new ArrayList<>();
		
		Iterator<String> iter = emails.iterator();
		String[] args = new String[emails.size()];
		int i = 0;
		while (iter.hasNext()) {
			args[i] = iter.next();
			i++;
		}
		email.setToList(args);
		sendEmailMessage(email);
	}


}

/**
 * 
 */
package com.bfa.ifast.exception;

/**
 * @author DivakarU
 *
 */
public class IFastServiceDownException extends IFastException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -385081225311339699L;

	/**
	 * @param exceptionMessage
	 */
	public IFastServiceDownException(String exceptionMessage) {
		super(exceptionMessage);
		// TODO Auto-generated constructor stub
	}

}


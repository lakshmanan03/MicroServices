package com.bfa.request.entity;

import java.util.List;

public class GenerateLatestReportResponseMessage {
	
	private List<GenerateLatestReportResponse> objectList;

	public List<GenerateLatestReportResponse> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<GenerateLatestReportResponse> objectList) {
		this.objectList = objectList;
	}
	
	

}

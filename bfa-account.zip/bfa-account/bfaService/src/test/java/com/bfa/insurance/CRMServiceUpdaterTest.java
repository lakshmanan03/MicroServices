/**
 * 
 */
package com.bfa.insurance;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.product.Premium;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.ads.RetirementPlanningModel;
import com.bfa.serviceimpl.CRMServiceUpdater;
import com.bfa.util.APIConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * @author pradheep.p
 *
 */

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure = false)
@ContextConfiguration
public class CRMServiceUpdaterTest {

	@InjectMocks
	private CRMServiceUpdater crmServiceUpdater;

	@Mock
	private AccountsDao accountsDAO;

	@Mock
	private Environment environment;

	private String authHeader = "";

	@Mock
	private TokenProvider tokenProvider;

	//@Mock
	private MockMvc mockMvc;

	private String crmAPI = APIConstants.POST_RETIREMENT_PLANNING;

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	private Gson gson = new Gson();
	
	@Mock
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Mock
	private Logger mLogger;	
	
	@Mock
	Customer cObj;
	
	private Integer customerId = 1;

	@Transactional
	public Customer loadCustomers() { //Sonar: Non-public methods should not be "@Transactional"
		mLogger.info("--- Inserting customer ---");
		Customer customerObj = new Customer();
		customerObj.setEmail("test@email.com");
		customerObj.setGender("male");
		customerObj.setSurName("test");
		customerObj.setGivenName("testuser");
		customerObj.setMobileNumber("80000001");
		customerObj.setSmoker(true);
		customerObj.setEmailVerified("Yes");
		customerObj.setOtpString("11111");
		customerObj.setOtpVerfied("Yes");
		customerObj.setCreatedDate(new Date());
		customerObj.setDateOfBirth("18/04/1990");
		customerObj.setCountryCode("65");
		customerObj.setVerificationEnquiryId(100);
		when(accountsDAO.saveObject(customerObj)).thenReturn(cObj);
		when(cObj.getId()).thenReturn(customerId);
		mLogger.info("Printing the ID :" + customerId);
		return cObj;
	}

	private List<ProductList> getSampleProducts() {
		ProductList prodList = new ProductList();
		List<ProductList> collection = new ArrayList<>();
		prodList.setProductName("Test Product");
		prodList.setId("P001");
		prodList.setStatus("Active");
		Premium premium = new Premium();
		premium.setPremiumAmount(50.5);
		premium.setPremiumAmountYearly(600.0);
		premium.setId(1);
		prodList.setPremium(premium);
		collection.add(prodList);
		return collection;
	}

	@Test
	public void testCrmServiceUpdater() {		
		mLogger.info("-- Testing CRM service --");
		Customer customerObj = loadCustomers();
		crmServiceUpdater.setCustomerObj(customerObj);
		crmServiceUpdater.setSelectedProducts(getSampleProducts());
		crmServiceUpdater.setEnvironment(this.environment);
		Thread d = new Thread(crmServiceUpdater);
		d.start();
	}

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	/**
	 * Test for - Retirement Planning.
	 */
	@Test
	public void testRetirementPlanning() {
		System.out.println("-----------------------------------------");
		System.out.println("Testing BFA-1744 , retirement planning");
		init();
		RetirementPlanningModel model = getRetirementPlanningModel();
		try {
			System.out.println("Auth Token:" + authHeader);
			System.out.println(gson.toJson(model));
			System.out.println("-----------------------------------------");
			ResultActions result = mockMvc
					.perform(post(crmAPI).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(model)).header("Authorization", authHeader))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Test for  Retirement Planning. - Security Test
	 */
	@Test
	public void testRetirementPlanningForSecurity() {
		System.out.println("-----------------------------------------");
		System.out.println("Testing BFA-1744  retirement planning - Security testing.");		
		RetirementPlanningModel model = getRetirementPlanningModel();
		try {
			authHeader = "No Header Token";
			System.out.println("Auth Token:" + authHeader);
			System.out.println(gson.toJson(model));
			System.out.println("-----------------------------------------");
			ResultActions result = mockMvc
					.perform(post(crmAPI).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(model)).header("Authorization", authHeader))
					.andExpect(status().is(403));
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	private void init() {
		authHeader = getAuthToken();
	}

	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_USER");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		return tokenProvider.getTokenString("-1", authorities);
	}

	private String getMobileNumber() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("8");
		Random ran = new Random();
		for (int i = 0; i < 7; i++) {
			buffer.append(ran.nextInt(9));
		}
		return buffer.toString();
	}

	private String getTargetEmail() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		String[] arg = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p",
				"q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
		for (int i = 0; i < 8; i++) {
			buffer.append(arg[ran.nextInt(arg.length - 1)]);
		}
		buffer.append("@exampletest.com");
		return buffer.toString();
	}

	private String getRandomDateOfBirth() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		buffer.append("19");
		int yr = ran.nextInt(99);
		if (yr >= 10) {
			buffer.append(yr);
		} else {
			buffer.append("0");
			buffer.append(yr);
		}
		buffer.append("-");
		int month = ran.nextInt(12);
		if (month >= 10) {
			buffer.append(month);
		} else {
			buffer.append("0");
			if (month == 0) {
				month++;
			}
			buffer.append(month);
		}
		buffer.append("-");
		int day = ran.nextInt(28);
		if (day >= 10) {
			buffer.append(day);
		} else {
			if (day == 0) {
				day++;
			}
			buffer.append("0");
			buffer.append(day);
		}
		return buffer.toString();
	}

	private RetirementPlanningModel getRetirementPlanningModel() {
		Random ran = new Random();
		RetirementPlanningModel retirementPlanningModel = new RetirementPlanningModel();
		
		String targetEmail = getTargetEmail();
		retirementPlanningModel.setFirstName(targetEmail.substring(0, targetEmail.indexOf("@")));
		retirementPlanningModel.setLastName(" JUnit Test");
		retirementPlanningModel.setEmailAddress(targetEmail);
		retirementPlanningModel.setMobileNumber(getMobileNumber());
		
		retirementPlanningModel.setLumpSumAmount(ran.nextDouble());
		retirementPlanningModel.setMonthlyAmount(ran.nextDouble());
		
		retirementPlanningModel.setDateOfBirth(getRandomDateOfBirth());
		retirementPlanningModel.setMonthlyRetirementIncome(ran.nextDouble());
		retirementPlanningModel.setRetirementAge(65);		

		List retirementSchemeList = new ArrayList();
		retirementSchemeList.add("FLEXIBLE INCOME STREAM");
		retirementSchemeList.add("LONGER PERIOD OF INCOME");
		retirementPlanningModel.setRetirementSchemeList(retirementSchemeList);
		return retirementPlanningModel;
	}
}

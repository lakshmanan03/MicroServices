package com.bfa.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.admin.dto.AddAdvisorRequestDTO;
import com.bfa.admin.dto.AdminCustomerDetails;
import com.bfa.admin.dto.AdminCustomerSummary;
import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.AuthenticationErrorResponse;
import com.bfa.application.core.AuthenticationResponse;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.core.CustomerAndPrevilegeV2;
import com.bfa.application.core.CustomerPreference;
import com.bfa.application.core.CustomerTrackerRequest;
import com.bfa.application.core.SaveSelectedProductsRequest;
import com.bfa.application.core.UpdateMobileNumberRequest;
import com.bfa.application.core.UpdateMobileNumberResponse;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.CustomerProfileDetails;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.OptionsSearchResultDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.SavePrommoCodeDTO;
import com.bfa.common.dto.UpdateContactResponse;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerOverview;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.common.entity.SessionTracker;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.exception.AccountServiceException;
import com.bfa.ifast.exception.IFastException;
import com.bfa.insurance.core.CRMResponse;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.EmploymentStatusMaster;
import com.bfa.insurance.core.Profile;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.dto.CustomerSrsAccountDTO;
import com.bfa.investment.dto.InvestementDashboardResponseDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.OptionsSearchFilterDTO;
import com.bfa.investment.dto.UpdatePasswordDTO;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.request.entity.CustomerCreationResponse;
import com.bfa.request.entity.CustomerCreationResponseV2;
import com.bfa.request.entity.DependentMappingRequest;
import com.bfa.request.entity.UpdateProductEnquiryRequest;
import com.bfa.security.twofa.core.TwoFactorAuthValidation;
import com.bfa.service.AMLVerificationService;
import com.bfa.service.AccountsService;
import com.bfa.service.SecurityService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.serviceimpl.DelegateHandler;
import com.bfa.serviceimpl.UploadingContent;
import com.bfa.util.AMLVerificationServiceResponse;
import com.bfa.util.AMLVerificationStatus;
import com.bfa.util.APIConstants;
import com.bfa.util.APIResponse;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.DocumentType;
import com.bfa.util.ErrorCodes;
import com.bfa.util.InvestmentAccountStatus;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessageList;
import com.bfa.util.ServiceResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "/api")
public class AccountsController extends BaseController {

	@Autowired(required=false)
	private AccountsService accountsService;

	@Autowired
	AMLVerificationService amlService;

	@Autowired
	MOInvestmentService investmentService;

	@Autowired
	private DelegateHandler delegateHandler;

	@Autowired
	MOInvestmentService investService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	MOInvestmentService investServiceObj;

	protected String appKey = "IMXYlDmP4f4=";

	protected PublicUtility utility = PublicUtility.getInstance(appKey);

	@Autowired
	ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private Environment environment;

	protected Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}



	@GetMapping(APIConstants.API_ACCOUNT_TEST_UPDATE_INVSTATUS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_TEST_UPDATE_INVSTATUS)
	@ApiOperation(value = "Returns the list of user profiles", notes = "Returns the list of user profiles", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<Map<String, Object>> testUpdateInvStatus() {

		APIResponse<Map<String, Object>> response = new APIResponse<>();
		Map<String, Object> updateInvStatus = new HashMap<>();
		response.setObjectList(updateInvStatus);
		updateInvStatus.put("Calling Inv Status Update", "");
		try {
			investService.updateInvestmentAccountStatus_debug(InvestmentAccountStatus.EDD_CHECK_PENDING,
					updateInvStatus);
		} catch (Exception err) {
			updateInvStatus.put("Exception", err);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_PROFILE_TYPE_LIST)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_PROFILE_TYPE_LIST)
	@ApiOperation(value = "Returns the list of user profiles", notes = "Returns the list of user profiles", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList getProfileList() {
		getLogger(this.getClass()).info("get inside get profile list");
		ResponseMessageList responseList = getDefaultMessageList();
		try {
			List<Profile> profiles = accountsService.getProfileList();
			responseList.setObjectList(addObjects(profiles));
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(value = APIConstants.API_ACCOUNT_SAVE_PROMO_CODE)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_SAVE_PROMO_CODE)
	@ApiOperation(value = "", notes = "Authenticates the user for the given secret key", response = AuthenticationResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<Boolean> savePromocode(
			@RequestBody SavePrommoCodeDTO savepromocodeDto, HttpServletRequest requestObj) {
		APIResponse<Boolean> response = null;		


		try {
			getLogger(this.getClass()).info("Printing the thread name " + Thread.currentThread().getName());
			Integer custId = getCustomerId(requestObj);
			getLogger(this.getClass()).info("#savepromo::  Enquiry id and customer id--"+savepromocodeDto.getEnquiryId()+"---"+custId);

			securityService.savePromocode(custId, savepromocodeDto.getEnquiryId());			


		} catch (Exception ex) {
			ex.printStackTrace();
			getLogger(this.getClass()).error("Error catched in controller: " + ex);
			StackTraceElement[] traces = ex.getStackTrace();
			for (StackTraceElement trace : traces) {
				getLogger(this.getClass())
				.error(trace.getClassName() + ": " + trace.getMethodName() + ": " + trace.getLineNumber());
			}


		}
		response = APIResponse.createSuccessResponse();
		response.setObjectList(true);
		return response;

	}

	@GetMapping(APIConstants.API_ACCOUNT_EMPLOYMENT_STATUS)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path(APIConstants.API_ACCOUNT_EMPLOYMENT_STATUS)
	@ApiOperation(value = "Returns the Status", notes = "Returns the status", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList getEmploymentStatus() {
		getLogger(this.getClass()).info("Calling get Employment list");
		ResponseMessageList responseList = getDefaultMessageList();
		try {
			List<EmploymentStatusMaster> profiles = accountsService.getEmploymentList();
			responseList.setObjectList(addObjects(profiles));
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_UPDATE_EMPLOYMENT)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_UPDATE_EMPLOYMENT)
	@ApiOperation(value = "Edit the profile", notes = "Edit user profile", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList editProfile(@RequestBody EmploymentDetailsDTO employmentDetails,
			HttpServletRequest httpServletRequest) {
		ResponseMessageList responseList = getDefaultMessageList();
		Integer custId = getCustomerId(httpServletRequest);
		Customer customerDetails = accountsService.getDetailsByCustomerId(custId);
		try {
			accountsService.updateEmployment(customerDetails, employmentDetails);

		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_SAVE_DEPENDENTS)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path(APIConstants.API_ACCOUNT_SAVE_DEPENDENTS)
	@ApiOperation(value = "Returns the list of Save Dependent Details", notes = "Save Dependent Details of the user.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public ResponseMessageList saveDependents(@RequestBody DependentMappingRequest dependentMappingRequest,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Inside method Save Dependents");
		ResponseMessageList responseList = getDefaultMessageList();
		List<DependentMapping> dependents = dependentMappingRequest.getDependentMappingList();
		try {
			accountsService.saveDependents(dependents);
			String sessionId = dependentMappingRequest.getSessionId();
			SessionDetails sessionDetails = securityService.saveSessionDetails(sessionId, httpServletRequest);
			List<Object> objectList = new ArrayList<>();
			objectList.add(sessionDetails);
			responseList.setObjectList(objectList);
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_SIGNUP)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path(APIConstants.API_ACCOUNT_SIGNUP)
	@ApiOperation(value = "User sign up check", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList Signup(@RequestBody CustomerCreationPostRequest customer) {
		ResponseMessageList responseList = getDefaultMessageList();
		String sessionId = customer.getSessionId();
		String captcha = customer.getCaptcha();
		boolean isValidCaptcha = securityService.isValidCaptcha(sessionId, captcha);
		if (!isValidCaptcha) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CAPTCHA);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_CAPTCHA);
			return responseList;
		}
		String errorResponse = accountsService.validateUser(customer);
		if (!errorResponse.equals(ApplicationConstants.VALIDATION_SUCCESS)) {
			getLogger(this.getClass()).error("Validation failed " + errorResponse);
			responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseList.getResponseMessage().setResponseDescription(errorResponse);
			return responseList;
		}
		try {
			CustomerCreationResponse customerCreationResponse = new CustomerCreationResponse();
			getLogger(this.getClass()).info("Calling get Customer list");
			CustomerAndPrevilege custAndPrevilege = accountsService.signup(customer);
			Customer custObj = custAndPrevilege.getCustomer();
			getLogger(this.getClass()).info("added Customer list");
			customerCreationResponse.setEnquiryId(customer.getEnquiryId());
			Integer customerId = custObj.getId();
			String customerRef = accountsService.encryptUserResponseData(customerId.toString());
			customerCreationResponse.setSecurityToken(custAndPrevilege.getSecurityToken());
			customerCreationResponse.setCustomerRef(customerRef);
			List objectList = new ArrayList();
			objectList.add(customerCreationResponse);
			responseList.setObjectList(objectList);
			// ------------------------------------------------------------------------------------//
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_UPDATE_PERSONAL_DETAILS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_UPDATE_PERSONAL_DETAILS)
	@ApiOperation(value = "Edit the profile", notes = "Edit user profile", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })	
	public @ResponseBody ResponseMessageList editPersonalDetails(@RequestBody ContactDetailsDTO updateCustomercontact,
			HttpServletRequest servletRequest) {
		//-------- Validation ---------//
		Integer custId = getCustomerId(servletRequest);
		String mobileNumber = updateCustomercontact.getMobileNumber();
		String emailAddress = updateCustomercontact.getEmailId();
		String sessionId = servletRequest.getHeader(ApplicationConstants.SESSION_ID);
		TwoFactorAuthValidation twoFactorAuthValidation = securityService.authenticate2FAWithReturnCode(sessionId);
		Integer code = twoFactorAuthValidation.getReturnCode();		
		ResponseMessageList responseMessageList = validate2FAInputs(custId,mobileNumber,emailAddress,sessionId,code);
		if(null != responseMessageList){
			getLogger().error("[Error in validation]:" + responseMessageList.getResponseMessage().getResponseDescription());
			return responseMessageList;
		}
		//-----------------------------//
		getLogger(this.getClass()).info("Updating the user information " + custId);
		ResponseMessageList responseList = getDefaultMessageList();
		try {
			ServiceResponse<Boolean> updateCustomerContactDetails = accountService
					.updateCustomerContactDetails(custId, updateCustomercontact, servletRequest);

			if (updateCustomerContactDetails.getResponse() == false && (null != updateCustomerContactDetails.getErrorInfo() && updateCustomerContactDetails.getErrorInfo().containsKey("error"))) {
				responseList.getResponseMessage().setResponseCode(5000);
				responseList.getResponseMessage().setResponseDescription("Email Address or Mobile Number already exists");
			}
			else if (updateCustomerContactDetails.getResponse() == true) {
				responseList.getResponseMessage().setResponseCode(6000);
				responseList.getResponseMessage().setResponseDescription("Contact details are updated successfully!");
				// When mobile number updated successfully
				if (null != updateCustomerContactDetails.getErrorInfo() && updateCustomerContactDetails.getErrorInfo().containsKey("mobileupdatestatus")) {
					UpdateContactResponse updateContactResponse = new UpdateContactResponse();
					String customerRef = updateCustomerContactDetails.getResponseInfo().get("customerRef").toString();
					updateContactResponse.setCustomerRef(customerRef);
					List<Object> objectList = new ArrayList<>();
					objectList.add(updateContactResponse);
					responseList.setObjectList(objectList);
				}
			}

		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	private ResponseMessageList validate2FAInputs(Integer custId,String mobileNumber,String emailAddress,String sessionId,Integer code) {
		ResponseMessageList responseList = getDefaultMessageList();
		// ------------ Validations ---------------//
		getLogger().info("Cust Id:" + custId);
		if (custId <= 0) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.UNABLE_TO_FIND_THE_CUSTOMER);
			return responseList;
		}
		if (null == mobileNumber || !StringUtils.isNumeric(mobileNumber) || mobileNumber.length() < 8) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE);
			return responseList;
		}
		if (null == emailAddress || !EmailValidator.getInstance().isValid(emailAddress)) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_REQUEST);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.VALIDATION_ERROR_INVALID_EMAIL);
			return responseList;
		}

		if (!securityService.isValidSession(sessionId)) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_SESSION);
			return responseList;
		}
		switch (code) {
		case ErrorCodes.TWO_FACTOR_AUTH_TIME_EXCEEDED:
			responseList.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTH_TIME_EXCEEDED);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_EXCEEDED_TIME);
			return responseList;
		case ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED:
			responseList.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_FAILED);
			return responseList;
		}
		return null;
	}

	@PostMapping(APIConstants.UPDATE_CUSTOMER_CRM_INFO)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path(APIConstants.UPDATE_CUSTOMER_CRM_INFO)
	@ApiOperation(value = "Returns the success response ", notes = "Save CRM data for the customer.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public ResponseMessageList saveCRMDataInCustomer(@RequestBody CRMResponse crmResponseData,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Persisting the CRM details for the customer provided.");
		ResponseMessageList responseList = getDefaultMessageList();
		try {

			accountsService.updateCRMDetailsOfCustomer(crmResponseData);
			List<Object> objectList = new ArrayList<>();
			responseList.setObjectList(objectList);
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return responseList;
	}

	@GetMapping(APIConstants.API_ACCOUNT_PROFILE_SUMMARY)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path(APIConstants.API_ACCOUNT_PROFILE_SUMMARY)
	@ApiOperation(value = "Returns user profile summary", notes = "Returns user profile summary", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<ProfileSummaryDTO> getProfileSummary(HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Calling get profile list");
		APIResponse<ProfileSummaryDTO> response = null;
		try {
			Integer custId = getCustomerId(httpServletRequest);
			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();
			ProfileSummaryDTO dto = null;
			Boolean isAdminUser = grantedAuthorities.stream().anyMatch(a -> {
				return (a.getAuthority().contains(BFAGrandtedAuthority.ROLE_ADVISOR));
			});
			if (isAdminUser) {
				Advisor advisorDetails = accountService.getAdvisorbyId(custId);
				dto = new ProfileSummaryDTO();
				dto.setFullName(advisorDetails.getName());
				dto.setEmailAddress(advisorDetails.getEmailId());
				dto.setMobileNumber(advisorDetails.getMobileNumber());

			} else {

				dto = accountsService.getProfileSummaryById(custId);
			}
			if (dto != null) {
				response = APIResponse.createSuccessResponse();
				response.setObjectList(dto);
			} else {
				response = APIResponse.createFailureResponse();
			}
		} catch (DatabaseAccessException err) {
			response = APIResponse.createFailureResponse();
			response.setException(err);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			response.setException(err);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_CUSTOMER_PROFILE_DETAILS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_PROFILE_DETAILS)
	@ApiOperation(value = "Returns user profile summary", notes = "Returns user profile summary", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<ProfileSummaryDTO> getCustomerProfile(HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Calling get profile list");
		APIResponse<ProfileSummaryDTO> response = null;
		try {			
			Integer custId = getCustomerId(httpServletRequest);
			ProfileSummaryDTO dto = accountsService.getCustomerProfileDetails(custId);

			if (dto != null) {
				getLogger(this.getClass()).info("Return Calling get profile list for::" + dto.toString());
				response = APIResponse.createSuccessResponse();
				response.setObjectList(dto);
			} else {
				response = APIResponse.createFailureResponse();
			}
		}
		catch(IFastException ex) {
			response = APIResponse.createFailureResponse();
			response.setException(ex);
			response.getResponseMessage().setResponseCode(ErrorCodes.IFAST_DOWN);
			response.getResponseMessage().setResponseDescription(ex.getMessage());
			getLogger(this.getClass()).error(ApplicationConstants.IFAST_SERVICE_DOWN, ex);
		}
		catch (DatabaseAccessException err) {
			response = APIResponse.createFailureResponse();
			response.setException(err);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			response.setException(err);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_DASHBOARD)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_DASHBOARD)
	@ApiOperation(value = "Get User Details", notes = "Get USer Details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<InvestementDashboardResponseDTO> dashboardDetails(
			HttpServletRequest httpServletRequest) {
		APIResponse<InvestementDashboardResponseDTO> response = null;
		try {
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			Integer customerId = bfaUser.getId();
			InvestementDashboardResponseDTO investementDashboardresponse = new InvestementDashboardResponseDTO();
			InvestementDashboardStatusDTO dashboardStatus;
			dashboardStatus = accountService.getInvestmentDashboardStatus(customerId);
			investementDashboardresponse.setInvestement(dashboardStatus);

			response = APIResponse.createSuccessResponse();
			response.setObjectList(investementDashboardresponse);
		} catch (Exception ex) {
			response = APIResponse.createFailureResponse();
			getLogger().info("exception at customer/dashboard" + ex);
			getLogger().info("exception message at customer/dashboard" + ex.getMessage());
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_DETAILED_CUSTOMER_SUMMARY)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_DETAILED_CUSTOMER_SUMMARY)
	@ApiOperation(value = "Returns user profile summary", notes = "Returns user profile summary", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<DetailedCustomerSummary> getDetailedCustomerSummary(
			@RequestParam(value = "customerId", required = false) Integer customerId,			
			@RequestParam(value = "enquiryId", required = false) Integer enquiryId,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Calling getDetailedCustomerSummary for customerID:" + customerId + "For Enquiry id: " + enquiryId);
		// To get email from principal object
		APIResponse<DetailedCustomerSummary> response = null;
		try {

			// Added condition to fetch CustomerSummary for the
			BFAUserDetails bfaUser = null;
			DetailedCustomerSummary dto = null;
			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();
			getLogger(this.getClass()).info("Reached getDetailedCustomerSummary");
			Boolean adminManager = grantedAuthorities.stream().anyMatch(a -> {
				return (a.getAuthority().contains(BFAGrandtedAuthority.ROLE_ADVISOR_MANAGER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_BUSINESS_USER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_COMPLIANCE_MANAGER));
			});
			getLogger().info("adminManager value" + adminManager);
			if (adminManager) {
				getLogger().info("logged in as admin, fetching Customer Summary");
				if (customerId != null && customerId > 0) {
					getLogger().info("getDetailedCustomerSummary Customer Id" + customerId);
					dto = accountsService.getDetailedCustomerSummary(customerId, 0);
				}

			} else {
				getLogger().info("non admin, fetching Customer Summary");
				bfaUser = getAuthUser(httpServletRequest);
				if (enquiryId != null && enquiryId > 0) {
					getLogger().info("getDetailedCustomerSummary for enquiry id : " + enquiryId + "for userid :" + bfaUser.getId());
					dto = accountsService.getDetailedCustomerSummary(bfaUser.getId(), enquiryId);
				} else {

					getLogger().info("getDetailedCustomerSummary userid" + bfaUser.getId());
					dto = accountsService.getDetailedCustomerSummary(bfaUser.getId(), 0);
				}
			}
			if (dto != null) {
				response = APIResponse.createSuccessResponse();
				response.setObjectList(dto);
			} else {
				response = APIResponse.createFailureResponse();
			}
		} catch (DatabaseAccessException err) {
			response = APIResponse.createFailureResponse();
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_FETCH_CUSTOMER_SUMMARY)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_FETCH_CUSTOMER_SUMMARY)
	@ApiOperation(value = "Returns the success response ", notes = "Save CRM data for the customer.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public APIResponse<AdminCustomerDetails> fetchCustomerSummary(
			@RequestParam(value = "customerId", required = true) Integer customerId,
			@RequestParam(value = "advisorId", required = true) Integer advisorId,

			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Reached fetchCustomerSummary");
		APIResponse<AdminCustomerDetails> response = null;
		AdminCustomerDetails dto = null;
		try {

			Collection<GrantedAuthority> grantedAuthorities = getAuthToken(httpServletRequest).getAuthorities();
			dto = accountsService.fetchIndividualCustomerDetails(customerId, advisorId);
			if (dto != null) {

				response = APIResponse.createSuccessResponse();
				response.setObjectList(dto);
			}
		} catch (DatabaseAccessException err) {
			response = APIResponse.createFailureResponse();
			response.setException(err);
			response.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			response.getResponseMessage().setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception e) {
			response = APIResponse.createFailureResponse();
			response.setException(e);
			response.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			response.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_FETCH_CUSTOMER_DETAILS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_FETCH_CUSTOMER_DETAILS)
	@ApiOperation(value = "Returns user profile summary", notes = "Returns user profile summary", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<List<AdminCustomerDetails>> fetchCustomerDetails(
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Calling fetchCustomerDetails");
		// To get email from principal object
		APIResponse<List<AdminCustomerDetails>> response = null;
		try {
			Integer adviserId = 1;
			getLogger(this.getClass()).info("fetchCustomerDetails adviserId" + adviserId);
			List<AdminCustomerDetails> dto = accountsService.getCustomerSummaryByAdvisor(adviserId);
			response = APIResponse.createSuccessResponse();
			response.setObjectList(dto);
		} catch (DatabaseAccessException err) {
			response = APIResponse.createFailureResponse();
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_CUSTOMER_SUMMARY_BY_ADVISOR)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_SUMMARY_BY_ADVISOR)
	@ApiOperation(value = "Returns user profile summary", notes = "Returns user profile summary", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody APIResponse<List<AdminCustomerDetails>> getCustomerSummaryByAdvisor(
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Calling getCustomerSummaryByAdvisor");
		// To get email from principal object
		APIResponse<List<AdminCustomerDetails>> response = null;
		try {
			Integer adviserId = 1;
			getLogger(this.getClass()).info("getCustomerSummaryByAdvisor adviserId" + adviserId);
			List<AdminCustomerDetails> dto = accountsService.getCustomerSummaryByAdvisor(adviserId);
			response = APIResponse.createSuccessResponse();
			response.setObjectList(dto);
		} catch (DatabaseAccessException err) {
			response = APIResponse.createFailureResponse();
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	/**
	 * Updates the customer id for the given enquiry. This API Also updates the
	 * selected products and calls the CRM for product registration.
	 * 
	 * @param updateProductEnquiryRequest
	 * @return
	 */
	@PostMapping(APIConstants.API_ACCOUNT_UPDATE_CUSTOMER_ENQUIRY)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_UPDATE_CUSTOMER_ENQUIRY)
	@ApiOperation(value = "Updates customer records and CRM ", notes = "Updates the selected products and customer id for the given enquiry", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList updateProductEnquiry(
			@RequestBody UpdateProductEnquiryRequest updateProductEnquiryRequest,HttpServletRequest httpServletRequest) {
		ResponseMessageList responseList = getDefaultMessageList();		
		try {
			Integer custId = -1;
			String customerRef = updateProductEnquiryRequest.getCustomerId();
			if (customerRef != null && !customerRef.isEmpty()) {
				String decrypted = utility.DecryptText(customerRef);
				getLogger().info("Printing the customer reference " + decrypted);
				custId = Integer.parseInt(decrypted);
			} else {
				custId = getCustomerId(httpServletRequest);
			}
			getLogger().info("Trying to update the customer id : " + custId + " Enquiry ID: "
					+ updateProductEnquiryRequest.getEnquiryId());
			Customer custObj = accountsService.updateCustomerdetails(updateProductEnquiryRequest.getEnquiryId(),
					custId.toString(), updateProductEnquiryRequest.getSelectedProducts());
			securityService.updateCRMPostCustomerCreation(custId.toString(),
					updateProductEnquiryRequest.getSelectedProducts(), updateProductEnquiryRequest.isNewCustomer(),
					updateProductEnquiryRequest.getEnquiryId());
			// ------------------------------------------------------------------------------------//
		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_CONTACT_US)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path(APIConstants.API_ACCOUNT_CONTACT_US)
	@ApiOperation(value = "Send Contact Us email", notes = "Send Contact Us email", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList sendContactUsEmail(@RequestBody Map<String, Object> contactUsEmailJson) {
		ResponseMessageList responseList = getDefaultMessageList();
		String toEmail = (String) contactUsEmailJson.get("toEmail");
		String subject = (String) contactUsEmailJson.get("subject");
		String body = (String) contactUsEmailJson.get("body");
		String custEmail = (String) contactUsEmailJson.get("custEmail");
		String custContactNo = (String) contactUsEmailJson.get("custContactNo");
		getLogger(this.getClass()).info("Printing the email !: " + toEmail.toString());
		try {
			if (null != toEmail && null != subject && null != body && null != custEmail && null != custContactNo) {
				accountsService.sendContactUsEmail(toEmail, subject, body, custEmail, custContactNo);
			} else {
				throw new AccountServiceException("Email Address or Subject or Body is null");
			}
		} catch (Exception err) {
			getLogger(this.getClass()).debug("Exception caught at sendContactUsEmail" + err);
			getLogger(this.getClass()).debug("Exception message caught at sendContactUsEmail" + err.getMessage());
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@GetMapping(APIConstants.GET_SESSION_ID)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path(APIConstants.GET_SESSION_ID)
	@ApiOperation(value = "Get session tracker id details", notes = "Get session tracker id details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList getSessionDetails(HttpServletRequest httpServletRequest) {
		ResponseMessageList responseList = getDefaultMessageList();
		String sessionId = httpServletRequest.getParameter("sessionId");
		getLogger(this.getClass()).info("Printing the session id " + sessionId);
		SessionDetails sessionDetails = securityService.getSessionDetailsBySessionId(sessionId);
		int sessionTrackerId = sessionDetails.getId();
		SessionTracker sessionTracker = new SessionTracker();
		sessionTracker.setSessionTrackerId(sessionTrackerId);
		ArrayList listObj = new ArrayList();
		listObj.add(sessionTracker);
		responseList.setObjectList(listObj);
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_UPDATE_ADDRESS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_UPDATE_ADDRESS)
	@ApiOperation(value = "Edit the profile", notes = "Edit user profile", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody APIResponse<Map<String, String>> updateCustomerAddress(
			@RequestBody UpdateCustomerAddressDTO updateCustomerAddress,
			@RequestParam(value = "customerId", required = true) String encryptedCustomerId,
			@RequestParam(value = "advisorId", required = true) Integer advisorId,
			HttpServletRequest httpServletRequest) {
		APIResponse<Map<String, String>> response = new APIResponse<>();
		Map<String, String> sessionDetails = new HashMap<>();
		String sessionId = null;
		Integer decryptedCustomerId = null;

		try {
			if (encryptedCustomerId != null) {
				decryptedCustomerId = Integer.parseInt(utility.DecryptText(encryptedCustomerId));
			}

			if (decryptedCustomerId != null && decryptedCustomerId > 0) {
				sessionId = accountsService.updateCustomerAddress(decryptedCustomerId, advisorId,
						updateCustomerAddress);
				if (sessionId != null && !sessionId.isEmpty()) {
					response = APIResponse.createSuccessResponse();
					sessionDetails.put("sessionDetails", sessionId);
					response.setObjectList(sessionDetails);
					response.getResponseMessage().setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
					response.getResponseMessage().setResponseDescription("Address updated Successfully");
				} else {
					response.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
					response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
					return response;
				}
			}
		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			response.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			response.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}
	@PostMapping(APIConstants.API_ACCOUNT_EDIT_PASSWORD)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_EDIT_PASSWORD)
	@ApiOperation(value = "Edit the profile", notes = "Edit user profile", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody ResponseMessageList editPassword(@RequestBody UpdatePasswordDTO newPasswordDetails,
			HttpServletRequest httpServletRequest) {
		ResponseMessageList responseList = getDefaultMessageList();

		Integer custId = getCustomerId(httpServletRequest);
		Customer customerDetails = accountsService.getDetailsByCustomerId(custId);
		try {

			boolean isPasswordUpdated = accountsService.editPassword(customerDetails, newPasswordDetails);

			if (isPasswordUpdated) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
				responseList.getResponseMessage().setResponseDescription("Password is updated Successfully");
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
				responseList.getResponseMessage()
				.setResponseDescription(ApplicationConstants.ERROR_IN_EXISTING_PASSWORD);
			}

		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_SAVE_CUSTOMER_DETAILS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_SAVE_CUSTOMER_DETAILS)
	@ApiOperation(value = "Saving Investment Account details", notes = "Saving Investment Account details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList saveCustomerDetails(@RequestBody CustomerDetailsDTO customerDetails,
			HttpServletRequest httpServletRequest) {
		ResponseMessageList responseList = getDefaultMessageList();
		List<Object> objectList = new ArrayList<>();
		BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
		Integer customerId = bfaUser.getId();
		// To get email from principal object
		if (customerId == null) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			return responseList;
		}
		try {
			if (customerDetails != null) {
				ServiceResponse<Map<String, String>> response = accountsService.saveCustomerDetails(customerDetails,
						customerId);
				objectList.add(response);
				responseList.setObjectList(objectList);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
				return responseList;
			}

		} catch (Exception ex) {
			getLogger().info("exception at /saveCustomerDetails" + ex);
			getLogger().info("exception message at /saveCustomerDetails" + ex.getMessage());
			responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
		}

		return responseList;
	}

	/**
	 * 
	 * @param nricFrontFile
	 * @param nricBackFile
	 * @param passportFile
	 * @param mailingAddressProof
	 * @param residentialAddressProof
	 * @param beneficiaryPassport
	 * @param supportingDocument
	 * @param details
	 * @return
	 */
	@PostMapping(APIConstants.API_ACCOUNT_SAVE_DOCUMENTS_V2)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_SAVE_DOCUMENTS_V2)
	@ApiOperation(value = "Save Investment details and files", notes = "Save Investment details and files", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList saveDocumentsV2(
			@RequestPart(name = "nricFront", required = false) MultipartFile nricFrontFile,
			@RequestPart(name = "nricBack", required = false) MultipartFile nricBackFile,
			@RequestPart(name = "passport", required = false) MultipartFile passportFile,
			@RequestPart(name = "mailingAddressProof", required = false) MultipartFile mailingAddressProof,
			@RequestPart(name = "residentialAddressProof", required = false) MultipartFile residentialAddressProof,
			@RequestPart(name = "beneficiaryPassport", required = false) MultipartFile beneficiaryPassport,
			@RequestPart(name = "supportingDocument", required = false) MultipartFile supportingDocument,
			@RequestParam(name = "form", required = false) String details, HttpServletRequest httpServletRequest) {
		getLogger().info("reached saveDocuments");
		ResponseMessageList responseList = getDefaultMessageList();
		List<Object> objectList = new ArrayList<>();
		BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
		Integer customerId = bfaUser.getId();
		// To get email from principal object
		if (customerId == null) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			return responseList;
		}
		try {
			boolean isSuccess = true;
			if (details == null && nricFrontFile == null && nricBackFile == null && passportFile == null
					&& mailingAddressProof == null && residentialAddressProof == null && beneficiaryPassport == null
					&& supportingDocument == null) {
				getLogger().debug("no details or files available");
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
				responseList.getResponseMessage()
				.setResponseDescription(ApplicationConstants.NO_INPUT_PARAMETERS_FOUND);
				return responseList;
			}
			getLogger().info("saving file document");
			if (details != null) {
				GsonBuilder gsonBuilder = new GsonBuilder();
				gsonBuilder.setDateFormat("dd-MM-yyyy");
				Gson gson = gsonBuilder.create();
				CustomerDetailsDTO accountDetails = gson.fromJson(details, CustomerDetailsDTO.class);
				ServiceResponse<Map<String, String>> response = accountsService.saveCustomerDetails(accountDetails,
						customerId);
				isSuccess = response.isSuccess();
				objectList.add(response);
			}
			int fileUploadedCount = 0;

			UploadingContent uploadingContent1 = new UploadingContent();
			uploadingContent1.setDocumentType(DocumentType.NRIC_FRONT);
			uploadingContent1.setMultiPartFile(nricFrontFile);

			UploadingContent uploadingContent2 = new UploadingContent();
			uploadingContent2.setDocumentType(DocumentType.NRIC_BACK);
			uploadingContent2.setMultiPartFile(nricBackFile);

			UploadingContent uploadingContent3 = new UploadingContent();
			uploadingContent3.setDocumentType(DocumentType.PASSPORT);
			uploadingContent3.setMultiPartFile(passportFile);

			UploadingContent uploadingContent4 = new UploadingContent();
			uploadingContent4.setDocumentType(DocumentType.MAILING_ADDRESS_PROOF);
			uploadingContent4.setMultiPartFile(mailingAddressProof);

			UploadingContent uploadingContent5 = new UploadingContent();
			uploadingContent5.setDocumentType(DocumentType.RESIDENTIAL_ADDRESS_PROOF);
			uploadingContent5.setMultiPartFile(residentialAddressProof);

			UploadingContent uploadingContent6 = new UploadingContent();
			uploadingContent6.setDocumentType(DocumentType.BENEFICIARY_OWNER_DOCUMENT);
			uploadingContent6.setMultiPartFile(beneficiaryPassport);

			UploadingContent uploadingContent7 = new UploadingContent();
			uploadingContent7.setDocumentType(DocumentType.SUPPORTING_DOCUMENT);
			uploadingContent7.setMultiPartFile(supportingDocument);

			List<UploadingContent> uploadingContentList = new ArrayList<>();
			if (null != nricFrontFile) {
				uploadingContentList.add(uploadingContent1);
			}
			if (null != nricBackFile) {
				uploadingContentList.add(uploadingContent2);
			}
			if (null != passportFile) {
				uploadingContentList.add(uploadingContent3);
			}
			if (null != mailingAddressProof) {
				uploadingContentList.add(uploadingContent4);
			}
			if (null != residentialAddressProof) {
				uploadingContentList.add(uploadingContent5);
			}
			if (null != beneficiaryPassport) {
				uploadingContentList.add(uploadingContent6);
			}
			if (null != supportingDocument) {
				uploadingContentList.add(uploadingContent7);
			}

			List aggregator = delegateHandler.saveDocument(customerId, uploadingContentList);
			Iterator<ServiceResponse<Map<String, String>>> iterator = aggregator.iterator();
			while (iterator.hasNext()) {
				ServiceResponse<Map<String, String>> serviceResponse = iterator.next();
				if (serviceResponse.isSuccess()) {
					fileUploadedCount = fileUploadedCount + 1;
				}
			}

			if (isSuccess) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
			}

			if (fileUploadedCount >= 1) {
				getLogger().info("calling updateInvestmentAccountStatus");
				investmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED);
			}

			responseList.setObjectList(objectList);
		} catch (Exception ex) {
			getLogger().debug("savedocuments final exception" + ex);
			getLogger().debug("savedocuments final exception message" + ex.getMessage());
			responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			responseList.setExceptionDetails(ex);
		}

		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_ADD_ADVISOR)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_ADD_ADVISOR)
	@ApiOperation(value = "Edit the profile", notes = "Edit user profile", response = ResponseMessageList.class)
	@ApiResponses(value = {

			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR) })
	public @ResponseBody APIResponse<Customer> addAdvisor(@RequestBody AddAdvisorRequestDTO addAdvisor) {
		APIResponse<Customer> response = null;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); // To get email from principal
		// object

		int decryptedCustomerId = Integer.parseInt(utility.DecryptText(addAdvisor.getCustomerId()));
		//		int customerId = addAdvisor.getCustomerId();
		int advisorId = addAdvisor.getAdvisorId();

		try {
			Customer customerDetails = accountsService.addAdvisor(decryptedCustomerId, advisorId);
			if (customerDetails != null && customerDetails.getAdvisorId() == advisorId) {
				response = APIResponse.createSuccessResponse();
				response.setObjectList(customerDetails);
			} else {
				response = APIResponse.createFailureResponse();

			}

		} catch (Exception err) {
			response = APIResponse.createFailureResponse();
			response.setException(err);
			response.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			response.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_VERIFY_AML)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_VERIFY_AML)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody Object verifyAML(HttpServletRequest httpServletRequest) {
		getLogger().info("api/verifyAML");
		APIResponse<AMLVerificationServiceResponse> apiResponse = APIResponse.createSuccessResponse();
		try {
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			Integer customerId = bfaUser.getId();
			// To get email from principal object
			if (amlService != null && customerId != null) {
				AMLVerificationServiceResponse amlResponse = amlService.verify(customerId);
				if(amlResponse != null && amlResponse.getStatus() != null) {
					apiResponse = APIResponse.createSuccessResponse();
					apiResponse.setObjectList(amlResponse);
				} else {
					apiResponse = APIResponse.createFailureResponse();
				}
			}
		} catch (Exception ex) {
			apiResponse = APIResponse.createFailureResponse();
			apiResponse.setException(ex);
			getLogger().debug("verify aml exception" + ex);
			getLogger().debug("verify aml exception message" + ex.getMessage());
		}
		return apiResponse;
	}

	@GetMapping(APIConstants.API_ACCOUNT_CLEAR_AML)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CLEAR_AML)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody Object clearAML(@RequestParam(value = "customerId", required = false) Integer customerId,
			HttpServletRequest httpServletRequest) {

		getLogger().info("api/clearAML");
		APIResponse<AMLVerificationServiceResponse> apiResponse = APIResponse.createSuccessResponse();
		try {
			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();
			Boolean adminManager = grantedAuthorities.stream().anyMatch(a -> {
				return (a.getAuthority().contains(BFAGrandtedAuthority.ROLE_ADVISOR_MANAGER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_BUSINESS_USER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_COMPLIANCE_MANAGER));
			});

			if (!adminManager) {
				BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
				customerId = bfaUser.getId();
			}

			if (amlService != null && customerId != null) {
				AMLVerificationServiceResponse amlResponse = amlService.clearVerification(customerId);
				amlResponse.setStatus(AMLVerificationStatus.CLEARED);
				apiResponse.setObjectList(amlResponse);
			} else {
				apiResponse = APIResponse.createFailureResponse();
			}

		} catch (Exception ex) {
			apiResponse = APIResponse.createFailureResponse();
			apiResponse.setException(ex);
			getLogger().debug("exception at /clearAML" + ex);
			getLogger().debug("exception message at /clearAML" + ex.getMessage());
		}
		return apiResponse;
	}

	@GetMapping(APIConstants.API_ACCOUNT_CUSTOMER_BANKS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_BANKS)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<List<CustomerBankDetail>> getCustomerBanks(HttpServletRequest httpServletRequest) {
		
		APIResponse<List<CustomerBankDetail>> response = null;
		Integer customerId = 0;
		
		try {
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			if (bfaUser != null) {
				customerId = bfaUser.getId();
				// To get email from principal object
				List<CustomerBankDetail> banks = accountsService.getCustomerBankDetails(customerId);
				String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
				boolean isTwoFactorAuth = securityService.authenticate2FA(sessionId);
				if (!isTwoFactorAuth && null != banks) {
					for (CustomerBankDetail bank : banks) {
						String accountNumber = bank.getAccountNumber();
						bank.setAccountNumber(PublicUtility.maskBankAccountNumber(accountNumber));
					}
				}
				response = APIResponse.createSuccessResponse();
				response.setObjectList(banks);
			} else {
				response = APIResponse.createFailureResponse();
				response.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			}
		} catch (Exception ex) {
			response = APIResponse.createFailureResponse();
			getLogger().error("exception at " + APIConstants.API_ACCOUNT_CUSTOMER_BANKS + ". Customer ID : [" + customerId + "]" ,  ex);
		}
		return response;
	}

	@PostMapping(APIConstants.API_ACCOUNT_CUSTOMER_BANK)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_BANK)
	@ApiOperation(value = "Saves Customer Bank Info", notes = "Saves Customer Bank Info", response = APIResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<CustomerBankDetail> saveCustomerBank(@RequestBody CustomerBankDetail bank,
			HttpServletRequest httpServletRequest) {
		
		APIResponse<CustomerBankDetail> response = null;
		Integer customerId = null;
		
		try {
			// To check 2FA Authentication
			String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
			ResponseMessageList responseMessageList = get2FAValidationMessage(sessionId);
			if(null != responseMessageList && ErrorCodes.TWO_FACTOR_AUTH_SUCCESS != responseMessageList.getResponseMessage().getResponseCode()) {
				getLogger().error("Save Two Factor Authentication Failed:" + responseMessageList.getResponseMessage().getResponseDescription());
				response = APIResponse.createFailureResponse();
				response.setResponseMessage(responseMessageList.getResponseMessage());
				return response;
			}
			// if 2FA is success and valid
			customerId=0;
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			if (bfaUser != null) {
				customerId = bfaUser.getId();
			}
			if (null != bank && null != customerId && customerId != 0) {
				bank.setCustomerId(customerId);
				bank = accountsService.saveCustomerBankDetail(bank);
				// if save is not complete
				if (null == bank) {
					response = APIResponse.createFailureResponse();
					response.getResponseMessage().setResponseCode(ErrorCodes.IFAST_DOWN);
					response.getResponseMessage().setResponseDescription(ApplicationConstants.IFAST_SERVICE_DOWN);
				} else {
					response = APIResponse.createSuccessResponse();
					response.setObjectList(bank);
				}
			} else {
				response = APIResponse.createFailureResponse();
				response.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			}
		} catch (Exception ex) {
			response = APIResponse.createFailureResponse();
			getLogger().error("exception at " + APIConstants.API_ACCOUNT_CUSTOMER_BANK + ". Customer ID : [" + customerId + "]" ,  ex);
		}
		return response;
	}

	//Saving the Customer SRS Account Bank account details


	@GetMapping(APIConstants.API_ACCOUNT_GET_SRSBANK)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_GET_SRSBANK)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<CustomerSrsAccount> fetchCustomerSrsBankDetails(HttpServletRequest httpServletRequest) {

		return getSrsBankDetails(httpServletRequest, false);
	}
	
	@GetMapping(APIConstants.API_ACCOUNT_PROFILE_GET_SRSBANK)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_PROFILE_GET_SRSBANK)
	@ApiOperation(value = "Get SRS banks details through customer profile", notes = "Get SRS banks details through customer profile", response = APIResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<CustomerSrsAccount> fetchCustomerProfileSrsBankDetails(HttpServletRequest httpServletRequest) {

		return getSrsBankDetails(httpServletRequest, true);
	}

	@PostMapping(APIConstants.API_ACCOUNT_CUSTOMER_SRS_BANK)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_SRS_BANK)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList saveCustomerSrsbankDetails(
			@PathVariable("customerPortfolioId") Integer customerPortfolioId,
			@RequestBody CustomerSrsAccountDTO srsDetailsRequest, HttpServletRequest httpServletRequest) {

		return saveSrsBankDetails(httpServletRequest, srsDetailsRequest, customerPortfolioId, false);
	}
	
	@PostMapping(APIConstants.API_ACCOUNT_PROFILE_SAVE_SRS_BANK)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_PROFILE_SAVE_SRS_BANK)
	@ApiOperation(value = "Save SRS bank details through edit profile", notes = "Save SRS bank details through edit profile", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList saveCustomerProfileSrsbankDetails(
			@PathVariable("customerPortfolioId") Integer customerPortfolioId,
			@RequestBody CustomerSrsAccountDTO srsDetailsRequest, HttpServletRequest httpServletRequest) {
		
		return saveSrsBankDetails(httpServletRequest, srsDetailsRequest, customerPortfolioId, true);
	}
	
	

	//getting the customer  srs bank details api

	@GetMapping(APIConstants.API_ACCOUNT_CUSTOMER_ADDRESS)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_ADDRESS)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<Map<String, Address>> customerAddress(HttpServletRequest httpServletRequest) {
		APIResponse<Map<String, Address>> response = null;
		try {
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			Integer customerId = bfaUser.getId();
			response = APIResponse.createSuccessResponse();
			Map<String, Address> addresses = accountsService.getCustomerAddresses(customerId);
			response.setObjectList(addresses);
		} catch (Exception ex) {
			response = APIResponse.createFailureResponse();
			getLogger().debug("exception at customer/address" + ex);
			getLogger().debug("exception message at customer/address" + ex.getMessage());
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_CUSTOMER_PROFILE)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMER_PROFILE)
	@ApiOperation(value = "Get User Details", notes = "Get USer Details", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<CustomerProfileDetails> customerProfileDetails(HttpServletRequest httpServletRequest) {
		APIResponse<CustomerProfileDetails> response = null;
		try {
			String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
			TwoFactorAuthValidation twoFactorAuthValidation = securityService.authenticate2FAWithReturnCode(sessionId);
			if(twoFactorAuthValidation.getReturnCode() == ErrorCodes.INVALID_SESSION_ID){
				response = APIResponse.createFailureResponse();
				response.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_SESSION);
				return response;
			}
			Boolean is2FactorAuthenticated = twoFactorAuthValidation.getIsValidated();	
			getLogger().info("Trying to get the customer profile details [is2FAuhenticated]:" + is2FactorAuthenticated);
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			Integer customerId = bfaUser.getId();
			getLogger().info("Printing the [customer id]:" + customerId);
			CustomerProfileDetails dto = accountsService.getCustomerDetailsById(customerId);
			if(!is2FactorAuthenticated){
				maskCustomerDetails(dto);
			}
			getLogger().info("Printing the customer profile details: " + dto.toString());
			response = APIResponse.createSuccessResponse();
			response.setObjectList(dto);
		} catch (Exception ex) {			
			response = APIResponse.createFailureResponse();
			response.setException(ex);
			getLogger().info("exception at customer/customerProfile" + ex);
			getLogger().info("exception message at customer/customerProfile" + ex.getMessage());
		}
		return response;
	}

	@GetMapping(APIConstants.API_ACCOUNT_TEST_OPTIONS_SEARCH)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_TEST_OPTIONS_SEARCH)
	@ApiOperation(value = "User sign up", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody OptionsSearchResultDTO testOptionsSearch() {
		OptionsSearchFilterDTO filter = new OptionsSearchFilterDTO();
		filter.setCountryCode("SG");
		filter.setNationalityCode("SG");
		filter.setSsic("3209");
		filter.setSsoc("11150");
		filter.setHouseHoldRange("$200,001 to $300,000");
		return investServiceObj.searchOptions(filter);
	}

	@PostMapping(APIConstants.API_ACCOUNT_CUSTOMERS_SEARCH)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMERS_SEARCH)
	@ApiOperation(value = "Returns the success response ", notes = "Save CRM data for the customer.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public APIResponse<List<CustomerOverview>> searchCustomers(@RequestBody AdminSearchRequestDTO searchRequest,
			HttpServletRequest httpServletRequest) {
		getLogger(this.getClass()).info("Reached customers/search");
		APIResponse<List<CustomerOverview>> response = null;
		try {
			List<CustomerOverview> dto = null;
			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();
			String advisorID = String.valueOf(getCustomerId(httpServletRequest));
			Integer adviserId = Integer.valueOf(advisorID);

			if (grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_ADVISOR_MANAGER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_BUSINESS_USER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_COMPLIANCE_MANAGER)) {

				dto = accountService.findCustomers(searchRequest);

			} else {

				AdminSearchRequestDTO searchRequestForAdvisor = new AdminSearchRequestDTO();
				searchRequestForAdvisor.setAdvisorId(adviserId);
				searchRequestForAdvisor.setCustomerName(searchRequest.getCustomerName());
				searchRequestForAdvisor.setEmailId(searchRequest.getEmailId());
				searchRequestForAdvisor.setMobileNumber(searchRequest.getMobileNumber());
				searchRequestForAdvisor.setiFastRefNo(searchRequest.getiFastRefNo());

				dto = accountService.findCustomers(searchRequestForAdvisor);

			}

			response = APIResponse.createSuccessResponse();
			response.setObjectList(dto);
		} catch (DatabaseAccessException err) {
			getLogger().debug("Exception block reached searchCustomers" + err);
			getLogger().debug("Exception message block reached searchCustomers" + err.getMessage());
			if (response != null) {
				response.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
				response.getResponseMessage()
				.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
				getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
			}
		} catch (Exception e) {
			getLogger().debug("Exception block reached searchCustomers" + e);
			getLogger().debug("Exception message block reached searchCustomers" + e);
			if (response != null) {
				response.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
				getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
			}
		}
		return response;
	}

	@RequestMapping(value = APIConstants.API_ACCOUNT_CUSTOMERS_Summary, method = RequestMethod.GET)
	@Produces({ "application/xml", "application/json" })
	@GET
	@Path(APIConstants.API_ACCOUNT_CUSTOMERS_Summary)
	@ApiOperation(value = "Returns the success response ", notes = "Save CRM data for the customer.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE), })
	public APIResponse<AdminCustomerSummary> fetchCustomerSummary(
			@RequestParam(value = "customerId", required = true) Integer customerId,
			HttpServletRequest httpServletRequest) {

		APIResponse<AdminCustomerSummary> response = null;
		AdminCustomerSummary dto = null;
		try {

			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();
			String advisorID = String.valueOf(getCustomerId(httpServletRequest));
			Integer adviserId = Integer.valueOf(advisorID);
			getLogger(this.getClass()).info("Reached customerSummary customerId" + customerId);
			if (grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_ADVISOR_MANAGER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_BUSINESS_USER)
					|| grantedAuthorities.contains(BFAGrandtedAuthority.ROLE_COMPLIANCE_MANAGER)) {
				adviserId = 0;

			}

			dto = accountService.fetchCustomerSummary(customerId, adviserId);
			if (dto != null) {

				response = APIResponse.createSuccessResponse();
				response.setObjectList(dto);
			}
		} catch (DatabaseAccessException err) {
			getLogger().debug("Exception block reached customerSummary" + err);
			getLogger().debug("Exception message block reached customerSummary" + err.getMessage());
			if (response != null) {
				response.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
				response.getResponseMessage()
				.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
				getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
			}
		} catch (Exception e) {
			response = APIResponse.createFailureResponse();
			response.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			response.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, e);
		}
		return response;
	}

	/* BFA-1343 */

	@PostMapping(APIConstants.API_ACCOUNT_CUSTOMERS_SIGNUP_V2)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_CUSTOMERS_SIGNUP_V2)
	@ApiOperation(value = "User sign up version 2", notes = "user sign up", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList signupv2(
			@RequestBody CustomerCreationPostRequestV2 customerCreationPostRequest, HttpServletRequest servletRequest) {
		getLogger(this.getClass()).info("Working the signup request version 2");
		ResponseMessageList responseList = getDefaultMessageList();
		String sessionId = customerCreationPostRequest.getSessionId();
		boolean skipCaptcha = canSkipCaptcha();
		getLogger().info(skipCaptcha ? "Captcha is skipped for this signup request": "Captcha is not skipped for this signup request");
		if (!skipCaptcha) {
			String captcha = customerCreationPostRequest.getCaptcha();
			boolean isValidCaptcha = securityService.isValidCaptcha(sessionId, captcha);
			if (!isValidCaptcha) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_CAPTCHA);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_CAPTCHA);
				return responseList;
			}
		} else {
			getLogger(this.getClass()).info("Captcha validation is not done in Dev and UAT environments.");
		}
		AuthenticationErrorResponse authenticationErrorResponse = accountsService
				.validateUserV2(customerCreationPostRequest);
		String errorResponse = authenticationErrorResponse.getErrorMessage();
		if (!errorResponse.equals(ApplicationConstants.VALIDATION_SUCCESS)) {
			getLogger(this.getClass()).error("Validation failed " + errorResponse);
			if (errorResponse.equals(ApplicationConstants.ACCOUNT_ALREADY_EXISTS)) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.ACCOUNT_ALREADY_EXISTS);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			}
			responseList.getResponseMessage().setResponseDescription(errorResponse);
			ArrayList authenticationErrorResponseList = new ArrayList();
			authenticationErrorResponseList.add(authenticationErrorResponse);
			responseList.setObjectList(authenticationErrorResponseList);
			return responseList;
		}
		try {
			CustomerCreationResponseV2 customerCreationResponse = new CustomerCreationResponseV2();
			getLogger(this.getClass()).info("Calling get Customer list");
			CustomerAndPrevilegeV2 custAndPrevilege = accountsService.signupV2(customerCreationPostRequest);
			Customer custObj = custAndPrevilege.getCustomer();
			getLogger(this.getClass()).info("added Customer list");
			Integer customerId = custObj.getId();
			String customerRef = accountsService.encryptCustomerId(customerId.toString());
			customerCreationResponse.setCustomerRef(customerRef);
			List objectList = new ArrayList();
			objectList.add(customerCreationResponse);
			responseList.setObjectList(objectList);
			delegateHandler.handlePostSignupProcess(customerCreationPostRequest, customerId);

		} catch (DatabaseAccessException err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
			responseList.getResponseMessage()
			.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
			getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		if (authenticationErrorResponse.isAccountExists()) {
			getLogger().info("An account already exists : kindly activate it !");
			responseList.getResponseMessage().setResponseCode(ErrorCodes.ACCOUNT_ALREADY_EXISTS);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.ACCOUNT_ALREADY_EXISTS);
		}
		return responseList;
	}

	private boolean canSkipCaptcha() {
		String canSkipCaptcha = environment.getProperty("disable.captcha.while.creating.account","false");
		return Boolean.valueOf(canSkipCaptcha);
	}

	/**
	 * Post signup the selected products of the user is persisted in the database in
	 * the insurance journey. This API persists the user data and also informs CRM
	 * about the products opted by the user in the insurance journey.
	 * 
	 * @param saveSelectedProductsRequest
	 * @param requestObj
	 * @return
	 */

	@RequestMapping(value = APIConstants.UPDATE_SELECTED_PRODUCTS, method = RequestMethod.POST)
	@POST
	@Path(APIConstants.UPDATE_SELECTED_PRODUCTS)
	@ApiOperation(value = "updates the selected products for the customer.", notes = "Updates the selected products for the customer.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList updateSelectedProducts(
			@RequestBody SaveSelectedProductsRequest saveSelectedProductsRequest, HttpServletRequest requestObj) {
		getLogger(this.getClass()).info("Updating the selected products of the user.");
		getLogger(this.getClass()).info("Printing the thread name " + Thread.currentThread().getName());
		boolean isNewCustomer = saveSelectedProductsRequest.getIsNewCustomer();
		securityService.updateCRMPostDuringSignupV2(saveSelectedProductsRequest, isNewCustomer);
		return getDefaultMessageList();
	}

	private static final String API_GET_TRACKER_STATUS = "/api/getTrackStatus";
	private static final String API_SET_TRACKER_STATUS = "/api/setTrackStatus";

	/**
	 * To Retrieve the status of the SRS and Multi-Portfolio Popup
	 * 
	 * @param Integer customerId
	 * @param requestObj
	 * @return
	 */
	@RequestMapping(value = API_GET_TRACKER_STATUS, method = RequestMethod.POST)
	@POST
	@Produces({ "application/xml", "application/json" })
	@Path(API_GET_TRACKER_STATUS)
	@ApiOperation(value = "retrieving the different status of the trackers", notes = "Retrieving the status of the trackers based on customer id.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	private @ResponseBody APIResponse<CustomerPreference> getSrsPopupStatus(@RequestBody CustomerTrackerRequest customer, HttpServletRequest requestObj) {
		APIResponse<CustomerPreference> response = null;
		try {
			CustomerPreference dto = accountsService.getTrackStatus(customer.getCustomerId(), customer.getTrackCode());
			response = APIResponse.createSuccessResponse();
			response.setObjectList(dto);
		} catch (DatabaseAccessException err) {
			getLogger().debug("Exception block reached customerSrsPopStatus" + err);
			getLogger().debug("Exception message block reached customerSrsPopStatus" + err.getMessage());
			if (response != null) {
				response.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
				response.getResponseMessage()
				.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
				getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
			}
		} catch (Exception err) {
			response.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			response.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return response;
	}

	/**
	 * To Retrieve the status of the SRS Popup
	 * 
	 * @param Integer customerId
	 * @param requestObj
	 * @return
	 */
	@RequestMapping(value = API_SET_TRACKER_STATUS, method = RequestMethod.POST)
	@POST
	@Produces({ "application/xml", "application/json" })
	@Path(API_SET_TRACKER_STATUS)
	@ApiOperation(value = "seting the status of the srs popup.", notes = "setting the status of the srs pop based on customer id.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	private @ResponseBody ResponseMessageList setSrsPopupStatus(@RequestBody CustomerTrackerRequest customer, HttpServletRequest requestObj) {
		ResponseMessageList responseList = getDefaultMessageList();
		try {
			Integer customerId = getCustomerId(requestObj);
			customerId = customer.getCustomerId();
			ServiceResponse<Boolean> setTrackStatusResponse = accountsService.setTrackStatus(customerId, customer.getCheck(), customer.getTrackCode());
			getLogger().info("Final Track Status Response: " + setTrackStatusResponse.getResponse());
			if (!setTrackStatusResponse.getResponse()) {
				if (setTrackStatusResponse.getErrorInfo().containsKey("error")) {
					responseList.getResponseMessage().setResponseCode(5000);
					responseList.getResponseMessage()
					.setResponseDescription(setTrackStatusResponse.getErrorInfo().get("error").toString());
				}
			}
			if (setTrackStatusResponse.getResponse()) {
				responseList.getResponseMessage().setResponseCode(6000);
				responseList.getResponseMessage().setResponseDescription("Tracker Status updated successfully!");
			}
		} catch (DatabaseAccessException err) {
			getLogger().debug("Exception block reached customerTrackerStatus" + err);
			getLogger().debug("Exception message block reached customerTrackerStatus" + err.getMessage());
			if (responseList != null) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
				responseList.getResponseMessage()
				.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
				getLogger(this.getClass()).error(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE, err);
			}
		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}



	/**
	 * This is the controller main method which takes care of update mobile number
	 * service.
	 * 
	 * @param updateMobileNumberRequest - UpdateMobileNumberRequest.
	 * @return responseList - ResponseMessageList.
	 */
	@RequestMapping(value = APIConstants.API_ACCOUNT_CUSTOMERS_UPDATE_MOBILE_NO, method = RequestMethod.POST)
	@POST
	@Path(APIConstants.API_ACCOUNT_CUSTOMERS_UPDATE_MOBILE_NO)
	@ApiOperation(value = "Update Mobile Number.", notes = "Update Mobile Number by customer reference.", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.INTERNAL_SERVER_ERROR),
			@ApiResponse(code = ErrorCodes.INVALID_INPUT_FIELD, message = ApplicationConstants.INVALID_INPUT) })
	public @ResponseBody ResponseMessageList updateMobileNumberByCustomerId(
			@RequestBody UpdateMobileNumberRequest updateMobileNumberRequest) {
		ResponseMessageList responseList = getDefaultMessageList();
		// Validate basic input.
		if (updateMobileNumberRequest != null && (StringUtils.isBlank(updateMobileNumberRequest.getCustomerRef())
				|| StringUtils.isBlank(updateMobileNumberRequest.getMobileNumber()))) {
			responseList.getResponseMessage().setResponseCode(5000);
			responseList.getResponseMessage().setResponseDescription("Either customer Id (or) Mobile number is blank.");
			return responseList;
		}
		try {
			getLogger(this.getClass()).info("Updating mobile number for a  user by using their customer Id.");
			getLogger(this.getClass()).info("Printing the thread name " + Thread.currentThread().getName());
			ServiceResponse<Boolean> updateMobileNumberResponse = accountService
					.updateMobileNumber(updateMobileNumberRequest);
			if (!updateMobileNumberResponse.getResponse()) {
				if (updateMobileNumberResponse.getErrorInfo().containsKey("error")) {
					responseList.getResponseMessage().setResponseCode(5000);
					responseList.getResponseMessage()
					.setResponseDescription(updateMobileNumberResponse.getErrorInfo().get("error").toString());
				}
			}
			UpdateMobileNumberResponse updateMobileNumberResponseObj = new UpdateMobileNumberResponse();
			if (updateMobileNumberResponse.getResponse()) {
				responseList.getResponseMessage().setResponseCode(6000);
				responseList.getResponseMessage().setResponseDescription("Mobile number updated successfully!");
				// When mobile number updated successfully
				if (updateMobileNumberResponse.getErrorInfo().containsKey("mobileupdatestatus")) {
					String customerRef = updateMobileNumberResponse.getResponseInfo().get("customerRef").toString();
					updateMobileNumberResponseObj.setResponseDescription("Mobile number updated successfully!");
					updateMobileNumberResponseObj.setResponseCode(200);
					updateMobileNumberResponseObj.setCustomerRef(customerRef);
					updateMobileNumberResponseObj.setUpdated(true);
					List<Object> objectList = new ArrayList<>();
					objectList.add(updateMobileNumberResponseObj);
					responseList.setObjectList(objectList);
				}

			}

		} catch (Exception err) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			getLogger(this.getClass()).error(ApplicationConstants.INTERNAL_SERVER_ERROR, err);
		}
		return responseList;
	}

	@PostMapping(APIConstants.API_ACCOUNT_SAVE_DOCUMENTS_ADMIN)
	@Produces({ "application/xml", "application/json" })
	@Path(APIConstants.API_ACCOUNT_SAVE_DOCUMENTS_ADMIN)
	@ApiOperation(value = "Save Investment details and files from Admin", notes = "Save Investment details and files from Admin", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody APIResponse<Boolean> saveDocumentsV2FromAdmin(
			@RequestPart(name = "nricFront", required = false) MultipartFile nricFrontFile,
			@RequestPart(name = "nricBack", required = false) MultipartFile nricBackFile,
			@RequestPart(name = "passport", required = false) MultipartFile passportFile,
			@RequestPart(name = "mailingAddressProof", required = false) MultipartFile mailingAddressProof,
			@RequestPart(name = "residentialAddressProof", required = false) MultipartFile residentialAddressProof,
			@RequestPart(name = "beneficiaryPassport", required = false) MultipartFile beneficiaryPassport,
			@RequestPart(name = "supportingDocument", required = false) MultipartFile supportingDocument,
			@RequestParam(name = "form", required = false) String details, 
			@RequestParam(name = "customerId", required = true) String encryptedCustomerId,
			HttpServletRequest httpServletRequest) {
		getLogger().info("reached saveDocumentsV2FromAdmin");
		Integer decryptedCustomerId = null;
		APIResponse<Boolean> response = null; 
		try {

			JWTAuthToken authToken = getAuthToken(httpServletRequest);
			Collection<GrantedAuthority> grantedAuthorities = authToken.getAuthorities();
			Boolean isAllowed = grantedAuthorities.stream().anyMatch(a -> {
				return (a.getAuthority().contains(BFAGrandtedAuthority.ROLE_CLIENT_SERVICE_MANAGER)
						|| a.getAuthority().contains(BFAGrandtedAuthority.ROLE_COMPLIANCE_MANAGER));
			});
			if(Boolean.TRUE.equals(isAllowed)&& encryptedCustomerId != null) {
				decryptedCustomerId = Integer.parseInt(utility.DecryptText(encryptedCustomerId));

			}
			if (decryptedCustomerId != null && decryptedCustomerId > 0) {
				boolean isSuccess = true;
				if (details == null && nricFrontFile == null && nricBackFile == null && passportFile == null
						&& mailingAddressProof == null && residentialAddressProof == null && beneficiaryPassport == null
						&& supportingDocument == null) {
					getLogger().debug("no details or files available");
					response = APIResponse.createFailureResponse();
					response.setObjectList(false);
					return response;
				}
				getLogger().info("saving file document");
				if (details != null) {
					GsonBuilder gsonBuilder = new GsonBuilder();
					gsonBuilder.setDateFormat("dd-MM-yyyy");
					Gson gson = gsonBuilder.create();
					CustomerDetailsDTO accountDetails = gson.fromJson(details, CustomerDetailsDTO.class);
					ServiceResponse<Map<String, String>> serviceResponse = accountsService.saveCustomerDetails(accountDetails,
							decryptedCustomerId);
					isSuccess = serviceResponse.isSuccess();
				}
				int fileUploadedCount = 0;

				UploadingContent uploadingContent1 = new UploadingContent();
				uploadingContent1.setDocumentType(DocumentType.NRIC_FRONT);
				uploadingContent1.setMultiPartFile(nricFrontFile);

				UploadingContent uploadingContent2 = new UploadingContent();
				uploadingContent2.setDocumentType(DocumentType.NRIC_BACK);
				uploadingContent2.setMultiPartFile(nricBackFile);

				UploadingContent uploadingContent3 = new UploadingContent();
				uploadingContent3.setDocumentType(DocumentType.PASSPORT);
				uploadingContent3.setMultiPartFile(passportFile);

				UploadingContent uploadingContent4 = new UploadingContent();
				uploadingContent4.setDocumentType(DocumentType.MAILING_ADDRESS_PROOF);
				uploadingContent4.setMultiPartFile(mailingAddressProof);

				UploadingContent uploadingContent5 = new UploadingContent();
				uploadingContent5.setDocumentType(DocumentType.RESIDENTIAL_ADDRESS_PROOF);
				uploadingContent5.setMultiPartFile(residentialAddressProof);

				UploadingContent uploadingContent6 = new UploadingContent();
				uploadingContent6.setDocumentType(DocumentType.BENEFICIARY_OWNER_DOCUMENT);
				uploadingContent6.setMultiPartFile(beneficiaryPassport);

				UploadingContent uploadingContent7 = new UploadingContent();
				uploadingContent7.setDocumentType(DocumentType.SUPPORTING_DOCUMENT);
				uploadingContent7.setMultiPartFile(supportingDocument);

				List<UploadingContent> uploadingContentList = new ArrayList<>();
				if (null != nricFrontFile) {
					uploadingContentList.add(uploadingContent1);
				}
				if (null != nricBackFile) {
					uploadingContentList.add(uploadingContent2);
				}
				if (null != passportFile) {
					uploadingContentList.add(uploadingContent3);
				}
				if (null != mailingAddressProof) {
					uploadingContentList.add(uploadingContent4);
				}
				if (null != residentialAddressProof) {
					uploadingContentList.add(uploadingContent5);
				}
				if (null != beneficiaryPassport) {
					uploadingContentList.add(uploadingContent6);
				}
				if (null != supportingDocument) {
					uploadingContentList.add(uploadingContent7);
				}

				List aggregator = delegateHandler.saveDocument(decryptedCustomerId, uploadingContentList);
				Iterator<ServiceResponse<Map<String, String>>> iterator = aggregator.iterator();
				while (iterator.hasNext()) {
					ServiceResponse<Map<String, String>> serviceResponse = iterator.next();
					if (serviceResponse.isSuccess()) {
						fileUploadedCount = fileUploadedCount + 1;
					}
				}

				if (isSuccess) {
					response = APIResponse.createSuccessResponse();
					response.setObjectList(true);
				} else {
					response = APIResponse.createFailureResponse();
					response.setObjectList(false);
				}

			}
		} catch (Exception ex) {
			getLogger().debug("savedocuments final exception" + ex);
			getLogger().debug("savedocuments final exception message" + ex.getMessage());
			response = APIResponse.createFailureResponse();
			response.setObjectList(false);
			return response;
		}

		return response;
	}
	
	/**
	 * Retrieves SRS Bank Details based on http request, user details and if 2FA required or not
	 * @param httpServletRequest
	 * @param bfaUser
	 * @param twoFaRequired
	 * @return
	 */
	private APIResponse<CustomerSrsAccount> getSrsBankDetails(HttpServletRequest httpServletRequest, boolean twoFaRequired) {
		
		APIResponse<CustomerSrsAccount> response = null;
		Integer customerId = null;
		
		try {
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			if (null != bfaUser && bfaUser.getId() != 0) {
				customerId = bfaUser.getId();				
				CustomerSrsAccount srsBankData = accountsService.getCustomerSrsBankDetails(customerId);
				// Check for 2FA auth, if not authenticated, mask bank account numbers				
				if (twoFaRequired) {
					String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
					boolean isTwoFactorAuth = securityService.authenticate2FA(sessionId);
					if (!isTwoFactorAuth && null != srsBankData) {
						String accountNumber = srsBankData.getAccountNumber();
						srsBankData.setAccountNumber(PublicUtility.maskBankAccountNumber(accountNumber));
					}
				}
				response = APIResponse.createSuccessResponse();
				response.setObjectList(srsBankData);
			} else {
				response = APIResponse.createFailureResponse();
				response.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
				response.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);

			}
		} catch (Exception ex) {
			response = APIResponse.createFailureResponse();
			getLogger().error("exception at getSrsBankDetails. Customer ID : [" + customerId + "]" ,  ex);
		}
		
		return response;
		
	}
	
	/**
	 * Saves SRS Bank Details based on http request, srs request details, customer portfolio ID and if 2FA required or not
	 * @param httpServletRequest
	 * @param srsDetailsRequest
	 * @param customerPortfolioId
	 * @param twoFaRequired
	 * @return
	 */
	private ResponseMessageList saveSrsBankDetails(HttpServletRequest httpServletRequest, CustomerSrsAccountDTO srsDetailsRequest, Integer customerPortfolioId, boolean twoFaRequired) {

		ResponseMessageList responseList = getDefaultMessageList();
		List<Object> objectList = new ArrayList<Object>();
		Integer customerId = 0;
		
		try {
			if (twoFaRequired) {
				// To check 2FA Authentication
				String sessionId = httpServletRequest.getHeader(ApplicationConstants.SESSION_ID);
				ResponseMessageList responseMessageList = get2FAValidationMessage(sessionId);
				if(null != responseMessageList && ErrorCodes.TWO_FACTOR_AUTH_SUCCESS != responseMessageList.getResponseMessage().getResponseCode()) {
					getLogger().error("Two Factor Authentication Failed:" + responseMessageList.getResponseMessage().getResponseDescription());
					return responseMessageList;
				}
			}
			
			// if 2FA is success and valid or 2FA not required
			BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
			if (bfaUser != null) {
				customerId = bfaUser.getId();
			}
			
			if (srsDetailsRequest != null && customerPortfolioId != null && customerPortfolioId != 0
					&& customerId != 0) {
				ServiceResponse<Boolean> saveCustomerSrsBankDetail = accountService.saveCustomerSrsBankDetail(customerPortfolioId, srsDetailsRequest, customerId);
				objectList.add(saveCustomerSrsBankDetail);
				responseList.setObjectList(objectList);

			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
				responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			}
		} catch (Exception ex) {
			getLogger().error("exception at saveSrsBankDetails - Customer ID :[" + customerId + "]", ex);			
			responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
		}
		
		return responseList;
	}
}

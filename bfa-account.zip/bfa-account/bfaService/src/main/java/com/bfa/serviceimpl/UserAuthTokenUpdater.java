/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.Date;
import java.util.List;

import com.bfa.application.core.CustomerIssuedToken;
import com.bfa.util.ApplicationConstants;

/**
 * @author pradheep.p
 *
 */
public class UserAuthTokenUpdater extends DefaultServiceImpl implements Runnable {

	private String token;

	private Integer customerId;

	@Override
	public void run() {
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			getLogger().error("InterruptedException while run the thread: " + e);
			// Restore interrupted state...
			Thread.currentThread().interrupt();   // Sonar: Either re-interrupt this method or rethrow the "InterruptedException
		}
		getLogger().info("Updating the user auth token for customer " + customerId + " Token :" + token);
		List<CustomerIssuedToken> customerIssuedTokenList = accountsDao.getObjectsById(CustomerIssuedToken.class,
				"customerId", customerId);
		if (customerIssuedTokenList == null || customerIssuedTokenList.isEmpty()) {
			// No token found before //
			CustomerIssuedToken customerIssuedToken = new CustomerIssuedToken();
			customerIssuedToken.setCustomerId(customerId);
			customerIssuedToken.setIssuedTime(new Date());
			customerIssuedToken.setTokenValue(token);
			accountsDao.saveOrUpdateObject(customerIssuedToken);
			getLogger().info("Updated the token for customer id :" + customerId);
		} else {
			CustomerIssuedToken customerIssuedToken = customerIssuedTokenList.get(0);
			String oldToken = customerIssuedToken.getTokenValue();
			blackList(oldToken, ApplicationConstants.ALREADY_LOGOUT_FROM_ANOTHERTAB);
			getLogger().info("Old token " + oldToken);
			getLogger().info("New Token " + token);
			customerIssuedToken.setIssuedTime(new Date());
			customerIssuedToken.setTokenValue(token);
			accountsDao.saveOrUpdateObject(customerIssuedToken);
			getLogger().info("Blacklisted old token and saved new token ");
		}
	}

	public void setToken(String token) {
		this.token = token;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

}

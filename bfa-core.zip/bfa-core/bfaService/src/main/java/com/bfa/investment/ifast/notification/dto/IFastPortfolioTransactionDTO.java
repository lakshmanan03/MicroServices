package com.bfa.investment.ifast.notification.dto;

import java.util.List;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class IFastPortfolioTransactionDTO {
	
    private String transactionType;
    private String portfolioId;
    private String portfolioName;
    private String paymentMethod;
    private String paymentMode;
    private int amount;
    private String currency;
    private int conversionRate;
    private String contractNo;
    private String status;
    private String timestamp;
    private List<IFastPortfolioFundTransactionDTO> funds;
    
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getConversionRate() {
		return conversionRate;
	}
	public void setConversionRate(int conversionRate) {
		this.conversionRate = conversionRate;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getTimestamp() {
		return timestamp;
	}
	
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	
		
}

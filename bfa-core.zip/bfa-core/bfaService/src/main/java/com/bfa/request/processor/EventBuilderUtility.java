/**
 * 
 */
package com.bfa.request.processor;

import java.util.HashMap;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.bfa.request.aggregate.DefaultFailureHandler;
import com.bfa.request.aggregate.DefaultSuccessHandler;
import com.google.gson.Gson;

/**
 * @author pradheep.p
 *
 */
public class EventBuilderUtility implements ApplicationContextAware{
	
	private ApplicationContext applicationContext;

	public ProcessorCommand getHttpProcessorCommand(String targetURL, String requestBody, String method,
			HashMap headers, HashMap cookies,String commandName) {		
		HttpProcessorCommand command = (HttpProcessorCommand) applicationContext.getBean("httpProcessorCommand");		
		command.setParameters(targetURL, method, commandName, headers, requestBody, cookies);	
		HttpRequestSuccessHandler successHandler = (HttpRequestSuccessHandler) applicationContext.getBean("httpSuccessHandler");
		successHandler.setSource(command);
		HttpRequestFailureHandler failureHandler = (HttpRequestFailureHandler) applicationContext.getBean("httpFailureHandler");
		failureHandler.setSource(command);
		command.setSuccessHandler(successHandler);
		command.setFailureHandler(failureHandler);
		return command;
	}
	
	public ProcessorCommand getHttpProcessorGetCommand(String targetURL, String method,
			HashMap headers, HashMap cookies,String commandName) {		
		HttpProcessorGetCommand command = (HttpProcessorGetCommand) applicationContext.getBean("httpProcessorGetCommand");		
		command.setParameters(targetURL, method, commandName, headers, cookies);	
		DefaultSuccessHandler successHandler = (DefaultSuccessHandler) applicationContext.getBean("defaultSuccessHandler");		
		command.setSuccessHandler(successHandler);		
		DefaultFailureHandler failureHandler = (DefaultFailureHandler) applicationContext.getBean("defaultFailureHandler");	
		command.setFailureHandler(failureHandler);	
		return command;
	}
	
	private Object parseResponse(String inputString,Class obj){
		Gson gsonObj = new Gson();
		Object returnObj = gsonObj.fromJson(inputString, obj);
		return returnObj;
	}

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
			this.applicationContext = context;	
	}

}

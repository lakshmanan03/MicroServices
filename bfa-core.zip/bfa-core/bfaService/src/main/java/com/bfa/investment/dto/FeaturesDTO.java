package com.bfa.investment.dto;

import java.util.List;

public class FeaturesDTO {
	
	private List<String> features;

	/**
	 * @return the features
	 */
	public List<String> getFeatures() {
		return features;
	}

	/**
	 * @param features the features to set
	 */
	public void setFeatures(List<String> features) {
		this.features = features;
	}
	
	
}

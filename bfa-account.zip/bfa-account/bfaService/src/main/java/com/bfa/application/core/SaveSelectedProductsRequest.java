/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

import com.bfa.insurance.product.ProductList;

/**
 * @author pradheep.p
 *
 */
public class SaveSelectedProductsRequest {
	
	@JsonProperty("isNewCustomer")
	private Boolean isNewCustomer;
	
	private String customerRef;
	
	private List<ProductList> selectedProducts;

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public Boolean getIsNewCustomer() {
		return isNewCustomer;
	}

	public void setIsNewCustomer(Boolean isNewCustomer) {
		this.isNewCustomer = isNewCustomer;
	}
}

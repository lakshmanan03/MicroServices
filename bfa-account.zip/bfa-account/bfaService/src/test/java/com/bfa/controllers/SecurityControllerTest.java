package com.bfa.controllers;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.core.AuthenticationRequest;
import com.bfa.application.core.EmailLinkValidityRequest;
import com.bfa.application.core.OTPRequest;
import com.bfa.application.core.OTPVerificationResponse;
import com.bfa.application.core.PasswordRequest;
import com.bfa.application.core.ResendOTP;
import com.bfa.application.core.VerifyEmailRequest;
import com.bfa.common.dto.ForgotPasswordDTO;
import com.bfa.common.dto.ResetPasswordDTO;
import com.bfa.common.entity.ResendEmailVerificationRequest;
import com.bfa.common.entity.TokenValidityRequest;
import com.bfa.common.entity.WelcomeMailRequest;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.service.AccountsService;
import com.bfa.service.CommunicationService;
import com.bfa.service.PasswordResetStatus;
import com.bfa.service.SecurityService;
import com.bfa.serviceimpl.AccountLogoutService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ResponseMessageList;

@RunWith(SpringJUnit4ClassRunner.class)
public class SecurityControllerTest {

	@InjectMocks
	private SecurityController mSecurityController;

	@Mock
	private HttpServletRequest mHttpServletRequest;

	@Mock
	private AuthenticationRequest mAuthenticationRequest;

	@Mock
	private OTPVerificationResponse mOTPVerificationResponse;

	@Mock
	private SecurityService msecurityService;

	@Mock
	private VerifyEmailRequest mVerifyEmailRequest;

	@Mock
	private OTPRequest mOTPRequest;

	@Mock
	private ResponseMessageList mResponseMessageList;

	@Mock
	private PasswordRequest mPasswordRequest;

	@Mock
	private SessionDetails mSessionDetails;

	@Mock
	private ResendOTP mResendOTP;

	@Mock
	AccountsService maccountService;

	@Mock
	private ForgotPasswordDTO mForgotPasswordDTO;

	@Mock
	private ResetPasswordDTO mResetPasswordDTO;

	@Mock
	private PasswordResetStatus mPasswordResetStatus;

	@Mock
	private TokenValidityRequest mTokenValidityRequest;

	@Mock
	private AccountLogoutService mAccountLogoutService;

	@Mock
	private EmailLinkValidityRequest mEmailLinkValidityRequest;

	@Mock
	private ResendEmailVerificationRequest mResendEmailVerificationRequest;

	@Mock
	private CommunicationService mCommunicationService;

	@Mock
	private WelcomeMailRequest mWelcomeMailReq;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	int cusId = 1;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}

	@Test
	public void testAuthenticateUser() {
		when(mAuthenticationRequest.isAdminUser()).thenReturn(true);
		when(msecurityService.authenticateAdvisor(mHttpServletRequest, mAuthenticationRequest))
				.thenReturn(mResponseMessageList);
		ResponseMessageList response = mSecurityController.authenticateUser(mAuthenticationRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateUser_isNotAdmin() {
		when(mAuthenticationRequest.isAdminUser()).thenReturn(false);
		when(msecurityService.authenticateRequest(mHttpServletRequest, mAuthenticationRequest,true))
				.thenReturn(mResponseMessageList);
		ResponseMessageList response = mSecurityController.authenticateUser(mAuthenticationRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testAuthenticateUser_Exception() {
		when(mAuthenticationRequest.isAdminUser()).thenThrow(new RuntimeException());
		ResponseMessageList response = mSecurityController.authenticateUser(mAuthenticationRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testVerifyOTP() {
		when(mOTPVerificationResponse.isVerified()).thenReturn(true);
		when(msecurityService.verifyOTP(mOTPRequest)).thenReturn(mOTPVerificationResponse);
		ResponseMessageList response1 = mSecurityController.verifyOTP(mOTPRequest, mHttpServletRequest);
		assertTrue(response1.getResponseMessage().getResponseCode() == ErrorCodes.OPT_VERIFICATION_SUCCESSFUL);
		assertNotNull(response1);

		when(mOTPVerificationResponse.isVerified()).thenReturn(false);
		when(mOTPVerificationResponse.getResetCode()).thenReturn(ApplicationConstants.USER_OPT_ALREADY_VERIFIED);
		ResponseMessageList response2 = mSecurityController.verifyOTP(mOTPRequest, mHttpServletRequest);
		assertTrue(response2.getResponseMessage().getResponseCode() == ErrorCodes.OTP_VALIDATION_ALREADY_DONE);
		assertNotNull(response2);

		when(mOTPVerificationResponse.getResetCode()).thenReturn(ApplicationConstants.USER_OTP_EXPIRED);
		ResponseMessageList response3 = mSecurityController.verifyOTP(mOTPRequest, mHttpServletRequest);
		assertNotNull(response3);
		assertTrue(response3.getResponseMessage().getResponseCode() == ErrorCodes.OTP_EXPIRED);

	}

	@Test
	public void testSetPassword() {
		when(mPasswordRequest.getJourneyType()).thenReturn("insurance");
		when(msecurityService.setPassword(mPasswordRequest, mHttpServletRequest)).thenReturn(true);
		ResponseMessageList response = mSecurityController.setPassword(mPasswordRequest, mHttpServletRequest);
		assertNotNull(response);
		when(msecurityService.setPassword(mPasswordRequest, mHttpServletRequest)).thenReturn(false);
		ResponseMessageList response1 = mSecurityController.setPassword(mPasswordRequest, mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testSaveSessionDetails() {
		when(msecurityService.saveSessionDetails("", mHttpServletRequest)).thenReturn(mSessionDetails);
		ResponseMessageList response = mSecurityController.saveSessionDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testGetSessionDetails() {
		when(mHttpServletRequest.getParameter("session_id")).thenReturn("abcd");
		when(msecurityService.getSessionDetailsBySessionId("abcd")).thenReturn(mSessionDetails);
		SessionDetails response = mSecurityController.getSessionDetails(mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testVerifyEmailAddress() {
		when(msecurityService.verifyEmailAddress(mVerifyEmailRequest)).thenReturn("success");
		ResponseMessageList response = mSecurityController.verifyEmailAddress(mVerifyEmailRequest, mHttpServletRequest);
		assertNotNull(response);

		when(msecurityService.verifyEmailAddress(mVerifyEmailRequest)).thenReturn("Invalid");
		ResponseMessageList response1 = mSecurityController.verifyEmailAddress(mVerifyEmailRequest,
				mHttpServletRequest);
		assertNotNull(response1);

	}

	@Test
	public void testResendOTP() {
		when(mResendOTP.getCustomerRef()).thenReturn("reissue");
		when(maccountService.reIssueOTP("reissue",cusId)).thenReturn(true);
		ResponseMessageList response = mSecurityController.resendOTP(mResendOTP, mHttpServletRequest);
		assertNotNull(response);
		when(maccountService.reIssueOTP("reissue",cusId)).thenReturn(false);
		ResponseMessageList response1 = mSecurityController.resendOTP(mResendOTP, mHttpServletRequest);
		assertNotNull(response1);
	}

	@Test
	public void testForgotPassword() {
		when(mForgotPasswordDTO.getSessionId()).thenReturn("sdsd");
		when(mForgotPasswordDTO.getCaptcha()).thenReturn("C2U2b");
		when(msecurityService.isValidCaptcha("sdsd", "C2U2b")).thenReturn(false);
		ResponseMessageList response = mSecurityController.forgotPassword(mForgotPasswordDTO, mHttpServletRequest);
		assertNotNull(response);
		when(msecurityService.generatePasswordResetMail(mForgotPasswordDTO))
				.thenReturn(ApplicationConstants.NO_SUCH_USER);
		when(msecurityService.isValidCaptcha("sdsd", "C2U2b")).thenReturn(true);
		ResponseMessageList response1 = mSecurityController.forgotPassword(mForgotPasswordDTO, mHttpServletRequest);
		assertNotNull(response1);
	}

	@Test
	public void testResetPassword() {
		mPasswordResetStatus = new PasswordResetStatus(6000, "success");
		when(msecurityService.resetPassword(mResetPasswordDTO)).thenReturn(mPasswordResetStatus);
		ResponseMessageList response = mSecurityController.resetPassword(mResetPasswordDTO, mHttpServletRequest);
		assertNotNull(response);

	}

	@Test
	public void testLogoutUser() {
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn("mauthorizationtkey");
		doNothing().when(msecurityService).blackList("mauthorizationtkey",
				ApplicationConstants.ALREADY_LOGOUT_FROM_ANOTHERTAB);
		ResponseMessageList response = mSecurityController.logoutUser(mHttpServletRequest);
		assertNotNull(response);
		when(mHttpServletRequest.getHeader("Authorization")).thenReturn(null);
		ResponseMessageList response1 = mSecurityController.logoutUser(mHttpServletRequest);
		assertNotNull(response1);
	}

	@Test
	public void testIsAlreadyLoggedOut() throws Exception {
		when(mTokenValidityRequest.getToken()).thenReturn("token");
		when(mAccountLogoutService.isTokenBlackListed("token")).thenReturn("Invalid Token");
		ResponseMessageList response = mSecurityController.isAlreadyLoggedOut(mTokenValidityRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testIsAlreadyLoggedOut_Exception() throws Exception {
		when(mTokenValidityRequest.getToken()).thenReturn("token");
		when(mAccountLogoutService.isTokenBlackListed("token")).thenThrow(new RuntimeException());
		ResponseMessageList response = mSecurityController.isAlreadyLoggedOut(mTokenValidityRequest,
				mHttpServletRequest);
		assertNotNull(response);
	}

	@Test
	public void testCheckEmailLinkValidity() {
		when(msecurityService.isEmailLinkValid(mEmailLinkValidityRequest)).thenReturn("Valid");
		ResponseMessageList response = mSecurityController.checkEmailLinkValidity(mEmailLinkValidityRequest);
		assertNotNull(response);
	}

	@Test
	public void testCheckEmailLinkValidityElse() {

		when(msecurityService.isEmailLinkValid(mEmailLinkValidityRequest)).thenReturn("Password link already expired");
		ResponseMessageList response = mSecurityController.checkEmailLinkValidity(mEmailLinkValidityRequest);
		assertNotNull(response);
	}

	@Test
	public void testCheckEmailLinkElseValidity() {
		when(msecurityService.isEmailLinkValid(mEmailLinkValidityRequest)).thenReturn("Password link already used");
		ResponseMessageList response = mSecurityController.checkEmailLinkValidity(mEmailLinkValidityRequest);
		assertNotNull(response);
	}

	@Test
	public void testCheckElseEmailLinkValidity() {
		when(msecurityService.isEmailLinkValid(mEmailLinkValidityRequest))
				.thenReturn("Unable to find the customer details");
		ResponseMessageList response = mSecurityController.checkEmailLinkValidity(mEmailLinkValidityRequest);
		assertNotNull(response);
	}

	@Test
	public void testCheckEmailLinkValidity_Exception() {
		when(msecurityService.isEmailLinkValid(mEmailLinkValidityRequest)).thenThrow(new RuntimeException());
		ResponseMessageList response = mSecurityController.checkEmailLinkValidity(mEmailLinkValidityRequest);
		assertNotNull(response);
	}

	@Test
	public void testResendEmailVerification() throws Exception {
		when(mResendEmailVerificationRequest.getMobileNumber()).thenReturn("4563217895");
		when(mResendEmailVerificationRequest.getEmailAddress()).thenReturn("yopmail@owl.com");
		when(mResendEmailVerificationRequest.getCallbackUrl()).thenReturn("localhost");
		when(mResendEmailVerificationRequest.getHostedServerName()).thenReturn(null);
		when(mCommunicationService.resendVerificationEmail("4563217895", "yopmail@owl.com", "localhost", null))
				.thenReturn(0);
		ResponseMessageList response = mSecurityController.resendEmailVerification(mResendEmailVerificationRequest);
		assertNotNull(response);
	}

	@Test
	public void testResendEmailVerificationElse() throws Exception {
		when(mResendEmailVerificationRequest.getMobileNumber()).thenReturn("4563217895");
		when(mResendEmailVerificationRequest.getEmailAddress()).thenReturn("yopmail@owl.com");
		when(mResendEmailVerificationRequest.getCallbackUrl()).thenReturn("localhost");
		when(mResendEmailVerificationRequest.getHostedServerName()).thenReturn(null);
		when(mCommunicationService.resendVerificationEmail("4563217895", "yopmail@owl.com", "localhost", null))
				.thenReturn(-1);
		ResponseMessageList response = mSecurityController.resendEmailVerification(mResendEmailVerificationRequest);
		assertNotNull(response);
	}

	@Test
	public void testResendEmailVerificationException() throws Exception {
		when(mResendEmailVerificationRequest.getMobileNumber()).thenReturn("4563217895");
		when(mResendEmailVerificationRequest.getEmailAddress()).thenReturn("yopmail@owl.com");
		when(mResendEmailVerificationRequest.getCallbackUrl()).thenReturn("localhost");
		when(mResendEmailVerificationRequest.getHostedServerName()).thenReturn(null);
		when(mCommunicationService.resendVerificationEmail("4563217895", "yopmail@owl.com", "localhost", null))
				.thenThrow(new RuntimeException());
		ResponseMessageList response = mSecurityController.resendEmailVerification(mResendEmailVerificationRequest);
		assertNotNull(response);

	}

	@Test
	public void testSendWelcomeMailPostSignup() throws Exception {
		when(mWelcomeMailReq.getMobileNumber()).thenReturn("4563217895");
		when(mWelcomeMailReq.getEmailAddress()).thenReturn("yopmail@owl.com");
		when(mWelcomeMailReq.getCallbackUrl()).thenReturn("localhost");
		when(mWelcomeMailReq.getHostedServerName()).thenReturn(null);
		when(mCommunicationService.sendWelcomeEmailComprehensive("4563217895", "yopmail@owl.com", "localhost", null))
				.thenReturn(0);
		ResponseMessageList response = mSecurityController.sendWelcomeMailPostSignup(mWelcomeMailReq);
		assertNotNull(response);

	}

	@Test
	public void testSendWelcomeMailPostSignupElse() throws Exception {
		when(mWelcomeMailReq.getMobileNumber()).thenReturn("4563217895");
		when(mWelcomeMailReq.getEmailAddress()).thenReturn("yopmail@owl.com");
		when(mWelcomeMailReq.getCallbackUrl()).thenReturn("localhost");
		when(mWelcomeMailReq.getHostedServerName()).thenReturn(null);
		when(mCommunicationService.sendWelcomeEmailComprehensive("4563217895", "yopmail@owl.com", "localhost", null))
				.thenReturn(-1);
		ResponseMessageList response = mSecurityController.sendWelcomeMailPostSignup(mWelcomeMailReq);
		assertNotNull(response);

	}

	@Test
	public void testSendWelcomeMailPostSignupException() throws Exception {
		when(mWelcomeMailReq.getMobileNumber()).thenReturn("4563217895");
		when(mWelcomeMailReq.getEmailAddress()).thenReturn("yopmail@owl.com");
		when(mWelcomeMailReq.getCallbackUrl()).thenReturn("localhost");
		when(mWelcomeMailReq.getHostedServerName()).thenReturn(null);
		when(mCommunicationService.sendWelcomeEmailComprehensive("4563217895", "yopmail@owl.com", "localhost", null))
				.thenThrow(new RuntimeException());
		ResponseMessageList response = mSecurityController.sendWelcomeMailPostSignup(mWelcomeMailReq);
		assertNotNull(response);

	}

}

/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "existing_insurance")
public class ExistingInsurance implements Serializable{


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "life_protection_coverage")
	private double lifeProtectionCoverage;
	
	@Column(name = "critical_illness_coverage")
	private double criticalIllnessCoverage;	
	
	@Column(name = "occupational_disability_coverage_month")
	private double occupationalDisabilityCoveragePerMonth;	
	
	@Column(name = "long_term_care_coverage_month")
	private double longTermCareCoveragePerMonth;
	
	@Column(name="selected_hospital_plan")
	private Integer selectedHospitalPlanId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getLifeProtectionCoverage() {
		return lifeProtectionCoverage;
	}

	public void setLifeProtectionCoverage(double lifeProtectionCoverage) {
		this.lifeProtectionCoverage = lifeProtectionCoverage;
	}

	public double getCriticalIllnessCoverage() {
		return criticalIllnessCoverage;
	}

	public void setCriticalIllnessCoverage(double criticalIllnessCoverage) {
		this.criticalIllnessCoverage = criticalIllnessCoverage;
	}

	public double getOccupationalDisabilityCoveragePerMonth() {
		return occupationalDisabilityCoveragePerMonth;
	}

	public void setOccupationalDisabilityCoveragePerMonth(double occupationalDisabilityCoveragePerMonth) {
		this.occupationalDisabilityCoveragePerMonth = occupationalDisabilityCoveragePerMonth;
	}

	public double getLongTermCareCoveragePerMonth() {
		return longTermCareCoveragePerMonth;
	}

	public void setLongTermCareCoveragePerMonth(double longTermCareCoveragePerMonth) {
		this.longTermCareCoveragePerMonth = longTermCareCoveragePerMonth;
	}

	public Integer getSelectedHospitalPlanId() {
		return selectedHospitalPlanId;
	}

	public void setSelectedHospitalPlanId(Integer selectedHospitalPlanId) {
		this.selectedHospitalPlanId = selectedHospitalPlanId;
	}		
}

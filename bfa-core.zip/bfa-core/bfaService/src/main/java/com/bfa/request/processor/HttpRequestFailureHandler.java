/**
 * 
 */
package com.bfa.request.processor;

import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.application.event.BFAApplicationEventPublisher;

/**
 * @author pradheep.p
 *
 */
public class HttpRequestFailureHandler extends FailureHandler {	
	
	@Autowired
	private BFAApplicationEventPublisher publisher;

	public HttpRequestFailureHandler() {
		// created default constructor HttpRequestFailureHandler()
	}

	@Override
	public void run() {
		handle();
	}

}

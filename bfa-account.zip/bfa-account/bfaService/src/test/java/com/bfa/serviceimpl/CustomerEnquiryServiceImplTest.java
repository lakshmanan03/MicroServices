package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.ServiceResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerEnquiryServiceImplTest {

	@InjectMocks
	private CustomerEnquiryServiceImpl mCustomerEnquiryServiceImpl;

	@Mock
	MOInvestmentService mockMoInvestmentService;

	int cusId = 1;

	int enqId = 1;

	@Test
	public void testMapCustomerToEnquiry() {
		when(mockMoInvestmentService.mapEnquiryToCustomer(cusId, enqId)).thenReturn(true);
		ServiceResponse<String> response = mCustomerEnquiryServiceImpl.mapCustomerToEnquiry(cusId, enqId);
		assertNotNull(response);
	}
	
	@Test
	public void testMapCustomerToEnquiryElse() {
		when(mockMoInvestmentService.mapEnquiryToCustomer(cusId, enqId)).thenReturn(false);
		ServiceResponse<String> response = mCustomerEnquiryServiceImpl.mapCustomerToEnquiry(cusId, enqId);
		assertNotNull(response);
	}
	
}

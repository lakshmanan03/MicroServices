package com.bfa.notification.messenger.templates;

public abstract class BFATemplate {
	
	public abstract String getFormatString();
	
	public abstract int getType();

}

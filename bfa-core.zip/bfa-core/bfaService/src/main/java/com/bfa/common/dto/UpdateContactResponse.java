package com.bfa.common.dto;

public class UpdateContactResponse {
	private String customerRef;

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}
}

package com.bfa.common.dto;

public class OccupationalDisabilityNeedsDTO {
	
	private int id;
	
	private int customerId;

	private int enquiryId;
	
	private double percentageCoverage;
	
	private String coverageDuration;
	
	private double coverageAmount;
	
	private int employmentStatusId;
	
	private int maxAge;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public double getPercentageCoverage() {
		return percentageCoverage;
	}

	public void setPercentageCoverage(double percentageCoverage) {
		this.percentageCoverage = percentageCoverage;
	}

	public String getCoverageDuration() {
		return coverageDuration;
	}

	public void setCoverageDuration(String coverageDuration) {
		this.coverageDuration = coverageDuration;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public int getEmploymentStatusId() {
		return employmentStatusId;
	}

	public void setEmploymentStatusId(int employmentStatusId) {
		this.employmentStatusId = employmentStatusId;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}
	
	

}

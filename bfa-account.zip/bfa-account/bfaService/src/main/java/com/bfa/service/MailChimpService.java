/**
 * 
 */
package com.bfa.service;

import com.bfa.application.core.MailChimpModel;

/**
 * @author pradheep
 *
 */
public interface MailChimpService <T extends MailChimpModel>{

	public void subscribeInMailChimp(T obj, String ipaddress);

	public void subscribeForMarketingEmails(String firstName, String lastName, String emailAddress,long initialDelay);

}

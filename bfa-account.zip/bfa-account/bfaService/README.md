# Account Microservice.

This is a microservice designed for handling account related information for Money Owl.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

What things you need to install the software and how to install them

1. Apache Maven 3.5.2
2. Eclipse IDE
3. Apache-tomcat-8.0.23

### Installing

Clone the master branch and then check out the dev branch for development.

Bitbucket Reference:
https://bitbucket.org/dashboard/overview


## Running the tests

This project uses maven for unit testing, use the below command.

mvn test

## Deployment

Deployment is done in Jenkins.
http://jenkins.ntuclink.cloud/view/MoneyOwl/

## License

NA

## Acknowledgments

NA

package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "income")
public class Income implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "annual_salary")
	private Double annualSalary;

	@Column(name = "annual_bonus")
	private Double annualBonus;

	@Column(name = "other_income")
	private Double otherIncome;

	@Column(name = "percentage_of_saving")
	private Double percentageOfSaving;

	@Column(name = "income_range")
	private String incomeRange;

	// newly added - Multiple Portfolio
	@Column(name = "monthly_salary")
	private Double monthlySalary;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}	

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(Double annualSalary) {
		this.annualSalary = annualSalary;
	}

	public Double getAnnualBonus() {
		return annualBonus;
	}

	public void setAnnualBonus(Double annualBonus) {
		this.annualBonus = annualBonus;
	}

	public Double getOtherIncome() {
		return otherIncome;
	}

	public void setOtherIncome(Double otherIncome) {
		this.otherIncome = otherIncome;
	}

	public Double getPercentageOfSaving() {
		return percentageOfSaving;
	}

	public void setPercentageOfSaving(Double percentageOfSaving) {
		this.percentageOfSaving = percentageOfSaving;
	}

	public String getIncomeRange() {
		return incomeRange;
	}

	public void setIncomeRange(String incomeRange) {
		this.incomeRange = incomeRange;
	}

	public Double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(Double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}


}

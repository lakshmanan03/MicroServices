/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.notification.messenger.VerifyEmailInitiator;
import com.bfa.service.CommunicationService;

/**
 * @author pradheep.p
 *
 */
public class CommunicationServiceImpl implements CommunicationService {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	private AccountsDao accountsDao;
	
	@Autowired
	private DelegateHandler delegateHandler;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	/**
	 * This is part of the new signup feature. BFA-1343. 
	 * Returns 1 if the email was resend using mobile number. 
	 * Returns 2 if the email was resend using
	 * email address. 
	 * Returns -1 if the arguments passed where wrong. 
	 * Returns 0
	 * if the user is not found.
	 */
	@Override
	public Integer resendVerificationEmail(String mobileNumber, String emailAddress, String callBackUrl,String hostedServerName) {
		getLogger().info("Trying to resend email verification - notification");
		int result = -1;
		if (null == mobileNumber || mobileNumber.isEmpty()) {
			getLogger().info("Mobile number was not passed as argument for verification.");
		} else {
			result = 1;
			// 1. Obtain the customer by mobile address.
			Customer customerObj = locateCustomerByMobile(mobileNumber);
			// 2. Initiate the email verification.
			if (customerObj != null) {				
				delegateHandler.sendVerificationEmail(customerObj, null, callBackUrl, hostedServerName);
			} else {
				getLogger().error("Unable to find the customer to initiate the email verification " + mobileNumber);
				return 0;
			}
			return result;
		}
		if (null == emailAddress || emailAddress.isEmpty()) {
			getLogger().info("Email address was not passed as argument for verification.");
		} else {
			result = 2;
			// 1. Obtain the customer by email address.
			Customer customerObj = locateCustomerByEmail(emailAddress);
			// 2. Initiate the verify email request.
			if (customerObj != null) {
				delegateHandler.sendVerificationEmail(customerObj, null, callBackUrl, hostedServerName);
			} else {
				getLogger().error("Unable to find the customer to initiate the email verification " + mobileNumber);
				return 0;
			}
			return result;
		}
		return result;
	}
	
	private Customer locateCustomerByEmail(String emailAddress) {
		List customers = accountsDao.getObjectByHql("from Customer where email =:emailAddress","emailAddress",emailAddress);
		if (customers != null && customers.size() > 0) {
			Customer customer = (Customer) customers.get(0);
			return customer;
		}
		return null;
	}

	private Customer locateCustomerByMobile(String mobileNumber) {
		List customers = accountsDao.getObjectByHql("from Customer where mobileNumber =:mobileNumber","mobileNumber",mobileNumber);
		if (customers != null && customers.size() > 0) {
			Customer customer = (Customer) customers.get(0);
			return customer;
		}
		return null;
	}

	@Override
	public Integer sendWelcomeEmailComprehensive(String mobileNumber, String emailAddress, String callBackUrl,
			String hostedServerName) throws Exception {
		getLogger().info("Sending welcome mail in Communication Service Impl.");
		int result = -1;
		
		if (null == mobileNumber || mobileNumber.isEmpty()) {
			getLogger().info("Mobile number was not passed as argument for welcome email comprehensive.");
		} else {
			result = 1;
			// 1. Obtain the customer by mobile address.
			Customer customerObj = locateCustomerByMobile(mobileNumber);
			// 2. Initiate the welcome email
			if (customerObj != null) {				
				delegateHandler.sendWelcomeEmailComprehensive(customerObj, callBackUrl, hostedServerName);
			} else {
				getLogger().error("Unable to find the customer to initiate the welcome email comprehensive " + mobileNumber);
				return 0;
			}
			return result;
		}
		
		if (null == emailAddress || emailAddress.isEmpty()) {
			getLogger().info("Email address was not passed as argument for welcome email comprehensive.");
		} else {
			result = 2;
			// 1. Obtain the customer by email address.
			Customer customerObj = locateCustomerByEmail(emailAddress);
			// 2. Initiate the welcome email request.
			if (customerObj != null) {
				delegateHandler.sendWelcomeEmailComprehensive(customerObj, callBackUrl, hostedServerName);
			} else {
				getLogger().error("Unable to find the customer to initiate the welcome email " + mobileNumber);
				return 0;
			}
			return result;
		}
		return result;
		
		
	}
}

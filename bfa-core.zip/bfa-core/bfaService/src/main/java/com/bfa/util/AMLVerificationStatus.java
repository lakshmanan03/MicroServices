package com.bfa.util;

public enum AMLVerificationStatus {
	PENDING, CLEARED, ACCEPTED, REJECTED, FAILED
}

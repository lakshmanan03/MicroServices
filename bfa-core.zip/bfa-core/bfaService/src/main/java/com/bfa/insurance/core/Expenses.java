/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "expences")
public class Expenses implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "customer_id")
	private int customerId;	
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "monthly_installments")
	private double monthlyInstallments;
	
	@Column(name = "living_expences")
	private double livingExpenses;
	
	@Column(name = "other_expences")
	private double otherExpenses;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public double getMonthlyInstallments() {
		return monthlyInstallments;
	}

	public void setMonthlyInstallments(double monthlyInstallments) {
		this.monthlyInstallments = monthlyInstallments;
	}

	public double getLivingExpenses() {
		return livingExpenses;
	}

	public void setLivingExpenses(double livingExpenses) {
		this.livingExpenses = livingExpenses;
	}

	public double getOtherExpenses() {
		return otherExpenses;
	}

	public void setOtherExpenses(double otherExpenses) {
		this.otherExpenses = otherExpenses;
	}	
}

package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = "fund_investment_splitup")
public class FundInvestmentSplit {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private int id;
	
//	@ManyToOne
//    private PortfolioTransaction portfolio_transaction;
	
	  @ManyToOne(fetch = FetchType.EAGER)
	  @JoinColumn(name = "portfolio_transaction_id", nullable = false)
	  @JsonIgnore
	  private PortfolioTransaction portfolioTransaction;
	
	@OneToOne
	@JoinColumn(name = "fund_id")
	private Fund fund;
	
	@Column(name = "unit")
	private Double unit;
	
	@Column(name = "unit_price")
	private Double unitPrice;
	
	@Column(name = "total_units")
	private Double totalUnits;
	

	/**
	 * @return the totalUnits
	 */
	public Double getTotalUnits() {
		return totalUnits;
	}

	/**
	 * @param totalUnits the totalUnits to set
	 */
	public void setTotalUnits(Double totalUnits) {
		this.totalUnits = totalUnits;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public PortfolioTransaction getPortfolioTransaction() {
		return portfolioTransaction;
	}

	public void setPortfolioTransaction(PortfolioTransaction portfolioTransaction) {
		this.portfolioTransaction = portfolioTransaction;
	}

	public Fund getFund() {
		return fund;
	}

	public void setFund(Fund fund) {
		this.fund = fund;
	}

	public Double getUnit() {
		return unit;
	}

	public void setUnit(Double unit) {
		this.unit = unit;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	
}


package com.bfa.investment.dto;

public class CustomerSrsAccountDTO {

	private Integer fundTypeId;

	public Integer getFundTypeId() {
		return fundTypeId;
	}

	public void setFundTypeId(Integer fundTypeId) {
		this.fundTypeId = fundTypeId;
	}

	public SRSDetails getSrsDetails() {
		return srsDetails;
	}

	public void setSrsDetails(SRSDetails srsDetails) {
		this.srsDetails = srsDetails;
	}

	private SRSDetails srsDetails;

}

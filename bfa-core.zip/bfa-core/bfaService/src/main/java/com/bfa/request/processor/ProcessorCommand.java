/**
 * 
 */
package com.bfa.request.processor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.google.gson.Gson;

/**
 * @author pradheep.p
 *
 */
public abstract class ProcessorCommand implements Runnable, WriteToStream, Comparable {

	public abstract SuccessHandler getSuccessHandler();

	public abstract FailureHandler getFailureHandler();

	public abstract boolean isCommandSucceeded();

	public abstract String getCommandName();

	public long timeDelayForReschedule = 0;

	public int failureCount = 0;

	public String uniqueKey = "";
	
	@Override
	public boolean writeToFile() {
		// Write the content to a file in case of failure //
		FileOutputStream outputStream = null;
		try {
			File writingFile = File.createTempFile("Backup-Job-" + this.uniqueKey, ".json");
			System.out.println("Writing output to file " + writingFile.getAbsolutePath());
			Gson gsonObj = new Gson();
			String content = gsonObj.toJson(this);
			outputStream = new FileOutputStream(writingFile);
			outputStream.write(content.getBytes());
			outputStream.close();
			System.out.println("File written successfully.");
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally {
			if(outputStream!=null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return true;
	}

}

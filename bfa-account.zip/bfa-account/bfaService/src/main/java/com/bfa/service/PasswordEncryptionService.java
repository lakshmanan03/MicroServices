/**
 * 
 */
package com.bfa.service;

/**
 * BFA-1395
 * @author pradheep.p
 *
 */
public interface PasswordEncryptionService {
	
	public String PASSWORDS_MATCH = "Passwords match";
	
	public String PASSWORD_MATCH_ERROR = "Passwords do not match";
	
	public String ERROR_COMPARING_PASSWORDS = "Error while comparing passwords";
	
	public String PASSWORD_SAVED = "Passwords saved successfully";
	
	public String PASSWORD_SAVE_FAILED = "Unable to save password - Check logs";

	public String checkPassword(Integer customerId,String password,String sessionId);
	
	public String savePassword(Integer customerId,String password,String sessionId);
	
	public String getEncryptedPassword(String password, String sessionId);
	
	public String decryptAndHash(String password , String sessionId);
	
	public String decrypt(String password , String sessionId);	
		
}

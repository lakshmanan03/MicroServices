/**
 * 
 */
package com.bfa.serviceimpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.common.CRMDataTransformer;
import com.bfa.common.entity.BFAGrantedAuthority;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.EnquiryWithProtectionType;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.CRMNewEnquiryRequest;
import com.bfa.request.entity.NewEnquiryRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * 
 * @author pradheep.p
 *
 */
public class CRMServiceUpdater extends CRMDataTransformer implements Runnable {

	@Autowired
	private Environment environment;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private String API_NAME = APIConstants.CRM_API;	
	
	private Customer customerObj;

	private List<ProductList> selectedProducts;
	
	private boolean isNewCustomer;	 
	
	private Integer enquiryId;	

	private Logger getLogger() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}

	public void updateCRM(Customer customerDetails, List<ProductList> selectedProducts) {
		setEnvironment(environment);
		String commandName = "crm-new-enquiry";
		String targetURL = getBaseUrl(ServiceNames.CRM_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + API_NAME;
		NewEnquiryRequest crmEnquiryRequest = new NewEnquiryRequest();
		EnquiryWithProtectionType enquiryDetailsWithProtection = getEnquiryAndProtectionData(enquiryId);		
		mapCRMData(crmEnquiryRequest, customerDetails, selectedProducts,enquiryDetailsWithProtection.getEnquiryDetails());
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new BFAGrantedAuthority("ROLE_USER"));
		authorities.add(new BFAGrantedAuthority("ROLE_SERVICE_CALL"));
		loadSecurityHeader(securityConstants.TOKEN_NAME,authorities);
		String requestBody = "";
		
		int customerId = customerDetails.getId();
		// ---------------------------------------------------------------------//
		CRMNewEnquiryRequest crmEnquiryRequestObj = new CRMNewEnquiryRequest();
		crmEnquiryRequestObj.setCustomerId(customerId);
		crmEnquiryRequestObj.setEnquiryId(getEnquiryId());
		crmEnquiryRequestObj.setNewEnquiryRequest(crmEnquiryRequest);
		crmEnquiryRequestObj.setSelectedProductList(selectedProducts);
		crmEnquiryRequestObj.setNewCustomer(isNewCustomer());
		crmEnquiryRequestObj.setRequestByEmail(false);
		addCategoryAndProtectionType(crmEnquiryRequestObj,enquiryDetailsWithProtection);
		Gson gsonFormater = new GsonBuilder()
				   .setDateFormat("yyyy-MM-dd").create();
		requestBody = gsonFormater.toJson(crmEnquiryRequestObj);
		getLogger().info("Printing the target URL :" + targetURL);
		getLogger().info("Calling crm microservice -" + "Request body :" + requestBody);
		addJobToQueue(targetURL, requestBody, commandName, 0);
		// ----------------------------------------------------------------------//
		getLogger().info("CRM Jobs added to queue");
	}	
	
	private String getEnquiryIdWithPadding(Integer enquiryId) {
		return utility.getStringWithPadding(enquiryId.toString(), ApplicationConstants.DELIMITER);
	}

	private void mapCRMData(NewEnquiryRequest newEnquiryRequest, Customer customerObj,
			List<ProductList> selectedProducts,Enquiry enquiryDetails) {
		try {
			String surName = "";
			StringBuffer eventPlans = new StringBuffer();
			Iterator<ProductList> productListIterator = selectedProducts.iterator();
			while (productListIterator.hasNext()) {
				ProductList productObj = productListIterator.next();
				eventPlans.append(productObj.getProductName());
				if (productListIterator.hasNext()) {
					eventPlans.append(" ");
				}
			}
			getLogger().info("Printing the event plans " + eventPlans.toString());
			newEnquiryRequest.setSubject(ApplicationConstants.CRM_REQUEST_SUBJECT);
			newEnquiryRequest.setEmail(customerObj.getEmail());
			newEnquiryRequest.setContact(customerObj.getMobileNumber());
			newEnquiryRequest.setName(customerObj.getGivenName());
			if (customerObj.getSurName() != null) {
				surName = customerObj.getSurName();
			}			
			String gender = "";
			String dateOB = "";
			if (null != enquiryDetails) {
				gender = enquiryDetails.getGender();
				dateOB = enquiryDetails.getDateOfBirth();
			} else {
				getLogger().error("Unable to obtain the date of birth and gender (BFA-1513)");
			}
			getLogger().info("Printing the gender :" + gender);
			newEnquiryRequest.setLast_name(surName);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			newEnquiryRequest.setEmail_date(sdf.format(new Date()));
			newEnquiryRequest.setGender(gender);
			String smoker = "No";
			if (customerObj.isSmoker()) {
				smoker = "Yes";
			}
			newEnquiryRequest.setSmoker(smoker);
			newEnquiryRequest.setContactTime("NA"); // As per Vadhani
			if (eventPlans.toString().isEmpty()) {
				newEnquiryRequest.setEventPlan("Protection Plan");
			} else {
				newEnquiryRequest.setEventPlan(eventPlans.toString());
			}
			newEnquiryRequest.setCategory("Protection");			
			if(dateOB.contains("T")){
				dateOB = dateOB.substring(0, dateOB.indexOf("T"));
				dateOB = convertDOBForCRM(dateOB, sdf);
			}
			getLogger().info("Printing the data of birth" + dateOB);
			newEnquiryRequest.setDob(dateOB.trim());
			newEnquiryRequest.setDescription("New customer request");
		} catch (Exception err) {
			getLogger().error("Conversion of CRM data failed ", err);
			err.printStackTrace();
		}
	}
	
	/**
	 * Utility method to convert the date from Enquiry table to CRM
	 * acceptable date format.<BR></BR>
	 * 
	 * <B>DOB format from Enquiry table :</B>  dd-MM-yyyy<BR/>
	 * <B>DOB format to CRM call        :</B>  yyyy-MM-dd
	 * 
	 * @param dobFromEnquiryTable - String
	 * @param crmDateFormat - SimpleDateFormat
	 * @return - DOB with CRM acceptable format / Incoming format if any exception happened.
	 */
    private String convertDOBForCRM(String dobFromEnquiryTable, SimpleDateFormat crmDateFormat) {
        try {
            Date dobDateObj = new SimpleDateFormat("dd-MM-yyyy").parse(dobFromEnquiryTable);
            return crmDateFormat.format(dobDateObj);
        } catch (NullPointerException | IllegalArgumentException | ParseException  exc) {
            getLogger().error("Exception while converting DOB for CRM, Hence not converting further, returning as : " + dobFromEnquiryTable);
            return dobFromEnquiryTable;
        }    
    }

	@Override
	public void run() {
		getLogger().info("Updating the CRM Details ..");
		setEnvironment(environment);
		loadSecurityHeader(securityConstants.TOKEN_NAME);
		updateCRM(getCustomerObj(), getSelectedProducts());		
	}

	public Customer getCustomerObj() {
		return customerObj;
	}

	public void setCustomerObj(Customer customerObj) {
		this.customerObj = customerObj;
	}

	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public boolean isNewCustomer() {
		return isNewCustomer;
	}

	public void setNewCustomer(boolean isNewCustomer) {
		this.isNewCustomer = isNewCustomer;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}		
}

package com.bfa.investment.ifast.dto;

import java.util.ArrayList;


public class IFastServerStatus
{
  private String status;

  public String getStatus() { return this.status; }

  public void setStatus(String status) { this.status = status; }

  private String message;

  public String getMessage() { return this.message; }

  public void setMessage(String message) { this.message = message; }

  private ArrayList<IFastError> errors;

  public ArrayList<IFastError> getErrors() { return this.errors; }

  public void setErrors(ArrayList<IFastError> errors) { this.errors = errors; }

  private String timeStamp;

  public String getTimeStamp() { return this.timeStamp; }

  public void setTimeStamp(String timeStamp) { this.timeStamp = timeStamp; }
}

/**
 * 
 */
package com.bfa.request.processor;

import java.util.concurrent.PriorityBlockingQueue;

/**
 * @author pradheep.p
 *
 */
public class ApplicationProcessorQueue<T extends ProcessorCommand> extends PriorityBlockingQueue {
		
	public void addJob(T t) {
		this.add(t);
	}
	
}

/**
 * 
 */
package com.bfa.common;

import java.io.Serializable;

/**
 * 
 *

 * This is used when making a service call to CRM and specifying the protection
 * type.
 * 
 * @author pradheep
 * 
 * @since Release 3.0
 *
 */

public enum ProtectionTypeEnum implements Serializable{

	Life_Protection("Life Protection"),
	Critical_Illness("Critical Illness"),
	Occupational_Disability("Occupational Disability"),
	Hospital_Plan("Hospital Plan"),
	Long_Term_Care("Long Term Care"),
	Education_Fund("Education Fund"),
	Retirement_Income_Plan("Retirement Income Plan"),
	SRS_Approved_Plans("SRS Approved Plans"),
	None("None");

	private String value;

	private ProtectionTypeEnum(String value) {
		this.value = value;
	}
	
	public String getValue(){
		return this.value;
	}	

}


/**
 * 
 */
package com.bfa.application.exception;

/**
 * @author pradheep.p
 *
 */
public class NoSuchUserException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchUserException(){
		super("No such user");
	}
}
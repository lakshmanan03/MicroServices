package com.bfa.common.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class CustomerData {
	@JsonInclude(Include.NON_NULL)
	private String firstName;
	@JsonInclude(Include.NON_NULL)
	private String lastName;
	@JsonInclude(Include.NON_NULL)
	private int age;
	@JsonInclude(Include.NON_NULL)
	private String nricName;
	@JsonInclude(Include.NON_NULL)
	private String refCode;
	
	/**
	 * @return the refCode
	 */
	public String getRefCode() {
		return refCode;
	}

	/**
	 * @param refCode the refCode to set
	 */
	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getNricName() {
		return nricName;
	}

	public void setNricName(String nricName) {
		this.nricName = nricName;
	}	
	
}

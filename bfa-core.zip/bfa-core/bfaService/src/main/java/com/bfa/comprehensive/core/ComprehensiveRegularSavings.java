/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "comprehensive_regular_savings")
public class ComprehensiveRegularSavings {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name="regular_unit_trust")
	private String regularUnitTrust;
	
	@Column(name="regular_paid_cash")
	private Double regularPaidByCash;
	
	@Column(name="regular_paid_cpf")
	private Double regularPaidByCPF;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getRegularUnitTrust() {
		return regularUnitTrust;
	}

	public void setRegularUnitTrust(String regularUnitTrust) {
		this.regularUnitTrust = regularUnitTrust;
	}

	public Double getRegularPaidByCash() {
		return regularPaidByCash;
	}

	public void setRegularPaidByCash(Double regularPaidByCash) {
		this.regularPaidByCash = regularPaidByCash;
	}

	public Double getRegularPaidByCPF() {
		return regularPaidByCPF;
	}

	public void setRegularPaidByCPF(Double regularPaidByCPF) {
		this.regularPaidByCPF = regularPaidByCPF;
	}
		
}

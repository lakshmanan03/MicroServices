/**
 * 
 */
package com.bfa.insurance.core;

/**
 * @author gajendrak
 *
 */

public class RegularSavingsMapping {
	
	private int id;

	private int enquiryId;
	
	private String regularUnitTrust;
	
	private Double regularPaidByCash;
	
	private Double regularPaidByCPF;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getRegularUnitTrust() {
		return regularUnitTrust;
	}

	public void setRegularUnitTrust(String regularUnitTrust) {
		this.regularUnitTrust = regularUnitTrust;
	}

	public Double getRegularPaidByCash() {
		return regularPaidByCash;
	}

	public void setRegularPaidByCash(Double regularPaidByCash) {
		this.regularPaidByCash = regularPaidByCash;
	}

	public Double getRegularPaidByCPF() {
		return regularPaidByCPF;
	}

	public void setRegularPaidByCPF(Double regularPaidByCPF) {
		this.regularPaidByCPF = regularPaidByCPF;
	}

}

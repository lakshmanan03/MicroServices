/**
 * 
 */
package com.bfa.insurance.core;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author gajendrak
 *
 */

public class ComprehensiveDependentMapping {

	
	private int id;

	@JsonIgnore
	private int customerId;

	private int enquiryId;
	
	private String name;

	private String gender;

	private String relationship;

	private String dateOfBirth;
	
	private String nation;
	
	private Integer noOfHouseholdMembers;
	
	private String houseHoldIncome;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public Integer getNoOfHouseholdMembers() {
		return noOfHouseholdMembers;
	}

	public void setNoOfHouseholdMembers(Integer noOfHouseholdMembers) {
		this.noOfHouseholdMembers = noOfHouseholdMembers;
	}

	public String getHouseHoldIncome() {
		return houseHoldIncome;
	}

	public void setHouseHoldIncome(String houseHoldIncome) {
		this.houseHoldIncome = houseHoldIncome;
	}
	
}

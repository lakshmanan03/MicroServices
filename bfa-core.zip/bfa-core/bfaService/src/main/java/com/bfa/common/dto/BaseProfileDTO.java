/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
public class BaseProfileDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	protected String id;

	protected String firstName;

	protected String lastName;

	protected String dateOfBirth;
	
	protected String dateOfBirthInvestment;

	protected String nation;
	
	protected String gender;
	
	protected String genderInvestment;
	
	protected String email;
	
	protected String mobileNumber;
	
	protected String nationalityStatus;
	
	protected Boolean dobUpdateable;
	
	protected String journeyType;
	
	private boolean isSmoker;


	public String getJourneyType() {
        return journeyType;
    }

    public void setJourneyType(String comprehensiveJourneyType) {
        this.journeyType = comprehensiveJourneyType;
    }

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}	

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getGenderInvestment() {
		return genderInvestment;
	}

	public void setGenderInvestment(String genderInvestment) {
		this.genderInvestment = genderInvestment;
	}

	
	public String toString() {
		return "First Name:" + getFirstName() + ",Last Name:" + getLastName() + ",Date Of Birth:" + getDateOfBirth() + ", NationalityCode"
				+ getNation() + ", NationalityStatus: "+ getNationalityStatus();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getNationalityStatus() {
		return nationalityStatus;
	}

	public void setNationalityStatus(String nationalityStatus) {
		this.nationalityStatus = nationalityStatus;
	}

	public Boolean getDobUpdateable() {
		return dobUpdateable;
	}

	public void setDobUpdateable(Boolean dobUpdateable) {
		this.dobUpdateable = dobUpdateable;
	}
	
	public String getDateOfBirthInvestment() {
		return dateOfBirthInvestment;
	}

	public void setDateOfBirthInvestment(String dateOfBirthInvestment) {
		this.dateOfBirthInvestment = dateOfBirthInvestment;
	}
	
	public boolean isSmoker() {
		return isSmoker;
	}

	public void setSmoker(boolean isSmoker) {
		this.isSmoker = isSmoker;
	}
	
}

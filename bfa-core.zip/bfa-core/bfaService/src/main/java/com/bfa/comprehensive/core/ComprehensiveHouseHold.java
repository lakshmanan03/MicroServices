/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "comprehensive_house_hold")
public class ComprehensiveHouseHold {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "enquiry_id")
	private int enquiryId;	
	
	@Column(name = "household_members")
	private Integer noOfHouseholdMembers;
	
	@Column(name="household_income")
	private String houseHoldIncome;
	
	@Column(name="no_of_years")
	private Integer noOfYears;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}	

	public Integer getNoOfHouseholdMembers() {
		return noOfHouseholdMembers;
	}

	public void setNoOfHouseholdMembers(Integer noOfHouseholdMembers) {
		this.noOfHouseholdMembers = noOfHouseholdMembers;
	}

	public String getHouseHoldIncome() {
		return houseHoldIncome;
	}

	public void setHouseHoldIncome(String houseHoldIncome) {
		this.houseHoldIncome = houseHoldIncome;
	}

	public Integer getNoOfYears() {
		return noOfYears;
	}

	public void setNoOfYears(Integer noOfYears) {
		this.noOfYears = noOfYears;
	}	
	
	
	
}

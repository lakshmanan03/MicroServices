package com.bfa.common.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "customer_identity")
public class CustomerIdentityDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@Column(name = "nric_number")
	private String nricNumber;
	
	@Column(name = "passport_number")
	private String passportNumber;
	
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="MM/dd/yyyy", timezone = "UTC")
	@Column(name ="passport_expiry_date")
	private Date passportExpiryDate;
	
	@OneToOne
	@JoinColumn(name ="passport_issued_country_id")
	private Country passportIssuedCountry;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "last_updated_time_stamp")
	private Date lastModifiedDate;
	
	
	public String getNricNumber() {
		return nricNumber;
	}
	public void setNricNumber(String nricNumber) {
		this.nricNumber = nricNumber;
	}
	public String getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	public Date getPassportExpiryDate() {
		return passportExpiryDate;
	}
	public void setPassportExpiryDate(Date passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	
	public Country getPassportIssuedCountry() {
		return passportIssuedCountry;
	}
	public void setPassportIssuedCountry(Country passportIssuedCountry) {
		this.passportIssuedCountry = passportIssuedCountry;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
	
		
}

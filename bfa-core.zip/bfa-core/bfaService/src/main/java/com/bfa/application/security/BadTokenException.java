/**
 * 
 */
package com.bfa.application.security;

import org.springframework.security.core.AuthenticationException;

/**
 * @author pradheep.p
 *
 */
public class BadTokenException extends AuthenticationException {
	
	public BadTokenException(String message){
		super(message);
	}
}

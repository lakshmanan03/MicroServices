delete from customers;
insert into customers (email,mobile_number,otp_verified,email_verified,accept_market_emails,is_smoker,is_identity_verified,by_phone,by_email) values ('testemail@gmail.com','98901122','No','No',0,0,1,0,0);
commit;
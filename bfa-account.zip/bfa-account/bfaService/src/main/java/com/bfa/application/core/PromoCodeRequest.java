package com.bfa.application.core;
/**
 * 
 */

/**
 * @author kianann
 *
 */
public class PromoCodeRequest {

	private String sessionId;

	private Integer promoCodeId;
	
	private String requestType;


	/**
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	/**
	 * @return the promoCodeId
	 */
	public Integer getPromoCodeId() {
		return promoCodeId;
	}

	/**
	 * @param promoCodeId the promoCodeId to set
	 */
	public void setPromoCodeId(Integer promoCodeId) {
		this.promoCodeId = promoCodeId;
	}
		
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
}

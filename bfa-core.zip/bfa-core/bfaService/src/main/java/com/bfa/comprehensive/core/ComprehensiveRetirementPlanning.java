/**
 * 
 */
package com.bfa.comprehensive.core;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "comprehensive_retirement_planning")
public class ComprehensiveRetirementPlanning {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "retirement_age")
	private String retirementAge;
	
	@Column(name = "has_other_src_retirement_income")
	private Boolean haveOtherSourceRetirementIncome;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "comprehensiveRetirementPlanning")
	Set <ComprehensiveRetirementIncome> retirementIncomeSet = new HashSet<>();
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "comprehensiveRetirementPlanning")
	Set <ComprehensiveRetirementLumpSum> lumpSumBenefitSet = new HashSet<>();

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(String retirementAge) {
		this.retirementAge = retirementAge;
	}

	public Boolean getHaveOtherSourceRetirementIncome() {
		return haveOtherSourceRetirementIncome;
	}

	public void setHaveOtherSourceRetirementIncome(Boolean haveOtherSourceRetirementIncome) {
		this.haveOtherSourceRetirementIncome = haveOtherSourceRetirementIncome;
	}

	public Set<ComprehensiveRetirementIncome> getRetirementIncomeSet() {
		return retirementIncomeSet;
	}

	public void setRetirementIncomeSet(Set<ComprehensiveRetirementIncome> retirementIncomeSet) {
		this.retirementIncomeSet = retirementIncomeSet;
	}

	public Set<ComprehensiveRetirementLumpSum> getLumpSumBenefitSet() {
		return lumpSumBenefitSet;
	}

	public void setLumpSumBenefitSet(Set<ComprehensiveRetirementLumpSum> lumpSumBenefitSet) {
		this.lumpSumBenefitSet = lumpSumBenefitSet;
	}
	
}

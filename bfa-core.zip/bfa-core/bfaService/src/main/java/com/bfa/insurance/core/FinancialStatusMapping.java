package com.bfa.insurance.core;

import java.io.Serializable;

public class FinancialStatusMapping implements Serializable {

	private static final long serialVersionUID = 1L;

	private Assets assets;
	
	private Income income;
	
	private Liabilities liabilities;
	
	private Expenses expenses;

	public Assets getAssets() {
		return assets;
	}

	public void setAssets(Assets assets) {
		this.assets = assets;
	}

	public Income getIncome() {
		return income;
	}

	public void setIncome(Income income) {
		this.income = income;
	}

	public Liabilities getLiabilities() {
		return liabilities;
	}

	public void setLiabilities(Liabilities liabilities) {
		this.liabilities = liabilities;
	}

	public Expenses getExpenses() {
		return expenses;
	}

	public void setExpenses(Expenses expenses) {
		this.expenses = expenses;
	}	

}

package com.bfa.common.dto;

public class FinancialDTO {

	private Double monthlyIncome;
	private Double incomePercentageSaved;
	private Double totalAssets;
	private Double totalLoans;
	public Double getMonthlyIncome() {
		return monthlyIncome;
	}
	public void setMonthlyIncome(Double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
	public double getIncomePercentageSaved() {
		return incomePercentageSaved;
	}
	public void setIncomePercentageSaved(Double incomePercentageSaved) {
		this.incomePercentageSaved = incomePercentageSaved;
	}
	public Double getTotalAssets() {
		return totalAssets;
	}
	public void setTotalAssets(Double totalAssets) {
		this.totalAssets = totalAssets;
	}
	public Double getTotalLoans() {
		return totalLoans;
	}
	public void setTotalLoans(Double totalLoans) {
		this.totalLoans = totalLoans;
	}
	
	
}

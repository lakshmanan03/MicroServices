package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "sector_allocation_risk_profile")
public class SectorAllocationRiskProfile {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "sector_name")
	private String sectorName;
	
	@Column(name = "risk_profile_id")
	private Integer riskProfileId;
	
	@Column(name = "title")
	private String sectorTitle;

	@Column(name = "region")
	private String sectorRegion;
	
	@Column(name = "percentage")
	private Double percentage;
	
	@Column(name = "listing_order")
	private Integer listingOrder;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public Integer getRiskProfileId() {
		return riskProfileId;
	}

	public void setRiskProfileId(Integer riskProfileId) {
		this.riskProfileId = riskProfileId;
	}

	public String getSectorTitle() {
		return sectorTitle;
	}

	public void setSectorTitle(String sectorTitle) {
		this.sectorTitle = sectorTitle;
	}

	public String getSectorRegion() {
		return sectorRegion;
	}

	public void setSectorRegion(String sectorRegion) {
		this.sectorRegion = sectorRegion;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
	
	public Integer getListingOrder() {
		return listingOrder;
	}

	public void setListingOrder(Integer listingOrder) {
		this.listingOrder = listingOrder;
	}

	@Override
	public String toString() {
		return "SectorAllocationRiskProfile [id=" + id + ", sectorName=" + sectorName + ", riskProfileId="
				+ riskProfileId + ", sectorTitle=" + sectorTitle + ", sectorRegion=" + sectorRegion + ", percentage="
				+ percentage + "]";
	}
	
	
	
}

/**
 * 
 */
package com.bfa.common.entity;

/**
 * @author pradheep.p
 *
 */
public class SessionTracker {
	
	private Integer sessionTrackerId;

	public Integer getSessionTrackerId() {
		return sessionTrackerId;
	}

	public void setSessionTrackerId(Integer sessionTrackerId) {
		this.sessionTrackerId = sessionTrackerId;
	}
}

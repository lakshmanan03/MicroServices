package com.bfa.request.entity;

public class GenerateReportPostResponse {

	private Integer reportId;
	private String reportStatus;
	/**
	 * @return the reportId
	 */
	public Integer getReportId() {
		return reportId;
	}
	/**
	 * @param reportId the reportId to set
	 */
	public void setReportId(Integer reportId) {
		this.reportId = reportId;
	}
	/**
	 * @return the reportStatus
	 */
	public String getReportStatus() {
		return reportStatus;
	}
	/**
	 * @param reportStatus the reportStatus to set
	 */
	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}
	
	
}

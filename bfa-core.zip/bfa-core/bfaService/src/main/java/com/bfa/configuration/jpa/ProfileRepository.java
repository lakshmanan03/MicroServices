/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.insurance.core.Profile;

/**
 * @author pradheep.p
 *
 */
public interface ProfileRepository extends JpaRepository<Profile, Integer> {

}

/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class DependentDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private int id;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int customerId;

	private int enquiryId;

	private String name;

	private String relationship;

	private String gender;

	private String dateOfBirth;

	private String nation;

	@JsonIgnore
	private String status;

	private Boolean isInsuranceNeeded;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Boolean getIsInsuranceNeeded() {
		return isInsuranceNeeded;
	}

	public void setIsInsuranceNeeded(Boolean isInsuranceNeeded) {
		this.isInsuranceNeeded = isInsuranceNeeded;
	}

}

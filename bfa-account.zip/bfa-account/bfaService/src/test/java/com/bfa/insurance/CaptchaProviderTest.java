/**
 * 
 */
package com.bfa.insurance;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.serviceimpl.CaptchaProvider;

/**
 * @author pradheep.p
 *
 */

@RunWith(SpringRunner.class)
public class CaptchaProviderTest {	

	@InjectMocks
	private CaptchaProvider captchaProvider;	
	
	@Mock
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Mock
	private Logger mLogger;
	
	@Test
	public void testCaptchaProvider() {		
		mLogger.info("-- Testing captcha provider --");
		String arg = captchaProvider.getCaptchaString();
		Assert.assertNotNull(arg);
	}	
}

/**
 * 
 */
package com.bfa.application.discovery;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.application.security.SecurityConstants;
import com.bfa.comprehensive.core.ComprehensiveEnquiryResponseMessage;
import com.bfa.comprehensive.core.EnquiryResponseMessage;
import com.bfa.insurance.core.Enquiry;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.PublicUtility;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class ComprehensiveEnquiryPreferencesHelper extends DiscoveryHelper {

	@Autowired
	private Environment environment;

	private String SAVE_COMPREHENSIVE_ENQUIRY_API_NAME = "/api/customer/comprehensive/saveComprehensivePreferences";
	
	private String GET_COMPREHENSIVE_ENQUIRY_API_NAME = "/api/customer/comprehensive/getComprehensivePreferences";
	
	@Autowired
	private BFAHttpClient bfaHttpClient;

	public void saveComprehensiveEnquiry(ComprehensiveEnquiryPostRequest request) {

		setEnvironment(environment);
		String targetURL = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + SAVE_COMPREHENSIVE_ENQUIRY_API_NAME;

		loadSecurityHeaderV2(SecurityConstants.TOKEN_NAME, request.getEnquiryObject().getCustomerId());

		logger.info("Printing the target URL :" + targetURL);
		
		request.getEnquiryObject().setCustomerId(-1);

		String requestBody = constructRequestBody(request);
		logger.info("Printing the requestBody " + requestBody);

		BFAHttpResponse response = bfaHttpClient.doPostCall(requestBody, targetURL, header, null);
		
		logger.info("The response: " + response.getResponseBody());
		
	}
	
	public ComprehensiveEnquiryPostResponse getComprehensiveEnquiry(ComprehensiveEnquiryPostRequest request) {

		setEnvironment(environment);
		String targetURL = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + GET_COMPREHENSIVE_ENQUIRY_API_NAME;

		//BFAHttpClient bfaHttpClient = new BFAHttpClient();
		loadSecurityHeaderV2(SecurityConstants.TOKEN_NAME, request.getEnquiryObject().getCustomerId());

		logger.info("Printing the target URL :" + targetURL);
		
		request.getEnquiryObject().setCustomerId(-1);

		String requestBody = constructRequestBody(request);
		logger.info("Printing the requestBody " + requestBody);

		BFAHttpResponse response = bfaHttpClient.doPostCall(requestBody, targetURL, header, null);
		String responseBody = response.getResponseBody();

		ComprehensiveEnquiryPostResponse enquiryResponse = new ComprehensiveEnquiryPostResponse();
		if (responseBody != null && !responseBody.isEmpty()) {
			Gson gson = new GsonBuilder().serializeNulls().create();
			ComprehensiveEnquiryResponseMessage responseMessageList = new ComprehensiveEnquiryResponseMessage();
			try {
				responseMessageList = gson.fromJson(responseBody, ComprehensiveEnquiryResponseMessage.class);
			} catch (Exception error) {
				logger.error("Error while paring the response ", error);
			}
			List<ComprehensiveEnquiryPostResponse> objectList = responseMessageList.getObjectList();
			enquiryResponse = objectList.get(0);

		}
		return enquiryResponse;
	}
	
	public Enquiry getEnquiryDetails(Enquiry request) {
		// TODO Auto-generated method stub
		logger.info("***GET ENQUIRY DETAILS - SERVICE-TO-SERVICE CALL ****" );
		
		logger.info("***CustomerId || EnquiryId ****"+request.getCustomerId()+"||" +request.getId());
		
		setEnvironment(environment);
		String targetURL = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + "/api/Enquiry/"+request.getId();//APIConstants.FETCH_ENQUIRY;
		
		//BFAHttpClient bfaHttpClient = new BFAHttpClient();
		loadSecurityHeaderV2(SecurityConstants.TOKEN_NAME, request.getCustomerId());
		
		logger.info("Printing the target URL :" + targetURL);
		
		String requestBody = constructRequestBody(request);
		logger.info("Printing the requestBody " + requestBody);
		BFAHttpResponse response = bfaHttpClient.doGetCall(targetURL, header, null);
		String responseBody = response.getResponseBody();

		logger.info("Printing the response: " + responseBody);

		Enquiry enquiryResponse = new Enquiry();
		if (responseBody != null && !responseBody.isEmpty()) {
			Gson gson = new GsonBuilder().serializeNulls().create();
			EnquiryResponseMessage responseMessageList = new EnquiryResponseMessage();
			try {
				responseMessageList = gson.fromJson(responseBody, EnquiryResponseMessage.class);
			} catch (Exception error) {
				logger.error("Error while paring the response ", error);
			}
			List<Enquiry> objectList = responseMessageList.getObjectList();
			
			if (null != objectList && !objectList.isEmpty()) {
				
				enquiryResponse = objectList.get(0);
				
			} else {
				
				logger.error("The service to service call response is Null..!!");
			}
			

		}
		return enquiryResponse;
	}
	
	
	private String constructRequestBody(Enquiry request) {

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Double.class, new JsonSerializer<Double>() {
			@Override
			public JsonElement serialize(Double originalValue, java.lang.reflect.Type arg1,
					JsonSerializationContext arg2) {
				BigDecimal bigValue = BigDecimal.valueOf(originalValue);
				return new JsonPrimitive(bigValue.toPlainString());
			}
		});
		Gson gson = gsonBuilder.create();
		return gson.toJson(request);		

	}

	private String constructRequestBody(ComprehensiveEnquiryPostRequest request) {

		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Double.class, new JsonSerializer<Double>() {
			@Override
			public JsonElement serialize(Double originalValue, java.lang.reflect.Type arg1,
					JsonSerializationContext arg2) {
				BigDecimal bigValue = BigDecimal.valueOf(originalValue);
				return new JsonPrimitive(bigValue.toPlainString());
			}
		});
		gsonBuilder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {


			@Override
			public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
					throws JsonParseException {

				Date parsedDate = PublicUtility.tryParseDate(json.getAsString());
				if (parsedDate == null)
					parsedDate = new Date();
				logger.info("Date: " + json.getAsString() + ", parsed: " + parsedDate);
				return parsedDate;
			}
		});
		Gson gson = gsonBuilder.create();
		String requestBody = gson.toJson(request);
		return requestBody;

	}

	
}

package com.bfa.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

@Configuration
@PropertySource(value = "classpath:application.properties")
public class AmazonS3ClientServiceImpl implements AmazonS3ClientService {
	
	private static final Logger logger = LoggerFactory.getLogger(AmazonS3ClientService.class);

	private AmazonS3 s3client;

	@Value("${amazonProperties.endpointUrl}")
	private String endpointUrl;

	@Value("${amazonProperties.accessKey:}")
	private String accessKey;

	@Value("${amazonProperties.secretKey:}")
	private String secretKey;
	
	/*
	 * @PostConstruct public void init() { if (StringUtils.isNotBlank(accessKey) &&
	 * StringUtils.isNotBlank(secretKey)) { // If access key and secret key is
	 * provided, use it as authentication (Local Dev) AWSCredentials credentials =
	 * new BasicAWSCredentials(this.accessKey, this.secretKey); this.s3client =
	 * AmazonS3ClientBuilder.standard().withCredentials(new
	 * AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTHEAST_1)
	 * .build(); } else { // All server authentication should be via IAM roles
	 * this.s3client = AmazonS3ClientBuilder.defaultClient(); } }
	 */

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	private String generateFileName(MultipartFile multiPart) {
		return new Date().getTime() + "-" + multiPart.getOriginalFilename().replace(" ", "_");
	}

	private void uploadFileTos3bucket(String bucketName, String fileName, File file) {
		try {
			System.out.println("filsssse" + file.getName());
			s3client.putObject(new PutObjectRequest(bucketName, fileName, file)
					.withCannedAcl(CannedAccessControlList.Private));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	@Deprecated
	public List<S3ObjectSummary> getS3ObjectsSummaries(String bucketName) {
		try {
			ListObjectsV2Result result = s3client.listObjectsV2(bucketName);
			List<S3ObjectSummary> objects = result.getObjectSummaries();
			return objects;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public S3Object getS3Object(String bucketName, String keyName) {
		try {
			S3Object obj = s3client.getObject(bucketName, keyName);
			return obj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	

	public String upload(String bucketName, String fileName, File file) {
		String fileUrl = "";
		try {
			fileUrl = this.upload(bucketName, fileName, file, CannedAccessControlList.Private);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return fileUrl;
	}

	public String upload(String bucketName, String fileName, MultipartFile file) {
		String fileUrl = "";
		try {
			Long contentLength = Long.valueOf(file.getBytes().length);
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(contentLength);
			fileUrl = endpointUrl + "/" + bucketName + "/" + fileName;
			s3client.putObject(new PutObjectRequest(bucketName, fileName, file.getInputStream(),metadata)
					.withCannedAcl(CannedAccessControlList.Private));
		}catch(Exception e) {
			e.printStackTrace();
		}
		return fileUrl;
	}

	public String uploadFileToS3Bucket(String bucketName, MultipartFile multipartFile) {
		System.out.println("Inside Method");
		String fileUrl = "";
		try {
			File file = convertMultiPartToFile(multipartFile);
			System.out.println("file" + file.getName());
			
			String fileName = generateFileName(multipartFile);
			System.out.println("generateFileName" + fileName);
			fileUrl = endpointUrl + "/" + bucketName + "/" + fileName;
			System.out.println("fileUrl" + fileUrl);
			uploadFileTos3bucket(bucketName, fileName, file);
			file.delete();
		} catch (Exception e) {
			e.printStackTrace();
			fileUrl = "Error";
		}
		return fileUrl;
	}

	public String deleteFileFromS3Bucket(String fileName) {		
		try {
			AmazonS3URI s3Uri = new AmazonS3URI(fileName);
			String keyName = s3Uri.getKey();
			s3client.deleteObject(s3Uri.getBucket(), keyName);
			System.out.println("after Delete File");
		}catch(AmazonS3Exception ex) {
			ex.getMessage();
			return "fail";
		}
		catch(Exception e) {
			e.getMessage();
			return "fail";
		}
		return "success";
	}

	/*
	 * (non-Javadoc)
	 * @see com.bfa.util.AmazonS3ClientService#upload(java.lang.String, java.lang.String, java.io.File, com.amazonaws.services.s3.model.CannedAccessControlList)
	 */
	public String upload(String bucketName, String fileName, File file, CannedAccessControlList cannedACL) {
		String fileUrl = "";
		try {
			fileUrl = endpointUrl + "/" + bucketName + "/" + fileName;
			System.out.println("New Method upload " + fileUrl);
			s3client.putObject(new PutObjectRequest(bucketName, fileName, file)
					.withCannedAcl(cannedACL));
		}catch(Exception e) {
			e.printStackTrace();
		}
		return fileUrl;
	}

	/*
	 * method for create folder with respect to the account name into S3
	 */
	@Override
	public String createFolder(String statementBucketName, String folderName) throws SdkClientException,
	AmazonServiceException{
		String status = "";
		try {
			//	String bucketName = "mo-ifast-bucket/investment/statements/folder";    // example bucketName
			InputStream input = new ByteArrayInputStream(new byte[0]);
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(0);
			String bucketFolderName = statementBucketName+"/"+folderName;
			System.out.println("bucketFolderName==>"+bucketFolderName);
			if(s3client.doesBucketExistV2(bucketFolderName)) {
				System.out.format("Bucket %s already exists.\n", bucketFolderName);
			} else {
				System.out.println("Bucket needs to be created");
				PutObjectResult a=	s3client.putObject(new PutObjectRequest(statementBucketName, folderName, input, metadata));
				System.out.println("Folder Created::::::    "+a.toString());
			}status="created successfullly";
		} catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	/*
	 * Methods after here to use IAM
	 * ----------------------------- Start -----------------------------
	 */
	
	/*
	 * (non-Javadoc)
	 * @see com.bfa.util.AmazonS3ClientService#upload(java.lang.String, java.lang.String, java.io.File, com.amazonaws.services.s3.model.CannedAccessControlList)
	 */
	@Deprecated
	public String uploadWithIAM(String bucketName, String fileName, File file, CannedAccessControlList cannedACL) {
		System.out.println("Uploading with AWS IAM");
		String fileUrl = "";
		try {
			fileUrl = endpointUrl + "/" + bucketName + "/" + fileName;
			System.out.println("New Method upload " + fileUrl);
			s3client.putObject(new PutObjectRequest(bucketName, fileName, file)
					.withCannedAcl(cannedACL));
		}catch(Exception e) {
			e.printStackTrace();
		}
		return fileUrl;
	}
	
	public S3ObjectInputStream downloadStream(String bucketName, String fileName){
		try {
			logger.debug("Bucketname {} and fileName {}", bucketName, fileName);
		S3Object object = s3client.getObject(bucketName, fileName);
		return  object.getObjectContent();
		}catch(Exception e) {
			logger.error("Exception occured in download statement: {} ", e);
		}
		return null;
	}
		
}

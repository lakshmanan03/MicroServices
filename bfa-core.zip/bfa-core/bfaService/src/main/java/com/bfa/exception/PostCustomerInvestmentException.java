package com.bfa.exception;

/**
 * 
 * @author GajendraK
 *
 */

public class PostCustomerInvestmentException extends RuntimeException {

	/**
	 * The serializable class service call to PostCustomerInvestmentException declared a static final
	 * serialVersionUID field of type long
	 */
	private static final long serialVersionUID = -5687368227645851769L;

	/**
	 * @param exceptionMessage
	 */
	public PostCustomerInvestmentException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
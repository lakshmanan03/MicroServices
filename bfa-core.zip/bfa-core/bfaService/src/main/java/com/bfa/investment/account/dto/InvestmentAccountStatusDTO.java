package com.bfa.investment.account.dto;

public class InvestmentAccountStatusDTO {
	
	private boolean showInvestmentAccountCreationForm;
	
	private boolean allowEngagementJourney;
	
	private boolean portfolioLimitExceeded;
	
	private String accountCreationState;
	
	private boolean isEnquiryMappedToCustomer;

	public String getAccountCreationState() {
		return accountCreationState;
	}

	public void setAccountCreationState(String accountCreationState) {
		this.accountCreationState = accountCreationState;
	}

	public boolean isShowInvestmentAccountCreationForm() {
		return showInvestmentAccountCreationForm;
	}

	public void setShowInvestmentAccountCreationForm(boolean showInvestmentAccountCreationForm) {
		this.showInvestmentAccountCreationForm = showInvestmentAccountCreationForm;
	}

	public boolean isAllowEngagementJourney() {
		return allowEngagementJourney;
	}

	public void setAllowEngagementJourney(boolean allowEngagementJourney) {
		this.allowEngagementJourney = allowEngagementJourney;
	}

	public boolean isPortfolioLimitExceeded() {
		return portfolioLimitExceeded;
	}

	public void setPortfolioLimitExceeded(boolean portfolioLimitExceeded) {
		this.portfolioLimitExceeded = portfolioLimitExceeded;
	}

	public boolean isEnquiryMappedToCustomer() {
		return isEnquiryMappedToCustomer;
	}

	public void setEnquiryMappedToCustomer(boolean isEnquiryMappedToCustomer) {
		this.isEnquiryMappedToCustomer = isEnquiryMappedToCustomer;
	}
	

}


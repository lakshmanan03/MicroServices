package com.bfa.common.dto;

public class LongTermCareNeedsDTO {

	private int id;
	
	private int enquiryId;
	
	private int customerId;
	
	private int careGiverTypeId;	
	
	private int monthlyPayout;
	
	private String incomePayoutDuration;
	
	private int noOfAdls;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getCareGiverTypeId() {
		return careGiverTypeId;
	}

	public void setCareGiverTypeId(int careGiverTypeId) {
		this.careGiverTypeId = careGiverTypeId;
	}

	public int getMonthlyPayout() {
		return monthlyPayout;
	}

	public void setMonthlyPayout(int monthlyPayout) {
		this.monthlyPayout = monthlyPayout;
	}

	public String getIncomePayoutDuration() {
		return incomePayoutDuration;
	}

	public void setIncomePayoutDuration(String incomePayoutDuration) {
		this.incomePayoutDuration = incomePayoutDuration;
	}

	public int getNoOfAdls() {
		return noOfAdls;
	}

	public void setNoOfAdls(int noOfAdls) {
		this.noOfAdls = noOfAdls;
	}
	
	
	
}

package com.bfa.servicehelper;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.springframework.core.env.Environment;
import org.springframework.util.ObjectUtils;

import com.bfa.util.APIConstants;
import com.bfa.util.PublicUtility;

public class URLDirectory {
	private URLDirectory() {
		// created constructor
	}
	public static void initialize(Environment environment) {
		try {
			String activeProfile = PublicUtility.getActiveProfile(environment);
			ArtemisService.root = environment.getProperty("urlDirectory.artemisService.root");// getRoot("urlDirectory.artemisService.root",activeProfile);
			IFastService.root = environment.getProperty("urlDirectory.ifastService.root");// getRoot("urlDirectory.ifastService.root",activeProfile);
			AccountService.root = getRoot("urlDirectory.accountsService.root", activeProfile);
			InvestmentService.root = getRoot("urlDirectory.investmentService.root", activeProfile);
			NotificationService.root = getRoot("urlDirectory.notificationService.root", activeProfile);
			FinanceService.root = getRoot("urlDirectory.financeService.root", activeProfile);
		} catch (Exception ex) {

		}
	}

	public static class ArtemisService {
		private ArtemisService(){
			// created constructor
		}
		public static String root;

		public static String individualAPI() {
			return root + "/default/individual_risk";
		}
	}

	public static class IFastService {
		private IFastService(){
			// created constructor
		}
		public static String root;

		public static String apiKey() {
			return root + "/security/apiKey";
		}

		public static String accountOpening() {
			return root + "/accountOpening";
		}

		public static String accountProcessing(String ifastRefNumber) {
			return root + "/accountProcessing/" + ifastRefNumber;
		}

		public static String dpmsBuyPortfolio() {
			return root + "/portfolios/orders/buy";
		}
		
		public static String subsequentAccountOpening() {
			return root + "/accountOpeningForMultiPortfolio";
		}

		public static String rspBuyPortfolio() {
			return root + "/portfolios/orders/rsp";
		}

		public static String sellPortfolio() {
			return root + "/portfolios/orders/sell";
		}

		public static String getHoldings(String refNo) {
			return root + "/holdings/" + refNo;
		}
		
		public static String getHoldingsList() {
			return root + "/holdingsList";
		}

		public static String getNAVDetails(String date) {
			return root + "/funds/prevBizDayNavList?date=" + date;
		}
		
		public static String getPortfolios() {
			return root + "/portfolios/";
		}

		public static String getPortfolioDetails(String portfolioId) {
			return root + "/portfolios/" + portfolioId;
		}

		public static String getFundList() {
			return root + "/funds";
		}

		public static String getFundDetail(String fundId) {
			return root + "/funds/" + fundId;
		}

		public static String getCashAccount(String refNo, String trustId) {
			return root + "/cashAccounts/" + refNo + "/" + trustId;
		}

		public static String updateAccount(String refNo) {
			return root + "/accountUpdate/bankDetails/" + refNo;
		}
		
		public static String updateAddress(String refNo) {
			return root + "/accountUpdate/" + refNo;
		}

	}

	public static class AccountService {
		private AccountService(){
			// created constructor
		}
		public static String root;

		public static String profileSummary() {

			return root + APIConstants.API_ACCOUNT_PROFILE_SUMMARY;
		}

		public static String detailedCustomerSummary(Integer customerId) {
			return root + APIConstants.API_ACCOUNT_DETAILED_CUSTOMER_SUMMARY+"?customerId=" + customerId;
		}
		public static String detailedCustomerSummaryForAccountProcessing(Integer customerId,Integer enquiryId) {
			return root + APIConstants.API_ACCOUNT_DETAILED_CUSTOMER_SUMMARY+"?customerId=" + customerId+"&enquiryId="+ enquiryId ;
		}
		public static String customerBankDetails() {
			return root + APIConstants.API_ACCOUNT_CUSTOMER_BANKS;
		}

		public static String customerBankDetails(Integer customerId) {
			return root + APIConstants.API_ACCOUNT_CUSTOMER_BANKS+"?customerId=" + customerId;
		}

		public static String verifyAML() {
			return root + APIConstants.API_ACCOUNT_VERIFY_AML;
		}

		public static String clearAML(Integer customerId) {
			return root + APIConstants.API_ACCOUNT_CLEAR_AML+"?customerId=" + customerId;
		}

		public static String fetchCustomerSummary(Integer customerId, Integer advisorId) {
			return root + APIConstants.API_ACCOUNT_FETCH_CUSTOMER_SUMMARY+"?customerId=" + customerId + "&advisorId=" + advisorId;
		}
		

		public static String updateAdvisor() {
			return root + APIConstants.API_ACCOUNT_ADD_ADVISOR;
		}

		public static String savePromoCode() {
			return root + APIConstants.API_ACCOUNT_SAVE_PROMO_CODE;

		}

		public static String fetchCustomerSRSDetails() {
			return root + APIConstants.API_ACCOUNT_GET_SRSBANK;
		}
		
		public static String updateCustomerAddress(String customerId, Integer advisorId) {
			return root + APIConstants.API_ACCOUNT_UPDATE_ADDRESS+"?customerId=" + customerId + "&advisorId=" + advisorId;
		}
		
		public static String saveDocumentForAdmin(String customerId) {
			return root + APIConstants.API_ACCOUNT_SAVE_DOCUMENTS_ADMIN+"?customerId=" + customerId;
		}
	}

	public static class NotificationService {
		public static String root;

		public static String inAppNotification() {
			return root + "/api/notify";
		}
		
		public static String sendNotification() {
			return root + "/api/internal/notification";
		}
	}
	
	public static class FinanceService {
		public static String root;

		public static String getFinacialDetailsByCustomerId() {
			return root + APIConstants.GET_FINANCIAL_DETAILS_BY_CUSTOMER_ID;
		}
		
		public static String financialData(Boolean isAdmin, String customerId) {
			if (!ObjectUtils.isEmpty(isAdmin) && !ObjectUtils.isEmpty(customerId) && isAdmin) {
				return root + APIConstants.API_FINANCIAL_DATA + "?customerId=" + customerId + "&isAdmin=" + isAdmin;
			} else {
				return root + APIConstants.API_FINANCIAL_DATA;
			}

		}
	}

	public static class InvestmentService {
		public static String root;

		public static String optionsSearch(String countryCode, String nationalityCode, String ssoc, String ssic,
				String houseHoldRange) {
			String parameters = "";

			try {
				parameters = appendParam(parameters, "countryCode", countryCode);
				parameters = appendParam(parameters, "nationalityCode", nationalityCode);
				parameters = appendParam(parameters, "ssoc", ssoc);
				parameters = appendParam(parameters, "ssic", ssic);
				parameters = appendParam(parameters, "houseHoldRange", houseHoldRange);

			} catch (Exception e) {
				e.printStackTrace();
			}
			return root + APIConstants.OPTIONS_SEARCH + (parameters != "" ? "?" + parameters : "");
		}

		public static String updateInvestmentAccountStatus() {
			return root + APIConstants.INVESTMENT_ACCOUNT_STATUS;
		}
		
		public static String updateCustomerInvfundType() {
			return root + APIConstants.SAVE_OR_UPDATE_PORTFOLIO_FUNDING_TYPE;
		}
		
		public static String fetchOptionItemById(Integer id) {
			return root + APIConstants.OPTION_LIST_BY_ID+"?id=" + id;
		}


		public static String updateMapCustomerEnquiry() {
			return root + APIConstants.CUSTOMER_ENQUIRY;
		}
		
		public static String saveSRSIntoIfast() {
			return root + APIConstants.UPDATE_SRS_BANK_LIST;
		}
		
		public static String saveBankIntoIfast() {
			return root + APIConstants.PROFILE_BANK_LIST;
		}

		// update trust id
		public static String updateTrustId() {
			return root + APIConstants.UPDATE_TRUST_ID;
		}

		public static String getInvestmentProfile() {
			return root + APIConstants.CUSTOMER_INVESTMENT_PROFILE;
		}

		public static String getInvestmentAccountActions() {
			return root + APIConstants.INVESTMENT_ACCOUNT_ACTIONS;
		}
		
		public static String getInvestmentProfile(Integer customerId) {
			return root + APIConstants.CUSTOMER_INVESTMENT_PROFILE+"?customerId=" + customerId;
		}

		public static String fetchCustomerId(String counterPartyAccountNumber) {
			return root + APIConstants.FETCH_CUSTOMER_ID+"?cPNo=" + counterPartyAccountNumber;
		}

		public static String fetchCustIdForStatements(String ifastRefno) {
			return root + "/customer/fetchCustIdForStatements?ifastRefno=" + ifastRefno;
		}

		public static String updateCustomerPortfolioPurchasedStatus(Integer customerPortfolioId) {
			return root + "/api/customers/portfolios/"+customerPortfolioId+"/transactions/buy";
		}
		
		public static String getInvetmentObjectiveForAdmin(String customerId) {
			return root + APIConstants.ADMIN_GET_CUSTOMER_INVESTMENT_OBJECTIVE_ADMIN + "?customerId=" + customerId;

		}

		public static String getRspHolidayList(String date) {     
			return root + APIConstants.HOLIDAYS+"?currentDate=" + date;
		}

		public static String saveRspBatchTimings() {
			return root + APIConstants.BATCH_RSP_TIMINGS;
		}

		public static String getRspBatchTimings(int month) {
			return root + APIConstants.BATCH_RSP_MONTHLY+"?rspRunMonth=" + month;
		}
		
		public static String notifyInvestmentAccountSetup() {
			return root + APIConstants.NOTIFY_INVESTMENT_ACCOUNT_SETUP;
		}

		public static String updateInsufficientFundStatus() {
			return root + APIConstants.INSUFFICIENT_FUND_MAILER;
		}
		
		public static String savePortfolioNavList(String date) {
			return root + APIConstants.CUSTOMER_PORTFOLIO_UPDATE_NAV+"?currentDate=" + date;
		}

		public static String saveCashTransaction() {
			return root + APIConstants.SAVE_CASH_TRANSACTION;
		}

		public static String savePortfolioTransaction() {
			return root + APIConstants.PORTFOLIO_SAVE_PORTFOLIO_TRANSACTION;
		}

		public static String fetchHoldingDetails(Integer customerId) {
			return root +APIConstants.PORTFOLIO_HOLDINGS_ADMIN+ "?customerId=" + customerId;
		}


		public static String monthlyStatementMailer(String customerPortfolioId, String month, String year) {
			return root + String.format(APIConstants.MONTHLY + "?customerPortfolioId=%s&month=%s&year=%s", customerPortfolioId, month, year);
		}

		public static String rspReminderMailer(Integer customerPortfolioId) {
			return root + String.format(APIConstants.SEND_MONTHLY_INVESTMENT_REMINDER_EMAIL+"?customerPortfolioId="+customerPortfolioId);
		}
		
		public static String getCustomerIfastAccount(String counterPartyAccNumber) {
			return root + String.format(APIConstants.GET_CUSTOMER_IFAST_ACCOUNT + "?counterPartyAccNumber=%s", counterPartyAccNumber);
		}
		
		public static String postCustomerInvestmentObjective() {
			return root + APIConstants.POST_CUSTOMER_INVESTMENT_OBJECTIVE;
		}
		
		public static String fetchOptionsCollectionMaster(String groupName){
			return root + String.format(APIConstants.OPTION_LIST_COLLECTION +"?groupName=%s",groupName);
		}
		
		public static String getDeletedPortfolioDetailsForAdmin(String customerId) {
			return root + APIConstants.DELETED_PORTFOLIO_DETAILS_ADMIN + "?customerId=" + customerId;

		}
		
		private static String appendParam(String existingParams, String key, String value) {
			try {
				if ((key == null && key.isEmpty()) || (value == null && value.isEmpty()))
					return existingParams;
				existingParams += (existingParams != "" && existingParams != null)
						? "&" + key + "=" + URLEncoder.encode(value, "UTF-8")
						: key + "=" + URLEncoder.encode(value, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			return existingParams;
		}
		
		public static String saveAddressToIfast(String customerId) {
			return root + APIConstants.UPDATE_ADDRESS + "?customerId=" + customerId ;
		}
	}

	private static String moProdRoot = "https://www.moneyowl.com.sg/svc";
	private static String moUatRoot = "https://bfa-uat.ntucbfa.com/svc";
	private static String moUat2Root = "https://bfa-uat2.ntucbfa.com/svc";
	private static String moUat3Root = "https://bfa-uat3.ntucbfa.com/svc";
	private static String moDevRoot = "https://bfa-dev.ntucbfa.cloud/svc";
	private static String moDev2Root = "https://bfa-dev2.ntucbfa.cloud/svc";
	private static String artemisProdRoot = "https://p4.cynopsis.co/artemis_moneyowl_uat";
	private static String artemisUatRoot = "https://p4.cynopsis.co/artemis_moneyowl_uat";
	private static String ifastProdRoot = "https://203.116.58.21/sg-bfa-rws";
	private static String ifastUatRoot = "https://203.116.58.21/sg-bfa-rws";
	private static String accountContextPath = "/account/account-microservice";
	private static String investmentContextPath = "/invest/investment-microservice";
	private static String notificationContextPath = "/notification/notify-microservice";
	private static String financeContextPath = "/finance/finhealth";
	private static String newMoUat1 = "https://newmouat1.ntucbfa.com/svc";

	private static Map<String, String> urlMap = new HashMap<String, String>() {
		{
			put("newmo-urlDirectory.accountsService.root", newMoUat1 + accountContextPath);
			put("newmo-urlDirectory.investmentService.root", newMoUat1 + investmentContextPath);
			put("newmo-urlDirectory.notificationService.root", newMoUat1 + notificationContextPath);
			put("newmo-urlDirectory.artemisService.root", artemisUatRoot);
			put("newmo-urlDirectory.ifastService.root", ifastUatRoot);
			put("newmo-urlDirectory.financeService.root", newMoUat1 + financeContextPath);

			put("prod-urlDirectory.accountsService.root", moProdRoot + accountContextPath);
			put("prod-urlDirectory.investmentService.root", moProdRoot + investmentContextPath);
			put("prod-urlDirectory.notificationService.root", moProdRoot + notificationContextPath);
			put("prod-urlDirectory.artemisService.root", artemisProdRoot);
			put("prod-urlDirectory.ifastService.root", ifastProdRoot);
			put("prod-urlDirectory.financeService.root", moProdRoot + financeContextPath);


			put("uat-urlDirectory.accountsService.root", moUatRoot + accountContextPath);
			put("uat-urlDirectory.investmentService.root", moUatRoot + investmentContextPath);
			put("uat-urlDirectory.notificationService.root", moUatRoot + notificationContextPath);
			put("uat-urlDirectory.artemisService.root", artemisUatRoot);
			put("uat-urlDirectory.ifastService.root", ifastUatRoot);
			put("uat-urlDirectory.financeService.root", moUatRoot + financeContextPath);

			put("uat2-urlDirectory.accountsService.root", moUat2Root + accountContextPath);
			put("uat2-urlDirectory.investmentService.root", moUat2Root + investmentContextPath);
			put("uat2-urlDirectory.notificationService.root", moUat2Root + notificationContextPath);
			put("uat2-urlDirectory.artemisService.root", artemisUatRoot);
			put("uat2-urlDirectory.ifastService.root", ifastUatRoot);
			put("uat2-urlDirectory.financeService.root", moUat2Root + financeContextPath);

			put("uat3-urlDirectory.accountsService.root", moUat3Root + accountContextPath);
			put("uat3-urlDirectory.investmentService.root", moUat3Root + investmentContextPath);
			put("uat3-urlDirectory.notificationService.root", moUat3Root + notificationContextPath);
			put("uat3-urlDirectory.artemisService.root", artemisUatRoot);
			put("uat3-urlDirectory.ifastService.root", ifastUatRoot);
			put("uat3-urlDirectory.financeService.root", moUat3Root + financeContextPath);

			put("dev2-urlDirectory.investmentService.root", moDev2Root + investmentContextPath);
			put("dev2-urlDirectory.accountsService.root", moDev2Root + accountContextPath);
			put("dev2-urlDirectory.notificationService.root", moDev2Root + notificationContextPath);
			put("dev2-urlDirectory.artemisService.root", artemisUatRoot);
			put("dev2-urlDirectory.ifastService.root", ifastUatRoot);
			put("dev2-urlDirectory.financeService.root", moDev2Root + financeContextPath);

			put("dev-urlDirectory.accountsService.root", moDevRoot + accountContextPath);
			put("dev-urlDirectory.investmentService.root", moDevRoot + investmentContextPath);
			put("dev-urlDirectory.notificationService.root", moDevRoot + notificationContextPath);
			put("dev-urlDirectory.artemisService.root", artemisUatRoot);
			put("dev-urlDirectory.ifastService.root", ifastUatRoot);
			put("dev-urlDirectory.financeService.root", moDevRoot + financeContextPath);

			put("local-urlDirectory.accountsService.root", "http://localhost:8085");
			put("local-urlDirectory.investmentService.root", "http://localhost:8081");
			put("local-urlDirectory.notificationService.root", "http://localhost:8086");
			put("local-urlDirectory.artemisService.root", artemisUatRoot);
			put("local-urlDirectory.ifastService.root", ifastUatRoot);
			put("local-urlDirectory.financeService.root", "http://localhost:8080");
		}
	};

	private static String getRoot(String propertyName, String activeProfile) {
		String key = activeProfile + "-" + propertyName;
		if (urlMap.containsKey(key)) {
			return urlMap.get(key);
		}
		return null;
	}

	private static String getPropertyRoot(String propertyName, String activeProfile) {
		String key = activeProfile + "-" + propertyName;
		if (urlMap.containsKey(key)) {
			return urlMap.get(key);
		}
		return null;
	}
}

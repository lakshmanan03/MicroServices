
/**
 * 
 */
package com.bfa.configuration;

import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.bfa.application.security.AdminTokenAuthenticationFilter;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.BFALogoutFilter;
import com.bfa.application.security.BFATokenAuthenticationFilter;
import com.bfa.application.security.BFAUserDetailsService;
import com.bfa.application.security.BFAUserDetailsServiceImpl;
import com.bfa.application.security.TokenProvider;
import com.bfa.service.SecurityService;
import com.bfa.serviceimpl.SecurityServiceImpl;
import com.bfa.util.APIConstants;

/**
 * @author pradheep.p
 *
 */
@Configuration
public class CustomWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

	@Autowired
	private org.springframework.core.env.Environment environment;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	@Autowired
	ClassPathResource classPathResourceObj;
	
	@Autowired
	Properties prop;

	@Bean
	public BFAUserDetailsService getBFAUserDetailsService() {
		return new BFAUserDetailsServiceImpl();
	}

	@Bean
	public BFATokenAuthenticationFilter getTokenAuthenticationFilter() {
		return new BFATokenAuthenticationFilter();
	}

	@Bean
	public SecurityService getSecurityService() {
		SecurityService securityService = new SecurityServiceImpl();
		securityService.provideClientSecretKey();
		
		System.out.println("=-========================================================creating bean "+  securityService.toString());
		return securityService;
	}

	@Bean
	public TokenProvider getTokenProvider() {
		return new TokenProvider();
	}

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@Bean(name = "prodCorsFilter")
	public CorsFilter productionCorsFilter() {
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		String hostList = environment.getProperty("cors.mo.hostUrl");
		if (StringUtils.isNotBlank(hostList)) {
			getLogger().info("productionCorsFilter():::::::::::: Host List which are allowing in CORS -> " + hostList);
			StringTokenizer st = new StringTokenizer(hostList, ",");
			getLogger().info("productionCorsFilter():::::::::::: Hosts with comma separator -> " + st.toString());
			while (st.hasMoreTokens()) {
				String origin = st.nextToken();
				getLogger().info("productionCorsFilter():::::::::::: Individual Host which are allowing in CORS -> " + origin);
				config.addAllowedOrigin(origin);
			}
		}
		config.addAllowedHeader("*");
		config.addAllowedMethod("*");
		source.registerCorsConfiguration("/**", config);
		CorsFilter bean = new CorsFilter(source);
		return bean;
	}

	@Profile("!prod")
	@Bean(name = "corsFilter")
	public CorsFilter corsFilter() {
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		config.addAllowedOrigin("*");
		config.addAllowedHeader("*");
		config.addAllowedMethod("*");
		source.registerCorsConfiguration("/**", config);
		return new CorsFilter(source);
	}

	private boolean isProduction() {
		String hostList = environment.getProperty("cors.mo.hostUrl");
		if (StringUtils.isNotBlank(hostList)) {
			getLogger().info("CORS Filter On");
			return true;
		} else {
			getLogger().info("CORS Filter Off");
			return false;
		}
	}	

	@Override
	protected void configure(HttpSecurity http) throws Exception {		
		if (!isProduction()) {
			http.cors().and().addFilter(corsFilter());
		} else {
			http.cors().and().addFilter(productionCorsFilter());
		}		
		http.authorizeRequests().antMatchers("/swagger*").permitAll();
		http.authorizeRequests().antMatchers("/actuator*").permitAll();
		http.authorizeRequests().antMatchers("/authenticate").permitAll();		
		http.authorizeRequests().antMatchers("**/api/**").access("hasRole('" + BFAGrandtedAuthority.ROLE_USER + "')");
		http.authorizeRequests().antMatchers(APIConstants.API_ACCOUNT_CUSTOMER_PROFILE).access("hasRole('" + BFAGrandtedAuthority.ROLE_SIGNED_USER + "')");
		http.authorizeRequests().antMatchers(APIConstants.API_VALIDATE_2FA).access("hasRole('" + BFAGrandtedAuthority.ROLE_SIGNED_USER + "')");
		http.authorizeRequests().antMatchers(APIConstants.API_SEND_2FA_OTP).access("hasRole('" + BFAGrandtedAuthority.ROLE_SIGNED_USER + "')");
		http.authorizeRequests().antMatchers(APIConstants.API_IS_TWO_FACT_AUTHENTICATED).access("hasRole('" + BFAGrandtedAuthority.ROLE_SIGNED_USER + "')");
		http.authorizeRequests().antMatchers(APIConstants.API_ACCOUNT_UPDATE_PERSONAL_DETAILS).access("hasRole('" + BFAGrandtedAuthority.ROLE_SIGNED_USER + "')");
		http.authorizeRequests().antMatchers("**/service-calls/**").access("hasRole('" + BFAGrandtedAuthority.ROLE_SERVICE_CALL + "')");
		http.addFilterBefore(getLogoutFilter(), UsernamePasswordAuthenticationFilter.class);
		http.addFilterAfter(getTokenAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
		http.addFilterAfter(getAdminTokenAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
		http.csrf().disable();		
	}

	@Bean
	public SecurityContextHolder getSecurityContextHolder() {
		return new SecurityContextHolder();
	}

	@Bean
	public BFALogoutFilter getLogoutFilter() {
		return new BFALogoutFilter();
	}
	
	@Bean
	public AdminTokenAuthenticationFilter getAdminTokenAuthenticationFilter() {
		return new AdminTokenAuthenticationFilter();
	}	
}

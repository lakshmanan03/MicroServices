/**
 * 
 */
package com.bfa.serviceimpl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.service.AccountsService;

/**
 * This class is to reissue the OTP to the user.
 * This was introduced as part of new signup feature.
 * 
 * @author pradheep.p
 *
 */
public class ReissueOTPRunnable implements Runnable {

	private String customerRef;
	
	private Integer customerId;
	
	@Autowired
	private AccountsService accountService;
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	private Logger getLogger(){
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}
	
	@Override
	public void run() {		
		getLogger().info("Trying to reissue the SMS for the customer");
		accountService.reIssueOTP(customerRef,customerId);
	}

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}
}

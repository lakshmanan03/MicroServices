package com.bfa.application.security;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

public class JWTAuthenticationToken extends AbstractAuthenticationToken {
	private static final long serialVersionUID = 1L;
	private final Object principal;
	private Object details;
	private String id;

	Collection<GrantedAuthority> authorities;

	public JWTAuthenticationToken(String jwtToken, String id) {
		super(null);
		super.setAuthenticated(true);
		principal = jwtToken;
		this.id = id;

	}
	

	public Object getCredentials() {
		return "";
	}

	public Object getPrincipal() {
		return principal;
	}

	
	
	public Object getDetails() {
		return details;
	}

	public void setDetails(Object details) {
		this.details = details;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public Collection<GrantedAuthority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Collection<GrantedAuthority> authorities) {
		this.authorities = authorities;
	}
}

package com.bfa.investment.ifast.dto;

import java.util.Date;
import java.util.List;

import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class DPMSTransactionResponse {
	private String contractNo;
	private String refno;
	private String paymentMethod;
	private String portfolioId;
	private String portfolioName;
	private String paymentMode;
	private String investmentAmount;
	private String amount;
	private String trustId;
	private String status;
	private String createdDate;
	private String investmentCurrency;
	private String costSgd;
	private String conversionRate;
	private String transactionType;
	private String voidReason;
	private String completedDate;
	private String timestamp;
	private String createdBy;
	
	private List<DPMSFundTransaction> funds;
	
	

	
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public List<DPMSFundTransaction> getFunds() {
		return funds;
	}
	public void setFunds(List<DPMSFundTransaction> funds) {
		this.funds = funds;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getInvestmentAmount() {
		return investmentAmount;
	}
	public void setInvestmentAmount(String investmentAmount) {
		this.investmentAmount = investmentAmount;
	}
	public String getTrustId() {
		return trustId;
	}
	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getInvestmentCurrency() {
		return investmentCurrency;
	}
	public void setInvestmentCurrency(String investmentCurrency) {
		this.investmentCurrency = investmentCurrency;
	}
	public String getCostSgd() {
		return costSgd;
	}
	public void setCostSgd(String costSgd) {
		this.costSgd = costSgd;
	}
	public String getConversionRate() {
		return conversionRate;
	}
	public void setConversionRate(String conversionRate) {
		this.conversionRate = conversionRate;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getVoidReason() {
		return voidReason;
	}
	public void setVoidReason(String voidReason) {
		this.voidReason = voidReason;
	}
	public String getCompletedDate() {
		return completedDate;
	}
	public void setCompletedDate(String completedDate) {
		this.completedDate = completedDate;
	}
	
	@JsonIgnore
	public Date getDateFromTimeStamp() {
		try {
			if (getTimestamp() != null) {
				return PublicUtility.convertLongFormatToDate(getTimestamp());
			}
		}
		catch (Exception ex) {
			
		}
		return null;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DPMSTransactionResponse [contractNo=");
		builder.append(contractNo);
		builder.append(", refno=");
		builder.append(refno);
		builder.append(", paymentMethod=");
		builder.append(paymentMethod);
		builder.append(", portfolioId=");
		builder.append(portfolioId);
		builder.append(", portfolioName=");
		builder.append(portfolioName);
		builder.append(", paymentMode=");
		builder.append(paymentMode);
		builder.append(", investmentAmount=");
		builder.append(investmentAmount);
		builder.append(", amount=");
		builder.append(amount);
		builder.append(", trustId=");
		builder.append(trustId);
		builder.append(", status=");
		builder.append(status);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", investmentCurrency=");
		builder.append(investmentCurrency);
		builder.append(", costSgd=");
		builder.append(costSgd);
		builder.append(", conversionRate=");
		builder.append(conversionRate);
		builder.append(", transactionType=");
		builder.append(transactionType);
		builder.append(", voidReason=");
		builder.append(voidReason);
		builder.append(", completedDate=");
		builder.append(completedDate);
		builder.append(", timestamp=");
		builder.append(timestamp);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", funds=");
		builder.append(funds);
		builder.append("]");
		return builder.toString();
	}
	
}

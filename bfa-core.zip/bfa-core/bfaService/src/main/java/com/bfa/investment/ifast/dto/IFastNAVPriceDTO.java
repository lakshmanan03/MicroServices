package com.bfa.investment.ifast.dto;

import java.util.Date;

/**
 * @author DivakarU
 *
 */
public class IFastNAVPriceDTO {

	private String fundId;
	private Date navDate;
	private Double navValue;
	private String actualNavDate;
	/**
	 * @return the fundId
	 */
	public String getFundId() {
		return fundId;
	}
	/**
	 * @param fundId the fundId to set
	 */
	public void setFundId(String fundId) {
		this.fundId = fundId;
	}
	/**
	 * @return the date
	 */
	
	
	/**
	 * @return the navValue
	 */
	public Double getNavValue() {
		return navValue;
	}
	/**
	 * @return the navDate
	 */
	public Date getNavDate() {
		return navDate;
	}
	/**
	 * @param navDate the navDate to set
	 */
	public void setNavDate(Date navDate) {
		this.navDate = navDate;
	}
	/**
	 * @return the actualNavDate
	 */
	public String getActualNavDate() {
		return actualNavDate;
	}
	/**
	 * @param actualNavDate the actualNavDate to set
	 */
	public void setActualNavDate(String actualNavDate) {
		this.actualNavDate = actualNavDate;
	}
	/**
	 * @param navValue the navValue to set
	 */
	public void setNavValue(Double navValue) {
		this.navValue = navValue;
	}
	
	
}


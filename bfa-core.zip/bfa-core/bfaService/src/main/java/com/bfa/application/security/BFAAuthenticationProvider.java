/**
 * 
 */
package com.bfa.application.security;

import java.util.Collection;
import java.util.Iterator;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;

/**
 * @author pradheep.p
 *
 */
public class BFAAuthenticationProvider implements AuthenticationProvider {
	
	private boolean authorized = false;
	
	/* (non-Javadoc)
	 * @see org.springframework.security.authentication.AuthenticationProvider#authenticate(org.springframework.security.core.Authentication)
	 */
	@Override
	public Authentication authenticate(Authentication arg0) throws AuthenticationException {		
		AbstractAuthenticationToken userAuthenticationToken = (AbstractAuthenticationToken) arg0; 
		Collection auth = userAuthenticationToken.getAuthorities();
		Iterator iter = auth.iterator();
		while (iter.hasNext()) {
			GrantedAuthority obj = (GrantedAuthority) iter.next();
			System.out.println("Printing the previllage : " + obj.getAuthority());
			if ("ROLE_USER".equals(obj.getAuthority())) {
				authorized = true;
				break;
			}
		}
		if(!authorized){
			throw new BadTokenException("Invalid authentication token");
		}
		return arg0;
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.authentication.AuthenticationProvider#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> arg0) {
		return true;
	}

}

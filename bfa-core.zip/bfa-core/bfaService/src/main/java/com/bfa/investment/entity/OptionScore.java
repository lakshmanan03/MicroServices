package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "option_score_master")
public class OptionScore {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "question_option_id")
	private int questionOptionId;
	
	@Column(name = "score")
	private int score;

	public int getQuestionOptionId() {
		return questionOptionId;
	}

	public void setOption(int questionOptionId) {
		this.questionOptionId = questionOptionId;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
}

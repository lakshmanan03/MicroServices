package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.CustomerSrsAccount;

public interface CustomerSrsAccountRepository extends CrudRepository<CustomerSrsAccount, String> {
	
	Optional<CustomerSrsAccount> findTopByCustomerIdOrderByCustomerIdDesc(Integer customerId);

}

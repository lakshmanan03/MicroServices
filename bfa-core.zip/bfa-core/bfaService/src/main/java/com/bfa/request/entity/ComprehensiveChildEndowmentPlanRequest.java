/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;

/**
 * @author gajendrak
 *
 */
public class ComprehensiveChildEndowmentPlanRequest {
	
	private String hasEndowments;
	
	private List<ComprehensiveEndowmentPlanMapping> endowmentDetailsList;

	public List<ComprehensiveEndowmentPlanMapping> getEndowmentDetailsList() {
		return endowmentDetailsList;
	}

	public void setEndowmentDetailsList(List<ComprehensiveEndowmentPlanMapping> endowmentDetailsList) {
		this.endowmentDetailsList = endowmentDetailsList;
	}

	public String getHasEndowments() {
		return hasEndowments;
	}

	public void setHasEndowments(String hasEndowments) {
		this.hasEndowments = hasEndowments;
	}

}

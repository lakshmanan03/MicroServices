package com.bfa.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_customer_assessment_details")
public class CustomerAssessmentDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "enquiry_id")
	private int enquiryId;

	@Column(name = "portfoilio_id")
	private String portfolioId;

	@Column(name = "portfolio_status")
	private String portfolioStatus;

	@Column(name = "question")
	private String question;

	@Column(name = "option_id")
	private int optionId;

	@Column(name = "option_answer")
	private String answer;
	
	@Column(name = "age")
	private int age;
	
	@Column(name = "monthlyExpense")
	private double monthlyExpense;
	
	@Column(name = "monthlyIncome")
	private double monthlyIncome;
	
	@Column(name = "initialInvestement")
	private double initialInvestement;
	
	@Column(name = "monthlyInvestment")
	private double monthlyInvestment;
	
	@Column(name = "investemntPeriod")
	private int investmentPeriod;
	
	@Column(name = "investment_status")
	private String investmentStatus;
	
	@Column(name = "customer_portfolio_id")
	private Integer customerPortfolioID;
	


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getMonthlyExpense() {
		return monthlyExpense;
	}

	public void setMonthlyExpense(double monthlyExpense) {
		this.monthlyExpense = monthlyExpense;
	}

	public double getMonthlyIncome() {
		return monthlyIncome;
	}

	public void setMonthlyIncome(double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}

	public double getInitialInvestement() {
		return initialInvestement;
	}

	public void setInitialInvestement(double initialInvestement) {
		this.initialInvestement = initialInvestement;
	}

	public double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public int getInvestmentPeriod() {
		return investmentPeriod;
	}

	public void setInvestmentPeriod(int investmentPeriod) {
		this.investmentPeriod = investmentPeriod;
	}

	public String getInvestmentStatus() {
		return investmentStatus;
	}

	public void setInvestmentStatus(String investmentStatus) {
		this.investmentStatus = investmentStatus;
	}

	public Integer getCustomerPortfolioID() {
		return customerPortfolioID;
	}

	public void setCustomerPortfolioID(Integer customerPortfolioID) {
		this.customerPortfolioID = customerPortfolioID;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerAssessmentDetails [id=");
		builder.append(id);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", enquiryId=");
		builder.append(enquiryId);
		builder.append(", portfolioId=");
		builder.append(portfolioId);
		builder.append(", portfolioStatus=");
		builder.append(portfolioStatus);
		builder.append(", question=");
		builder.append(question);
		builder.append(", optionId=");
		builder.append(optionId);
		builder.append(", answer=");
		builder.append(answer);
		builder.append(", age=");
		builder.append(age);
		builder.append(", monthlyExpense=");
		builder.append(monthlyExpense);
		builder.append(", monthlyIncome=");
		builder.append(monthlyIncome);
		builder.append(", initialInvestement=");
		builder.append(initialInvestement);
		builder.append(", monthlyInvestment=");
		builder.append(monthlyInvestment);
		builder.append(", investmentPeriod=");
		builder.append(investmentPeriod);
		builder.append(", investmentStatus=");
		builder.append(investmentStatus);
		builder.append(", customerPortfolioID=");
		builder.append(customerPortfolioID);
		builder.append("]");
		return builder.toString();
	}

	

	

}

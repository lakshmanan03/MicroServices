package com.bfa.util;

public class DocumentType {
	
	private DocumentType() {
		// created constructor
	}
	
	public static final String NRIC_FRONT = "NRIC_FRONT";
	public static final String NRIC_BACK = "NRIC_BACK";
	public static final String PASSPORT = "PASSPORT";
	public static final String MAILING_ADDRESS_PROOF = "MAILING_ADDRESS_PROOF";
	public static final String RESIDENTIAL_ADDRESS_PROOF = "RESIDENTIAL_ADDRESS_PROOF";
	public static final String SUPPORTING_DOCUMENT = "SUPPORTING_DOCUMENT";
	public static final String BENEFICIARY_OWNER_DOCUMENT = "BENEFICIARY_OWNER_DOCUMENT";
}

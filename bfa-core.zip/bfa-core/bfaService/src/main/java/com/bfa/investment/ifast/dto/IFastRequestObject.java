/**
 * 
 */
package com.bfa.investment.ifast.dto;

/**
 * @author DivakarU
 *
 */
public interface IFastRequestObject {
	
	String getReferenceNumber();

}

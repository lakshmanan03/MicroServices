package com.bfa.investment.dto;


public class EmployerAddressDTO {
	private Integer id;
	private Integer employerId;
	private CustomerAddressDTO employerAddress;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getEmployerId() {
		return employerId;
	}
	public void setEmployerId(Integer employerId) {
		this.employerId = employerId;
	}
	public CustomerAddressDTO getEmployerAddress() {
		return employerAddress;
	}
	public void setEmployerAddress(CustomerAddressDTO employerAddress) {
		this.employerAddress = employerAddress;
	}
	
	
	

}

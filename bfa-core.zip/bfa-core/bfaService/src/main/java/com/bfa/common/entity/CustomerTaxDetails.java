package com.bfa.common.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;

@Entity
@Table(name = "customer_tax_details")
public class CustomerTaxDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	@OneToOne
	@JoinColumn(name = "tax_residency_country_id")
	private Country taxCountry;
	
	@Column(name = "tin")
	private String tinNumber;
	
	@Column(name = "no_tin_reason")
	private String noTinReason;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "last_updated_time_stamp")
	private Date lastModifiedDate;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Country getTaxCountry() {
		return taxCountry;
	}

	public void setTaxCountry(Country taxCountry) {
		this.taxCountry = taxCountry;
	}

	public String getTinNumber() {
		return tinNumber;
	}

	public void setTinNumber(String tinNumber) {
		this.tinNumber = tinNumber;
	}

	public String getNoTinReason() {
		return noTinReason;
	}

	public void setNoTinReason(String noTinReason) {
		this.noTinReason = noTinReason;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	
}

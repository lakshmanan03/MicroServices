/**
 * 
 */
package com.bfa.investment.ifast.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.common.entity.OptionItem;

/**
 * @author DivakarU
 *
 */

@Entity
@Table(name = "funding_account")
public class IFastFundingAccount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "customer_portfolio_id")
	private int customerPortfolioId;
	
	@Column(name = "ref_number")
	private String refNo;
	
	@Column(name = "trust_id")
	private String trustId;
	
	@Column(name = "account_balance")
	private Double balance;
	
	@Column(name = "customer_id")
	private int customerId;
	
	 @OneToOne
	@JoinColumn(name ="funding_type")
	private OptionItem fundingType;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "last_updated_date")
	private Date modifiedDate;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the customerPortfolioId
	 */
	public int getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	/**
	 * @param customerPortfolioId the customerPortfolioId to set
	 */
	public void setCustomerPortfolioId(int customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the trustId
	 */
	public String getTrustId() {
		return trustId;
	}

	/**
	 * @param trustId the trustId to set
	 */
	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}

	/**
	 * @return the balance
	 */
	public Double getBalance() {
		return balance;
	}

	/**
	 * @param balance the balance to set
	 */
	public void setBalance(Double balance) {
		this.balance = balance;
	}

	/**
	 * @return the customerId
	 */
	public int getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the fundingType
	 */
	public OptionItem getFundingType() {
		return fundingType;
	}

	/**
	 * @param fundingType the fundingType to set
	 */
	public void setFundingType(OptionItem fundingType) {
		this.fundingType = fundingType;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("IFastFundingAccount [id=");
		builder.append(id);
		builder.append(", customerPortfolioId=");
		builder.append(customerPortfolioId);
		builder.append(", refNo=");
		builder.append(refNo);
		builder.append(", trustId=");
		builder.append(trustId);
		builder.append(", balance=");
		builder.append(balance);
		builder.append(", customerId=");
		builder.append(customerId);
		builder.append(", fundingType=");
		builder.append(fundingType);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", modifiedDate=");
		builder.append(modifiedDate);
		builder.append("]");
		return builder.toString();
	}
			
}

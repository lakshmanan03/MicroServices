package com.bfa.investment.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.insurance.core.Customer;

@Entity
@Table(name="customer_document_details")
public class CustomerDocumentDetails implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	//@GenericGenerator(name="bfa", strategy = "identity")
	//@GeneratedValue(generator="bfa",strategy = GenerationType.IDENTITY)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@OneToOne
	@JoinColumn(name="customer_id")
	private Customer customer;
	
	@Column(name="filename")
	private String fileName;
	
	@Column(name="doc_type")
	private String docType;
	
	@OneToOne
	@JoinColumn(name="document_status_id")
	private DocumentStatusMaster documentStatus;

	@Column(name="review_comments")
	private String reviewComments;
	
	@Column(name="created_date")
	private Date createdDate;
	
	@Column(name="last_updated_time_stamp")
	private Date lastUpdatedTimeStamp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public DocumentStatusMaster getDocumentStatusId() {
		return documentStatus;
	}

	public void setDocumentStatus(DocumentStatusMaster documentStatus) {
		this.documentStatus = documentStatus;
	}
	
	public String getReviewComments() {
		return reviewComments;
	}

	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	
	
}

/**
 * 
 */
package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This is the model class for making the mailchimp API call.
 * BFA-1565
 * 
 * Most of the fields are configured at MailChimp service. Hence do not change any property.
 * 
 * @author pradheep
 *
 */
public class BundleMailChimpRequest {	
	
	@JsonProperty("email_address")
	private String email_address;	
	
	private String email_type;
	
	private String ip_signup;
	
	private MailChimpBundleRequestParameters merge_fields;
	
	@JsonProperty("status")
	private String status;

	public String getEmail_address() {
		return email_address;
	}

	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}

	public String getEmail_type() {
		return email_type;
	}

	public void setEmail_type(String email_type) {
		this.email_type = email_type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public MailChimpBundleRequestParameters getMerge_fields() {
		return merge_fields;
	}

	public void setMerge_fields(MailChimpBundleRequestParameters merge_fields) {
		this.merge_fields = merge_fields;
	}

	public String getIp_signup() {
		return ip_signup;
	}

	public void setIp_signup(String ip_signup) {
		this.ip_signup = ip_signup;
	}	
	
}

package com.bfa.common.entity;

public class Range {
	public double min;
	public double max;
	public double step;
	
	public Range(double min, double max, double step ) {
		this.min = min;
		this.max = max;
		this.step = step;
	}
	public double round(double value) {
		return Math.round(value / step) * step;
	}
}

/**
 * 
 */
package com.bfa.insurance.product;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "ranking_groups")
public class RankingGroup {

	@Id
	@GeneratedValue
	@Column(name = "ranking_group_id")
	private int rankingGroupId;

	@Column(name = "protection_type_id")
	private int protectionTypeId;

	@Column(name="rider_id")
	private int riderId;

	@Column(name="type_id")
	private int typeId;

	@Column(name="purpose_id")
	private int purposeId;

	@Column(name="objective_id")
	private int objectiveId;

	public int getRankingGroupId() {
		return rankingGroupId;
	}

	public void setRankingGroupId(int rankingGroupId) {
		this.rankingGroupId = rankingGroupId;
	}

	public int getProtectionTypeId() {
		return protectionTypeId;
	}

	public void setProtectionTypeId(int protectionTypeId) {
		this.protectionTypeId = protectionTypeId;
	}

	public int getRiderId() {
		return riderId;
	}

	public void setRiderId(int riderId) {
		this.riderId = riderId;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public int getPurposeId() {
		return purposeId;
	}

	public void setPurposeId(int purposeId) {
		this.purposeId = purposeId;
	}

	public int getObjectiveId() {
		return objectiveId;
	}

	public void setObjectiveId(int objectiveId) {
		this.objectiveId = objectiveId;
	}
}

package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

// 
@Entity
@Table(name = "sector_allocation_detail")
public class SectorAllocationDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	
	  @ManyToOne(fetch = FetchType.LAZY)
	  @JoinColumn(name = "sector_id", nullable = false)
	  @JsonIgnore
	  private Sector sector;
	  
	
	@Column(name = "title")
	private String sectorTitle;

	@Column(name = "region")
	private String sectorRegion;
	
	@Column(name = "percentage")
	private Double percentage;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public String getSectorTitle() {
		return sectorTitle;
	}
	
	

	public void setSectorTitle(String sectorTitle) {
		this.sectorTitle = sectorTitle;
	}

	public String getSectorRegion() {
		return sectorRegion;
	}

	public void setSectorRegion(String sectorRegion) {
		this.sectorRegion = sectorRegion;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}	
	
	
	
}

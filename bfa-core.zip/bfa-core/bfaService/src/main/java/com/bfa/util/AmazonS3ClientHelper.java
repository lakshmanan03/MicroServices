package com.bfa.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import org.apache.log4j.Logger;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;


public class AmazonS3ClientHelper {
	
	private String statementAccessKey;
	private String statementSecretKey;
	private String statementEndpointURL;
	private String bucketName;
		
	private AmazonS3 s3clientObj;
	
	private Logger logger;	

	public void loadProperties(String accessKey, String secretKey, String endpointURL, String bucketName) {
		this.statementAccessKey = accessKey;
		this.statementSecretKey = secretKey;
		this.bucketName = bucketName;
		this.statementEndpointURL =endpointURL;
		if (getLogger() != null) {
			getLogger().info("this.statementAccessKey: " + this.statementAccessKey);
			getLogger().info("this.statementSecretKey: " + this.statementSecretKey);
			getLogger().info("this.bucketName: " + this.bucketName);
			getLogger().info("this.statementEndpointURL: " + this.statementEndpointURL);
		}
	}	
	
	private boolean initializeAmazon() {
		AWSCredentials credentials = new BasicAWSCredentials(statementAccessKey, statementSecretKey);
		this.s3clientObj = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(Regions.AP_SOUTHEAST_1)
				.build();
		if (s3clientObj != null) {
			return true;
		} else {
			getLogger().info("S3 client obj null ");
		}
		return false;
	}	
	
	@Deprecated
	public S3ObjectInputStream downloadStream(String accessKey, String secretKey, String bucketName, String fileName) {
		 try {			
			if (initializeAmazon()) {
				S3Object s3Object = s3clientObj.getObject(bucketName, fileName);
				return s3Object.getObjectContent();
			} else {
				getLogger().info("downloadStream() ==> unable to download");
			}
		} catch (Exception e) {
			getLogger().error("Exception occured in downloadStream() : " , e);
		}
		return null;
	}
	
	@Deprecated
	public String uploadStatement(String bucketName, String fileName, File file) {
		String fileUrl = "";
		try {
			if(initializeAmazon()) {
				getLogger().info("bucketName===>" + bucketName + "\n" + "fileName===>" + fileName + "\n" + "statmentAccessKey====>"+ statementAccessKey);
				fileUrl = this.uploadStatement(bucketName, fileName, file, CannedAccessControlList.Private);
			} else {
				getLogger().info("unable to upload");
			}
		}catch(Exception e) {
			getLogger().error("Exception occured in uploadStatement() : " + e);
		}
		return fileUrl;
	}
	
	
	
	/*
	 *  method for upload monthly statements to s3 
	 */
	private String uploadStatement(String statementBucketName, String fileName, File file, CannedAccessControlList cannedACL) {
		String fileUrl = "";
		try {
			fileUrl = statementEndpointURL + "/" + statementBucketName + "/" + fileName;
			getLogger().info(statementEndpointURL + "/" + statementBucketName + "/" + fileName);
			getLogger().info("New Method upload " + fileUrl);
			s3clientObj.putObject(new PutObjectRequest(statementBucketName, fileName, file)
					.withCannedAcl(cannedACL));
		}catch(Exception e) {
			getLogger().error("Exception occured in uploadStatement() : " +  e);
		}
		return fileUrl;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.bfa.util.AmazonS3ClientService#upload(java.lang.String, java.lang.String, java.io.File, com.amazonaws.services.s3.model.CannedAccessControlList)
	 */
	public String upload(String bucketName, String fileName, File file, CannedAccessControlList cannedACL) {
		String fileUrl = "";
		try {
			fileUrl = statementEndpointURL + "/" + bucketName + "/" + fileName;
			getLogger().info("New Method upload " + fileUrl);
			s3clientObj.putObject(new PutObjectRequest(bucketName, fileName, file)
					.withCannedAcl(cannedACL));
		}catch(Exception e) {
			getLogger().error("Exception occured in upload() : " + e);
		}
		return fileUrl;
	}
	
	/*
	 * method for create folder with respect to the account name into S3
	 */
	
	public String createFolder(String statementBucketName, String folderName) {
		String status = "";
		try {
			if (initializeAmazon()) {
				InputStream input = new ByteArrayInputStream(new byte[0]);
				ObjectMetadata metadata = new ObjectMetadata();
				metadata.setContentLength(0);
				String bucketFolderName = statementBucketName + "/" + folderName;
				getLogger().info("bucketFolderName==>" + bucketFolderName);
				if (s3clientObj.doesBucketExistV2(bucketFolderName)) { // doesBucketExist - deprecated
					getLogger().info("Bucket %s already exists.\n" + bucketFolderName);
				} else {
					getLogger().info("Bucket needs to be created");
					PutObjectResult a = s3clientObj
							.putObject(new PutObjectRequest(statementBucketName, folderName, input, metadata));
					getLogger().info("Folder Created::::::    " + a.toString());
				}
				status = "created successfullly";
			}
        } catch(Exception e) {
        	getLogger().error("Exception occured in createFolder() : " + e);
        }
		return status;
	}
	
	
	
	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
}

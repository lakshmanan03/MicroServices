/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.core.RegularSavingsMapping;

/**
 * @author gajendrak
 *
 */
public class ComprehensiveRegularSavingsRequest {
	
	private boolean hasRegularSavings;
	
	private List<RegularSavingsMapping> comprehensiveRegularSavingsList;

	public boolean isHasRegularSavings() {
		return hasRegularSavings;
	}

	public void setHasRegularSavings(boolean hasRegularSavings) {
		this.hasRegularSavings = hasRegularSavings;
	}

	public List<RegularSavingsMapping> getComprehensiveRegularSavingsList() {
		return comprehensiveRegularSavingsList;
	}

	public void setComprehensiveRegularSavingsList(List<RegularSavingsMapping> comprehensiveRegularSavingsList) {
		this.comprehensiveRegularSavingsList = comprehensiveRegularSavingsList;
	}

}

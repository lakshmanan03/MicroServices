/**
 * 
 */
package com.bfa.application.security;

import java.util.Random;

/**
 * @author pradheep.p
 *
 */
public class TokenEncryptor {

	private int length = 7;

	private char[] random = { 'c', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
			's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C',
			'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
			'Y', 'Z' };

	private String getRandomString() {
		String arg = "";
		Random ran = new Random();
		for (int x = 0; x < length; x++) {
			int randomValue = ran.nextInt(random.length);
			arg = arg + random[randomValue];
		}
		return arg;
	}

	public String shuffleToken(String rawToken) {
		StringBuffer buffer = new StringBuffer(rawToken);
		return getRandomString() + buffer.reverse().toString();
	}

	public String rebaseToken(String shuffledToken) {
		String rebaseToken = shuffledToken.substring(length);
		StringBuffer buffer = new StringBuffer(rebaseToken);
		return buffer.reverse().toString();
	}

	public static void main(String args[]) {
		TokenEncryptor tEnc = new TokenEncryptor();
		System.out.println(tEnc.getRandomString());
		String rawToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJub3JtYWxfdXNlciIsInJvbGVzIjoiUk9MRV9VU0VSLCIsImlhdCI6MTU0NzY1MTY3NSwiaXNzIjoiQXV0aG9yaXphdGlvbiIsImV4cCI6MTU0NzY1NTI3NX0.p9udeMpZ970Grg4-QledhIo-SOVftRlzTFGjDn0Hfvo";
		System.out.println("Printing the raw token :" + rawToken);
		String sToken = tEnc.shuffleToken(rawToken);
		System.out.println("Printing the shuffled token " + sToken);
		String rebaseToken = tEnc.rebaseToken(sToken);
		System.out.println("Printing the rebase token :" + rebaseToken);
		if(rawToken.equals(rebaseToken)){
			System.out.println("Methods Works !");
		}
	}
}

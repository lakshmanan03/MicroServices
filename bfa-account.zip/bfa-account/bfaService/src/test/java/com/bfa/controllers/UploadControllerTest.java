package com.bfa.controllers;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.application.security.SecurityConstants;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.service.AccountsService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.DocumentType;
import com.bfa.util.InvestmentAccountStatus;
import com.bfa.util.ResponseMessageList;
import com.bfa.util.ServiceResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class UploadControllerTest {

	@InjectMocks
	private UploadController mUploadController;

	@Mock
	private HttpServletRequest mHttpServletRequest;

	@Mock
	private MultipartFile mMultipartFile;

	@Mock
	private AccountsService maccountService;

	@Mock
	private BFAUserDetails mBFAUserDetails;

	@Mock
	private ServiceResponse<Map<String, String>> mServiceResponse;

	@Mock
	private MOInvestmentService minvestmentService;

	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}

	@Test
	public void testSaveDocuments() {
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mHttpServletRequest.getAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST)).thenReturn(1);
		when(maccountService.getUserById(1)).thenReturn(mBFAUserDetails);
		ResponseMessageList response = mUploadController.saveDocuments(null, null, null, null, null, null, null, null,
				mHttpServletRequest);
		assertNotNull(response);
		String Details = "{'singaporePR': true,'myInfoVerified':false,'residentialAddress':'residentialAddress','mailingAddress':'mailingAddress',"
				+ " 'employmentDetails':'employmentDetails','householdDetails':'householdDetails','financialDetails':'financialDetails','taxDetails':'taxDetails','personalDeclarations':'personalDeclarations','sameAsMailingAddress':true}";
		ResponseMessageList response1 = mUploadController.saveDocuments(mMultipartFile, mMultipartFile, mMultipartFile,
				mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, Details, mHttpServletRequest);
		assertNotNull(response1);
	}

	@Test
	public void testSaveDocuments_FileUpload() {
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mHttpServletRequest.getAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST)).thenReturn(1);
		when(maccountService.getUserById(1)).thenReturn(mBFAUserDetails);
		when(mServiceResponse.isSuccess()).thenReturn(true);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.NRIC_FRONT)).thenReturn(mServiceResponse);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.NRIC_BACK)).thenReturn(mServiceResponse);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.MAILING_ADDRESS_PROOF))
				.thenReturn(mServiceResponse);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.PASSPORT)).thenReturn(mServiceResponse);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.RESIDENTIAL_ADDRESS_PROOF))
				.thenReturn(mServiceResponse);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.BENEFICIARY_OWNER_DOCUMENT))
				.thenReturn(mServiceResponse);
		when(maccountService.saveDocument(1, mMultipartFile, DocumentType.SUPPORTING_DOCUMENT))
				.thenReturn(mServiceResponse);
		
		ResponseMessageList response2 = mUploadController.saveDocuments(mMultipartFile, mMultipartFile, mMultipartFile,
				mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, null, mHttpServletRequest);
		assertNotNull(response2);
		
		when(minvestmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED))
		.thenThrow(new RuntimeException());
		ResponseMessageList response3 = mUploadController.saveDocuments(mMultipartFile, mMultipartFile, mMultipartFile,
				mMultipartFile, mMultipartFile, mMultipartFile, mMultipartFile, null, mHttpServletRequest);
		assertNotNull(response3);
		
	}

	@Test
	public void testSaveDocumentsV2() {
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mHttpServletRequest.getAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST)).thenReturn(1);
		when(mServiceResponse.isSuccess()).thenReturn(true);
		when(maccountService.getUserById(1)).thenReturn(mBFAUserDetails);
		when(maccountService.saveDocumentV2(1, mHttpServletRequest, DocumentType.NRIC_FRONT))
				.thenReturn(mServiceResponse);
		when(minvestmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED))
				.thenReturn(null);
		ResponseMessageList response = mUploadController.saveDocumentsV2(mHttpServletRequest, "details");
		assertNotNull(response);
	}
	
	@Test
	public void testSaveDocumentsV2_else() {
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mHttpServletRequest.getAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST)).thenReturn(1);
		when(mServiceResponse.isSuccess()).thenReturn(false);
		when(maccountService.getUserById(1)).thenReturn(mBFAUserDetails);
		when(maccountService.saveDocumentV2(1, mHttpServletRequest, DocumentType.NRIC_FRONT))
				.thenReturn(mServiceResponse);
		when(minvestmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED))
				.thenReturn(null);
		ResponseMessageList response = mUploadController.saveDocumentsV2(mHttpServletRequest, "details");
		assertNotNull(response);
	}

	@Test
	public void testSaveDocumentsV2_Exception() {
		when(mBFAUserDetails.getId()).thenReturn(1);
		when(mHttpServletRequest.getAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST)).thenReturn(1);
		when(mServiceResponse.isSuccess()).thenReturn(true);
		when(maccountService.getUserById(1)).thenReturn(mBFAUserDetails);
		when(maccountService.saveDocumentV2(1, mHttpServletRequest, DocumentType.NRIC_FRONT))
				.thenReturn(mServiceResponse);
		when(minvestmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED))
		.thenThrow(new RuntimeException());
		ResponseMessageList response = mUploadController.saveDocumentsV2(mHttpServletRequest, "details");
		assertNotNull(response);
	}

}

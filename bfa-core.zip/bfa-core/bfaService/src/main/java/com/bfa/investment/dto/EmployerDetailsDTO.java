package com.bfa.investment.dto;

import com.bfa.common.entity.EmployerDetails;

public class EmployerDetailsDTO {
	private EmployerDetails detailedEmployerDetails;
	private EmployerAddressDTO detailedemployerAddress;
	private String employerContact;
	public String getEmployerContact() {
		return employerContact;
	}
	public void setEmployerContact(String employerContact) {
		this.employerContact = employerContact;
	}
	public EmployerDetails getDetailedEmployerDetails() {
		return detailedEmployerDetails;
	}
	public void setDetailedEmployerDetails(EmployerDetails detailedEmployerDetails) {
		this.detailedEmployerDetails = detailedEmployerDetails;
	}
	public EmployerAddressDTO getDetailedemployerAddress() {
		return detailedemployerAddress;
	}
	public void setDetailedemployerAddress(EmployerAddressDTO detailedemployerAddress) {
		this.detailedemployerAddress = detailedemployerAddress;
	}
	
	

}

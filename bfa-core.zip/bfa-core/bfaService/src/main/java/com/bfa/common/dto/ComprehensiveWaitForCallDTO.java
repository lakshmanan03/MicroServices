/**
 * 
 */
package com.bfa.common.dto; 

public class ComprehensiveWaitForCallDTO {
		
	private Integer customerId;
	
	private String generatedToken;
	
	private Boolean waitForCall;	

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getGeneratedToken() {
		return generatedToken;
	}

	public void setGeneratedToken(String generatedToken) {
		this.generatedToken = generatedToken;
	}

	public Boolean getWaitForCall() {
		return waitForCall;
	}

	public void setWaitForCall(Boolean waitForCall) {
		this.waitForCall = waitForCall;
	}

	

}

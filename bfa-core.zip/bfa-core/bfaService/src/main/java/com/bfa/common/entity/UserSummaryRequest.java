/**
 * 
 */
package com.bfa.common.entity;

/**
 * 
 * @author GajendraK
 *
 */
public class UserSummaryRequest {

	/**
	 * Accepted values are 1. insurance-guided 2. insurance-direct 3.investment
	 * 4. will-writing
	 */
	private String requestType;	
	
	private String sessionId;
	
	private Boolean isReport;

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public Boolean getIsReport() {
		return isReport;
	}

	public void setIsReport(Boolean isReport) {
		this.isReport = isReport;
	}
}

/**
 * 
 */
package com.bfa.request.processor;

import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.util.BFAHttpResponse;

/**
 * @author pradheep.p
 *
 */
public class HttpRequestSuccessHandler extends SuccessHandler implements BFAHttpOperations {
	
	private ProcessorCommand command = null;
	
	@Autowired
	private QueueProcessorController queueProcessorController;
	
	private BFAHttpResponse bfaHttpResponse;
	
	@Override
	public void run() {
		ProcessorCommand command = (ProcessorCommand) getSource();
		System.out.println("Successfully updated the Job : " + command.uniqueKey + " Failure Count :"+ command.failureCount);
		ProcessorCommand nextLevelCommand = getNextCommand();
		if(nextLevelCommand != null){
			if(nextLevelCommand instanceof BFAHttpOperations){
				BFAHttpOperations httpOperations = (BFAHttpOperations) nextLevelCommand;
				httpOperations.setPreOpreratedResponse(getPreOpreratedResponse());
			}
			queueProcessorController.addJobToQueue(nextLevelCommand);
		}
	}
	
	private ProcessorCommand getNextCommand(){
		return this.command;
	}

	@Override
	public void setNextCommand(ProcessorCommand processorCommand) {		
		this.command = processorCommand;
	}

	@Override
	public BFAHttpResponse getPreOpreratedResponse() {		
		return bfaHttpResponse;
	}

	@Override
	public void setPreOpreratedResponse(BFAHttpResponse httpResponse) {		
		this.bfaHttpResponse = httpResponse;
	}

}

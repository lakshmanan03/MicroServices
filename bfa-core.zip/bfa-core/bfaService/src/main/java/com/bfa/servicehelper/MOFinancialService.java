package com.bfa.servicehelper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;

import com.bfa.application.discovery.DiscoveryService;
import com.bfa.common.dto.CustomerFinancialDataDTO;
import com.bfa.common.dto.FinancialDTO;
import com.bfa.util.APIResponse;
import com.bfa.util.PublicUtility;
import com.google.common.reflect.TypeToken;

public class MOFinancialService extends MOServiceHelper {
	

	@Autowired
	private DiscoveryService discoveryService;
	
	/** Logger available to subclasses */
	protected final Log logger = LogFactory.getLog(getClass());
	protected String appKey = "IMXYlDmP4f4=";

	protected PublicUtility utility = PublicUtility.getInstance(appKey);


	

	//Get financial details call
	
	public FinancialDTO getFinacialDetailsByCustomerId(){
		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		FinancialDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.FinanceService.getFinacialDetailsByCustomerId());
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (response != null) {
			TypeToken<APIResponse<FinancialDTO>> typeToken = new TypeToken<APIResponse<FinancialDTO>>() {
			};
			APIResponse<FinancialDTO> apiResponse = APIResponse
					.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (apiResponse != null && apiResponse.getObjectList() != null) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
	
	public CustomerFinancialDataDTO getFinancialData(Boolean isAdmin, String customerId) {
		String authorizationToken = discoveryService.preAuthorizeV2(Integer.valueOf(utility.DecryptText(customerId)));
//		String authorizationToken = getCurrentHttpRequest().getHeader("Authorization");
		CustomerFinancialDataDTO dto = null;
		MOServiceRequest request = new MOServiceRequest();
		request.setUrl(URLDirectory.FinanceService.financialData(isAdmin, customerId));
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("GET");
		MOServiceResponse response = get(request);
		if (!ObjectUtils.isEmpty(response)) {
			TypeToken<APIResponse<CustomerFinancialDataDTO>> typeToken = new TypeToken<APIResponse<CustomerFinancialDataDTO>>() {
			};
			APIResponse<CustomerFinancialDataDTO> apiResponse = APIResponse
					.parseAbstractResponse(response.getResponseBody(), typeToken);
			if (!ObjectUtils.isEmpty(apiResponse) && !ObjectUtils.isEmpty(apiResponse.getObjectList())) {
				dto = apiResponse.getObjectList();
			}
		}
		return dto;
	}
		
	
	
}

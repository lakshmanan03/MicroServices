/**
 * 
 */
package com.bfa.insurance;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.SessionDetails;

/**
 * This test is to check the features of BFA 1587
 * 
 * BFA-1587
 * 
 * @author pradheep.p
 *
 */
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure = false)
@ContextConfiguration
//@Sql(scripts = { "classpath:bfa-1578/enq_by_email_base_script.sql" })
public class EnquiryByEmailTest {
	
//	@Mock
	private MockMvc mockMvc;

	private String enquiryByEmailAPI = "/api/enquiryByEmail";	

	private String sessionId = "51c3f8b5-feb0-4e2f-b98b-45cffceae575";	

	private String captchaStr = "";

	@Mock
	private TokenProvider tokenProvider;

//	@InjectMocks
	@Mock
	private AccountsDao accountsDao;

	String authHeader = "";

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	@Before
	public void start(){
		System.out.println("Starting test for enquiry by email address.");
	}

	public void init(String captcha) {
		System.out.println("-- Initializing the bfa-1578 tests -- ");
		authHeader = getAuthToken();
		saveSessionDetails(captcha);	
	}

	/**
	 * Loads the captcha required for testing.
	 */
	private void saveSessionDetails(String captcha) {
		String hql = "delete from SessionDetails";
		accountsDao.executeUpdate(hql);
		// -----------------------------------------//
		SessionDetails sessionDetails = new SessionDetails();
		sessionDetails.setBrowser("None");
		sessionDetails.setCaptcha(captcha);
		sessionDetails.setDevice("None");
		sessionDetails.setSessionId(sessionId);
		accountsDao.saveOrUpdateObject(sessionDetails);
	}	

	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_USER");
		BFAGrandtedAuthority grantedAuthority2 = new BFAGrandtedAuthority("ROLE_SIGNED_USER");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		authorities.add(grantedAuthority2);
		return tokenProvider.getTokenString("-1", authorities);
	}
	
	private String getEnquiryByEmailRequestBody(String fileName) {
		String str = "";
		StringBuffer buffer = new StringBuffer();
		Resource res = new ClassPathResource(fileName);
		InputStream inputStream;
		try {
			inputStream = res.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
			if (inputStream != null) {
				while ((str = reader.readLine()) != null) {
					buffer.append(str + "\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}

	/**
	 * Normal test - Positive case
	 */
	@Test	
	public void testEnquiryByEmailAddress() {
		init(captchaStr);
		printDelimiter();
		System.out.println("-- Testing enquiry made by email address :Postitive case test--");
		printDelimiter();
				
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";			
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(enquiryByEmailAPI).contentType(this.APPLICATION_JSON_UTF8)
							.content(getEnquiryByEmailRequestBody("bfa-1578/bfa-1578-test-data.json").getBytes()).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "6000").exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Invalid Email address - Negative Case
	 */
	@Test	
	public void testEnquiryByEmailAddress1() {
		init(captchaStr);
		printDelimiter();
		System.out.println("-- Testing enquiry made by email address : Invalid email address test --");
		printDelimiter();
				
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";			
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(enquiryByEmailAPI).contentType(this.APPLICATION_JSON_UTF8)
							.content(getEnquiryByEmailRequestBody("bfa-1578/invalid-email-test-data.json").getBytes()).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5006").exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Invalid Session ID - Negative Case
	 */
	@Test	
	public void testEnquiryByEmailInvalidSession() {
		init(captchaStr);
		printDelimiter();
		System.out.println("-- Testing enquiry made by email address : invalid session id test --");
		printDelimiter();
				
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";			
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(enquiryByEmailAPI).contentType(this.APPLICATION_JSON_UTF8)
							.content(getEnquiryByEmailRequestBody("bfa-1578/invalid-session-test-data.json").getBytes()).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5015").exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Invalid Captcha - Negative Case
	 */
	@Test	
	public void testEnquiryByEmailInvalidCaptcha() {
		init("abcdef");
		printDelimiter();
		System.out.println("-- Testing enquiry made by email address : Invalid captcha test--");
		printDelimiter();
				
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";			
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(enquiryByEmailAPI).contentType(this.APPLICATION_JSON_UTF8)
							.content(getEnquiryByEmailRequestBody("bfa-1578/invalid-captcha-test-data.json").getBytes()).header("Authorization",
									authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "5016").exists());
			result.andDo(MockMvcResultHandlers.print());
			printEndTest();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void printDelimiter() {
		System.out.println("---------------------------------------------------------------");
	}

	private void printEndTest() {
		System.out.println("--------------------- Test End ---------------------------------");
	}
}

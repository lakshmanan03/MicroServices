package com.bfa.controllers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCode;
import com.bfa.application.core.PromoCodeRequest;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.service.PromoCodeService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ResponseMessageList;

@RunWith(SpringJUnit4ClassRunner.class)
public class PromoCodeControllerTest {

	@InjectMocks
	private PromoCodeController mPromoCodeController;
	
	@Mock
	private PromoCodeRepository mPromoCodeRepository;
	
	@Mock
	private PromoCodeService mPromoCodeService;
	
	@Mock
	private PromoCodeRequest mPromoCodeRequest;
	
	@Mock
	private Map<String, Object> jsonData;
	
	@Mock
	private PromoCode mPromoCode;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private EnquiryResponseMessage mEnquiryResponseMessage;
	
	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	@Test
	public void testValidatePromoCode() {

		String str = "2015-03-31";
		Date mStartdate = Date.valueOf(str);
		String str1 = "2021-03-31";
		Date mEndDate = Date.valueOf(str1);
			when(jsonData.get("sessionId")).thenReturn("123-564");
			when(jsonData.get("promoCode")).thenReturn("promocode");
			when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
			when(mPromoCode.getId()).thenReturn(123);
			when(mPromoCode.getStatus()).thenReturn("A");
			when(mPromoCode.getStartDate()).thenReturn(mStartdate);
			when(mPromoCode.getEndDate()).thenReturn(mEndDate);
			when(mPromoCodeRepository.findByCodeAndCategory("promocode", "INVEST")).thenReturn(mPromoCode);
			when(mPromoCodeService.getEnquiryReference(mPromoCodeRequest)).thenReturn(mEnquiryResponseMessage);
			ResponseMessageList response = mPromoCodeController.validatePromoCode(jsonData);
			assertEquals(ErrorCodes.PROMO_CODE_VERIFICATION_SUCCESSFUL, response.getResponseMessage().getResponseCode());
			assertEquals(ApplicationConstants.VALIDATION_SUCCESS, response.getResponseMessage().getResponseDescription());
	}
	
	@Test
	public void testValidatePromoCodeException() {

		String str = "2015-03-31";
		Date mStartdate = Date.valueOf(str);
		String str1 = "2021-03-31";
		Date mEndDate = Date.valueOf(str1);
			when(jsonData.get("sessionId")).thenReturn("123-564");
			when(jsonData.get("promoCode")).thenReturn("promocode");
			when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
			when(mPromoCode.getId()).thenReturn(123);
			when(mPromoCode.getStatus()).thenReturn("B");
			when(mPromoCode.getStartDate()).thenReturn(mStartdate);
			when(mPromoCode.getEndDate()).thenReturn(mEndDate);
			when(mPromoCodeRepository.findByCodeAndCategory("promocode", "INVEST")).thenReturn(mPromoCode);
			ResponseMessageList response = mPromoCodeController.validatePromoCode(jsonData);
			assertNotNull(response);
	}
	
	@Test
	public void testValidatePromoCodeExce() {

		String str = "2015-03-31";
		Date mStartdate = Date.valueOf(str);
		String str1 = "2021-03-31";
		Date mEndDate = Date.valueOf(str1);
			when(jsonData.get("sessionId")).thenReturn(null);
			when(jsonData.get("promoCode")).thenReturn("promocode");
			when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
			when(mPromoCode.getId()).thenReturn(123);
			when(mPromoCode.getStatus()).thenReturn("B");
			when(mPromoCode.getStartDate()).thenReturn(mStartdate);
			when(mPromoCode.getEndDate()).thenReturn(mEndDate);
			when(mPromoCodeRepository.findByCodeAndCategory("promocode", "INVEST")).thenReturn(null);
			ResponseMessageList response = mPromoCodeController.validatePromoCode(jsonData);
			assertNotNull(response);

	}


	@Test(expected = NullPointerException.class)
	public void testSaveCustomerPromoCode() {
		
		when(jsonData.get("customerId")).thenReturn("4531");
		when(jsonData.get("promoCode")).thenReturn("promocode");
		when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
		when(jsonData.get("promoCodeId")).thenReturn("12354");
		ResponseMessageList response = mPromoCodeController.saveCustomerPromoCode(jsonData);
		assertNotNull(response);
	}
	
	
	@Test
	public void saveCustomerPromoCodeTest() {
		
		when(jsonData.get("customerId")).thenReturn("-1");
		when(jsonData.get("promoCode")).thenReturn("promocode");
		when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
		when(jsonData.get("promoCodeId")).thenReturn("12354");
		ResponseMessageList response = mPromoCodeController.saveCustomerPromoCode(jsonData);
		assertNotNull(response);
	}
	
	@Test
	public void testSaveCustomerPromoCodeException() {
		
		when(jsonData.get("customerId")).thenReturn("4531");
		when(jsonData.get("promoCode")).thenReturn("promocode");
		when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
		when(jsonData.get("promoCodeId")).thenReturn("");
		when(mPromoCode.getId()).thenReturn(1234);
		when(mPromoCodeRepository.findByCodeAndCategory("promocode", "")).thenReturn(mPromoCode);
		ResponseMessageList response = mPromoCodeController.saveCustomerPromoCode(jsonData);
		assertNotNull(response);
	}

	@Test
	public void testGetDefaultEmailPromoCode() {
		
		when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
		when(mPromoCodeRepository.findByCategoryAndIsDefault("INVEST", "Y")).thenReturn(null);
		ResponseMessageList response = mPromoCodeController.getDefaultEmailPromoCode(jsonData);
		assertNotNull(response);
	}
	
	@Test
	public void testGetDefaultEmailPromoCodeElse() {
		
		when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
		when(mPromoCodeRepository.findByCategoryAndIsDefault("INVEST", "Y")).thenReturn(mPromoCode);
		ResponseMessageList response = mPromoCodeController.getDefaultEmailPromoCode(jsonData);
		assertNotNull(response);
	}
	
	@Test
	public void testGetDefaultEmailPromoCodeException() {
		
		when(jsonData.get("promoCodeCat")).thenReturn("INVEST");
		when(mPromoCodeRepository.findByCategoryAndIsDefault("INVEST", "Y")).thenThrow(new RuntimeException());
		ResponseMessageList response = mPromoCodeController.getDefaultEmailPromoCode(jsonData);
		assertNotNull(response);
	}
}

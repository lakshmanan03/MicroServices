/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveLiabilitiesDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private Integer id;
	
	@JsonIgnore
	private Integer customerId;

	private Integer enquiryId;

	private Double homeLoanOutstandingAmount;

	private Double otherPropertyLoanOutstandingAmount;

	private Double otherLoanOutstandingAmount;

	private Double carLoansAmount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getOtherPropertyLoanOutstandingAmount() {
		return otherPropertyLoanOutstandingAmount;
	}

	public void setOtherPropertyLoanOutstandingAmount(Double otherPropertyLoanOutstandingAmount) {
		this.otherPropertyLoanOutstandingAmount = otherPropertyLoanOutstandingAmount;
	}

	public Double getOtherLoanOutstandingAmount() {
		return otherLoanOutstandingAmount;
	}

	public void setOtherLoanOutstandingAmount(Double otherLoanOutstandingAmount) {
		this.otherLoanOutstandingAmount = otherLoanOutstandingAmount;
	}

	public Double getHomeLoanOutstandingAmount() {
		return homeLoanOutstandingAmount;
	}

	public void setHomeLoanOutstandingAmount(Double homeLoanOutstandingAmount) {
		this.homeLoanOutstandingAmount = homeLoanOutstandingAmount;
	}

	public Double getCarLoansAmount() {
		return carLoansAmount;
	}

	public void setCarLoansAmount(Double carLoansAmount) {
		this.carLoansAmount = carLoansAmount;
	}

}

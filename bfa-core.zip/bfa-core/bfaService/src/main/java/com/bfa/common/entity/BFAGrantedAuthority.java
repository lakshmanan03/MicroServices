package com.bfa.common.entity;

import org.springframework.security.core.GrantedAuthority;

public class BFAGrantedAuthority implements GrantedAuthority {

	private String authorityType;
	public BFAGrantedAuthority(String authorityType) {
		this.authorityType = authorityType; 	
	}
	
	@Override
	public String getAuthority() {
		return authorityType;
	}

}

package com.bfa.serviceimpl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.application.core.CustomerIssuedToken;
import com.bfa.dao.AccountsDao;
@RunWith(SpringJUnit4ClassRunner.class)
public class UserAuthTokenUpdaterTest {

	@InjectMocks
	private UserAuthTokenUpdater mUserAuthTokenUpdater;

	@Mock
	private AccountsDao mAccountsDao;
	
	@Mock
	private CustomerIssuedToken mCustomerIssuedToken;

	private Integer customerId;

	List<CustomerIssuedToken> cusTokenList = new ArrayList<>();
	
	String token = "517879a9-f65e-4f65-a0a3-0234a54be704";

	@Test(expected=NullPointerException.class)
	public void testRun() {
		cusTokenList.add(mCustomerIssuedToken);
		when(mCustomerIssuedToken.getTokenValue()).thenReturn(token);
		when(mAccountsDao.getObjectsById(CustomerIssuedToken.class, "customerId", customerId)).thenReturn(cusTokenList);
		mUserAuthTokenUpdater.run();
	}

}

package com.bfa.util;

import java.util.Map;

import com.bfa.insurance.core.Customer;
import com.bfa.investment.entity.CustomerInvestmentAccountInfo;
/*
 * @Author Vimala Shan
 */
import com.bfa.investment.entity.PortfolioTransactionDetails;

public interface EmailQueueHelper {
	public void sendEmail(Customer customer, String toEmail, String ccEmail, boolean ccToCustomer,
			PortfolioTransactionDetails transactionObj, String ftlTemplate, String subject);

	public void sendEmail(Customer customer, String toEmail, String ccEmail, PortfolioTransactionDetails transactionObj,
			String ftlTemplate, String subject);

	public void sendEmail(Customer customer, String toEmail, boolean ccToCustomer,
			PortfolioTransactionDetails transactionObj, String ftlTemplate, String subject);

	public void sendEmail(Customer customer, String toEmail, PortfolioTransactionDetails transactionObj,
			String ftlTemplate, String subject);

	public void sendEmail(Customer customer, PortfolioTransactionDetails transactionObj, String ftlTemplate,
			String subjectKey);
	
	public void sendEmail(Customer customer, String referenceNo, String ftlTemplate,String subjectKey);
	
	public void sendEmail(CustomerInvestmentAccountInfo customerInfo, Map<String,Object> additionalInfo, String ftlTemplate,
			String subject);
}

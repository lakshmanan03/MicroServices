/**
 * 
 */
package com.bfa.notification.messenger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Customer;
import com.bfa.notification.EmailMessageObject;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.PublicUtility;

/**
 * @author GajendraK
 *
 */
public class WelcomeEmailInitiator implements Runnable {

	private Customer customer;

	private String callBackUrl;
	
	private String hostedServerName;
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private String appKey = "FUDq3FpzKW4=";

	@Autowired
	private MessengerDelegate messengerDelegate;
	
	@Autowired
	private Environment environment;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	private String getWelcomeEmailBody() {
		Resource res = new ClassPathResource("welcome_email.template");
		InputStream ins = null;
		try {
			ins = res.getInputStream();
		} catch (IOException e) {			
			getLogger().error("IOException while fetching welcome email body: " + e);
		}
		StringBuffer buffer = new StringBuffer();
		InputStreamReader reader = new InputStreamReader(ins);
		BufferedReader bReader = new BufferedReader(reader);
		String str = null;
		try {
			while ((str = bReader.readLine()) != null) {
				buffer.append(str);
			}
		} catch (IOException e) {
			getLogger().error("IOException while get welcome email body: " + e);
		} finally {
			try {
				if (ins != null) {
					ins.close();
				}
			} catch (IOException e) {
				getLogger().error("Exception while get welcome email body: " + e);
			}
		}
		return buffer.toString();
	}
	
	@Override
	public void run() {		
		sendWelcomeEmailComprehensive(customer);
	}
	
	private void sendWelcomeEmailComprehensive(Customer customer) {		
		EmailMessageObject emailMessageObj = new EmailMessageObject();
		String customerName = customer.getGivenName();
		getLogger().info("Sending email .. " + new Date() + " to " + customerName);
		PublicUtility utility = PublicUtility.getInstance(appKey);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		Date obj = new Date();
		String encryptedData = sdf.format(obj) + ApplicationConstants.DELIMITER + customer.getEmail()
				+ ApplicationConstants.DELIMITER + customer.getId();
		encryptedData = utility.EncryptText(encryptedData);
		String token = Base64.getEncoder().encodeToString(encryptedData.getBytes());
		getLogger().info("Printing the base 64 encoded " + token);
		String str = this.callBackUrl + "?confirmation_token=" + token;
		String body = getWelcomeEmailBody();
		body = body.replace("#firstName", customer.getGivenName());
		body = body.replace("#lastName", customer.getSurName());
		body = body.replace("#content1", str);
		body = body.replace("#content2", str);
		String domainImagePath = environment.getProperty("server.context.domain", "");
		getLogger().info("Printing the body of the domainImagePath :" + domainImagePath);
		body = body.replace("#machine_domainRoot#", domainImagePath);
		String imagePath = environment.getProperty("server.context.sub.domain", "");
		body = body.replace("#machine_address#", getHostedServerName() + imagePath);
		body = body.replace("#contact_email#", environment.getProperty("email.support.contact", ""));
		body = body.replace("#contact_number#", environment.getProperty("mobile.support.contact", ""));
		emailMessageObj.setBodyOfMessage(body);
		emailMessageObj.setFooterInformation("");
		String[] toList = { customer.getEmail() };
		String[] bccList = {"enquiries@moneyowl.com.sg"};
		emailMessageObj.setToList(toList);
		emailMessageObj.setFromAddress("notifications@moneyowl.sg");
		emailMessageObj.setBccList(bccList);
		emailMessageObj.setSubjectOfMessage("Promo Code from MoneyOwl - Start Your Comprehensive Financial Planning Now!");
		getLogger().info("Printing the body of the email :" + body);
		messengerDelegate.communicateMessage(emailMessageObj, Messenger.EMAIL_MESSAGE);
	}
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getCallBackUrl() {
		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	public String getHostedServerName() {
		return hostedServerName;
	}

	public void setHostedServerName(String hostedServerName) {
		this.hostedServerName = hostedServerName;
	}

}

package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.EmployerDetails;

public interface EmployerDetailsRepository extends CrudRepository<EmployerDetails, String> {
	Optional<EmployerDetails>  findFirstById(Integer employerId);

}

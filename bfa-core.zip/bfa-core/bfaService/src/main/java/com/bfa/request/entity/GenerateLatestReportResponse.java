package com.bfa.request.entity;

import java.sql.Timestamp;

public class GenerateLatestReportResponse {

	private Integer id;
	
	private Integer customerId;
	
	private Integer enquiryId;
	
	private String reportType;
	
	private String status;
	
	private String cpfExcelLocation;
	
	private String rptExcelLocation;
	
	private String rptLocation;	
	
	private Timestamp rptGenTs;
	
	private String errorCode;
	
	private String errorMsg;
	
	private Integer retryCount;
	
	private Integer version;
	
	private Timestamp rptSubmitTs;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the customerId
	 */
	public Integer getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the enquiryId
	 */
	public Integer getEnquiryId() {
		return enquiryId;
	}

	/**
	 * @param enquiryId the enquiryId to set
	 */
	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
	
	/**
	 * @return the report type 
	 */
	public String getReportType() {
		return reportType;
	}
	
	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the cpfExcelLocation
	 */
	public String getCpfExcelLocation() {
		return cpfExcelLocation;
	}

	/**
	 * @param cpfExcelLocation the cpfExcelLocation to set
	 */
	public void setCpfExcelLocation(String cpfExcelLocation) {
		this.cpfExcelLocation = cpfExcelLocation;
	}

	/**
	 * @return the rptExcelLocation
	 */
	public String getRptExcelLocation() {
		return rptExcelLocation;
	}

	/**
	 * @param rptExcelLocation the rptExcelLocation to set
	 */
	public void setRptExcelLocation(String rptExcelLocation) {
		this.rptExcelLocation = rptExcelLocation;
	}

	/**
	 * @return the rptLocation
	 */
	public String getRptLocation() {
		return rptLocation;
	}

	/**
	 * @param rptLocation the rptLocation to set
	 */
	public void setRptLocation(String rptLocation) {
		this.rptLocation = rptLocation;
	}

	/**
	 * @return the rptGenTs
	 */
	public Timestamp getRptGenTs() {
		return rptGenTs;
	}

	/**
	 * @param rptGenTs the rptGenTs to set
	 */
	public void setRptGenTs(Timestamp rptGenTs) {
		this.rptGenTs = rptGenTs;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the retryCount
	 */
	public Integer getRetryCount() {
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}

	/**
	 * @return the rptSubmitTs
	 */
	public Timestamp getRptSubmitTs() {
		return rptSubmitTs;
	}

	/**
	 * @param rptSubmitTs the rptSubmitTs to set
	 */
	public void setRptSubmitTs(Timestamp rptSubmitTs) {
		this.rptSubmitTs = rptSubmitTs;
	}

}

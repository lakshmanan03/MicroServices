/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveRetirementPlanningDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private Integer customerId;
	
	private Integer enquiryId;
	
	private String retirementAge;
	
	private Boolean haveOtherSourceRetirementIncome;
	
	private Set<ComprehensiveRetirementIncomeDTO> retirementIncomeSet;
	
	private Set<ComprehensiveRetirementLumpSumDTO> lumpSumBenefitSet;

	
	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(String retirementAge) {
		this.retirementAge = retirementAge;
	}

	public Boolean getHaveOtherSourceRetirementIncome() {
		return haveOtherSourceRetirementIncome;
	}

	public void setHaveOtherSourceRetirementIncome(Boolean haveOtherSourceRetirementIncome) {
		this.haveOtherSourceRetirementIncome = haveOtherSourceRetirementIncome;
	}

	public Set<ComprehensiveRetirementIncomeDTO> getRetirementIncomeSet() {
		return retirementIncomeSet;
	}

	public void setRetirementIncomeSet(Set<ComprehensiveRetirementIncomeDTO> retirementIncomeSet) {
		this.retirementIncomeSet = retirementIncomeSet;
	}

	public Set<ComprehensiveRetirementLumpSumDTO> getLumpSumBenefitSet() {
		return lumpSumBenefitSet;
	}

	public void setLumpSumBenefitSet(Set<ComprehensiveRetirementLumpSumDTO> lumpSumBenefitSet) {
		this.lumpSumBenefitSet = lumpSumBenefitSet;
	}

}

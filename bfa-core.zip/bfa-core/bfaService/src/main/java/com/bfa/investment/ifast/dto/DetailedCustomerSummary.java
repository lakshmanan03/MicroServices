package com.bfa.investment.ifast.dto;

import java.util.List;

import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.dto.NationalityDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;

public class DetailedCustomerSummary {
	private Customer customer;
	private CustomerEmploymentInformation employmentInformation;
	private Income income;
	private Assets assets;
	private Liabilities liabilities;
	private List<CustomerTaxDetails> taxDetails;
	private CustomerInvestmentObjective investmentObjective;
	private CustomerPEPDetails pepDetails;
	private CustomerSrsAccount srsDetails;
	private CustomerAdditionalDetails additionalDetails;
	private CustomerIdentityDetails identityDetails;
	private List<CustomerDocumentDetails> documentDetails;
	private Boolean isMyInfoVerified;
	private NationalityDTO nationality;
	

	
	
	
	public CustomerIdentityDetails getIdentityDetails() {
		return identityDetails;
	}

	public void setIdentityDetails(CustomerIdentityDetails identityDetails) {
		this.identityDetails = identityDetails;
	}

	public CustomerAdditionalDetails getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(CustomerAdditionalDetails additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public CustomerEmploymentInformation getEmploymentInformation() {
		return employmentInformation;
	}
	public void setEmploymentInformation(CustomerEmploymentInformation employmentInformation) {
		this.employmentInformation = employmentInformation;
	}

	public Income getIncome() {
		return income;
	}
	public void setIncome(Income income) {
		this.income = income;
	}
	public Assets getAssets() {
		return assets;
	}
	public void setAssets(Assets assets) {
		this.assets = assets;
	}
	public Liabilities getLiabilities() {
		return liabilities;
	}
	public void setLiabilities(Liabilities liabilities) {
		this.liabilities = liabilities;
	}
	
	public CustomerInvestmentObjective getInvestmentObjective() {
		return investmentObjective;
	}
	public void setInvestmentObjective(CustomerInvestmentObjective investmentObjective) {
		this.investmentObjective = investmentObjective;
	}
	public CustomerPEPDetails getPepDetails() {
		return pepDetails;
	}
	public void setPepDetails(CustomerPEPDetails pepDetails) {
		this.pepDetails = pepDetails;
	}
	public List<CustomerDocumentDetails> getDocumentDetails() {
		return documentDetails;
	}
	public void setDocumentDetails(List<CustomerDocumentDetails> documentDetails) {
		this.documentDetails = documentDetails;
	}

	public List<CustomerTaxDetails> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(List<CustomerTaxDetails> taxDetails) {
		this.taxDetails = taxDetails;
	}

	public CustomerSrsAccount getSrsDetails() {
		return srsDetails;
	}

	public void setSrsDetails(CustomerSrsAccount srsDetails) {
		this.srsDetails = srsDetails;
	}

	public Boolean getIsMyInfoVerified() {
		return isMyInfoVerified;
	}

	public void setIsMyInfoVerified(Boolean isMyInfoVerified) {
		this.isMyInfoVerified = isMyInfoVerified;
	}

	public NationalityDTO getNationality() {
		return nationality;
	}

	public void setNationality(NationalityDTO nationality) {
		this.nationality = nationality;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DetailedCustomerSummary [customer=");
		builder.append(customer);
		builder.append(", employmentInformation=");
		builder.append(employmentInformation);
		builder.append(", income=");
		builder.append(income);
		builder.append(", assets=");
		builder.append(assets);
		builder.append(", liabilities=");
		builder.append(liabilities);
		builder.append(", taxDetails=");
		builder.append(taxDetails);
		builder.append(", investmentObjective=");
		builder.append(investmentObjective);
		builder.append(", pepDetails=");
		builder.append(pepDetails);
		builder.append(", srsDetails=");
		builder.append(srsDetails);
		builder.append(", additionalDetails=");
		builder.append(additionalDetails);
		builder.append(", identityDetails=");
		builder.append(identityDetails);
		builder.append(", documentDetails=");
		builder.append(documentDetails);
		builder.append(", isMyInfoVerified=");
		builder.append(isMyInfoVerified);
		builder.append(", nationality=");
		builder.append(nationality);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
}

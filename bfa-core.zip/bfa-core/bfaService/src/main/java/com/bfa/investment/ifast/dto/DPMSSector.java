package com.bfa.investment.ifast.dto;

public class DPMSSector {
	
	private String dpmsSectorId;
	private String dpmsSectorName;
	private String sectorType;
	private Double riskRating;
	public String getDpmsSectorId() {
		return dpmsSectorId;
	}
	public void setDpmsSectorId(String dpmsSectorId) {
		this.dpmsSectorId = dpmsSectorId;
	}
	public String getDpmsSectorName() {
		return dpmsSectorName;
	}
	public void setDpmsSectorName(String dpmsSectorName) {
		this.dpmsSectorName = dpmsSectorName;
	}
	public String getSectorType() {
		return sectorType;
	}
	public void setSectorType(String sectorType) {
		this.sectorType = sectorType;
	}
	public Double getRiskRating() {
		return riskRating;
	}
	public void setRiskRating(Double riskRating) {
		this.riskRating = riskRating;
	}
	
	

}

package com.bfa.application.core;

/**
 * This is the request POJO which takes the user request values.
 * 
 * @author Johnny Israel
 *
 */
public class UpdateMobileNumberRequest {
	
	private String customerRef;
	
	private String mobileNumber;

	private String countryCode;
	
	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

}
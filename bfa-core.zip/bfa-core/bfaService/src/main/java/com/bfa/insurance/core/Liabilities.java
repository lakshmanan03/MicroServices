/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "liabilities")
public class Liabilities implements Serializable {

	private static final long serialVersionUID = 1L;	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;	
	
	@Column(name = "customer_id")
	private int customerId;	
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "property_loan")
	private double propertyLoan;
	
	@Column(name = "car_loan")
	private double carLoan;
	
	@Column(name = "other_loan")
	private double otherLoan;
	@Column(name = "total_liabilities")
	private double totalLiabilities;

	public int getId() {
		return id;
	}

	public double getTotalLiabilities() {
		return totalLiabilities;
	}

	public void setTotalLiabilities(double totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public double getPropertyLoan() {
		return propertyLoan;
	}

	public void setPropertyLoan(double propertyLoan) {
		this.propertyLoan = propertyLoan;
	}

	public double getCarLoan() {
		return carLoan;
	}

	public void setCarLoan(double carLoan) {
		this.carLoan = carLoan;
	}

	public double getOtherLoan() {
		return otherLoan;
	}

	public void setOtherLoan(double otherLoan) {
		this.otherLoan = otherLoan;
	}
}

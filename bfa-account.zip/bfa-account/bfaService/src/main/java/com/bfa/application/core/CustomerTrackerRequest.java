package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"customer_id",
"track_code"
})

public class CustomerTrackerRequest {
	
	@JsonProperty("customer_id")
	private Integer customerId;
	
	@JsonProperty("check")
	private Boolean check;
	
	@JsonProperty("track_code")
	private String trackCode;

	@JsonProperty("customer_id")
	public Integer getCustomerId() {
		return customerId;
	}

	@JsonProperty("customer_id")
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	@JsonProperty("check")
	public Boolean getCheck() {
		return check;
	}
	
	@JsonProperty("check")
	public void setCheck(Boolean check) {
		this.check = check;
	}
	
	@JsonProperty("track_code")
	public String getTrackCode() {
		return trackCode;
	}
	
	@JsonProperty("track_code")
	public void setTrackCode(String trackCode) {
		this.trackCode = trackCode;
	}
	
}

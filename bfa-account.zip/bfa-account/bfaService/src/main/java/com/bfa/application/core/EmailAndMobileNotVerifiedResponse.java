package com.bfa.application.core;

/**
 * This class is to return the mobile number and the customer reference when
 * both email and mobile is not verified.
 * 
 * BFA-1343 , BFA-1344
 * 
 * @author pradheep.p
 *
 */
public class EmailAndMobileNotVerifiedResponse {

	private String mobileNumber;

	private String customerRef;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}
}

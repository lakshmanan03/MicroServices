/**
 * 
 */
package com.bfa.dao;

import com.bfa.common.entity.CustomerContactVerification;

/**
 * @author pradheep
 *
 */
public interface SecurityDao {	
	
	public CustomerContactVerification getCustomerContactVerificationBySessionAndType(String sessionId,String actionType);
	
	public CustomerContactVerification getCustomerContactVerificationByCustomerIdAndType(Integer customerId,String actionType);
	
	public CustomerContactVerification updateCustomerContactVerification(CustomerContactVerification customerContactVerification);	
	
}

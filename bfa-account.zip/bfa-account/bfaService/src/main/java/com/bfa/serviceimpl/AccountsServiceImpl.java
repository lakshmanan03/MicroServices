package com.bfa.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.HtmlUtils;

import com.bfa.admin.dto.AdminCustomerDetails;
import com.bfa.admin.dto.AdminCustomerSummary;
import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.AccountStatus;
import com.bfa.application.core.AuthenticationErrorResponse;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.core.CustomerAndPrevilegeV2;
import com.bfa.application.core.CustomerIssuedToken;
import com.bfa.application.core.CustomerPassLog;
import com.bfa.application.core.CustomerPreference;
import com.bfa.application.core.UpdateMobileNumberRequest;
import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.exception.NoSuchUserException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.dto.AddressDTO;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.CustomerBankInfoDTO;
import com.bfa.common.dto.CustomerContactDetails;
import com.bfa.common.dto.CustomerDocumentInfo;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.dto.CustomerFinancialDataDTO;
import com.bfa.common.dto.CustomerPersonalInformation;
import com.bfa.common.dto.CustomerProfileDetails;
import com.bfa.common.dto.CustomerTaxDetailsDTO;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.UpdateContactDetailsDTO;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.Common;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerAssessmentDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.CustomerData;
import com.bfa.common.entity.CustomerDetailsEditHistory;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerOverview;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.common.entity.EmailContentWrapper;
import com.bfa.common.entity.EmailData;
import com.bfa.common.entity.EmployerAddress;
import com.bfa.common.entity.EmployerDetails;
import com.bfa.common.entity.Household;
import com.bfa.common.entity.Industry;
import com.bfa.common.entity.Occupation;
import com.bfa.common.entity.OptionItem;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.configuration.jpa.CountryRepository;
import com.bfa.configuration.jpa.CustomerAdditionalDetailsRepository;
import com.bfa.configuration.jpa.CustomerEmploymentDetailsRepository;
import com.bfa.configuration.jpa.CustomerExpenseRepository;
import com.bfa.configuration.jpa.CustomerIdentityDetailsRepository;
import com.bfa.configuration.jpa.CustomerIncomeRepository;
import com.bfa.configuration.jpa.CustomerLiabilityRepository;
import com.bfa.configuration.jpa.CustomerPEPDetailsRepository;
import com.bfa.configuration.jpa.CustomerRepository;
import com.bfa.configuration.jpa.CustomerSrsAccountRepository;
import com.bfa.configuration.jpa.CustomeriFASTAccountRepository;
import com.bfa.configuration.jpa.EmployerAddressRepository;
import com.bfa.configuration.jpa.EmployerDetailsRepository;
import com.bfa.dao.AccountsDao;
import com.bfa.dao.CustomerDocumentDAO;
import com.bfa.dao.CustomerPreferenceDao;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.dao.SecurityDao;
import com.bfa.dao.TrackingMasterDao;
import com.bfa.exception.BfaException;
import com.bfa.ifast.exception.IFastException;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.CRMResponse;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.Dependents;
import com.bfa.insurance.core.EmploymentStatus;
import com.bfa.insurance.core.EmploymentStatusMaster;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.insurance.core.Profile;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.insurance.product.ProductList;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.account.dto.CustomerDetailsDTO.AccountVerificationMode;
import com.bfa.investment.account.dto.PersonalDetailsDTO;
import com.bfa.investment.dto.CountryListDTO;
import com.bfa.investment.dto.CustomerAdditionalDetailsDTO;
import com.bfa.investment.dto.CustomerAddressDTO;
import com.bfa.investment.dto.CustomerEmploymentInfo;
import com.bfa.investment.dto.CustomerSrsAccountDTO;
import com.bfa.investment.dto.EmployerAddressDTO;
import com.bfa.investment.dto.EmployerDetailsDTO;
import com.bfa.investment.dto.GroupedCountryDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.NationalityDTO;
import com.bfa.investment.dto.PEPAdditionalDeclarationDTO;
import com.bfa.investment.dto.UpdateFundingTypeRequest;
import com.bfa.investment.dto.UpdatePasswordDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;
import com.bfa.investment.entity.DocumentStatusMaster;
import com.bfa.investment.entity.DocumentStatusMaster.DocumentStatusTypes;
import com.bfa.investment.ifast.dto.DPMSHoldingsSummary;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.notification.messenger.templates.SMSDetails;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.request.entity.CustomerCreationDTO;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.request.entity.UpdateCustomerRequest;
import com.bfa.service.AccountsService;
import com.bfa.util.AmazonS3ClientService;
import com.bfa.util.AmazonS3ClientServiceImpl;
import com.bfa.service.CustomerDocumentDetailService;
import com.bfa.service.CustomerEnquiryService;
import com.bfa.service.PasswordEncryptionService;
import com.bfa.service.SecurityService;
import com.bfa.servicehelper.MOFinancialService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.InvestmentAccountStatus;
import com.bfa.util.MOEmailSQSClient;
import com.bfa.util.PublicUtility;
import com.bfa.util.ServiceResponse;
import com.bfa.util.UniqueKeyGenerator;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.Field;
import java.util.Objects;

@Service
@Transactional
@PropertySource(value = "classpath:application.properties")
public class AccountsServiceImpl extends DefaultServiceImpl implements AccountsService {

	@Autowired
	private CustomerEnquiryService customerEnquiryService;
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private TrackingMasterDao trackingMasterDao;
	
	@Autowired
	private CustomerPreferenceDao customerPreferenceDao;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CustomeriFASTAccountRepository customeriFASTRepository;
	
	@Autowired
	private CustomerLiabilityRepository customerLiabilityRepository;
	
	@Autowired
	private CustomerIncomeRepository customerIncomeRepository;
	
	@Autowired
	private CustomerExpenseRepository customerExpenseRepository;
	
	@Autowired
	private CustomerAdditionalDetailsRepository customerAdditionalDetailsRepository;
	
	@Autowired
	private CustomerPEPDetailsRepository customerPEPDetailsRepository;
	
	@Autowired
	private CustomerIdentityDetailsRepository customerIdentityDetailsRepository;
	
	@Autowired
	private CustomerEmploymentDetailsRepository customerEmploymentDetailsRepository;
	
	@Autowired
	private EmployerDetailsRepository employerRepository;
	
	@Autowired
	private EmployerAddressRepository employerAddressRepository;
	
	@Autowired
	private CustomerSrsAccountRepository customerSrsAccountRepository;
	
	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CustomerDocumentDAO customerDocDao;

	@Autowired
	MOEmailSQSClient moemailObj;

	@Autowired
	InvestmentAccountDao dao;

	@Autowired
	MOInvestmentService investService;
	
	@Autowired
	MOFinancialService financeService;

	@Autowired
	AccountsDao accountsDao;

	@Autowired
	AmazonS3ClientService amazonS3ClientService;

	@Autowired
	CustomerDocumentDetailService customerDocService;

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private DelegateHandler delegateHandler;

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@Value("${amazonProperties.bucketName}")
	private String bucketName;

	protected String appKey = "IMXYlDmP4f4=";

	protected PublicUtility utility = PublicUtility.getInstance(appKey);

	@Autowired
	ClassPathResource classPathResourceObj;

	@Autowired
	Properties prop;
	
	@Autowired
	ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private PasswordEncryptionService passwordEncryptionService;	
	
	@Autowired
	private SecurityDao securityDAO;
	
	protected Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}
	
	@Autowired
	ComprehensiveEnquiryPreferencesHelper comprehensiveEnquiryPreferencesHelper;

	public List<Profile> getProfileList() throws DatabaseAccessException {
		try {
			return accountsDao.getProfileList();
		} catch (DatabaseAccessException e) {
			getLogger().error("DatabaseAccessException: " + e);
			throw e;
		}
	}

	@Override
	public List<EmploymentStatusMaster> getEmploymentList() throws DatabaseAccessException {
		return accountsDao.getEmploymentList();
	}

	@Override
	public void saveDependents(List<DependentMapping> dependents) throws DatabaseAccessException {
		accountsDao.saveDependentList(dependents);
	}

	@Override
	public BFAUserDetails getUserByEmail(String email) throws DatabaseAccessException, NoSuchUserException {
		return accountsDao.loadUserByEmail(email);
	}

	@Override
	public BFAUserDetails getUserById(Integer customerId) throws DatabaseAccessException, NoSuchUserException {
		return accountsDao.loadUserById(customerId);
	}

	@Override
	public SessionDetails saveSessionDetails(HttpServletRequest requestobj) throws DatabaseAccessException {
		SessionDetails sessionDetails = new SessionDetails();
		sessionDetails.setBrowser(getBrowserAndOSDetails(requestobj));
		sessionDetails.setIpAddress(getIPAddress(requestobj));
		return (SessionDetails) accountsDao.saveOrUpdateObject(sessionDetails);
	}

	@Override
	public CustomerAndPrevilege signup(CustomerCreationPostRequest customer) throws DatabaseAccessException {
		String otpString = generateOTP();
		String contactNumber = customer.getCustomer().getMobileNumber();
		String countryCode = customer.getCustomer().getCountryCode();
		sendOTP(contactNumber, countryCode, otpString, false);
		// ------------------------------------------------------//
		customer.getCustomer().setOtpString(appendDateToOTP(otpString));
		customer.getCustomer().setOtpVerfied("No");
		customer.getCustomer().setEmailVerified("No");
		getLogger().info("Singning up the user information " + otpString);
		// --- Set the user id to allow the user to edit the mobile number
		setPassword(customer.getCustomer());
		int enquiryId = customer.getEnquiryId();
		customer.getCustomer().setVerificationEnquiryId(enquiryId);
		CustomerAndPrevilege customerAndPrevilege = accountsDao.signup(customer);
		// -------------------------------------------------------//
		try {
			// Sleep introduced to ensure that the customer data is saved.
			Thread.sleep(100);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt(); // "InterruptedException" should not be ignored
			getLogger().error("InterruptedException while signup(): " + e);
		}
		getLogger().info("Printing the customer id " + customerAndPrevilege.getCustomer().getId());
		getLogger().info("Printing the enquiry id " + customer.getEnquiryId());
		List<BFAGrandtedAuthority> grantedAuthorities = getGrantedAuthorities(customerAndPrevilege);
		String authToken = getAuthToken(customerAndPrevilege.getCustomer(), grantedAuthorities);
		int customerId = customerAndPrevilege.getCustomer().getId();
		updateUserToken(authToken, customerId);
		customerAndPrevilege.setSecurityToken(authToken);
		Customer custObj = customerAndPrevilege.getCustomer();
		if (customer.getJourneyType().contains("insurance")) {
			updateCustomerInformation(customer.getEnquiryId(), custObj, customer.getSelectedProducts(), true);
		} else if ("investment".equalsIgnoreCase(customer.getJourneyType())) {
			customerEnquiryService.mapCustomerToEnquiry(custObj.getId(), customer.getEnquiryId());
			securityService.savePromocode(custObj.getId(), customer.getEnquiryId());
		}
		return customerAndPrevilege;
	}

	private void setPassword(Customer customerObj) {
		String arg = generateOTP();
		String _encrypt = "";
		// -------------------------------------------------------------
		//------------------- BFA-1552 ----------------------------
		try {
				byte[] uniqueId = utility.getSalt();
				customerObj.setUniqueId(uniqueId);
				_encrypt = utility.encryptTextWithKey(arg, false, uniqueId);
				customerObj.setPassword(_encrypt.getBytes());			
				} catch (NoSuchAlgorithmException e) {			
					getLogger().error("Error while obtaining the salted key",e);
				}
		// -------------------------------------------------------------- 		
	}

	@Override
	public CustomerPreference getTrackStatus(Integer customerId, String trackCode) {
		getLogger().info("Getting Tracker Status from customer " + customerId);
		try {
			CustomerPreference preference = customerPreferenceDao.getCustomerPreference(customerId, trackCode);
			if (preference != null) {
				return preference;
			}
		} catch (Exception ex) {
			getLogger().error(ex);
		}
		getLogger().info("Doesnt exist");
		return null;
	}
	
	@Override
	public ServiceResponse<Boolean> setTrackStatus(Integer customerId, Boolean check, String trackCode) {
		ServiceResponse<Boolean> response = new ServiceResponse<Boolean>();
		try {
			System.out.println("TrackingCode to be tested: " + trackCode);
			Boolean exists = trackingMasterDao.trackCodeExists(trackCode);
			if (!exists) {
				throw new Exception("trackingCode does not exist");
			}
			CustomerPreference customerPreference = customerPreferenceDao.getCustomerPreference(customerId, trackCode);
			if(customerPreference != null) {
				customerPreference.setTrackStatus(check);
				customerPreference.setLastupdatedtimeStamp(new Date());
			} else {
				customerPreference = new CustomerPreference();
				customerPreference.setCustomerId(customerId);
				customerPreference.setTrackStatus(true);
				customerPreference.setTrackCode(trackCode);
				customerPreference.setCreatedDate(new Date());
				customerPreference.setLastupdatedtimeStamp(new Date());			
			}
			customerPreferenceDao.saveOrUpdateObject(customerPreference);
			response.setResponse(true);
		} catch (Exception ex) {
			response.setResponse(false);
			response.addErrorInfo("error", ex.getMessage());
			response.addErrorInfo("Failed to update customerPreference", "Failed to update customer preference for :" + customerId);
			getLogger().error("Failed to update customer preference for :" + customerId);
			getLogger().error(ex);
		}
		return response;
	}
	
	@Override
	public CustomerAdditionalDetails getCustomerAdditionalDetails(Integer customerId) {
		CustomerAdditionalDetails additionalDetails = null;
		try {
			additionalDetails = accountsDao.getAdditionalDetails(customerId);
		} catch (Exception ex) {
			getLogger().error("Exception caught in getCustomerAdditionalDetails() for the customer:" + "===>" + ex);
		}
		return additionalDetails;
	}

	@Override
	public void updateCustomerAdditionalDetails(CustomerAdditionalDetails additionalInfo) {
		try {
			accountsDao.saveOrUpdateObject(additionalInfo);
		} catch (Exception ex) {
			getLogger().error("Exception in updateCustomerAdditionalDetails() : " + ex);
		}
	}	

	private List<BFAGrandtedAuthority> getGrantedAuthorities(CustomerAndPrevilege customerAndPrevilege) {
		List<BFAGrandtedAuthority> authorities = new ArrayList<>();
		customerAndPrevilege.getPrevileges().forEach(x -> x.getPrevileges().forEach(y -> {
			BFAGrandtedAuthority authObj = new BFAGrandtedAuthority(y.getPrvilegeName());
			authorities.add(authObj);
		}));
		return authorities;
	}

	private boolean isValidEmailAddress(String email) {
		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		java.util.regex.Matcher m = p.matcher(email);
		return m.matches();
	}

	private boolean isValidNumber(String numberStr) {
		try {
			Long data = Long.parseLong(numberStr);
			return true;
		} catch (NumberFormatException exp) {
			getLogger().error("Not a valid mobile number : " + numberStr);
			return false;
		}
	}

	Random ran = new Random();
	@Override
	public String generateOTP() {
		StringBuilder builder = new StringBuilder();
		String[] arg = { "1", "2", "3", "4", "5", "1", "2", "3", "4", "5", "6", "1", "2", "0", "1", "0", "1", "2", "5",
				"2", "5", "3", "7", "8", "9", "0", "6", "7", "8", "0", "1", "2", "5", "9", "0", "1", "2", "5", "6", "7",
				"8", "0", "1", "2", "5", "9", "0", "3", "4", "5", "6", "0", "1", "2", "5", "7", "8", "9", "0" };
		
		for (int x = 0; x <= 5; x++) {
			int y = ran.nextInt(arg.length - 1);
			builder.append(arg[y]);
		}
		return builder.toString();
	}

	@Override
	public String validateUser(CustomerCreationPostRequest customer) {
		Customer customerInfo = customer.getCustomer();
		int enquiryId = customer.getEnquiryId();

		String emailId = customerInfo.getEmail();
		boolean valid = isValidEmailAddress(emailId);
		if (!valid) {
			return ApplicationConstants.VALIDATION_ERROR_INVALID_EMAIL;
		}
		if (customer.getCustomer().getGender() == null || "".equals(customer.getCustomer().getGender())) {
			customer.getCustomer().setGender("Not available");
		}
		String mobileNumber = customerInfo.getMobileNumber();
		if (!isValidNumber(mobileNumber)) {
			return ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE_NUM;
		}
		if (mobileNumber.length() > 10 || mobileNumber.length() < 8) {
			return ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE;
		}
		/*
		 * Allow the user to edit the mobile number and email if the Enquiry id
		 * is the same
		 */

		if (doesMobileExistsForOtherCustomer(mobileNumber, enquiryId)) {
			return ApplicationConstants.VALIDATION_ERROR_MOBILE_EXISTS;
		}
		if (doesEmailExistsForOtherCustomer(emailId, enquiryId)) {
			return ApplicationConstants.VALIDATION_ERROR_EMAIL_EXISTS;
		}

		return ApplicationConstants.VALIDATION_SUCCESS;
	}

	private boolean isEnquiryAlreadyExists(int enquiryId) {
		getLogger().info("Printing the verify enquiry id " + enquiryId);
		List collection = accountsDao.getObjectsById(Customer.class, "verificationEnquiryId", enquiryId);
		getLogger().info("Printing the customer based on enquiry id" + collection);
		if (collection != null && !collection.isEmpty()) {
			return true;
		}
		return false;
	}

	@Override
	public String getAuthToken(Customer customer, List<BFAGrandtedAuthority> authorities) {
		return tokenProvider.getTokenStringV2(customer.getId(), authorities);
	}

	@Override
	public List<BFAGrandtedAuthority> getAuthorities(Customer customer) {

		String hqlString = "select master.PrvilegeName from Customer as cust, CustomerPrevilege as prev,PrevilageMaster as master  where cust.id=prev.customerId and prev.previlegetId=master.id and cust.id =:customerId";
		String custId = String.valueOf(customer.getId());
		String[] paramNames = new String[]{"customerId"};
		Object[] paramValues = new Object[]{new Integer(customer.getId())};
		List<String> roles = accountsDao.getObjectByHql(hqlString,paramNames,paramValues);
		List<BFAGrandtedAuthority> authorities = new ArrayList<BFAGrandtedAuthority>();
		roles.forEach(x -> {
			BFAGrandtedAuthority authObj = new BFAGrandtedAuthority(x);
			authorities.add(authObj);
		});
		getLogger().info("Printing the granted authorities : " + authorities);
		return authorities;
	}

	private List<Dependents> getAllDependents(int enquiryId) {
		List<Dependents> dependentList = accountsDao.getObjectsById(Dependents.class, "enquiryId", enquiryId);
		return dependentList;
	}

	/**
	 * Sends the request to persist the customer id in all microservices.
	 */

	@Override
	public void updateCustomerInformation(int enquiryId, Customer customerObj, List<ProductList> selectedProducts,
			boolean isNewCustomer) {

		getLogger().info("Updating customer information : ThreadName:" + Thread.currentThread().getName()
				+ " Started at :" + new Date());
		// ---------------------------------------------------------------//
		getLogger().info("Starting the customer id update request");
		UpdateCustomer updateCustomer = new UpdateCustomer(enquiryId, customerObj, selectedProducts);
		threadPoolTaskExecutor.execute(updateCustomer);
		// ---------------------------------------------------------------//

		// -------------- Update Dependents -------------------------//
		Thread d = new Thread() {
			public void run() {
				getLogger().info("Updating the dependents ");
				List<Dependents> dependentList = getAllDependents(enquiryId);
				dependentList.forEach(x -> {
					x.setCustomerId(customerObj.getId());
					accountsDao.saveOrUpdateObject(x);
					try {
						Thread.currentThread();
						Thread.sleep(200);
					} catch (Exception e) {
						getLogger().error("Error while updating the customer information", e);
					}
				});
				getLogger().info("Successfully updated the customer id in dependents data");
			}
		};
		threadPoolTaskExecutor.execute(d);
	}

	private void updateUserToken(String token, int customerId) {
		CustomerIssueTokenUpdater customerIssueTokenUpdater = new CustomerIssueTokenUpdater(token, customerId);
		threadPoolTaskExecutor.execute(customerIssueTokenUpdater);
	}

	class CustomerIssueTokenUpdater implements Runnable {

		private String token;

		private int customerId;

		public CustomerIssueTokenUpdater(String token, int customerId) {
			this.token = token;
			this.customerId = customerId;
		}

		@Override
		public void run() {
			CustomerIssuedToken ciToken = new CustomerIssuedToken();
			ciToken.setCustomerId(customerId);
			ciToken.setIssuedTime(new Date());
			ciToken.setTokenValue(token);
			accountsDao.saveObject(ciToken);
			getLogger().info("Persisted the customer :" + customerId + " Token: " + token);
		}

	}

	class UpdateCustomer implements Runnable {

		private UpdateCustomerRequest requestObj = new UpdateCustomerRequest();

		private Integer enquiryId;

		private Customer customerObj;

		private List<ProductList> selectedProducts;

		public UpdateCustomer(int enquiryId, Customer customerObj, List<ProductList> selectedProducts) {
			this.enquiryId = enquiryId;
			this.customerObj = customerObj;
			this.selectedProducts = selectedProducts;
		}

		@Override
		public void run() {
			if ((enquiryId == null) || customerObj == null) {
				getLogger().error(
						"Unable to update the customer id " + customerObj + " for the given enquiry id " + enquiryId);
				return;
			}
			requestObj.setCustomerId(customerObj.getId());
			requestObj.setEnquiryId(enquiryId);
			delegateHandler.updateCustomerIdAndProducts(requestObj, this.selectedProducts);
			getLogger().debug("Updating customer information in all microservices initiated ");
		}
	}

	@Override
	public String encryptUserResponseData(String toBeEncrypted) {
		SimpleDateFormat sdf = new SimpleDateFormat("SSSZ mm:ss");
		Date dateObj = new Date();
		Date dateObj1 = new Date();
		String arg = sdf.format(dateObj) + this.delimiter + toBeEncrypted + this.delimiter + sdf.format(dateObj1);
		getLogger().info("arg: " + arg);
		String encryptTxt = utility.EncryptText(arg);
		getLogger().info("encrypted string: " + encryptTxt);
		return encryptTxt;
	}

	@Override
	public boolean isOTPValid(String customerRef, String otpString)
			throws DatabaseAccessException, NoSuchUserException {
		return false;
	}

	@Override
	public boolean updatePassword(String customerRef, String password)
			throws DatabaseAccessException, NoSuchUserException {
		return false;
	}

	@Override
	public void updateCRMDetailsOfCustomer(CRMResponse crmAndCustomerData) throws DatabaseAccessException {
		Integer customerRef = crmAndCustomerData.getCustomerId();
		List<Object> objectList = accountsDao.getObjectsById(Customer.class, "id", customerRef);
		if (objectList == null || objectList.isEmpty()) {
			getLogger().error("No customer details found for customer id " + customerRef);
			return;
		}
		try {
			Customer customerObj = (Customer) objectList.get(0);
			String crmEntityType = crmAndCustomerData.getEntity_type();
			if (null != crmEntityType) {
				int crmId = Integer.parseInt(crmAndCustomerData.getEntity_id());
				String crmAgentId = crmAndCustomerData.getAgent_id();
				customerObj.setCrmEntityType(crmEntityType);
				customerObj.setCrmId(crmId);
				customerObj.setCrmAgentId(crmAgentId);
				getLogger().info("Updating the [Agent Id]:" + crmAgentId + ",[CRM id]:" + crmId + ",[CRM entity Type]:"
						+ crmEntityType + " for [Customer Id]:" + customerRef);
			}
			if(null != crmAndCustomerData.getHubspotReference()){
				customerObj.setHubspotReference(crmAndCustomerData.getHubspotReference());
				getLogger().info("Updating the husbpot reference :" + crmAndCustomerData.getHubspotReference()
						+ " for [Customer Id]:" + customerRef);
			}
			accountsDao.saveOrUpdateObject(customerObj);
			getLogger().info("Successfully updated the CRM details for the customer ");
		} catch (Exception err) {
			getLogger().error("Error while saving the crm data in customer table", err);
			throw new DatabaseAccessException(err.getMessage());
		}
	}

	/**
	 * Sends the OTP to the customer.
	 * 
	 * @param contactNumber
	 * @param countryCode
	 * @param otp
	 */
	@Override
	public void sendOTP(String contactNumber, String countryCode, String otp, boolean isResend) {
		SMSDetails smsDetails = new SMSDetails();
		smsDetails.setContactNumber(contactNumber);
		smsDetails.setCountryCode(countryCode);
		smsDetails.setOTP(otp);
		smsDetails.setResend(isResend);
		delegateHandler.sendOTPRequest(smsDetails);
	}

	/**
	 * This method is used to reissue the OTP to the user.
	 * 
	 * @param customerRef
	 */
	@Override
	public boolean reIssueOTP(String customerRef, Integer customerId) {
		try {
			Customer customerObj = null;
			if(null != customerId && customerId > 0) {
				customerObj = getCustomerById(customerId);
			} else {
				customerObj = getCustomerByReferenceV1(customerRef);
			}
			String otpString = generateOTP();
			String contactNumber = customerObj.getMobileNumber();
			String countryCode = customerObj.getCountryCode();
			sendOTP(contactNumber, countryCode, otpString, true);
			// --------------------------------------------------------------------------//
			getLogger().info("Reissue the OTP for the customer :" + customerObj.getId());
			customerObj.setOtpString(appendDateToOTP(otpString));
			customerObj.setOtpVerfied("No");
			accountsDao.saveOrUpdateObject(customerObj);
			getLogger().info("Reissued the OTP successfully ");
			return true;
		} catch (Exception err) {
			getLogger().error("Error while issuing the OTP ", err);
			return false;
		}
	}

	private ProfileSummaryDTO buildProfileSummary(Customer customer) {
		ProfileSummaryDTO dto = new ProfileSummaryDTO();

		dto.setId(customer.getId());
		dto.setFirstName(customer.getGivenName());
		dto.setLastName(customer.getSurName());
		dto.setFullName(customer.getNricName());
		dto.setMobileNumber(customer.getMobileNumber());
		dto.setEmailAddress(customer.getEmail());
		dto.setDateOfBirth(customer.getDateOfBirth());
		return dto;
	}

	private ProfileSummaryDTO buildInvestmentProfileDetails(int customerId) {
		ProfileSummaryDTO dto = new ProfileSummaryDTO();
		getLogger().info("buildInvestmentProfileDetails for:  " + customerId);
		InvestementDashboardStatusDTO investmentDashboardStatus = null;
		try {
			getLogger()
					.info("buildInvestmentProfileDetails(): calling MOInvestmentService.customerInvestmentProfile()");
			investmentDashboardStatus = investService.customerInvestmentProfile(customerId);
			getLogger().info("buildInvestmentProfileDetails(): called MOInvestmentService.customerInvestmentProfile()");
		} catch (IFastException ex) {
			getLogger()
					.error("buildInvestmentProfileDetails(): Error calling MOInvestmentService.customerInvestmentProfile()"
							+ ex);
			// throw ex;
		}
		CustomerAdditionalDetails customerAdditionalDetail = accountsDao.getAdditionalDetails(customerId);
		getLogger().info("buildInvestmentProfileDetails--DashboarStatusDTO object:  " + investmentDashboardStatus);
		if (investmentDashboardStatus != null) {
			if (customerAdditionalDetail != null && customerAdditionalDetail.getRegistrationProofType() != null
					&& "MY-INFO".equalsIgnoreCase(customerAdditionalDetail.getRegistrationProofType())) {
				investmentDashboardStatus.setMyInfoVerified(true);

			} else {
				investmentDashboardStatus.setMyInfoVerified(false);

			}
			if (investmentDashboardStatus.getAccount().getAccountStatus() != null && "INVESTMENT_ACCOUNT_DETAILS_SAVED".equals(investmentDashboardStatus
					.getAccount().getAccountStatus())
					&& customerAdditionalDetail != null) {
				investmentDashboardStatus.setIsPoliticallyExposed(customerAdditionalDetail.isPoliticallyExposed());
				investmentDashboardStatus.setBeneficialOwner(customerAdditionalDetail.getBeneficialOwner());
				investmentDashboardStatus
						.setConnectedToInvestmentFirm(customerAdditionalDetail.getConnectedToInvestmentFirm());
			} else {
				investmentDashboardStatus.setIsPoliticallyExposed(false);
				investmentDashboardStatus.setBeneficialOwner(false);
				investmentDashboardStatus.setConnectedToInvestmentFirm(false);
			}

		}
		dto.setInvestementDetails(investmentDashboardStatus);

		return dto;
	}

	@Override
	public ProfileSummaryDTO getProfileSummary(String email) {
		ProfileSummaryDTO dto = null;
		List customers = accountsDao.getObjectsByRef(Customer.class, "email", email);
		if (customers != null && !customers.isEmpty()) {
			Customer customer = (Customer) customers.get(0);
			dto = buildProfileSummary(customer);
		}
		return dto;
	}
	
	@Override
	public ProfileSummaryDTO getProfileSummaryById(Integer customerId) {
		ProfileSummaryDTO dto = null;
		List customers = accountsDao.getObjectByHql("from Customer where id=:customerId","customerId",customerId);		
		if (customers != null && customers.size() > 0) {
			Customer customer = (Customer) customers.get(0);
			dto = buildProfileSummary(customer);
		}
		return dto;
	}

	@Override
	public ProfileSummaryDTO getCustomerProfileDetails(String email) {
		ProfileSummaryDTO dto = null;
		getLogger().info("getCustomerProfileDetails for:  " + email);
		List customers = accountsDao.getObjectsByRef(Customer.class, "email", email);

		if (customers != null && !customers.isEmpty()) {
			Customer customer = (Customer) customers.get(0);
			Country countryDetails = dao.getNationality(customer.getNationalityCode());
			dto = buildCustomerProfileDetails(customer, countryDetails);
		}
		return dto;
	}
	
	@Override
	public ProfileSummaryDTO getCustomerProfileDetails(Integer customerId) {
		ProfileSummaryDTO dto = null;
		List customers = accountsDao.getObjectByHql("from Customer where id =:customerId","customerId",customerId);
		if (customers != null && customers.size() > 0) {
			Customer customer = (Customer) customers.get(0);
			Country countryDetails = dao.getNationality(customer.getNationalityCode());
			dto = buildCustomerProfileDetails(customer, countryDetails);

			// Code added for MO3-993,MO3-994 for dob & gender restriction for Comprehensive
			// customer
			try {
				int enquiryId;
				List enquiryList = accountsDao.getObjectByHql(
						"from Enquiry where type = 'Comprehensive' and customerId =:customerId ","customerId",customerId);
				if (null != enquiryList && !enquiryList.isEmpty()) {
					Enquiry comprehensiveEnquiry = (Enquiry) enquiryList.get(0);
					enquiryId = comprehensiveEnquiry.getId();
					// Fetching ComprehensiveEnquiry Object using cross service call
					ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();

					ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();

					comprehensiveEnquiryDTO.setCustomerId(customerId);

					comprehensiveEnquiryDTO.setEnquiryId(enquiryId);

					comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);

					ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = comprehensiveEnquiryPreferencesHelper
							.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest);
					if (null != comprehensiveEnquiryPostResponse) {
						
						comprehensiveEnquiryDTO = comprehensiveEnquiryPostResponse.getComprehensiveEnquiry();
						getLogger().info("Comprehensive report status:"+comprehensiveEnquiryDTO.getReportStatus());
						dto.setComprehensiveReportStatus(comprehensiveEnquiryDTO.getReportStatus());
					} else {
						dto.setComprehensiveReportStatus(null);
					}

				} else {
					dto.setComprehensiveReportStatus(null);
				}
			} catch (Exception e) {
				getLogger().debug("Exception occurred in getCustomerProfileDetails", e);

			}
		} 
		return dto;
	}
	
	

	private ProfileSummaryDTO buildCustomerProfileDetails(Customer customer, Country countryDetails) {
		ProfileSummaryDTO dto = new ProfileSummaryDTO();

		// To fetch country and
//		dto = buildInvestmentProfileDetails(customer.getId());
		NationalityDTO nationalityDto = new NationalityDTO();
		if (countryDetails != null) {
			nationalityDto.setName(countryDetails.getNationality());
			nationalityDto.setNationalityCode(countryDetails.getNationalityCode());
			// All countries under a nationality will have same isBlocked status
			nationalityDto.setBlocked(countryDetails.isBlocked());
			nationalityDto.setListorder(countryDetails.getListOrder());
			ArrayList<GroupedCountryDTO> grpCountryList = new ArrayList<>();

			GroupedCountryDTO cDto = new GroupedCountryDTO();
			cDto.setId(countryDetails.getId());
			cDto.setCountryCode(countryDetails.getCountryCode());
			cDto.setName(countryDetails.getCountry());
			cDto.setPhoneCode(countryDetails.getPhoneCode());
			grpCountryList.add(cDto);

			nationalityDto.setCountries(grpCountryList);
			dto.setNationality(nationalityDto);
		}

		dto.setId(customer.getId());
		dto.setFirstName(customer.getGivenName());
		dto.setLastName(customer.getSurName());
		dto.setFullName(customer.getNricName());
		dto.setMobileNumber(customer.getMobileNumber());
		dto.setEmailAddress(customer.getEmail());
		String dob = customer.getDateOfBirth();
		dto.setDateOfBirth(dob);

		return dto;
	}

	@Override
	public Customer updateCustomerdetails(int enquiryId, String customerId, List<ProductList> selectedProducts) {
		getLogger().info("Updating customer info post login.");
		Customer customer = getCustomerById(Integer.parseInt(customerId));
		getLogger().info("Customer " + customerId + ",Enquiry:" + enquiryId);
		if (customer != null) {
			getLogger().info("Trying to update the records of " + customer.getGivenName());
		} else {
			getLogger().error("Unable to find the customer for the ID " + customerId);
		}
		updateCustomerInformation(enquiryId, customer, selectedProducts, false);
		return null;
	}

	@Override
	public void sendContactUsEmail(String toEmail, String subject, String body, String custEmail, String custContactNo) {
		getLogger().info("Sending Email to Advisors");
		String fromEmail = "contactus@moneyowl.com.sg";
		Map<String, String> params = new HashMap<String, String>();
		body = HtmlUtils.htmlEscape(body);
		body = body.replaceAll("&lt;br/&gt;", "<br/>");
		params.put("body", body);
		params.put("custEmail", custEmail);
		params.put("custContactNo", custContactNo);
		delegateHandler.sendEmail(fromEmail, toEmail, subject, "contact_us.template", params);
	}

	@Override
	public Customer getCustomerDetails(String email) {
		return accountsDao.getCustomerDetails(email);
	}
	
	@Override
	public Customer getDetailsByCustomerId(Integer customerId) {		
		return accountsDao.getCustomerById(customerId);
	}

	public ServiceResponse<Boolean> updateCustomerContactDetails(Integer customerId, ContactDetailsDTO contactDetails,
			HttpServletRequest servletRequest) {

		ServiceResponse<Boolean> response = new ServiceResponse<>();
		response.setResponse(true);
		boolean isEmailChanged = false;
		boolean isMobileChanged = false;
		boolean proceedUpdate = true;

		// Fetch customer details
		Customer existingCustomer = dao.getCustomer(customerId);

		// Mobile number changed
		if (!existingCustomer.getMobileNumber().equals(contactDetails.getMobileNumber())) {
			isMobileChanged = true;
			String message = validateNewMobileNumber(contactDetails.getMobileNumber());
			// If mobile already registerd with other user
			if (!message.equals(ApplicationConstants.VALIDATION_SUCCESS)) {
				response.setResponse(false);
				response.addErrorInfo("error", "Mobile number already exists");
				proceedUpdate = false;
			}
		}

		// Email id changed
		if (proceedUpdate && !existingCustomer.getEmail().equals(contactDetails.getEmailId())) {
			isEmailChanged = true;
			String message = validateNewEmail(contactDetails.getEmailId());
			// If mobile already registerd with other user
			if (!message.equals(ApplicationConstants.VALIDATION_SUCCESS)) {
				response.setResponse(false);
				response.addErrorInfo("error", "Email id already exists");
				proceedUpdate = false;
			}
		}

		if (proceedUpdate && (isEmailChanged || isMobileChanged)) {			
			if (isMobileChanged) {
				// update mobile

				CustomerContactVerification updateMobileInfo = editContactDetails(contactDetails, customerId);

				String customerRef = encryptUserResponseData(String.valueOf(updateMobileInfo.getCustomer().getId()));
				response.setResponse(true);
				response.addErrorInfo("mobileupdatestatus", "Mobile Number is successfully updated!");
				response.addResponseInfo("customerRef", customerRef);

			}
			if (isEmailChanged) {
				// update email
				CustomerContactVerification updateEmailInfo = securityService.editEmail(contactDetails, customerId,
						servletRequest);
				getLogger().info("updatedEmailInfo: " + updateEmailInfo.getEmail());
				response.setResponse(true);
				response.addErrorInfo("emailupdatestatus", "Email Id is successfully updated!");
			}
		}

		return response;

	}

	@Override
	public String updateCustomerAddress(Integer customerId, Integer advisorId,
			UpdateCustomerAddressDTO updateCustomerAddress) {
		getLogger().info("Updating Address for the customer --" + customerId);
		Boolean isUpdated = false;
		String sessionId = UniqueKeyGenerator.getUniqueKey();
		try {
			Customer customerDetails = getDetailsByCustomerId(customerId);
			isUpdated = saveCustomerAddress(customerDetails, updateCustomerAddress, advisorId, sessionId);
			if (Boolean.TRUE.equals(isUpdated)) {
				return sessionId;
			}
		} catch (Exception ex) {
			getLogger().error("Exception in updateCustomerAddress method for customeId -->" + customerId, ex);
		}
		return null;
	}

	private boolean saveCustomerAddress(Customer customerDetails, UpdateCustomerAddressDTO updateCustomerAddress,
			Integer advisorId, String sessionId) {

		String residentialAddressType = "Residential Address";
		String mailingAddressType = "Mailing Address";
		Address updatedHomeAddress = null;
		Address updatedMailingAddress = null;
		if(updateCustomerAddress!=null && customerDetails!= null) {
			AddressDTO homeAddressDTO = updateCustomerAddress.getHomeAddress();
			Address homeAddress = customerDetails.getHomeAddress();
			AddressDTO mailingAddressDTO = updateCustomerAddress.getMailingAddress();
			Address mailingAddress = customerDetails.getMailingAddress();
		try {
			Advisor advisor = accountsDao.getAdvisorById(advisorId);
			if (homeAddressDTO != null) {
				updatedHomeAddress = saveHomeAddress(homeAddressDTO, homeAddress, customerDetails);
				saveFieldsChanged(updatedHomeAddress, homeAddress, customerDetails, advisor, residentialAddressType,
						sessionId);
			}
			
			if (Boolean.TRUE.equals(updateCustomerAddress.getSameAsMailingAddress())) {
				customerDetails.setMailingAddress(null);
				accountsDao.saveOrUpdateObject(customerDetails);
				saveFieldsChanged(updatedHomeAddress, mailingAddress, customerDetails, advisor, mailingAddressType,
						sessionId);
			} else {
				if (mailingAddressDTO != null) {
					updatedMailingAddress = saveMailingAddress(mailingAddressDTO,mailingAddress,customerDetails,updateCustomerAddress);
					saveFieldsChanged(updatedMailingAddress, mailingAddress, customerDetails, advisor, mailingAddressType,
							sessionId);
				}
				else {
					customerDetails.setMailingAddress(null);
					accountsDao.saveOrUpdateObject(customerDetails);
					updatedMailingAddress = new Address();
					saveFieldsChanged(updatedMailingAddress, mailingAddress, customerDetails, advisor,
							mailingAddressType, sessionId);
				}
			}
			return true;
		} catch (Exception e) {
			getLogger().error("Exception occured in saveCustomerAddress", e);
		}
		}return false;
	}

	private Address saveHomeAddress(AddressDTO homeAddressDTO, Address homeAddress, Customer customerDetails) {
		if (homeAddress == null) {
			homeAddress = new Address();
		}
		Address updatedHomeAddress = copyAddressToNew(homeAddressDTO, homeAddress);
		if (homeAddress.getId() > 0) {
			accountsDao.saveOrUpdateObject(updatedHomeAddress);
		} else {
			accountsDao.saveOrUpdateObject(updatedHomeAddress);
			customerDetails.setHomeAddress(updatedHomeAddress);
			accountsDao.saveOrUpdateObject(customerDetails);

		}
		return updatedHomeAddress;

	}

	private Address saveMailingAddress(AddressDTO mailingAddressDTO, Address mailingAddress, Customer customerDetails,
			UpdateCustomerAddressDTO updateCustomerAddress) {
		if (mailingAddress == null) {
			mailingAddress = new Address();
		}

		Address updatedMailingAddress = copyAddressToNew(mailingAddressDTO, mailingAddress);

		if (mailingAddress.getId() != null && mailingAddress.getId() > 0) {

			accountsDao.saveOrUpdateObject(updatedMailingAddress);
		}

		customerDetails.setMailingAddress(updatedMailingAddress);

		if (updateCustomerAddress.getMailingAddress().getReasonForOthers() != null) {
			customerDetails
					.setDifferentMailingAddressReason(updateCustomerAddress.getMailingAddress().getReasonForOthers());
		}
		if (updateCustomerAddress.getMailingAddress().getReasonId() != null) {
			customerDetails.setDifferentMailingAddressReasonId(updateCustomerAddress.getMailingAddress().getReasonId());
		}
		accountsDao.saveOrUpdateObject(customerDetails);

		return updatedMailingAddress;
	}

	private void copyAddress(AddressDTO source, Address target) {
		if (source.getCountryId() != null) {
			Country country = new Country();
			country.setId(source.getCountryId());
			target.setCountry(country);
		}

		target.setAddressLine1(source.getAddressLine1());
		target.setAddressLine2(source.getAddressLine2());
		target.setCity(source.getCity());
		target.setFloor(source.getFloor());
		target.setState(source.getState());
		target.setPostalCode(source.getPostalCode());
		target.setUnitNumber(source.getUnitNumber());

		target.setTownName(source.getTownName());
		if (target.getCreatedDate() == null) {
			target.setCreatedDate(PublicUtility.getCurrentUTC());
		}
		target.setLastModifiedDate(PublicUtility.getCurrentUTC());
	}
	
	
	private Address copyAddressToNew(AddressDTO source, Address existing) {
		Address target = new Address();
		target.setId(existing.getId());
		if (source.getCountryId() != null) {
			Country country = new Country();
			country.setId(source.getCountryId());
			target.setCountry(country);
		}

		target.setAddressLine1(source.getAddressLine1());
		target.setAddressLine2(source.getAddressLine2());
		target.setCity(source.getCity());
		target.setFloor(source.getFloor());
		target.setState(source.getState());
		target.setPostalCode(source.getPostalCode());
		target.setUnitNumber(source.getUnitNumber());

		target.setTownName(source.getTownName());
		if (target.getCreatedDate() == null) {
			target.setCreatedDate(PublicUtility.getCurrentUTC());
		}
		target.setLastModifiedDate(PublicUtility.getCurrentUTC());
		return target;

	}

	private void saveFieldsChanged(Address updated, Address existing, Customer customerDetails, Advisor advisor,
			String addressType, String sessionId) {
		
		getLogger().info("Saving fields changed for Address type -- "+addressType);
		try {
			if(existing == null) {
				if(addressType.equals("Mailing Address")) { 
				existing = customerDetails.getHomeAddress();
			}else {
				existing = new Address();
			}
			}
			for (Field field : updated.getClass().getDeclaredFields()) {
				if (!field.getName().equals("id") && !field.getName().equals("createdDate")
						&& !field.getName().equals("lastModifiedDate")) {
					field.setAccessible(true);
					Object oldValue = field.get(existing);
					Object newValue = field.get(updated);
					if (field.getName().equals("country")) {
						oldValue = getFieldFromObject(oldValue, "id");
						newValue = getFieldFromObject(newValue, "id");
					}
					if (newValue != null && !Objects.equals(newValue, oldValue)) {
						saveCustomerDetailsEditHistory(customerDetails, advisor, sessionId, oldValue, newValue,
								addressType, field);
					}
				}
			}
		} catch (IllegalAccessException ex) {
			getLogger().error("Illegal Access Exception occured in getFieldsChanged", ex);
		} catch (Exception e) {
			getLogger().error("Exception occured in getFieldsChanged", e);
		}
	}

	private void saveCustomerDetailsEditHistory(Customer customerDetails, Advisor advisor, String sessionId,
			Object oldValue, Object newValue, String addressType, Field field) {
		CustomerDetailsEditHistory customerDetailsEditHistory = null;
		customerDetailsEditHistory = accountsDao.getAddressHistory(customerDetails.getId(), field.getName(),
				addressType);
		if (customerDetailsEditHistory == null) {
			customerDetailsEditHistory = new CustomerDetailsEditHistory();
			customerDetailsEditHistory.setCustomer(customerDetails);
			customerDetailsEditHistory.setColumnName(field.getName());
			customerDetailsEditHistory.setTableName(addressType);
		}
			customerDetailsEditHistory.setModifiedBy(advisor.getName());
			customerDetailsEditHistory.setModifiedDate(PublicUtility.getCurrentSGT());
			customerDetailsEditHistory.setSessionId(sessionId);
			if (oldValue != null) {
				customerDetailsEditHistory.setOldValue(oldValue.toString());
			}
			customerDetailsEditHistory.setNewValue(newValue.toString());
			customerDetailsEditHistory.setAction(ApplicationConstants.ADMIN_EDIT);
			accountsDao.saveOrUpdateObject(customerDetailsEditHistory);
		}

	private Object getFieldFromObject(Object value, String fieldName) {
		Object result = null;
		try {
			if(value!=null) {
			for (Field field : value.getClass().getDeclaredFields()) {
				field.setAccessible(true);
				if (field.getName().equals(fieldName)) {
					result = field.get(value);
					return result;
				}
			}
		} 
			}catch (IllegalArgumentException e) {
			getLogger().error("IllegalArgumentException in getFieldFromObject", e);
		} catch (IllegalAccessException e) {
			getLogger().error("IllegalAccessException in getFieldFromObject", e);
		}
		return null;
	}
	
	@Override
	public boolean editPassword(Customer customerDetails, UpdatePasswordDTO newPasswordDetails) {
		try {
			byte[] passwordArray = customerDetails.getPassword();
			String password = new String(passwordArray, "UTF-8");
			String currentPassword = "";
			// ---------------- BFA-1552 ---------------------				
			if(customerDetails.getUniqueId() != null){
				String unsaltedPassword = utility.decryptTextWithKey(password, customerDetails.getUniqueId());
				currentPassword = unsaltedPassword;
			}
			else{
			//---------------------------------------------------
				currentPassword = utility.DecryptText(password);
			}			
			getLogger().info("Printing the session id for edit password " + newPasswordDetails.getSessionId());

			getLogger().info("New password:" + newPasswordDetails.getNewPassword());
			String oldPassword = passwordEncryptionService.decrypt(newPasswordDetails.getOldPassword(),
					newPasswordDetails.getSessionId());
			String newPassword = passwordEncryptionService.decrypt(newPasswordDetails.getNewPassword(),
					newPasswordDetails.getSessionId());
			
			if (currentPassword.equals(oldPassword)) {
				// -------------------------------------------------------------
				//------------------- BFA-1552 ----------------------------
				try {
					byte[] uniqueId = utility.getSalt();
					customerDetails.setUniqueId(uniqueId);
					String newPasswordDTO = utility.encryptTextWithKey(newPassword, false, uniqueId);
					customerDetails.setPassword(newPasswordDTO.getBytes());			
				} catch (NoSuchAlgorithmException e) {			
					getLogger().error("Error while obtaining the salted key",e);
				}
				// -------------------------------------------------------------- 
				accountsDao.saveOrUpdateObject(customerDetails);
				return true;
			}

		} catch (Exception e) {
			getLogger().error("Error while updating password ", e);
		}
		return false;
	}

	@Override
	public CustomerContactVerification editContactDetails(ContactDetailsDTO updateCustomercontact, Integer customerId) {

		CustomerContactVerification updatedContactedDetails;
		String contactNumber = null;
		String countryCode = null;
		String otpString = null;

		String actionType = new String(ApplicationConstants.CUSTOMER_UPDATE_TYPE);
		updatedContactedDetails = securityDAO.getCustomerContactVerificationByCustomerIdAndType(customerId, actionType);
		if (updatedContactedDetails == null) {
			updatedContactedDetails = new CustomerContactVerification();
		}
		otpString = generateOTP();
		contactNumber = updateCustomercontact.getMobileNumber();
		countryCode = updateCustomercontact.getCountryCode();
		sendOTP(contactNumber, countryCode, otpString, false);
		updatedContactedDetails.setCountryCode(countryCode);
		updatedContactedDetails.setMobileNumber(contactNumber);
		updatedContactedDetails.setOTPString(appendDateToOTP(otpString));
		updatedContactedDetails.setOtpVerifiedStatus("No");
		updatedContactedDetails.setActionType(ApplicationConstants.CUSTOMER_UPDATE_TYPE);
		updatedContactedDetails.setCustomer(getCustomerById(customerId));
		accountsDao.saveOrUpdateObject(updatedContactedDetails);
		return updatedContactedDetails;
	}

	public DetailedCustomerSummary getDetailedCustomerSummary(Integer customerId, Integer enquiryId) {
		getLogger().info("DetailedCustomerSummary for customerid: " + customerId + "for enquiryId: " + enquiryId);
		DetailedCustomerSummary parameters = new DetailedCustomerSummary();	

		Optional<CustomerSrsAccount> srsDetails = customerSrsAccountRepository
				.findTopByCustomerIdOrderByCustomerIdDesc(customerId);
		if (srsDetails.isPresent()) {
			CustomerSrsAccount srsData = srsDetails.get();
			parameters.setSrsDetails(srsData);
		}

		List<CustomerTaxDetails> taxDetails = dao.getCustomerTaxDetails(customerId);
		if (taxDetails != null) {
			taxDetails.stream().forEach(b -> {
				String taxDateOfBirth = formatDOB(b.getCustomer().getDateOfBirth());
				b.getCustomer().setDateOfBirth(taxDateOfBirth);

			});
		}
		
		parameters.setTaxDetails(taxDetails);
		CustomerInvestmentObjective investmentObjective = null;
		if (enquiryId != null && enquiryId > 0) {

			investmentObjective = dao.getCustomerInvestmentObjective(customerId, enquiryId);
		} else {

			investmentObjective = dao.getCustomerInvestmentObjective(customerId);
		}

		parameters.setInvestmentObjective(investmentObjective);

		Optional<CustomerAdditionalDetails> additionalDetails = customerAdditionalDetailsRepository
				.findFirstBycustomer_id(customerId);
		if (additionalDetails.isPresent()) {
			CustomerAdditionalDetails additionalDetailsData = additionalDetails.get();
			String addDateOfBirth = formatDOB(additionalDetailsData.getCustomer().getDateOfBirth());
			additionalDetailsData.getCustomer().setDateOfBirth(addDateOfBirth);
			parameters.setAdditionalDetails(additionalDetailsData);
			
			if (!ObjectUtils.isEmpty(additionalDetailsData.getRegistrationProofType()) 
					&& "MY-INFO".equalsIgnoreCase(additionalDetailsData.getRegistrationProofType())) {


			} else {


			}
		}
		Optional<CustomerPEPDetails> pepDetails = customerPEPDetailsRepository.findFirstBycustomer_id(customerId);
		if (pepDetails.isPresent()) {
			CustomerPEPDetails pepDetailsData = pepDetails.get();
			String pepDateOfBirth = formatDOB(pepDetailsData.getCustomer().getDateOfBirth());
			pepDetailsData.getCustomer().setDateOfBirth(pepDateOfBirth);
			parameters.setPepDetails(pepDetailsData);
		}

		Optional<CustomerIdentityDetails> customerIdentityDetails = customerIdentityDetailsRepository
				.findFirstBycustomer_id(customerId);
		if (customerIdentityDetails.isPresent()) {
			CustomerIdentityDetails customerIdentityDetailsData = customerIdentityDetails.get();
			String idDateOfBirth = formatDOB(customerIdentityDetailsData.getCustomer().getDateOfBirth());
			customerIdentityDetailsData.getCustomer().setDateOfBirth(idDateOfBirth);
			parameters.setIdentityDetails(customerIdentityDetailsData);

		}

		
		Optional<Customer> customerDetails = customerRepository.findById(customerId);
		

		if (customerDetails.isPresent()) {
			Customer customerData = customerDetails.get();
			String dateOfBirth = customerData.getDateOfBirth();
			customerData.setDateOfBirth(dateOfBirth);
			parameters.setCustomer(customerData);
			
			Optional<Country> countryDetails = countryRepository.findFirstByNationalityCode(customerData.getNationalityCode());
			if(countryDetails.isPresent()) {
				Country countryData =  countryDetails.get();
				setNationality(parameters,countryData);
			}
			
		}

		//
		CustomerEmploymentInformation employmentInfo = new CustomerEmploymentInformation();
		Optional<CustomerEmploymentDetails> customerEmploymentDetails = customerEmploymentDetailsRepository
				.findFirstByCustomerId(customerId);
		if (customerEmploymentDetails.isPresent()) {
			CustomerEmploymentDetails customerEmploymentData = customerEmploymentDetails.get();
			employmentInfo.setCustomerEmploymentDetails(customerEmploymentData);
			Optional<EmployerDetails> employerDetails = employerRepository
					.findFirstById(customerEmploymentData.getEmployerId());
			if (employerDetails.isPresent()) {
				EmployerDetails employerData = employerDetails.get();
				employmentInfo.setEmployerDetails(employerData);

			}
			Optional<EmployerAddress> employerAddress = employerAddressRepository
					.findFirstByEmployerId(customerEmploymentData.getEmployerId());
			if (employerAddress.isPresent()) {
				EmployerAddress employerAddressData = employerAddress.get();
				employmentInfo.setEmployerAddress(employerAddressData);
			}

			parameters.setEmploymentInformation(employmentInfo);

		}

		List<CustomerDocumentDetails> documentDetails = dao.getCustomerDocumentDetails(customerId);
		if (documentDetails != null) {
			documentDetails.stream().forEach(b -> {
				String docDateOfBirth = formatDOB(b.getCustomer().getDateOfBirth());
				b.getCustomer().setDateOfBirth(docDateOfBirth);

			});
		}
		parameters.setDocumentDetails(documentDetails);
		
		getLogger().info("DetailedCustomerSummary details:  " + parameters);
		return parameters;
	}

	private void setNationality(DetailedCustomerSummary parameters, Country countryData) {
		NationalityDTO nationalityDto = new NationalityDTO();

		nationalityDto.setName(countryData.getNationality());
		nationalityDto.setNationalityCode(countryData.getNationalityCode());
		// All countries under a nationality will have same isBlocked status
		nationalityDto.setBlocked(countryData.isBlocked());
		nationalityDto.setListorder(countryData.getListOrder());
		ArrayList<GroupedCountryDTO> grpCountryList = new ArrayList<>();

		GroupedCountryDTO cDto = new GroupedCountryDTO();
		cDto.setId(countryData.getId());
		cDto.setCountryCode(countryData.getCountryCode());
		cDto.setName(countryData.getCountry());
		cDto.setPhoneCode(countryData.getPhoneCode());
		grpCountryList.add(cDto);

		nationalityDto.setCountries(grpCountryList);
/*		parameters.setNationality(nationalityDto);*/

	}

	private String formatDOB(String dateOfBirth) {
		getLogger().info("reached formatDOB method input date: " + dateOfBirth);
		if ("".equals(dateOfBirth)) {
			return dateOfBirth;
		}
		Date defaultDateFormat = null;
		Date alternateFormat = null;
		String convertedDOB = null;
		String userDefinedDateFormat = "yyyy-MM-dd";
		defaultDateFormat = PublicUtility.parseDateString(dateOfBirth, userDefinedDateFormat, null);
		if (defaultDateFormat != null) {

			convertedDOB = PublicUtility.dateToString(defaultDateFormat, userDefinedDateFormat);
		}
		if (defaultDateFormat == null) {
			alternateFormat = PublicUtility.parseDateString(dateOfBirth, "yyyy-M-d", null);
			convertedDOB = PublicUtility.dateToString(alternateFormat, userDefinedDateFormat);
		}
		if (defaultDateFormat == null && alternateFormat == null) {
			convertedDOB = null;
		}
		return convertedDOB;
	}

	public ServiceResponse<Map<String, String>> saveDocument(Integer customerId, MultipartFile uploadedFile,
			String type) {
		getLogger().info("reached saveDocument method");
		ServiceResponse<Map<String, String>> response = new ServiceResponse<>();
		response.addResponseInfo("step", "SAVING_DOCUMENT");
		response.setSuccess(true);
		// Upload document to AWS S3 Bucket
		try {
			boolean status = true;
			if (uploadedFile.equals(null)) {
				getLogger().debug("uploadedFile null value");
				throw new BfaException("uploadedFile null object"); // Generic exceptions should never be thrown (squid:S00112)
			}
			String[] fileFrags = uploadedFile.getOriginalFilename().split("\\.");
			getLogger().info("Original filename:" + uploadedFile.getOriginalFilename());
			getLogger().info("fileFrags length" + fileFrags.length);
			if (fileFrags.length < 2) {
				throw new BfaException("fileFrags length less than two, no extension found"); // Generic exceptions should never be thrown (squid:S00112)
			}
			String extension = fileFrags[fileFrags.length - 1];
			getLogger().info("extension" + extension);
			String fileName = customerId + "_";
			getLogger().info("fileName" + fileName);
			fileName += type + "." + extension;
			File file = null;

			// file = PublicUtility.convertMultiPartToFile(uploadedFile);
			if (amazonS3ClientService.equals(null)) {
				getLogger().info("amazonS3ClientService found as null,creating new object");
				AmazonS3ClientService amazonS3ClientService = new AmazonS3ClientServiceImpl();
				this.amazonS3ClientService = amazonS3ClientService;
			}
			getLogger().info("bucketName :" + bucketName + "and fileName :" + fileName);
			String fileUrl = this.amazonS3ClientService.upload(bucketName, fileName, uploadedFile);
			getLogger().info("fileUrl" + fileUrl);
			CustomerDocumentDetails docDetails = new CustomerDocumentDetails();
			customerDocService.saveOrUpdateCustomerDocument(customerId, fileUrl, type);
			response.addResponseInfo("filePath", fileUrl);
			response.addResponseInfo("type", type);
		} catch (Exception e) {
			response.addExceptionInfo(e);
			getLogger().error("Excepion while saveDocument: " + e);
			getLogger().debug("exception in saveDocument() : " + e.getMessage());
		}

		return response;
	}

	public boolean deleteDocument(Integer customerId, String docType) {
		boolean status = true;
		try {
			// Upload document to AWS S3 Bucket
			CustomerDocumentDetails docDetail = dao.getCustomerDocumentDetails(customerId, docType);
			if (docDetail != null) {
				amazonS3ClientService.deleteFileFromS3Bucket(docDetail.getFileName());
				DocumentStatusMaster docStatus = customerDocDao.getDocumentStatus(DocumentStatusTypes.DELETED);
				docDetail.setDocumentStatus(docStatus);
				docDetail.setLastUpdatedTimeStamp(PublicUtility.getCurrentUTC());
				dao.saveOrUpdateDetails(docDetail);
			}
		} catch (Exception ex) {
			getLogger().error("Excepion while deleteDocument: " + ex);
			status = false;
		}
		return status;
	}

	@Override
	public ServiceResponse<Map<String, String>> saveCustomerDetails(CustomerDetailsDTO accountDetails,
			Integer customerId) {
		getLogger().info("Save Customer Details for customer : " + customerId);
		ServiceResponse<Map<String, String>> response = new ServiceResponse<>();
		response.addResponseInfo("step", "SAVING_INVESTMENT_DETAILS");
		response.setSuccess(true);
		try {
			Integer residentialAddressId = null;
			Integer mailingAddressId = null;
			Customer customer = getCustomerDetails(customerId);
			CustomerEmploymentInformation customerEmploymentInfo = null;
			if (accountDetails != null && customer != null) {
				// Save customer identity details
				saveCustomerIdentityDetails(accountDetails, customer);

				// Update customer informations
				saveCustomerInformations(accountDetails, customer);

				// Update Addresses
				updateCustomerAddress(customer, accountDetails);

				// Save employer details
				if (accountDetails.getEmploymentDetails() != null) {
					Integer employerAddressId = null;
					Integer employerId = null;
					Integer employerContactDetailsId = null;
					customerEmploymentInfo = dao.getCustomerEmploymentInformation(customerId);
					// To store employer address in 'address' table
					employerAddressId = updateEmployerAddress(customerEmploymentInfo, accountDetails);

					// To store employer details in 'employer' table
					employerId = updateEmployerDetails(customerEmploymentInfo, accountDetails);

					// To save employer address, contact number in
					// 'employer_address' table
					if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerAddress() != null) {
						employerContactDetailsId = customerEmploymentInfo.getEmployerAddress().getId();
					}
					updateEmployerContactDetails(employerContactDetailsId, employerId, employerAddressId,
							accountDetails);

					// To save customer employment details in
					// 'customer_employment_details'
					updateCustomerEmploymentDetails(customerId, employerId, accountDetails);
				}
				updateInvestmentAccountStatus(InvestmentAccountStatus.INVESTMENT_ACCOUNT_DETAILS_SAVED);
				// Save customer household details
				saveHouseholdDetails(accountDetails, customer);

				// save user financial details
				saveFinancialDetails(accountDetails, customer);

				// save asset and liabilities
				saveAssetLiabilitiesDetails(accountDetails, customer);

				// Save Tax Details
				saveTaxDetails(accountDetails, customer);

				// Save additional details
				saveAdditionsDetails(accountDetails, customer);

			} else {
				if (accountDetails != null)
					response.addErrorInfo("accountDetailsError", "accountDetails object is null");
				if (customer != null)
					response.addErrorInfo("customerObjectError", "customer is null");
			}
		} catch (Exception ex) {
			getLogger().debug("exception caught in saveCustomerDetails" + ex);
			getLogger().debug("exception message in saveCustomerDetails" + ex.getMessage());
			response.addExceptionInfo(ex);
		}
		return response;
	}

	private void updateInvestmentAccountStatus(String status) {
		investService.updateInvestmentAccountStatus(status);
	}

	private void saveCustomerInformations(CustomerDetailsDTO accountDetails, Customer customer) {

		if (accountDetails != null && accountDetails.getPersonalInfo() != null && customer != null) {
			PersonalDetailsDTO dto = accountDetails.getPersonalInfo();

			customer.setNationalityCode(dto.getNationalityCode());
			if (dto.getRace() != null)
				customer.setRace(dto.getRace());
			if (dto.getSalutation() != null)
				customer.setSalutation(dto.getSalutation());
			if (dto.getFullName() != null)
				customer.setNricName(dto.getFullName());
			if (dto.getFirstName() != null)
				customer.setGivenName(dto.getFirstName());
			if (dto.getLastName() != null)
				customer.setSurName(dto.getLastName());
			if (dto.getFullName() != null)
				customer.setNricName(dto.getFullName());
			if (dto.getGender() != null)
				customer.setGender(dto.getGender());
			if (dto.getDateOfBirth() != null)
				customer.setDateOfBirth(PublicUtility.dateToString(dto.getDateOfBirth(),"yyyy-MM-dd"));
			if (dto.getBirthCountryId() != null) {
				Country countryOfBirth = new Country();
				countryOfBirth.setId(dto.getBirthCountryId());
				customer.setCountryOfBirth(countryOfBirth);
			} else {
				customer.setCountryOfBirth(null);
			}
			customer.setDobUpdatedBy(ApplicationConstants.INVESTMENT_JOURNEY_TYPE);
			dao.saveOrUpdateDetails(customer);
			
		}
	}
	
	private boolean saveCustomerIdentityDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		boolean status = true;
		if (accountDetails != null && accountDetails.getPersonalInfo() != null && customer != null) {
			PersonalDetailsDTO dto = accountDetails.getPersonalInfo();
			CustomerIdentityDetails details = dao.getCustomerIdentityDetails(customer.getId());
			if (details == null) {
				details = new CustomerIdentityDetails();
				details.setCreatedDate(PublicUtility.getCurrentUTC());
			}
			details.setCustomer(customer);
			details.setLastModifiedDate(PublicUtility.getCurrentUTC());
			details.setNricNumber(dto.getNricNumber());
			details.setPassportNumber(dto.getPassportNumber());
			details.setPassportExpiryDate(dto.getPassportExpiryDate());
			if (dto.getPassportIssuedCountryId() != null) {
				Country country = new Country();
				country.setId(dto.getPassportIssuedCountryId());
				details.setPassportIssuedCountry(country);
			} else {
				details.setPassportIssuedCountry(null);
			}

			dao.saveOrUpdateDetails(details);
		}
		return true;
	}

	private void saveAdditionsDetails(CustomerDetailsDTO accountDetails, Customer customer) {

		if (accountDetails != null && accountDetails.getPersonalDeclarations() != null) {
			// Save customer investment souce details
			saveCustomerInvestmentSource(accountDetails, customer);
			// Save customer additional details
			saveCustomerAdditionalDetails(accountDetails, customer);
		}
	}

	private void saveCustomerAdditionalDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			if (accountDetails != null && accountDetails.getPersonalDeclarations() != null) {
				CustomerAdditionalDetails details = dao.getCustomerAdditionalDetails(customer.getId());
				if (details == null) {
					details = new CustomerAdditionalDetails();
					details.setCustomer(customer);
				}
				if (accountDetails.isMyInfoVerified() != null && accountDetails.isMyInfoVerified()) {
					details.setRegistrationProofType(AccountVerificationMode.MY_INFO);
				} else if (accountDetails.isMyInfoVerified() != null) {
					details.setRegistrationProofType(AccountVerificationMode.PASSPORT);
				}
				if (accountDetails.getPersonalDeclarations().isBeneficialOwner() != null) {
					details.setBeneficialOwner(accountDetails.getPersonalDeclarations().isBeneficialOwner());
				}
				if (accountDetails.getPersonalDeclarations().isPoliticallyExposed() != null) {
					details.setPoliticallyExposed(accountDetails.getPersonalDeclarations().isPoliticallyExposed());
				}
				if (accountDetails.getPersonalDeclarations().getPepDeclaration() != null && accountDetails
						.getPersonalDeclarations().getPepDeclaration().getExpectedNumberOfTransactions() != null) {
					savePEPDetails(accountDetails, customer);
					updateInvestmentAccountStatus(InvestmentAccountStatus.EDD_CHECK_PENDING);
				}

				if (accountDetails.getPersonalDeclarations().isConnectedToInvestmentFirm() != null) {
					details.setConnectedToInvestmentFirm(
							accountDetails.getPersonalDeclarations().isConnectedToInvestmentFirm());
				}
				if (accountDetails.getSingaporePR() != null) {
					details.setSingaporePR(accountDetails.getSingaporePR());
				}
				dao.saveOrUpdateDetails(details);
			}
		} catch (Exception ex) {
			if(customer!=null ) {
				getLogger().error("Exception catched in saveCustomerAdditionalDetails() for the customer :  " + customer.getId() + "===>" + ex);
			}
			getLogger().error("Exception catched in saveCustomerAdditionalDetails() : " + ex);
		}
	}

	private void savePEPDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			if (accountDetails != null && accountDetails.getPersonalDeclarations() != null
					&& accountDetails.getPersonalDeclarations().getPepDeclaration() != null) {
				PEPAdditionalDeclarationDTO dto = accountDetails.getPersonalDeclarations().getPepDeclaration();
				CustomerPEPDetails details = dao.getCustomerPEPDetails(customer.getId());
				if (details == null) {
					details = new CustomerPEPDetails();
					details.setCustomer(customer);
				}
				if (dto.getFirstName() != null) {
					details.setFirstName(dto.getFirstName());
				}
				if (dto.getLastName() != null) {
					details.setLastName(dto.getLastName());
				}
				if (dto.getCompanyName() != null) {
					details.setCompanyName(dto.getCompanyName());
				}
				if (dto.getInvestmentDuration() != null) {
					details.setInvestmentPeriod(dto.getInvestmentDuration());
				}
				if (dto.getOccupationId() != null) {
					Occupation occupation = new Occupation();
					occupation.setId(dto.getOccupationId());
					details.setOccupation(occupation);
				}
				if (dto.getOtherOccupation() != null) {
					details.setOtherOccupation(dto.getOtherOccupation());
				}
				if (dto.getExpectedAmountPerTransaction() != null) {
					details.setExpectedAmountPerTransactions(dto.getExpectedAmountPerTransaction());
				}
				if (dto.getExpectedNumberOfTransactions() != null) {
					details.setExpectedNumberOfTransactions(dto.getExpectedNumberOfTransactions());
				}
				if (dto.getAdditionalInfo() != null) {
					details.setAdditionalInfo(dto.getAdditionalInfo());
				}

				if (accountDetails.getPersonalDeclarations().getPepDeclaration().getInvestmentSourceId() != null) {
					OptionItem source = new OptionItem();
					source.setId(accountDetails.getPersonalDeclarations().getPepDeclaration().getInvestmentSourceId());
					details.setInvestmentSourceId(source);
				}

				if (dto.getEarningSourceId() != null) {
					OptionItem earning = new OptionItem();
					earning.setId(accountDetails.getPersonalDeclarations().getPepDeclaration().getEarningSourceId());
					details.setInvestmentPeriod(
							accountDetails.getPersonalDeclarations().getPepDeclaration().getInvestmentDuration());
					details.setEarningsGeneratedFromId(earning);
				}
				if (dto.getPepAddress() != null) {

					Address pepAddress = details.getPepAddress();
					if (details.getPepAddress() == null) {
						pepAddress = new Address();
					}

					copyAddress(dto.getPepAddress(), pepAddress);

				dao.saveOrUpdateDetails(pepAddress);

					details.setPepAddress(pepAddress);
				}

				dao.saveOrUpdateDetails(details);
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while savePEPDetails() for the customer : " +customer.getId() + "==>" + ex);
		}
	}

	private void saveCustomerInvestmentSource(CustomerDetailsDTO accountDetails, Customer customer) {
		getLogger().info("Save CustomerInvestmentSource for customer : " + customer.getId());
		try {
			if (accountDetails != null && accountDetails.getPersonalDeclarations() != null
					&& accountDetails.getPersonalDeclarations().getInvestmentSourceId() != null) {
				CustomerInvestmentObjective objective = dao.getCustomerInvestmentObjective(customer.getId());
				OptionItem source = new OptionItem();
				source.setId(accountDetails.getPersonalDeclarations().getInvestmentSourceId());
				getLogger().info("CustomerInvestmentSource for customer : " + customer.getId() + "details: " + accountDetails.getPersonalDeclarations());
				objective.setInvestmentSource(source);
				dao.saveOrUpdateDetails(objective);
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while saveCustomerInvestmentSource() for the customer : " +customer.getId() + "==>" + ex);
		}
	}

	private void saveTaxDetails(CustomerDetailsDTO accountDetails, Customer customer) {

		if (accountDetails != null && accountDetails.getTaxDetails() != null) {

			List<CustomerTaxDetails> taxDetails = dao.getCustomerTaxDetails(customer.getId());

			if (taxDetails != null) {
				for (CustomerTaxDetails taxDetail : taxDetails) {
					taxDetail.setCustomer(null);
					dao.saveOrUpdateDetails(taxDetail);
				}
			}
			CustomerTaxDetails taxDetail = new CustomerTaxDetails();

			for (CustomerTaxDetailsDTO taxDetailDTO : accountDetails.getTaxDetails()) {
				Country country = new Country();
				country = dao.getCountry(taxDetailDTO.getTaxCountryId());

				taxDetail.setCustomer(customer);
				taxDetail.setTaxCountry(country);
				taxDetail.setTinNumber(taxDetailDTO.getTinNumber());
				taxDetail.setNoTinReason(taxDetailDTO.getNoTinReason());
				taxDetail.setCreatedDate(PublicUtility.getCurrentUTC());
				taxDetail.setLastModifiedDate(PublicUtility.getCurrentUTC());
				accountsDao.saveObject(taxDetail);
			}
		}
	}

	private void saveAssetLiabilitiesDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			Enquiry enquiry = null;
			if (accountDetails.getFinancialDetails() != null && customer != null) {
				// Save asset details
				Assets asset = dao.getCustomerAssetDetails(customer.getId());
				if (asset == null) {
					asset = new Assets();
					asset.setCustomerId(customer.getId());
					enquiry = dao.getCustomerEnquiryDetails(customer.getId());
					if (enquiry != null) {
						asset.setEnquiryId(enquiry.getId());
					}
				}
				asset.setTotalAssets(accountDetails.getFinancialDetails().getTotalAssets());
				dao.saveOrUpdateDetails(asset);

				// Save liabilities details
				Liabilities liabilities = dao.getCustomerLiabilitiesDetails(customer.getId());
				if (liabilities == null) {
					liabilities = new Liabilities();
					liabilities.setCustomerId(customer.getId());
					if (enquiry != null)
						liabilities.setEnquiryId(enquiry.getId());
					else {
						enquiry = dao.getCustomerEnquiryDetails(customer.getId());
						if (enquiry != null) {
							liabilities.setEnquiryId(enquiry.getId());
						}
					}
				}
				liabilities.setTotalLiabilities(accountDetails.getFinancialDetails().getTotalLoans());
				dao.saveOrUpdateDetails(liabilities);
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while saveAssetLiabilitiesDetails() for the customer : " +customer.getId() + "==>" + ex);
		}
	}

	private void saveFinancialDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			Enquiry enquiry = null;
			if (accountDetails.getFinancialDetails() != null && customer != null) {
				Income income = dao.getCustomerIncomeDetails(customer.getId());
				if (income == null) {
					income = new Income();
					income.setCustomerId(customer.getId());
					enquiry = dao.getCustomerEnquiryDetails(customer.getId());
					if (enquiry != null) {
						income.setEnquiryId(enquiry.getId());
					}
				}
				if (accountDetails.getFinancialDetails().getAnnualIncome() != null) {
					income.setAnnualSalary(accountDetails.getFinancialDetails().getAnnualIncome());
				}

				if (accountDetails.getFinancialDetails().getPercentageOfSaving() != null) {
					income.setPercentageOfSaving(accountDetails.getFinancialDetails().getPercentageOfSaving());
				}
				if (accountDetails.getFinancialDetails().getIncomeRange() != null) {
					income.setIncomeRange(accountDetails.getFinancialDetails().getIncomeRange());
				}
				dao.saveOrUpdateDetails(income);
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while saveFinancialDetails() for the customer : " +customer.getId() + "==>" + ex);
		}
	}

	private void saveHouseholdDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		if (accountDetails.getHouseholdDetails() != null) {
			if (customer.getHouseHoldDetail() != null) {
				Household household = customer.getHouseHoldDetail();

				if (accountDetails.getHouseholdDetails().getHouseHoldIncomeId() != null) {
					OptionItem houseHoldIncome = new OptionItem();
					houseHoldIncome.setId(accountDetails.getHouseholdDetails().getHouseHoldIncomeId());
					household.setHouseHoldIncome(houseHoldIncome);
				}
				household.setNumberOfMembers(accountDetails.getHouseholdDetails().getNumberOfMembers());
				dao.saveOrUpdateDetails(household);
			} else {
				Household houseHold = new Household();
				if (accountDetails.getHouseholdDetails().getHouseHoldIncomeId() != null) {
					OptionItem houseHoldIncome = new OptionItem();
					houseHoldIncome.setId(accountDetails.getHouseholdDetails().getHouseHoldIncomeId());
					houseHold.setHouseHoldIncome(houseHoldIncome);
				}
				houseHold.setNumberOfMembers(accountDetails.getHouseholdDetails().getNumberOfMembers());
				customer.setHouseHoldDetail(houseHold);
				dao.saveOrUpdateDetails(houseHold);
				dao.saveOrUpdateDetails(customer);
			}
		}
	}

	private Integer updateEmployerAddress(CustomerEmploymentInformation customerEmploymentInfo,
			CustomerDetailsDTO accountDetails) {
		Integer employerAddressId = null;
		try {
			if (accountDetails != null && accountDetails.getEmploymentDetails() != null
					&& accountDetails.getEmploymentDetails().getEmployerAddress() != null) {
				// If address is new
				Address employerAddress = new Address();
				copyAddress(accountDetails.getEmploymentDetails().getEmployerAddress(), employerAddress);
				dao.saveOrUpdateAddress(employerAddress);
				employerAddressId = employerAddress.getId();
				if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerAddress() != null) {
					customerEmploymentInfo.getEmployerAddress().setEmployerAddress(employerAddress);
				}
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while updateEmployerAddress() ==>" + ex);
		}
		return employerAddressId;
	}

	private Integer updateEmployerAddress(CustomerEmploymentInformation customerEmploymentInfo,
			EmploymentDetailsDTO accountDetails) {
		Integer employerAddressId = null;
		try {
			if (accountDetails != null && accountDetails.getEmployerAddress() != null) {
				// If address is new
				Address employerAddress = new Address();
				copyAddress(accountDetails.getEmployerAddress(), employerAddress);
				dao.saveOrUpdateAddress(employerAddress);
				employerAddressId = employerAddress.getId();
				if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerAddress() != null) {
					customerEmploymentInfo.getEmployerAddress().setEmployerAddress(employerAddress);
				}
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while updateEmployerAddress() for the customer : ==>" + ex);
		}
		return employerAddressId;
	}

	private void updateCustomerEmploymentDetails(Integer customerId, Integer employerId,
			CustomerDetailsDTO accountDetails) {
		try {
			if (customerId > 0 && employerId > 0 && accountDetails != null
					&& accountDetails.getEmploymentDetails() != null) {

				CustomerEmploymentDetails details = new CustomerEmploymentDetails();
				details.setCustomerId(customerId);
				details.setEmployerId(employerId);
				if (accountDetails.getEmploymentDetails().getOccupationId() > 0) {
					Occupation occupation = new Occupation();
					occupation.setId(accountDetails.getEmploymentDetails().getOccupationId());
					details.setOccupation(occupation);
				} else {
					details.setOccupation(null);
				}
				details.setOtherOccupation(accountDetails.getEmploymentDetails().getOtherOccupation());
				details.setUnemployedReason(accountDetails.getEmploymentDetails().getUnemployedReason());
				details.setEmploymentStatusId(accountDetails.getEmploymentDetails().getEmploymentStatusId());
				dao.saveOrUpdateDetails(details);
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched in updateCustomerEmploymentDetails() for the customer: " + customerId + "===>" + ex); 
		}
	}

	private void updateCustomerEmploymentDetails(Integer customerId, Integer employerId,
			EmploymentDetailsDTO employmentDetails) {
		try {
			if (customerId > 0 && employerId > 0 && employmentDetails != null) {

				CustomerEmploymentDetails details = new CustomerEmploymentDetails();
				details.setCustomerId(customerId);
				details.setEmployerId(employerId);
				if (employmentDetails.getOccupationId() > 0) {
					Occupation occupation = new Occupation();
					occupation.setId(employmentDetails.getOccupationId());
					details.setOccupation(occupation);
				} else {
					details.setOccupation(null);
				}
				details.setOtherOccupation(employmentDetails.getOtherOccupation());
				details.setUnemployedReason(employmentDetails.getUnemployedReason());
				details.setEmploymentStatusId(employmentDetails.getEmploymentStatusId());
				dao.saveOrUpdateDetails(details);
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while updateEmployerAddress() for the customer : " + customerId + "===>" + ex);
		}
	}

	private Integer updateEmployerDetails(CustomerEmploymentInformation customerEmploymentInfo,
			CustomerDetailsDTO accountDetails) {
		Integer employerId = null;
		try {
			if (accountDetails.getEmploymentDetails() != null) {
				if (null != customerEmploymentInfo && null != customerEmploymentInfo.getEmployerDetails()) {
					employerId = customerEmploymentInfo.getEmployerDetails().getId();
				}

				EmployerDetails details = new EmployerDetails();
				if (accountDetails.getEmploymentDetails().getIndustryId() > 0) {
					Industry industry = new Industry();
					industry.setId(accountDetails.getEmploymentDetails().getIndustryId());
					details.setIndustry(industry);
				} else {
					details.setIndustry(null);
				}
				details.setOtherIndustry(accountDetails.getEmploymentDetails().getOtherIndustry());
				details.setEmployerName(accountDetails.getEmploymentDetails().getEmployerName());
				if (employerId != null && employerId > 0) {
					details.setId(employerId);
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				} else {
					details.setId(null);
					details.setCreatedDate(PublicUtility.getCurrentUTC());
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				}
				dao.saveOrUpdateDetails(details);
				employerId = details.getId();
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while updateEmployerDetails() : " + ex);
		}

		return employerId;
	}

	private Integer updateEmployerDetails(CustomerEmploymentInformation customerEmploymentInfo,
			EmploymentDetailsDTO employmentDetails) {
		Integer employerId = null;
		try {
			if (employmentDetails != null) {
				if (null != customerEmploymentInfo && null != customerEmploymentInfo.getEmployerDetails()) {
					employerId = customerEmploymentInfo.getEmployerDetails().getId();
				}

				EmployerDetails details = new EmployerDetails();
				if (employmentDetails.getIndustryId() > 0) {
					Industry industry = new Industry();
					industry.setId(employmentDetails.getIndustryId());
					details.setIndustry(industry);
				} else {
					details.setIndustry(null);
				}
				details.setOtherIndustry(employmentDetails.getOtherIndustry());
				details.setEmployerName(employmentDetails.getEmployerName());
				if (employerId != null && employerId > 0) {
					details.setId(employerId);
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				} else {
					details.setId(null);
					details.setCreatedDate(PublicUtility.getCurrentUTC());
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				}
				dao.saveOrUpdateDetails(details);
				employerId = details.getId();
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while updateEmployerDetails() ===>" + ex);
		}

		return employerId;
	}

	private Integer updateEmployerContactDetails(Integer contactDetailsId, Integer employerId,
			Integer employerAddressId, CustomerDetailsDTO accountDetails) {

		try {
			if (accountDetails != null && accountDetails.getEmploymentDetails() != null) {
				if (employerId != null && employerId > 0) {
					EmployerAddress details = new EmployerAddress();
					details.setContactNumber(accountDetails.getEmploymentDetails().getContactNumber());
					if (employerAddressId != null) {
						Address address = new Address();
						address.setId(employerAddressId);
						details.setEmployerAddress(address);
					}
					details.setEmployerId(employerId);
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
					details.setId(contactDetailsId);
					dao.saveOrUpdateDetails(details);
				}
			}
		} catch (Exception ex) {
			getLogger().error("Exception catched while updateEmployerDetails() for the employee : " + employerAddressId + "===>" + ex);
		}

		return employerId;
	}

	private Integer updateEmployerContactDetails(Integer contactDetailsId, Integer employerId,
			Integer employerAddressId, EmploymentDetailsDTO employmentDetails) {

		try {
			if (null != employmentDetails && null != employerId && employerId > 0) {
				EmployerAddress details = new EmployerAddress();
				details.setContactNumber(employmentDetails.getContactNumber());
				if (employerAddressId != null) {
					Address address = new Address();
					address.setId(employerAddressId);
					details.setEmployerAddress(address);
				}
				details.setEmployerId(employerId);
				details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				details.setId(contactDetailsId);
				dao.saveOrUpdateDetails(details);

			}
		} catch (Exception ex) {
			getLogger().error("Exception while update employer contact details for the employer id: " + employerId + "===>" + ex);
		}

		return employerId;
	}

	private void updateCustomersTable() {

	}

	private Customer getCustomerDetails(Integer customerId) {
		return dao.getCustomer(customerId);
	}

	public void updateCustomerAddress(Customer customer, CustomerDetailsDTO accountDetails) {
		if (customer != null) {
			if (accountDetails.getResidentialAddress() != null) {
				Address homeAddress = customer.getHomeAddress();
				if (homeAddress == null) {
					homeAddress = new Address();
					customer.setHomeAddress(homeAddress);
				}
				copyAddress(accountDetails.getResidentialAddress(), homeAddress);
				dao.saveOrUpdateDetails(homeAddress);
			}
			if (accountDetails.getSameAsMailingAddress() != null && accountDetails.getSameAsMailingAddress()) {
				customer.setMailingAddress(null);
			} else {
				if (accountDetails.getMailingAddress() != null) {
					Address mailingAddress = customer.getMailingAddress();
					if (mailingAddress == null) {
						mailingAddress = new Address();
						customer.setMailingAddress(mailingAddress);
					}
					copyAddress(accountDetails.getMailingAddress(), mailingAddress);
					if (accountDetails.getMailingAddress().getReasonForOthers() != null) {
						customer.setDifferentMailingAddressReason(
								accountDetails.getMailingAddress().getReasonForOthers());
					}
					if (accountDetails.getMailingAddress().getReasonId() != null) {
						customer.setDifferentMailingAddressReasonId(accountDetails.getMailingAddress().getReasonId());
					}

					dao.saveOrUpdateDetails(mailingAddress);

				}
			}
			dao.saveOrUpdateDetails(customer);
		}
	}

	private Integer updateAddressDetails(AddressDTO address, Integer addressId) {

		Address addressEntity = new Address();

		if (address.getCountryId() != null) {
			Country country = new Country();
			country.setId(address.getCountryId());
			addressEntity.setCountry(country);
		}
		addressEntity.setAddressLine1(address.getAddressLine1());
		addressEntity.setAddressLine2(address.getAddressLine2());
		addressEntity.setState(address.getState());
		addressEntity.setPostalCode(address.getPostalCode());
		addressEntity.setUnitNumber(address.getUnitNumber());
		addressEntity.setTownName(address.getTownName());
		if (addressId != null && addressId > 0) {
			addressEntity.setId(addressId);
			addressEntity.setCreatedDate(PublicUtility.getCurrentUTC());
			addressEntity.setLastModifiedDate(PublicUtility.getCurrentUTC());
		} else {
			addressEntity.setId(null);
			addressEntity.setCreatedDate(PublicUtility.getCurrentUTC());
			addressEntity.setLastModifiedDate(PublicUtility.getCurrentUTC());
		}
		dao.saveOrUpdateAddress(addressEntity);
		addressId = addressEntity.getId();
		return addressId;
	}

	@Override
	public Customer getCustomer() {
		return null;
	}

	@Override
	public void updateEmployment(Customer customerDetails, EmploymentDetailsDTO employmentDetails) {

		CustomerEmploymentInformation customerEmploymentInfo = null;
		if (employmentDetails != null) {
			Integer employerAddressId = null;
			Integer employerId = null;
			Integer employerContactDetailsId = null;
			customerEmploymentInfo = dao.getCustomerEmploymentInformation(customerDetails.getId());
			// To store employer address in 'address' table
			employerAddressId = updateEmployerAddress(customerEmploymentInfo, employmentDetails);

			// To store employer details in 'employer' table
			employerId = updateEmployerDetails(customerEmploymentInfo, employmentDetails);

			// To save employer address, contact number in 'employer_address'
			// table
			if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerAddress() != null) {
				employerContactDetailsId = customerEmploymentInfo.getEmployerAddress().getId();
			}
			updateEmployerContactDetails(employerContactDetailsId, employerId, employerAddressId, employmentDetails);

			// To save customer employment details in
			// 'customer_employment_details'
			updateCustomerEmploymentDetails(customerDetails.getId(), employerId, employmentDetails);
		}

	}

	public List<CustomerBankDetail> getCustomerBankDetails(Integer customerId) {
		List<CustomerBankDetail> banks = accountsDao.getCustomerBankDetails(customerId);		
		return banks;		
	}
	
	public CustomerSrsAccount getCustomerSrsBankDetails(Integer customerId) {
		return accountsDao.getCustomerSrsBankDetails(customerId);
		
	}		

	public CustomerBankDetail saveCustomerBankDetail(CustomerBankDetail bank) {
		
		if (bank == null)
			return null;
		
		if (bank.getId() != null && bank.getId() > 0) {
			CustomerBankDetail existingBank = accountsDao.getCustomerBankDetail(bank.getId(), bank.getCustomerId());
			if (existingBank != null) {
				bank.setLastModifiedDate(PublicUtility.getCurrentUTC());
				bank.setCreatedDate(existingBank.getCreatedDate());
				if (bank.getAccountNumber() == null || bank.getAccountNumber().isEmpty() || bank.getAccountNumber()
						.equalsIgnoreCase(PublicUtility.maskNumber(existingBank.getAccountNumber()))) {
					bank.setAccountNumber(existingBank.getAccountNumber());
				}
			} else {
				bank.setLastModifiedDate(PublicUtility.getCurrentUTC());
				bank.setCreatedDate(PublicUtility.getCurrentUTC());
			}
		} else {
			bank.setLastModifiedDate(PublicUtility.getCurrentUTC());
			bank.setCreatedDate(PublicUtility.getCurrentUTC());
		}

		accountsDao.saveOrUpdateObject(bank);
		
		// Call Invest BE to send bank details to IFAST
		getLogger().info("Call Invest Service - Start");
		boolean isSuccess = investService.saveCustomerBankToIfast(bank);
		getLogger().info("Invest Service Bank Details Update - isSuccess : [" + isSuccess + "] for customer ID : [" + bank.getCustomerId() + "]");
		if (!isSuccess)
			return null;
		getLogger().info("Call Invest Service - End");
		
		if (bank != null) {
			bank.setAccountNumber(PublicUtility.maskBankAccountNumber(bank.getAccountNumber()));
		}
		return bank;
	}


	public Map<String, Address> getCustomerAddresses(Integer customerId) {
		Map<String, Address> addresses = new HashMap<>();
		Customer customer = accountsDao.getCustomerById(customerId);
		addresses.put("homeAddress", customer.getHomeAddress());
		addresses.put("mailingAddress", customer.getMailingAddress());
		return addresses;
	}

	@Override
	public String validateNewMobileNumber(String mobileNumber) {

		if (!isValidNumber(mobileNumber)) {
			return ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE_NUM;
		}
		if (mobileNumber.length() > 10 || mobileNumber.length() < 8) {
			return ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE;
		}

		if (doesMobileAlreadyVerified(mobileNumber)) {
			return ApplicationConstants.VALIDATION_ERROR_MOBILE_EXISTS;
		}

		return ApplicationConstants.VALIDATION_SUCCESS;
	}

	@Override
	public String validateNewEmail(String emailId) {

		boolean valid = isValidEmailAddress(emailId);
		if (!valid) {
			return ApplicationConstants.VALIDATION_ERROR_INVALID_EMAIL;
		}
		if (doesEmailAlreadyVerified(emailId)) {
			return ApplicationConstants.VALIDATION_ERROR_EMAIL_EXISTS;
		}
		return ApplicationConstants.VALIDATION_SUCCESS;
	}

	@Override
	public CustomerProfileDetails getCustomerDetailsById(Integer customerId) {

		CustomerProfileDetails parameters = new CustomerProfileDetails();
		Customer customer = dao.getCustomer(customerId);		
		Country nationality = null;
		if (customer.getNationalityCode() != null)
			nationality = dao.getNationality(customer.getNationalityCode());
		CustomerPersonalInformation customerPersonalInformation = new CustomerPersonalInformation();

		if (customer.getGivenName() != null)
			customerPersonalInformation.setFirstName(customer.getGivenName());
		if (customer.getSurName() != null)
			customerPersonalInformation.setLastName(customer.getSurName());
		if (customer.getNricName() != null) {
			customerPersonalInformation.setFullName(customer.getNricName());
		}
		if (customer.getMobileNumber() != null)
			customerPersonalInformation.setMobileNumber(customer.getMobileNumber());
		if (customer.getCountryCode() != null)
			customerPersonalInformation.setCountryCode(customer.getCountryCode());		
		if (customer.getEmail() != null)
			customerPersonalInformation.setEmail(customer.getEmail());
		CustomerAdditionalDetails customerAdditionalDetails = dao.getCustomerAdditionalDetails(customerId);
		if (customerAdditionalDetails != null && customerAdditionalDetails.getSingaporePR() != null) {
			customerPersonalInformation.setIsSingaporeResident(customerAdditionalDetails.getSingaporePR());			
		}

		parameters.setPersonalInformation(customerPersonalInformation);

		CustomerContactDetails customerContactdetails = new CustomerContactDetails();

		CustomerAddressDTO customerHomeAddress = new CustomerAddressDTO();
		if (customer.getHomeAddress() != null) {
			customerHomeAddress.setId(customer.getHomeAddress().getId());
			customerHomeAddress.setAddressLine1(customer.getHomeAddress().getAddressLine1());
			customerHomeAddress.setAddressLine2(customer.getHomeAddress().getAddressLine2());
			customerHomeAddress.setFloor(customer.getHomeAddress().getFloor());
			customerHomeAddress.setTownName(customer.getHomeAddress().getTownName());
			customerHomeAddress.setCity(customer.getHomeAddress().getCity());
			customerHomeAddress.setState(customer.getHomeAddress().getState());

			CountryListDTO homeCountryList = new CountryListDTO();
			if (customer.getHomeAddress().getCountry() != null) {
				homeCountryList.setId(customer.getHomeAddress().getCountry().getId());
				homeCountryList.setNationality(customer.getHomeAddress().getCountry().getNationality());
				homeCountryList.setCountryCode(customer.getHomeAddress().getCountry().getCountryCode());
				homeCountryList.setName(customer.getHomeAddress().getCountry().getCountry());
				homeCountryList.setIsBlocked(customer.getHomeAddress().getCountry().isBlocked());
				homeCountryList.setNationalityCode(customer.getHomeAddress().getCountry().getNationalityCode());
				homeCountryList.setPhoneCode(customer.getHomeAddress().getCountry().getPhoneCode());
				homeCountryList.setListOrder(customer.getHomeAddress().getCountry().getListOrder());

				customerHomeAddress.setCountry(homeCountryList);
			}
			customerHomeAddress.setPostalCode(customer.getHomeAddress().getPostalCode());
			customerHomeAddress.setUnitNumber(customer.getHomeAddress().getUnitNumber());
			customerContactdetails.setHomeAddress(customerHomeAddress);

			if (parameters.getContactDetails() == null)
				parameters.setContactDetails(new CustomerContactDetails());
			parameters.getContactDetails().setHomeAddress(customerContactdetails.getHomeAddress());
		}
		CustomerContactDetails customerContactMailingdetails = new CustomerContactDetails();
		CustomerAddressDTO customerMailingAddress = new CustomerAddressDTO();

		if (customer.getMailingAddress() != null) {

			getLogger().info("Mailing Address: " + customer.getMailingAddress());

			customerMailingAddress.setId(customer.getMailingAddress().getId());
			customerMailingAddress.setAddressLine1(customer.getMailingAddress().getAddressLine1());
			customerMailingAddress.setAddressLine2(customer.getMailingAddress().getAddressLine2());
			customerMailingAddress.setFloor(customer.getMailingAddress().getFloor());
			customerMailingAddress.setTownName(customer.getMailingAddress().getTownName());
			customerMailingAddress.setCity(customer.getMailingAddress().getCity());
			customerMailingAddress.setState(customer.getMailingAddress().getState());

			CountryListDTO mailingCountryList = new CountryListDTO();
			if (customer.getMailingAddress().getCountry() != null) {
				mailingCountryList.setId(customer.getMailingAddress().getCountry().getId());
				mailingCountryList.setNationality(customer.getMailingAddress().getCountry().getNationality());
				mailingCountryList.setCountryCode(customer.getMailingAddress().getCountry().getCountryCode());
				mailingCountryList.setName(customer.getMailingAddress().getCountry().getCountry());
				mailingCountryList.setIsBlocked(customer.getMailingAddress().getCountry().isBlocked());
				mailingCountryList.setNationalityCode(customer.getMailingAddress().getCountry().getNationalityCode());
				mailingCountryList.setPhoneCode(customer.getMailingAddress().getCountry().getPhoneCode());
				mailingCountryList.setListOrder(customer.getMailingAddress().getCountry().getListOrder());
			}
			customerMailingAddress.setCountry(mailingCountryList);

			customerMailingAddress.setPostalCode(customer.getMailingAddress().getPostalCode());
			customerMailingAddress.setUnitNumber(customer.getMailingAddress().getUnitNumber());
			customerContactMailingdetails.setMailingAddress(customerMailingAddress);
			customerContactdetails.setDifferentMailingAddressReason(customer.getDifferentMailingAddressReason());
			customerContactdetails.setDifferentMailingAddressReasonId(customer.getDifferentMailingAddressReasonId());
			if (parameters.getContactDetails() == null)
				parameters.setContactDetails(new CustomerContactDetails());
			parameters.getContactDetails().setMailingAddress(customerContactMailingdetails.getMailingAddress());
			if (customerContactdetails.getDifferentMailingAddressReason() != null) {
				parameters.getContactDetails()
						.setDifferentMailingAddressReason(customerContactdetails.getDifferentMailingAddressReason());
			}
			if (customerContactdetails.getDifferentMailingAddressReasonId() != null) {
				parameters.getContactDetails().setDifferentMailingAddressReasonId(
						customerContactdetails.getDifferentMailingAddressReasonId());
			}
		}

		CustomerEmploymentInformation employmentdetails = dao.getCustomerEmploymentInformation(customerId);

		OptionItem employmentStatusvalue = null;
		if (employmentdetails.getCustomerEmploymentDetails() != null) {
			employmentStatusvalue = dao.getCustomerEmploymentStatus(
					employmentdetails.getCustomerEmploymentDetails().getEmploymentStatusId());

			CustomerEmploymentInfo employmentInfo = new CustomerEmploymentInfo();
			EmploymentStatus employmentStatus = new EmploymentStatus();
			if (employmentStatusvalue != null) {
				employmentStatus.setId(employmentStatusvalue.getId());
				employmentStatus.setName(employmentStatusvalue.getName());

				employmentInfo.setEmploymentStatus(employmentStatus);
			}

			EmployerDetailsDTO employerDetailsDto = new EmployerDetailsDTO();
			if (employmentdetails.getEmployerAddress() != null) {
				EmployerAddressDTO employerAddressDto = new EmployerAddressDTO();
				CustomerAddressDTO empAddressList = new CustomerAddressDTO();
				if (employmentdetails.getEmployerAddress().getEmployerAddress() != null) {
					empAddressList.setAddressLine1(
							employmentdetails.getEmployerAddress().getEmployerAddress().getAddressLine1());
					empAddressList.setAddressLine2(
							employmentdetails.getEmployerAddress().getEmployerAddress().getAddressLine2());
					empAddressList.setCity(employmentdetails.getEmployerAddress().getEmployerAddress().getCity());
					empAddressList.setFloor(employmentdetails.getEmployerAddress().getEmployerAddress().getFloor());
					empAddressList
							.setTownName(employmentdetails.getEmployerAddress().getEmployerAddress().getTownName());
					empAddressList.setId(employmentdetails.getEmployerAddress().getEmployerAddress().getId());
					empAddressList
							.setPostalCode(employmentdetails.getEmployerAddress().getEmployerAddress().getPostalCode());
					empAddressList.setState(employmentdetails.getEmployerAddress().getEmployerAddress().getState());
					empAddressList
							.setUnitNumber(employmentdetails.getEmployerAddress().getEmployerAddress().getUnitNumber());

					CountryListDTO empCoutryList = new CountryListDTO();
					if (employmentdetails.getEmployerAddress().getEmployerAddress().getCountry() != null) {
						empCoutryList.setCountryCode(employmentdetails.getEmployerAddress().getEmployerAddress()
								.getCountry().getCountryCode());
						empCoutryList.setName(
								employmentdetails.getEmployerAddress().getEmployerAddress().getCountry().getCountry());
						empCoutryList.setId(
								employmentdetails.getEmployerAddress().getEmployerAddress().getCountry().getId());
						empCoutryList.setIsBlocked(
								employmentdetails.getEmployerAddress().getEmployerAddress().getCountry().isBlocked());
						empCoutryList.setNationality(employmentdetails.getEmployerAddress().getEmployerAddress()
								.getCountry().getNationality());
						empCoutryList.setNationalityCode(employmentdetails.getEmployerAddress().getEmployerAddress()
								.getCountry().getNationalityCode());
						empCoutryList.setPhoneCode(employmentdetails.getEmployerAddress().getEmployerAddress()
								.getCountry().getPhoneCode());

						empAddressList.setCountry(empCoutryList);
					}

					employerAddressDto.setEmployerAddress(empAddressList);

					employerDetailsDto.setDetailedemployerAddress(employerAddressDto);

				}
			}
			employerDetailsDto.setDetailedEmployerDetails(employmentdetails.getEmployerDetails());
			if (employmentdetails.getEmployerAddress() != null) {
				employerDetailsDto.setEmployerContact(employmentdetails.getEmployerAddress().getContactNumber());

			}
			employmentInfo.setEmployerDetails(employerDetailsDto);
			if (employmentdetails.getCustomerEmploymentDetails() != null) {

				employmentInfo.setOccupation(employmentdetails.getCustomerEmploymentDetails().getOccupation());
				employmentInfo
						.setOtherOccupation(employmentdetails.getCustomerEmploymentDetails().getOtherOccupation());
			}

			parameters.setEmploymentDetails(employmentInfo);
		}

		List<CustomerDocumentDetails> documentDetails = dao.getCustomerDocumentDetails(customerId);
		if (documentDetails != null) {

			documentDetails = documentDetails.stream()
					.filter(d -> d.getDocType().equalsIgnoreCase(com.bfa.util.DocumentType.RESIDENTIAL_ADDRESS_PROOF)
							|| d.getDocType().equalsIgnoreCase(com.bfa.util.DocumentType.MAILING_ADDRESS_PROOF))
					.collect(Collectors.toList());			
			documentDetails.stream().forEach(d -> d.setCustomer(null));
			if (!documentDetails.isEmpty()) {

				parameters.setDocumentDetails(documentDetails);
			}

		}
		List<CustomerBankDetail> customerBankDetail = getCustomerBankDetails(customerId);
		if (customerBankDetail != null) {
			parameters.setCustomerBankDetail(customerBankDetail);
		}		
		return parameters;
	}
	
	

	@Override
	public InvestementDashboardStatusDTO getInvestmentDashboardStatus(Integer customerId) {

		InvestementDashboardStatusDTO investementDashboardStatusDTO = new InvestementDashboardStatusDTO();

		CustomerAdditionalDetails customerAdditionalDetils = null;
		customerAdditionalDetils = accountsDao.getAdditionalDetails(customerId);
		if (customerAdditionalDetils != null) {

			investementDashboardStatusDTO.setBeneficialOwner(customerAdditionalDetils.getBeneficialOwner());

			investementDashboardStatusDTO.setIsPoliticallyExposed(customerAdditionalDetils.isPoliticallyExposed());

			investementDashboardStatusDTO
					.setConnectedToInvestmentFirm(customerAdditionalDetils.getConnectedToInvestmentFirm());

		}

		return investementDashboardStatusDTO;
	}

	@Override
	public List<AdminCustomerDetails> getCustomerSummaryByAdvisor(int adviserId) {

		List<AdminCustomerDetails> parameters = new ArrayList<>();
		AdminCustomerDetails admincustomerDetails = new AdminCustomerDetails();

		List<Customer> customerDetails = dao.getCustomerByAdvisor(adviserId);

		for (Customer customerList : customerDetails) {
			int customerId = customerList.getId();
			Customer customer = dao.getCustomer(customerId);
			admincustomerDetails.setCustomer(customer);

			Assets assets = dao.getCustomerAssetDetails(customerId);
			admincustomerDetails.setAssets(assets);

			Income income = dao.getCustomerIncomeDetails(customerId);
			admincustomerDetails.setIncome(income);

			Liabilities liabilities = dao.getCustomerLiabilitiesDetails(customerId);
			admincustomerDetails.setLiabilities(liabilities);

			List<CustomerTaxDetails> taxDetails = dao.getCustomerTaxDetails(customerId);
			admincustomerDetails.setTaxDetails(taxDetails);

			CustomerInvestmentObjective investmentObjective = dao.getCustomerInvestmentObjective(customerId);
			admincustomerDetails.setInvestmentObjective(investmentObjective);

			CustomerAdditionalDetails additionalDetails = dao.getCustomerAdditionalDetails(customerId);
			CustomerAdditionalDetailsDTO customerAdditionalDetailsDto = new CustomerAdditionalDetailsDTO();
			customerAdditionalDetailsDto.setBeneficialOwner(additionalDetails.getBeneficialOwner());
			customerAdditionalDetailsDto.setConnectedToInvestmentFirm(additionalDetails.getConnectedToInvestmentFirm());
			customerAdditionalDetailsDto.setIsPoliticallyExposed(additionalDetails.isPoliticallyExposed());

			admincustomerDetails.setAdditionalDetails(customerAdditionalDetailsDto);

			CustomerPEPDetails pepDetails = dao.getCustomerPEPDetails(customerId);
			PEPAdditionalDeclarationDTO pepDetailsDto = new PEPAdditionalDeclarationDTO();
			pepDetailsDto.setFirstName(pepDetails.getFirstName());
			pepDetailsDto.setLastName(pepDetails.getLastName());
			pepDetailsDto.setCompanyName(pepDetails.getCompanyName());
			pepDetailsDto.setOccupationId(pepDetails.getOccupation().getId());
			pepDetailsDto.setExpectedAmountPerTransaction(pepDetails.getExpectedAmountPerTransactions());
			pepDetailsDto.setExpectedNumberOfTransactions(pepDetails.getExpectedNumberOfTransactions());
			pepDetailsDto.setInvestmentSourceId(pepDetails.getInvestmentSourceId().getId());
			pepDetailsDto.setAdditionalInfo(pepDetails.getAdditionalInfo());
			pepDetailsDto.setInvestmentDuration(pepDetails.getInvestmentPeriod());
			pepDetailsDto.setEarningSourceId(pepDetails.getEarningsGeneratedFromId().getId());
			AddressDTO pepaddressDTO = new AddressDTO();
			pepaddressDTO.setAddressLine1(pepDetails.getPepAddress().getAddressLine1());
			pepaddressDTO.setAddressLine2(pepDetails.getPepAddress().getAddressLine2());
			pepaddressDTO.setCity(pepDetails.getPepAddress().getCity());
			pepaddressDTO.setId(pepDetails.getPepAddress().getId());
			pepaddressDTO.setFloor(pepDetails.getPepAddress().getFloor());
			pepaddressDTO.setPostalCode(pepDetails.getPepAddress().getPostalCode());
			pepaddressDTO.setState(pepDetails.getPepAddress().getState());
			pepaddressDTO.setTownName(pepDetails.getPepAddress().getTownName());
			pepaddressDTO.setCountryId(pepDetails.getPepAddress().getCountry().getId());
			pepDetailsDto.setPepAddress(pepaddressDTO);

			admincustomerDetails.setPepDetails(pepDetails);

			CustomerIdentityDetails identityDetails = dao.getCustomerIdentityDetails(customerId);
			admincustomerDetails.setIdentityDetails(identityDetails);

			CustomerEmploymentInformation employmentInfo = dao.getCustomerEmploymentInformation(customerId);
			admincustomerDetails.setEmploymentInformation(employmentInfo);
			List<CustomerDocumentDetails> documentDetails = dao.getCustomerDocumentDetails(customerId);
			admincustomerDetails.setDocumentDetails(documentDetails);
			parameters.add(admincustomerDetails);
		}

		return parameters;

	}

	public List<CustomerOverview> findCustomers(AdminSearchRequestDTO searchRequest) {
		List<CustomerOverview> customers = accountsDao.findCustomers(searchRequest);
		return customers;
	}

	@Override
	public void sendEmail(Customer custObj) {

		EmailContentWrapper emailObj = new EmailContentWrapper();
		EmailData emailDataObj = new EmailData();
		CustomerData custDataObj = new CustomerData();
		try {
			InputStream input = classPathResourceObj.getInputStream();
			prop.load(input);
			custDataObj.setNricName(custObj.getNricName());
			emailDataObj.setCustomer(custDataObj);
			List<String> custEmailAddress = new ArrayList<>();
			custEmailAddress.add(custObj.getEmail());

			// added email id for compliance officer in bcc
			List<String> complianceOfficerEmailAddress = new ArrayList<>();			
			String bccEmailList = prop.getProperty("complianceOfficer.mo.emailAddress");
			 getLogger().info("Bcc Email from propertry" + bccEmailList);
			StringTokenizer st = new StringTokenizer(bccEmailList,",");  
			 getLogger().info("Bcc Email tokeniser" + st.toString());
		     while (st.hasMoreTokens()) {  
		    	 String token = st.nextToken();
		    	 getLogger().info("sendEmail(): Bcc Email: " + token);
		         complianceOfficerEmailAddress.add(token);	
		     }  
			Common commonObj = new Common();
			commonObj.setAdvisorynumber(prop.getProperty("common.mo.advisorynumber"));
			commonObj.setContactEmail(prop.getProperty("common.mo.generalemail"));
			commonObj.setGeneralenquiry(prop.getProperty("common.mo.generalenquiry"));
			commonObj.setLoginUrl(prop.getProperty("common.mo.loginUrl"));

			emailDataObj.setCommon(commonObj);
			emailObj.setData(emailDataObj);
			ObjectMapper mapper = new ObjectMapper();
			emailObj.setFromEmailAddress("notifications@moneyowl.sg");
			emailObj.setToEmailAddress(custEmailAddress);
			emailObj.setSubjectOfEmail(prop.getProperty("ifasteddcddcheck.subject"));
			emailObj.setAcknowledgeURL("https://test");
			emailObj.setScheduledEmailTime(new Date());
			emailObj.setNumberOfRetry(1);
			emailObj.getToEmailAddress().set(0, custObj.getEmail());
			emailObj.setBccEmailAddress(complianceOfficerEmailAddress);
			getLogger().info("Bcc Email 1" + complianceOfficerEmailAddress.get(0));
			getLogger().info("Bcc Email 2" + complianceOfficerEmailAddress.get(1));
			getLogger().info("Bcc Email 3" + complianceOfficerEmailAddress.get(2));
			emailObj.setEmailRequestId("123");
			emailObj.setEmailTemplateName("eddcddcheck.ftl");

			mapper.setSerializationInclusion(Include.NON_NULL);

			String mailJsonObj = mapper.writeValueAsString(emailObj);
			getLogger().info("MAIL OBJ PREPARED" + mailJsonObj);
			moemailObj.sendMessage(mailJsonObj);
			getLogger().info("Mail Sent");
		} catch (Exception e) {
			getLogger().debug("sendEmail Exception while loading properties" + e.getMessage());
			getLogger().debug("exception caught" + e);
		}

	}
	private javax.mail.Address[] getCommaSeperatedAddress(String[] address) {
		javax.mail.Address[] mailAddress = new javax.mail.Address[address.length];
		int i = 0;
		for (String obj : address) {
			try {
				getLogger().info(">>-" + obj);
				if (obj == null) {
					continue;
				}
				mailAddress[i] = new InternetAddress(obj);
				i++;
			} catch (AddressException e) {
				getLogger().error("AddressException in getCommaSeperatedAddress() " + e);
			}
		}
		return mailAddress;
	}

	@Override
	public AdminCustomerDetails fetchIndividualCustomerDetails(Integer customerId, Integer advisorId) {

		AdminCustomerDetails admincustomerDetails = new AdminCustomerDetails();

		Optional<Customer> customerData = null;
		if (advisorId > 0) {
			customerData = customerRepository.findByIdAndAdvisorId(customerId, advisorId);

		} else {

			customerData = customerRepository.findById(customerId);
		}
		if (customerData.isPresent()) {
			Customer customer = customerData.get();

			admincustomerDetails.setCustomer(customer);
			Optional<CustomerIFastAccount> customerIfastDetails = customeriFASTRepository
					.findFirstBycustomer_id(customerId);
			if (customerIfastDetails.isPresent()) {
				CustomerIFastAccount customerIfastData = customerIfastDetails.get();
				if (!ObjectUtils.isEmpty(customerIfastData.getIfastRefno())) {
					admincustomerDetails.setIfastReferenceNumber(customerIfastData.getIfastRefno());
				}

			}

			CustomerFinancialDataDTO financialData = financeService.getFinancialData(true,
					utility.EncryptTextURLSafe(String.valueOf(customerId)));

			if (!ObjectUtils.isEmpty(financialData)) {
				if (!ObjectUtils.isEmpty(financialData.getAssets()))
					admincustomerDetails.setAssets(financialData.getAssets());
				if (!ObjectUtils.isEmpty(financialData.getLiabilities()))
					admincustomerDetails.setLiabilities(financialData.getLiabilities());
				if (!ObjectUtils.isEmpty(financialData.getIncome()))
					admincustomerDetails.setIncome(financialData.getIncome());
				if (!ObjectUtils.isEmpty(financialData.getExpenses()))
					admincustomerDetails.setExpenses(financialData.getExpenses());
			}

			CustomerInvestmentObjective investmentObjective = dao.getCustomerInvestmentObjective(customer.getId());
			if (!ObjectUtils.isEmpty(investmentObjective)) {
				admincustomerDetails.setInvestmentObjective(investmentObjective);
			}			

			List<CustomerTaxDetails> taxDetails = dao.getCustomerTaxDetails(customer.getId());

			if (taxDetails != null) {
				taxDetails.stream().forEach(b -> {
					String taxDateOfBirth = formatDOB(b.getCustomer().getDateOfBirth());
					b.getCustomer().setDateOfBirth(taxDateOfBirth);

				});
			}

			admincustomerDetails.setTaxDetails(taxDetails);

			Optional<CustomerAdditionalDetails> additionalDetails = customerAdditionalDetailsRepository
					.findFirstBycustomer_id(customerId);
			if (additionalDetails.isPresent()) {
				CustomerAdditionalDetails additionalDetailsData = additionalDetails.get();
				CustomerAdditionalDetailsDTO customerAdditionalDetailsDto = getCustomeradditionalDetails(
						additionalDetailsData);
				admincustomerDetails.setAdditionalDetails(customerAdditionalDetailsDto);

			}
			Optional<CustomerPEPDetails> pepDetails = customerPEPDetailsRepository.findFirstBycustomer_id(customerId);
			if (pepDetails.isPresent()) {
				CustomerPEPDetails pepDetailsData = pepDetails.get();
				String pepDateOfBirth = formatDOB(pepDetailsData.getCustomer().getDateOfBirth());
				pepDetailsData.getCustomer().setDateOfBirth(pepDateOfBirth);
				admincustomerDetails.setPepDetails(pepDetailsData);
			}
			Optional<CustomerIdentityDetails> customerIdentityDetails = customerIdentityDetailsRepository
					.findFirstBycustomer_id(customerId);
			if (customerIdentityDetails.isPresent()) {
				CustomerIdentityDetails customerIdentityDetailsData = customerIdentityDetails.get();
				String idDateOfBirth = formatDOB(customerIdentityDetailsData.getCustomer().getDateOfBirth());
				customerIdentityDetailsData.getCustomer().setDateOfBirth(idDateOfBirth);
				admincustomerDetails.setIdentityDetails(customerIdentityDetailsData);

			}
			CustomerEmploymentInformation employmentInfo = new CustomerEmploymentInformation();
			Optional<CustomerEmploymentDetails> customerEmploymentDetails = customerEmploymentDetailsRepository
					.findFirstByCustomerId(customerId);
			if (customerEmploymentDetails.isPresent()) {
				CustomerEmploymentDetails customerEmploymentData = customerEmploymentDetails.get();
				employmentInfo.setCustomerEmploymentDetails(customerEmploymentData);
				Optional<EmployerDetails> employerDetails = employerRepository
						.findFirstById(customerEmploymentData.getEmployerId());
				if (employerDetails.isPresent()) {
					EmployerDetails employerData = employerDetails.get();
					employmentInfo.setEmployerDetails(employerData);

				}
				Optional<EmployerAddress> employerAddress = employerAddressRepository
						.findFirstByEmployerId(customerEmploymentData.getEmployerId());
				if (employerAddress.isPresent()) {
					EmployerAddress employerAddressData = employerAddress.get();
					employmentInfo.setEmployerAddress(employerAddressData);
				}
				admincustomerDetails.setEmploymentInformation(employmentInfo);
			}

			List<CustomerDocumentDetails> documentDetails = dao.getCustomerDocumentDetails(customer.getId());
			if (documentDetails != null) {
				documentDetails.stream().forEach(b -> {
					String docDateOfBirth = formatDOB(b.getCustomer().getDateOfBirth());
					b.getCustomer().setDateOfBirth(docDateOfBirth);

				});
			}
			admincustomerDetails.setDocumentDetails(documentDetails);

		}

		return admincustomerDetails;
	}
	private CustomerAdditionalDetailsDTO getCustomeradditionalDetails(CustomerAdditionalDetails additionalDetails) {
		CustomerAdditionalDetailsDTO customerAdditionalDetailsDto = new CustomerAdditionalDetailsDTO();
		customerAdditionalDetailsDto.setBeneficialOwner(additionalDetails.getBeneficialOwner());
		customerAdditionalDetailsDto
				.setConnectedToInvestmentFirm(additionalDetails.getConnectedToInvestmentFirm());
		customerAdditionalDetailsDto.setIsPoliticallyExposed(additionalDetails.isPoliticallyExposed());
		customerAdditionalDetailsDto.setIsSingaporePR(additionalDetails.getSingaporePR());
		
		return customerAdditionalDetailsDto;
	}

//	private Liabilities setLiabilities(CustomerLiabilitiesDetail customerLiabilityData) {
//		Liabilities liabilities = new Liabilities();
//		liabilities.setId(customerLiabilityData.getLiabilityId());
//		liabilities.setCarLoan(customerLiabilityData.getCarLoan());
//		liabilities.setCustomerId(customerLiabilityData.getCustomerId());
//		liabilities.setEnquiryId(customerLiabilityData.getEnquiryId());
//		liabilities.setOtherLoan(customerLiabilityData.getOtherLoan());
//		liabilities.setPropertyLoan(customerLiabilityData.getPropertyLoan());
//		liabilities.setTotalLiabilities(customerLiabilityData.getTotalLoans());
//		return liabilities;
//	}
//
//	private Assets setAssets(CustomerLiabilitiesDetail customerLiabilityData) {
//		Assets assets = new Assets();
//		assets.setOtherAssets(customerLiabilityData.getOtherAssets());
//		assets.setTotalAssets(customerLiabilityData.getTotalAssets());
//		assets.setCash(customerLiabilityData.getCash());
//		assets.setCpf(customerLiabilityData.getCpf());
//		assets.setCustomerId(customerLiabilityData.getCustomerId());
//		assets.setEnquiryId(customerLiabilityData.getEnquiryId());
//		assets.setHomeProperty(customerLiabilityData.getHomeProperty());
//		assets.setId(customerLiabilityData.getAssetId());
//		assets.setInvestmentProperties(customerLiabilityData.getInvestmentProperties());
//		assets.setOtherInvestments(customerLiabilityData.getOtherInvestments());
//		return assets;
//}

	@Override
	public AdminCustomerSummary fetchCustomerSummary(Integer customerId, Integer advisorId) {

		AdminCustomerDetails adminCustomerDetails = fetchIndividualCustomerDetails(customerId, advisorId);
		AdminCustomerSummary customerSummary = new AdminCustomerSummary();

		customerSummary.setCustomerDetails(adminCustomerDetails);

		Integer adminCustomerId = adminCustomerDetails.getCustomer().getId();

		if (adminCustomerId != null && adminCustomerId > 0) {
			DPMSHoldingsSummary dpmsHolding = investService.getDPMSHoldings(customerId);
			if (dpmsHolding != null) {
				customerSummary.setDpmsHolding(dpmsHolding);
			}

			List<CustomerAssessmentDetails> customerAssessment = accountsDao.assessmentDetails(adminCustomerId);
			if (customerAssessment != null && !customerAssessment.isEmpty()) {
				customerSummary.setCustomerAssessmentDetails(customerAssessment);
			}

		}

		return customerSummary;
	}

	@Override
	public Customer addAdvisor(int customerId, int advisorId) {

		Customer customer = accountsDao.getCustomerById(customerId);

		if (customer != null) {
			customer.setAdvisorId(advisorId);
			accountsDao.saveOrUpdateObject(customer);
			return customer;

		} else {
			Customer updateCustomer = null;

			return updateCustomer;
		}
	}

	public ServiceResponse<Map<String, String>> saveDocumentV2(Integer customerId,
			HttpServletRequest httpServletRequest, String type) {
		getLogger().info("Saving the document - V2 ##");
		ServiceResponse<Map<String, String>> response = new ServiceResponse<>();
		response.addResponseInfo("step", "SAVING_DOCUMENT");
		response.setSuccess(true);
		// Upload document to AWS S3 Bucket
		File fObj = null;
		try {
			boolean status = true;
			fObj = saveFileToDisk(httpServletRequest);
			String[] fileFrags = fObj.getAbsolutePath().split("\\");
			getLogger().info("Original filename:" + fObj.getAbsolutePath());
			getLogger().info("fileFrags length" + fileFrags.length);
			if (fileFrags.length < 2) {
				throw new BfaException("fileFrags length less than two, no extension found"); // Generic exceptions should never be thrown (squid:S00112)
			}
			String extension = fileFrags[fileFrags.length - 1];
			getLogger().info("extension" + extension);
			String fileName = customerId + "_";
			getLogger().info("fileName" + fileName);
			fileName += type + "." + extension;

			if (amazonS3ClientService.equals(null)) {
				getLogger().info("amazonS3ClientService found as null,creating new object");
				AmazonS3ClientService amazonS3ClientService = new AmazonS3ClientServiceImpl();
				this.amazonS3ClientService = amazonS3ClientService;
			}
			
			String fileUrl = this.amazonS3ClientService.upload(bucketName, fileName, fObj);
			getLogger().info("fileUrl" + fileUrl);
			
			customerDocService.saveOrUpdateCustomerDocument(customerId, fileUrl, type);
			response.addResponseInfo("filePath", fileUrl);
			response.addResponseInfo("type", type);
		} catch (Exception e) {
			response.addExceptionInfo(e);			
			getLogger().error("exception at saveDocument" + e.getMessage());
			getLogger().error("exception at saveDocument" + e);
		} finally {
			if (fObj != null) {
				if (fObj.delete()) {
					getLogger().info("Deleted successfully " + fObj.getAbsolutePath());
				} else {
					getLogger().info("Unable to delete the file : " + fObj.getAbsolutePath());
				}
			}
		}
		return response;
	}


	

	private File saveFileToDisk(HttpServletRequest httpServletRequest) {
		
		getLogger().info("Handling file at server side.");
		boolean isMultipart;
		String filePath;
		int maxFileSize = -1;
		int maxMemSize = 500000 * 1024;
		File file = null;
		filePath = "/opt/tomcat/logs/";
		File f = new File(filePath);
		if (!f.exists()) {
			try {
				File.createTempFile("Test", "dat", f);
			} catch (IOException e) {
				getLogger().error("Exception catched in saveFileToDisk(): " + e);
			}
		}
		// Check that we have a file upload request
		isMultipart = ServletFileUpload.isMultipartContent(httpServletRequest);
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(maxMemSize);
		factory.setRepository(new File(createOrReturnRepository()));
		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);
		// maximum file size to be uploaded.
		upload.setSizeMax(maxFileSize);
		try {
			// Parse the request to get file items.
			List fileItems = upload.parseRequest(httpServletRequest);
			// Process the uploaded file items
			Iterator i = fileItems.iterator();
			while (i.hasNext()) {
				FileItem fi = (FileItem) i.next();
				getLogger().info(fi.getName());
				if (!fi.isFormField()) {
					// Get the uploaded file parameters
					String fileName = fi.getName();
					// Write the file
					getLogger().info("FileName@@ : " + fileName);
					if (fileName.lastIndexOf("\\") >= 0) {
						file = new File(filePath + fileName.substring(fileName.lastIndexOf("\\")));
					} else {
						file = new File(filePath + fileName.substring(fileName.lastIndexOf("\\") + 1));
					}
					getLogger().info("FilePath ## " + file.getAbsolutePath());

					// -----------------------------------------------------------//
					try {
						fi.write(file);

					} catch (Exception e) {
						getLogger().info(
								"Error while writing file : " + e.getMessage() + " : " + file.getAbsolutePath(), e);
					}
					// -----------------------------------------------------------//
					getLogger().info("Written file " + file.getAbsolutePath());
					getLogger().info("Written file size : " + file.getTotalSpace());

				}
			}

			getLogger().info("Written the file to the server");

		} catch (Exception ex) {
			getLogger().info(ex);

		}
		return file;
	}

	private String createOrReturnRepository() {
		String basePath = System.getProperty("catalina.base");
		String fileUploadDir = "repository";
		String fileSeperator = "/";
		String fileUploadPath = basePath + fileSeperator + fileUploadDir;
		java.io.File file = new java.io.File(fileUploadPath);
		if (file.isDirectory()) {
			return fileUploadPath;
		} else {
			boolean flag = file.mkdir();
			if (flag) {
				getLogger().info("Repository folder created successfully");
				return fileUploadPath;
			}
		}
		return "";
	}

	@Override
	public Advisor getAdvisorbyId(Integer custId) {
		return accountsDao.getAdvisorById(custId);
	}

	@Override
	public boolean doesEmailExistsForOtherCustomer(String email, int enquiryId) {
		String hql = "select email from Customer where email =:email and verificationEnquiryId not in :enquiryId";
		String[] paramNames = new String[]{"email","enquiryId"};
		Object[] paramValues = new Object[]{new String(email),new Integer(enquiryId)};
		List collection = accountsDao.getObjectByHql(hql, paramNames, paramValues);		
		if (collection != null && !collection.isEmpty()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean doesMobileExistsForOtherCustomer(String mobileNumber, int enquiryId) {
		String hql = "select mobileNumber from Customer where mobileNumber =:mobileNumber and verificationEnquiryId not in :enquiryId";
		String paramNames[] = new String[]{"mobileNumber","enquiryId"};
		Object[] paramValues= new Object[]{new String(mobileNumber),new Integer(enquiryId)};
		//String paramValues[] = new String[]{mobileNumber,String.valueOf(enquiryId)};
		List collection = accountsDao.getObjectByHql(hql,paramNames,paramValues);
		if (collection != null && !collection.isEmpty()) {
			return true;
		}
		return false;
	}

	public boolean doesMobileAlreadyVerified(String mobileNumber) {
		String hql = "select mobileNumber from Customer where mobileNumber =:mobileNumber and otpVerfied=:otpVerifiedStatus";
		String[] paramNames = new String[]{"mobileNumber","otpVerifiedStatus"};
		String[] values = new String[]{mobileNumber,"Yes"};		
		List collection = accountsDao.getObjectByHql(hql,paramNames,values);
		if (collection != null && !collection.isEmpty()) {
			return true;
		}
		return false;
	}

	private boolean doesEmailAlreadyVerified(String email) {
		String hql = "select email from Customer where email=:emailAddress and emailVerified=:emailStatus";
		String[] paramNames = new String[]{"emailAddress","emailStatus"};
		String[] values = new String[]{email,"Yes"};		
		List collection = accountsDao.getObjectByHql(hql, paramNames, values);
		if (collection != null && !collection.isEmpty()) {
			return true;
		}
		return false;
	}
	
	/*private Customer lookForExistingRecords(String mobile, String email){		
			String hql = "from Customer where email='" + email + "'" + " OR mobileNumber='" + mobile + "'";
			List collection = accountsDao.getObjectByHql(hql);
			// - No such user in system- allow creation of account.
			if (collection != null && !collection.isEmpty()) {
				getLogger().info("User with mobile " + mobile + " Email :" + email + " found ");
				return (Customer) collection.get(0);
			}
			return null;
	}*/

	/**
	 * This method validates the user email and mobile number in the system.
	 * Return 0 if there is no such user in the system.  
	 * Returns 1 if the mobile number is already verified in the system. 
	 * Returns 2 if the email address is already verified in the system.
	 * Returns 4 if both email and mobile is verified.
	 * 
	 * @param mobile
	 * @param email
	 * @return
	 */
	private int doesMobileOrEmailVerified(String mobile, String email,AuthenticationErrorResponse authenticationErrorResponse) {
		String hql = "from Customer where email=:email OR mobileNumber=:mobile";
		String paramNames[] = new String[]{"email","mobile"};
		String paramValues[] = new String[]{email,mobile};
		List collection = accountsDao.getObjectByHql(hql,paramNames,paramValues);
		// - No such user in system- allow creation of account.
		if (collection == null || collection.isEmpty()) {
			getLogger().info("User with mobile " + mobile + " Email :" + email + " Not found ");
			return 0;
		}
		String mobileNumber = "";
		Iterator userCollectionIterator = collection.iterator();
		String customerRef = "";
		while (userCollectionIterator.hasNext()) {
			Customer customerObj = (Customer) userCollectionIterator.next();
			mobileNumber = customerObj.getMobileNumber();
			// Mobile is already verified for the customer - do not allow user
			// to create account //
			customerRef = encryptCustomerId(customerObj.getId().toString());
			if(customerObj.getOtpVerfied().equalsIgnoreCase("yes") && customerObj.getEmailVerified().equalsIgnoreCase("yes")){
				authenticationErrorResponse.setCustomerRef(customerRef);
				return 4;
			}
			else if (customerObj.getOtpVerfied().equalsIgnoreCase("yes")) {
				authenticationErrorResponse.setCustomerRef(customerRef);
				return 1;
			}
			else if (customerObj.getEmailVerified().equalsIgnoreCase("yes")) {
				authenticationErrorResponse.setCustomerRef(customerRef);
				return 2;
			}
			
		}
		authenticationErrorResponse.setCustomerRef(customerRef);
		// Returns 3 if the user account exists but nothing was verified.
		return 3;
	}

	@Override
	public AuthenticationErrorResponse validateUserV2(CustomerCreationPostRequestV2 customer) {

		AuthenticationErrorResponse authenticationErrorResponse = new AuthenticationErrorResponse();
		boolean validationFlag = true;
		CustomerCreationDTO customerCreationDTO = customer.getCustomer();
		int enquiryId = customer.getEnquiryId();

		String emailId = customerCreationDTO.getEmailAddress();
		boolean valid = isValidEmailAddress(emailId);
		if (!valid) {
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_ERROR_INVALID_EMAIL);
			validationFlag = false;
		}

		String mobileNumber = customerCreationDTO.getMobileNumber();
		if (!isValidNumber(mobileNumber)) {
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE_NUM);
			validationFlag = false;
		}
		if (mobileNumber.length() > 10 || mobileNumber.length() < 8) {
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_ERROR_INVALID_MOBILE);
			validationFlag = false;
		}
		int emailAndMobileVerification = doesMobileOrEmailVerified(mobileNumber, emailId,authenticationErrorResponse);
		getLogger().info("Printing the email , mobile verification status " + emailAndMobileVerification);

		/*
		 * This is the check for email address which has been verified already.
		 * And the user should not be allowed to modify the same email address.
		 */
		if (emailAndMobileVerification == 2) {
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_ERROR_EMAIL_ALREADY_VERIFIED);
			authenticationErrorResponse.setEmailVerified(true);
			validationFlag = false;
		} else {
			authenticationErrorResponse.setEmailVerified(false);
		}
		/*
		 * This is the check for mobile number to see if that is already
		 * verified.
		 */
		if (emailAndMobileVerification == 1) {
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_ERROR_MOBILE_ALREADY_VERIFIED);
			authenticationErrorResponse.setMobileVerified(true);
			validationFlag = false;
		} else {
			authenticationErrorResponse.setMobileVerified(false);
		}

		if (emailAndMobileVerification == 3) {
			authenticationErrorResponse.setAccountExists(true);
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.ACCOUNT_ALREADY_EXISTS);
			validationFlag = false;
		}
		if (emailAndMobileVerification == 4) {
			validationFlag = false;
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_ERROR_EMAIL_MOBILE_ALREADY_VERIFIED);			
			authenticationErrorResponse.setMobileVerified(true);
			authenticationErrorResponse.setEmailVerified(true);
		}
		authenticationErrorResponse.setAccountAlreadyCreated(
				authenticationErrorResponse.isEmailVerified() && authenticationErrorResponse.isMobileVerified());
		if (validationFlag) {
			authenticationErrorResponse.setErrorMessage(ApplicationConstants.VALIDATION_SUCCESS);
		}
		return authenticationErrorResponse;
	}

	@Override
	public CustomerAndPrevilegeV2 signupV2(CustomerCreationPostRequestV2 customerCreationPostRequestV2)
			throws DatabaseAccessException {
		String otpString = generateOTP();
		String contactNumber = customerCreationPostRequestV2.getCustomer().getMobileNumber();
		String countryCode = customerCreationPostRequestV2.getCustomer().getCountryCode();
		sendOTP(contactNumber, countryCode, otpString, false);
		// ------------------------------------------------------//
		String sessionId = customerCreationPostRequestV2.getSessionId();
		
		Customer customer = new Customer();		
		customer.setDateOfBirth("");
		customer.setGender("");
		customer.setCreatedBy("System");
		customer.setCreatedDate(new Date());
		customer.setVerificationEnquiryId(customerCreationPostRequestV2.getEnquiryId());
		customer.setMobileNumber(contactNumber);
		customer.setCountryCode(countryCode);
		customer.setAcceptMarketEmails(customerCreationPostRequestV2.getCustomer().isAcceptMarketingNotifications());
		customer.setGivenName(customerCreationPostRequestV2.getCustomer().getFirstName());
		customer.setSurName(customerCreationPostRequestV2.getCustomer().getLastName());
		customer.setNricName(customerCreationPostRequestV2.getCustomer().getFullName());
		customer.setEmail(customerCreationPostRequestV2.getCustomer().getEmailAddress());
		customer.setOtpString(appendDateToOTP(otpString));
		customer.setOtpVerfied("No");
		customer.setEmailVerified("No");
		getLogger().info("Singning up the user information " + otpString);
		// --- Set the user id to allow the user to edit the mobile number
		CustomerPassLog customerPassLog = setPasswordV2(customer, customerCreationPostRequestV2.getCustomer().getPassword(), sessionId);
		int enquiryId = customerCreationPostRequestV2.getEnquiryId();
		customer.setVerificationEnquiryId(enquiryId);
		CustomerAndPrevilegeV2 customerAndPrevilege = accountsDao.signupV2(customer);
		// -------------------------------------------------------//
		try {
			// Sleep introduced to ensure that the customer data is saved.
			Thread.sleep(100);
		} catch (InterruptedException e) {
			getLogger().error("InterruptedException in signupV2(): " + e);
			// Restore interrupted state...
		    Thread.currentThread().interrupt(); // "InterruptedException" should not be ignored (squid:S2142)
		}
		
		getLogger().info("Printing the customer id " + customerAndPrevilege.getCustomer().getId());
		getLogger().info("Printing the enquiry id " + enquiryId);
		List<BFAGrandtedAuthority> grantedAuthorities = getGrantedAuthoritiesV2(customerAndPrevilege);
		String authToken = getAuthToken(customerAndPrevilege.getCustomer(), grantedAuthorities);
		int customerId = customerAndPrevilege.getCustomer().getId();
		// - Persist the customer password information for tracking.// 
		customerPassLog.setCustomerId(customerId);
		accountsDao.saveObject(customerPassLog);
		//-----------------------------------------------------------------------------//
		updateUserToken(authToken, customerId);
		customerAndPrevilege.setSecurityToken(authToken);
		Customer custObj = customerAndPrevilege.getCustomer();
		if (customerCreationPostRequestV2.getJourneyType().toLowerCase().contains("insurance")) {
			updateCustomerInformationV2(customerCreationPostRequestV2.getEnquiryId(), custObj, true);
		}
		else if (customerCreationPostRequestV2.getJourneyType().toLowerCase().contains(("investment"))) {
			getLogger().info("Save Promo code: journey type"+customerCreationPostRequestV2.getJourneyType().toLowerCase());
			customerEnquiryService.mapCustomerToEnquiry(custObj.getId(), customerCreationPostRequestV2.getEnquiryId());
			getLogger().info("Save Promo code: Input parameters"+"Customer Id: "+custObj.getId()+" Enquiry ID: "+customerCreationPostRequestV2.getEnquiryId());
			securityService.savePromocode(custObj.getId(), customerCreationPostRequestV2.getEnquiryId());
		}
		return customerAndPrevilege;
	}

	/**
	 * Sends the request to persist the customer id in all microservices.
	 */

	@Override
	public void updateCustomerInformationV2(int enquiryId, Customer customerObj, boolean isNewCustomer) {

		getLogger().info("Updating customer information : ThreadName:" + Thread.currentThread().getName()
				+ " Started at :" + new Date());
		// ---------------------------------------------------------------//
		getLogger().info("Starting the customer id update request");
		UpdateCustomerV2 updateCustomer = new UpdateCustomerV2(enquiryId, customerObj);
		threadPoolTaskExecutor.execute(updateCustomer);
		// ---------------------------------------------------------------//

		// -------------- Update Dependents -------------------------//
		Thread d = new Thread() {
			public void run() {
				getLogger().info("Updating the dependents ");
				List<Dependents> dependentList = getAllDependents(enquiryId);
				dependentList.forEach(x -> {
					x.setCustomerId(customerObj.getId());
					accountsDao.saveOrUpdateObject(x);
					try {
						Thread.currentThread();
						Thread.sleep(200);
					} catch (Exception e) {
						getLogger().error("Error while updating the customer information", e);
					}
				});
				getLogger().info("Successfully updated the customer id in dependents data");
			}
		};
		threadPoolTaskExecutor.execute(d);
	}

	private void setPassword(Customer customerObj, String password) {
		String encrypt = utility.EncryptText(password);
		customerObj.setPassword(encrypt.getBytes());
	}

	/**
	 * This method decrypts the password and then hash the password before it is
	 * stored in database. This is as per the new signup logic.
	 * 
	 * @param customerObj
	 * @param password
	 */
	private CustomerPassLog setPasswordV2(Customer customerObj, String password, String sessionId) {
		// Step 1: Decrypt the password
		// Step 2 : Store the encrypted password as blob
		String decrypted = passwordEncryptionService.decrypt(password, sessionId);
		String _encrypt = "";
		// -------------------------------------------------------------
		//------------------- BFA-1552 ----------------------------
		try {
					byte[] uniqueId = utility.getSalt();
					customerObj.setUniqueId(uniqueId);
					_encrypt = utility.encryptTextWithKey(decrypted, false, uniqueId);
					customerObj.setPassword(_encrypt.getBytes());
					return getCustomerPasswordLog(_encrypt.getBytes(),uniqueId,customerObj.getId());
				} catch (NoSuchAlgorithmException e) {			
					getLogger().error("Error while obtaining the salted key",e);
				}
				// -------------------------------------------------------------- 	
		return null;
	}
	

	private CustomerPassLog getCustomerPasswordLog(byte[] password, byte[] uniqueId, Integer customerId){
		getLogger().info("Update the customer password log ,Thread Name:" + Thread.currentThread().getName());
		CustomerPassLog customerPassLog = new CustomerPassLog();		
		customerPassLog.setPassword(password);
		customerPassLog.setUniqueId(uniqueId);
		customerPassLog.setUpdateDate(new Date());	
		return customerPassLog;
	}

	private List<BFAGrandtedAuthority> getGrantedAuthoritiesV2(CustomerAndPrevilegeV2 customerAndPrevilege) {
		List<BFAGrandtedAuthority> authorities = new ArrayList<>();
		customerAndPrevilege.getPrevileges().forEach(x -> x.getPrevileges().forEach(y -> {
			BFAGrandtedAuthority authObj = new BFAGrandtedAuthority(y.getPrvilegeName());
			authorities.add(authObj);
		}));
		return authorities;
	}

	/**
	 * Updates the customer Id after signup.
	 * 
	 * @author pradheep.p
	 *
	 */
	class UpdateCustomerV2 implements Runnable {

		private UpdateCustomerRequest requestObj = new UpdateCustomerRequest();

		private Integer enquiryId;

		private Customer customerObj;

		public UpdateCustomerV2(int enquiryId, Customer customerObj) {
			this.enquiryId = enquiryId;
			this.customerObj = customerObj;
		}

		@Override
		public void run() {
			if ((enquiryId == null) || customerObj == null) {
				getLogger().error(
						"Unable to update the customer id " + customerObj + " for the given enquiry id " + enquiryId);
				return;
			}
			requestObj.setCustomerId(customerObj.getId());
			requestObj.setEnquiryId(enquiryId);
			delegateHandler.updateCustomerId(requestObj);
			getLogger().debug("Updating customer information in all microservices initiated ");
		}
	}

	@Override
	public void updateMobileAndEmailUniqueness(String mobileNumber, String emailAddress, AccountStatus accountStatus) {
		boolean isMobileAlreadyVerified = doesMobileAlreadyVerified(mobileNumber);
		boolean isEmailAlreadyVerified = doesEmailAlreadyVerified(emailAddress);
		boolean isAccountAlreadyCreated = isMobileAlreadyVerified && isEmailAlreadyVerified;
		accountStatus.setEmailVerified(isEmailAlreadyVerified);
		accountStatus.setMobileVerified(isMobileAlreadyVerified);
		accountStatus.setAccountAlreadyCreated(isAccountAlreadyCreated);
		getLogger().info("Inside update mobile and email uniqueness " + "Mobile Number : " + mobileNumber + "Email :"
				+ emailAddress + " is mobile verified :" + isMobileAlreadyVerified + " email verified "
				+ isEmailAlreadyVerified);
	}

	@Override
	public String encryptCustomerId(String toBeEncrypted) {
		String encrypt = utility.EncryptText(toBeEncrypted);
		System.out.println(encrypt);
		return encrypt;
	}
	
	/**
	 * <B>Here are the list of things activities that has been performed by this method:</B><BR></BR>
	 * 1) This class takes the Mobile number and customer reference in encrypted format as input.</BR>
	 * 2) Decrypts the customer reference and gets the customer id.</BR>
	 * 3) Fetches the data from customer table using the customer id.</BR>
	 * 4) Checks whether the given number and the already existing number are same, if yes it throws error back.</BR>
	 * 5) Checks the format of the mobile number and returns the validation errors.</BR>
	 * 6) If all the above checks are passed, then it updates the number on customer DB table.</BR>
	 * 7) After saving the details, it sends OTP to the new number and returns the success response back.</BR>
	 * 
	 * @param updateMobileNumberRequest - UpdateMobileNumberRequest
	 * @return response - ServiceResponse<Boolean>
	 */
	@Override
	public ServiceResponse<Boolean> updateMobileNumber(UpdateMobileNumberRequest updateMobileNumberRequest) {
		ServiceResponse<Boolean> response = new ServiceResponse<>();
		response.setResponse(true);
		boolean isMobileNumberChanged = false;
		// Fetch the customer Id by using customer reference value.
		Customer customerObj = getCustomerByReferenceV1(updateMobileNumberRequest.getCustomerRef());
		// If 
		if (customerObj == null) {
			getLogger().debug("Customer does not exists in our system, customer ref: " + updateMobileNumberRequest.getCustomerRef());
			response.setResponse(false);
			response.addErrorInfo("error", "Customer does not exists in our system.");
			return response;
		}
		if (!customerObj.getMobileNumber().equals(updateMobileNumberRequest.getMobileNumber())) {
			String message = validateNewMobileNumber(updateMobileNumberRequest.getMobileNumber());
			if (!message.equals(ApplicationConstants.VALIDATION_SUCCESS)) {
				response.setResponse(false);
				response.addErrorInfo("error", message);
			} else {
				isMobileNumberChanged = true;
			}
		} else {
			getLogger().debug("Given Mobile number already with us, Given number:" + updateMobileNumberRequest.getMobileNumber());
			response.setResponse(false);
			response.addErrorInfo("error", "Given Mobile number is already with us.");
		}

		if (isMobileNumberChanged) {
			ContactDetailsDTO contactDetailsDTO = new ContactDetailsDTO();
			contactDetailsDTO.setCountryCode(updateMobileNumberRequest.getCountryCode());
			contactDetailsDTO.setMobileNumber(updateMobileNumberRequest.getMobileNumber());
			Integer customerId = customerObj.getId();
			if (!StringUtils.isEmpty(updateMobileNumberRequest.getCountryCode())) {
				customerObj.setCountryCode(updateMobileNumberRequest.getCountryCode());
			}
			customerObj.setMobileNumber(updateMobileNumberRequest.getMobileNumber());
			accountsDao.updateObject(customerObj);
			if (isMobileNumberChanged) {
				// update mobile
				editContactDetails(contactDetailsDTO, customerId);
				response.setResponse(true);
				response.addErrorInfo("mobileupdatestatus", "Mobile Number is successfully updated!");
				response.addResponseInfo("customerRef", updateMobileNumberRequest.getCustomerRef());

			}
		}
		return response;
	}

	@Override
	public ServiceResponse<Boolean> saveCustomerSrsBankDetail(Integer customerPortfolioId,
			CustomerSrsAccountDTO srsDetailsRequest, Integer customerId) {

		CustomerSrsAccount customerSrsBank = null;
		ServiceResponse<Boolean> response = new ServiceResponse<>();
		
		OptionItem paymentMode = investService.fetchingOptionItemById(srsDetailsRequest.getFundTypeId());

		try {
			if (paymentMode != null && paymentMode.getValue().equals("SRS")
					&& srsDetailsRequest.getSrsDetails() != null) {
				
				customerSrsBank = dao.getCustomerSrsBankbyId(customerId);

				if (customerSrsBank == null) {
					customerSrsBank = new CustomerSrsAccount();
					customerSrsBank.setCustomerId(customerId);
					customerSrsBank.setCreatedDate(PublicUtility.getCurrentSGT());
				}
				customerSrsBank.setAccountNumber(srsDetailsRequest.getSrsDetails().getAccountNumber());
				if (srsDetailsRequest.getSrsDetails().getOperatorId() != null
						&& srsDetailsRequest.getSrsDetails().getOperatorId() != 0) {
					OptionItem operatorId = new OptionItem();
					operatorId.setId(srsDetailsRequest.getSrsDetails().getOperatorId());
					customerSrsBank.setSrsBankOperator(operatorId);
				}
			    customerSrsBank.setLastModifiedDate(PublicUtility.getCurrentSGT());
			    customerPreferenceDao.saveOrUpdateObject(customerSrsBank);
				response.setResponse(true);
				CustomerBankInfoDTO dto = new CustomerBankInfoDTO();
				List<CustomerBankDetail> customerBankDetailList = getCustomerBankDetails(customerId);
				if (customerBankDetailList != null && !customerBankDetailList.isEmpty()) {
					CustomerBankDetail customerBankDetail = customerBankDetailList.get(0);
					dto.setCustomerBankDetail(customerBankDetail);
				}
				dto.setCustomerSrsAccount(customerSrsBank);
				boolean issrsDetailsSavedtoIfast = investService.saveCustomerSRStoIfast(dto);
				getLogger().info("SRS Details of customerId" + customerId +"to ifast isSaved"+ issrsDetailsSavedtoIfast);
			}
			// updating SRS flag to Customer Portfolio Table with
			if (customerPortfolioId != null && paymentMode != null) {
			
				UpdateFundingTypeRequest fundingRequest=new UpdateFundingTypeRequest();
				fundingRequest.setCustomerPortfolioId(customerPortfolioId);
				fundingRequest.setFundingType(srsDetailsRequest.getFundTypeId());
				investService.updatetheSrsfundingType(fundingRequest);
			}
		} catch (Exception ex) {
			getLogger().error("Exception Occurred in saving srs bank Details::" + ex.getMessage());
		}
		return response;
	}

	@Override
	public void updateCustomer(Customer customerObj) {
		accountsDao.updateObject(customerObj);		
	}
}

/**
 * 
 */
package com.bfa.monthlystatements;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;

/**
 * @author HCL
 *
 * ZipUtil.java Created on Dec 11, 2018, 5:46:50 PM by Vimala Shan
 */
public class ZipUtil {
	
	private Logger logger;
	
	public File unzip(String zipFilePath, String destDir) {

		getLogger().info("zipFilePath: " +  zipFilePath + " ; " + "unzipped files to be save in directory path: " + destDir);
		File newFile = null;
		ZipInputStream zippedInputStream = null;
		FileOutputStream fileOutputStream = null;
		FileInputStream fileInputStream = null;
		try {
			File dir = new File(destDir);
			// create output directory if it doesn't exist
			if (!dir.exists())
				dir.mkdirs();
			// buffer for read and write data to file
			byte[] buffer = new byte[1024];
			int len = 0;
			fileInputStream = new FileInputStream(zipFilePath);
			zippedInputStream = new ZipInputStream(fileInputStream);
			ZipEntry ze = zippedInputStream.getNextEntry();
			while (ze != null) {
				String fileName = ze.getName();
				newFile = new File(destDir + File.separator + fileName);
				getLogger().info("Unzipping to " + newFile.getAbsolutePath());
				// create directories for sub directories in zip
				new File(newFile.getParent()).mkdirs();
				fileOutputStream = new FileOutputStream(newFile);

				while ((len = zippedInputStream.read(buffer)) > 0) {
					fileOutputStream.write(buffer, 0, len);
				}
				// close this ZipEntry
				zippedInputStream.closeEntry();
				ze = zippedInputStream.getNextEntry();
			}
		} catch (IOException e) {
			getLogger().error("IOException occured in ZIpUtil.unzip() for zipFilePath: " + zipFilePath + "destFolder: "
					+ destDir + e);
		} catch (Exception e) {
			getLogger().error("Exception occured in ZIpUtil.unzip() for zipFilePath: " + zipFilePath + "destFolder: "
					+ destDir + e);
		} finally {
			// close last ZipEntry
			try {
				if (zippedInputStream != null) {
					zippedInputStream.closeEntry();
				}
				if (zippedInputStream != null) {
					zippedInputStream.close();
				}
				if (fileInputStream != null) {
					fileInputStream.close();
				}
				if (fileOutputStream != null) {
					fileOutputStream.close();
				}
			} catch (IOException e) {
				getLogger().error("Exception occured while close file input stream : " + fileOutputStream + e);
			} catch (Exception e2) {
				getLogger().error("Exception occured while unzip the file : " + zipFilePath + ";" + e2);
			}
		}
		return newFile;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
}
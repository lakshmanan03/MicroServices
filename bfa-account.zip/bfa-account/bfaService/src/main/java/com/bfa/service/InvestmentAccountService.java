package com.bfa.service;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.bfa.insurance.core.Customer;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.util.ServiceResponse;

public interface InvestmentAccountService {
	ServiceResponse<Map<String, String>> saveInvestmentAccountDetails(CustomerDetailsDTO accountDetails,
			Integer customerId);

	ServiceResponse<Map<String, String>> saveDocument(Integer customerId, MultipartFile uploadedFile, String type);

	boolean deleteDocument(Integer customerId, String docType);

	DetailedCustomerSummary getIFastParameters(Integer customerId);

	Customer getCustomer();
}

/**
 * 
 */
package com.bfa.application.comprehensive;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.comprehensive.core.UserPromoCode;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;

/**
 * This runnable is to update the promo code issued to the user in the
 * comprehensive journey. Updates the record in the database.
 * 
 * @author pradheep.p
 *
 */
public class UserPromoCodeUpdater implements Runnable {

	@Autowired
	private AccountsDao accountsDao;

	UserPromoCode userPromoCode = new UserPromoCode();

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	public UserPromoCodeUpdater() {
		// created UserPromoCodeUpdater() constructor
	}

	public void setCustomerId(int customerId) {
		userPromoCode.setCustomerId(customerId);
	}

	public void setJourneyType(String journeyType) {
		userPromoCode.setJourney(journeyType);
	}

	public void setPromoCode(String promoCode) {
		userPromoCode.setPromoCode(promoCode);
	}

	@Override
	public void run() {
		userPromoCode.setIssuedDate(new Date());
		getLogger().info("Persisting user promo code " + userPromoCode);
		accountsDao.saveOrUpdateObject(userPromoCode);
		getLogger().info("-- Successfully persisted the user promo code -- ");
	}

}

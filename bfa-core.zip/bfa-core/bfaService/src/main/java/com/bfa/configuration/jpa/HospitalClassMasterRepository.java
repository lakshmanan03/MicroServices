/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bfa.insurance.core.HospitalClassMaster;

/**
 * @author pradheep.p
 *
 */
public interface HospitalClassMasterRepository extends JpaRepository<HospitalClassMaster, Integer> {

}

/**
 * 
 */
package com.bfa.notification.messenger;

import org.springframework.beans.factory.InitializingBean;

/**
 * This class is meant for dynamic switching of primary and secondary SMS
 * gateway providers.
 * 
 * @author pradheep.p
 *
 */
public class SMSGatewayActivator implements InitializingBean {	
	
	private String gatewayProvider = "";

	public String getGatewayProvider() {
		return gatewayProvider;
	}

	public void setGatewayProvider(String gatewayProvider) {		
		this.gatewayProvider = gatewayProvider;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		setGatewayProvider("primary");	
	}

}

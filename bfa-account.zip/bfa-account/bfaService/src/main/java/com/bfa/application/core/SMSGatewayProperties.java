/**
 * 
 */
package com.bfa.application.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "sms_gateway_properties")
public class SMSGatewayProperties {

	@Id
	@GenericGenerator(name = "bfa", strategy = "increment")
	@GeneratedValue(generator = "bfa")
	@Column(name = "id")
	private int id;

	@Column(name = "parameter_name")
	private String parameterName;

	@Column(name = "parameter_value")
	private String parameterValue;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}
}

package com.bfa.investment.ifast.dto;

public class InvestmentAccountCreationRequest {
	private Integer customerPortfolioId;
	private boolean isCDDFailed;

	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

	public boolean getIsCDDFailed() {
		return isCDDFailed;
	}

	public void setIsCDDFailed(boolean isCDDFailed) {
		this.isCDDFailed = isCDDFailed;
	}
	
	
}

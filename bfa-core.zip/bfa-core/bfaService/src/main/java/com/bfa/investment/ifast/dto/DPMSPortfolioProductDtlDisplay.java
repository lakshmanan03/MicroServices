package com.bfa.investment.ifast.dto;

public class DPMSPortfolioProductDtlDisplay {

	private String dpmsPortfolioId;
	private String productCode;
	private String productName;
	private String productType;
	private String allocationPercentage;
	private DPMSSector dpmsSector;
	public String getDpmsPortfolioId() {
		return dpmsPortfolioId;
	}
	public void setDpmsPortfolioId(String dpmsPortfolioId) {
		this.dpmsPortfolioId = dpmsPortfolioId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getAllocationPercentage() {
		return allocationPercentage;
	}
	public void setAllocationPercentage(String allocationPercentage) {
		this.allocationPercentage = allocationPercentage;
	}
	public DPMSSector getDpmsSector() {
		return dpmsSector;
	}
	public void setDpmsSector(DPMSSector dpmsSector) {
		this.dpmsSector = dpmsSector;
	}
	
	

}

/**
 * 
 */
package com.bfa.request.aggregate;

import java.util.List;

import org.apache.log4j.Logger;

import com.bfa.request.processor.ProcessorCommand;

/**
 * This class basically provides the functionality to compose the data obtained by a future task.
 * 
 * @see DefaultServiceAggregator
 * @author pradheep
 *
 * @since Release 2.16
 */
public interface BFADataComposer <T extends ProcessorCommand>{
	
	public static String INSURANCE_COMPOSER = "Insurance Composer";
	
	public static String INSURANCE_DATA_FINANCE_NEEDS = "Insurance financial data";
	
	public static String INSURANCE_NEEDS_DATA = "Insurance  data";
	
	public static String INSURANCE_DEPENDENTS_NEEDS_DATA = "Insurance dependents needs data";	
	
	public Object composeAllData(List<T> collection);
	
	public String getComposerName();
	
	public void setLogger(Logger logger);

}

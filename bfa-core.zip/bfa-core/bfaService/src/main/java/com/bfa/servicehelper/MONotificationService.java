package com.bfa.servicehelper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.application.discovery.DiscoveryService;

public class MONotificationService extends MOServiceHelper  {
	@Autowired
	DiscoveryService discoveryService;
	
	public void sendInAppNotification(Integer customerId, String message, String notificationType) {
		String authorizationToken = discoveryService.preAuthorize();
		MOServiceRequest request = new MOServiceRequest();
		Map<String,String> requestObject = new HashMap<>();
		requestObject.put("customerId", String.valueOf(customerId));
		requestObject.put("message", message);
		requestObject.put("notificationType", notificationType);
		request.setRequestBody(requestObject);
		request.addHeader("Authorization", authorizationToken);
		request.setMethodName("POST");
		request.setUrl(URLDirectory.NotificationService.inAppNotification());
		post(request);
	}	
}

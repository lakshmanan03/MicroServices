/**
 * 
 */
package com.bfa.application.core;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Entity for promo code for each customer
 * 
 * @author kianann
 * 
 */
@Entity
@Table(name = "customer_promo_code")
@EntityListeners(AuditingEntityListener.class)
public class CustomerPromo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Integer id;
	
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "promo_code_id")
	private Integer promoCodeId;
	
	@CreatedBy
	@Column(name = "created_by", 
			nullable = false, 
		    updatable = false)
	private String createdBy;
	
	@CreatedDate
	@Column(name = "created_ts",
			nullable = false, 
		    updatable = false)
	private Timestamp createdTs;
	
	@LastModifiedBy
	@Column(name = "last_updated_by")
	private String lastUpdatedBy;
	
	@LastModifiedDate
	@Column(name = "last_updated_ts")
	private Timestamp lastUpdatedTs;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the customerId
	 */
	public Integer getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the promoCodeId
	 */
	public Integer getPromoCodeId() {
		return promoCodeId;
	}

	/**
	 * @param promoCodeId the promoCodeId to set
	 */
	public void setPromoCodeId(Integer promoCodeId) {
		this.promoCodeId = promoCodeId;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdTs
	 */
	public Timestamp getCreatedTs() {
		return createdTs;
	}

	/**
	 * @param createdTs the createdTs to set
	 */
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	/**
	 * @return the lastUpdatedBy
	 */
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	/**
	 * @param lastUpdatedBy the lastUpdatedBy to set
	 */
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	/**
	 * @return the lastUpdatedTs
	 */
	public Timestamp getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	/**
	 * @param lastUpdatedTs the lastUpdatedTs to set
	 */
	public void setLastUpdatedTs(Timestamp lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}
}

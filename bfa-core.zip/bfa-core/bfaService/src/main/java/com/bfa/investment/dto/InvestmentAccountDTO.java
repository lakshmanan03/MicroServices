/**
 * 
 */
package com.bfa.investment.dto;

/**
 * @author DivakarU
 *
 */
public class InvestmentAccountDTO {
	
	private Double accountBalance;
	/**
	 * @return the accountBalance
	 */
	public Double getAccountBalance() {
		return accountBalance;
	}
	/**
	 * @param accountBalance the accountBalance to set
	 */
	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}
	/**
	 * @return the referenceCode
	 */
	public String getReferenceCode() {
		return referenceCode;
	}
	/**
	 * @param referenceCode the referenceCode to set
	 */
	public void setReferenceCode(String referenceCode) {
		this.referenceCode = referenceCode;
	}
	private String referenceCode;

}


package com.bfa.common.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_admin_customer_ifast_details")
public class CustomerIfastAccountView {

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private int id;
	
	@Column(name = "ifast_refno")
	private String iFastRefNo;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getiFastRefNo() {
		return iFastRefNo;
	}

	public void setiFastRefNo(String iFastRefNo) {
		this.iFastRefNo = iFastRefNo;
	}
	
}



/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.util.ServiceResponse;

/**
 * @author pradheep.p
 *
 */
public class FileUploader implements Runnable {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	private String documentType;
	
	private Integer customerId;
	
	private MultipartFile multiPartFile;
	
	private UploadService uploadService;
	
	private ServiceResponse<Map<String, String>> results;
	
	private List<ServiceResponse<Map<String, String>>> resultsAggregator;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}	
	
	public void run() {
		getLogger().info("Uploading the document :" );
		results = uploadService.saveDocument(getCustomerId(), getMultiPartFile(), getDocumentType());
		resultsAggregator.add(results);
	}

	public String getDocumentType() {
		return documentType;
	}
	
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public MultipartFile getMultiPartFile() {
		return multiPartFile;
	}

	public void setMultiPartFile(MultipartFile multiPartFile) {
		this.multiPartFile = multiPartFile;
	}

	public UploadService getUploadService() {
		return uploadService;
	}

	public void setUploadService(UploadService uploadService) {
		this.uploadService = uploadService;
	}

	public List<ServiceResponse<Map<String, String>>> getResultsAggregator() {
		return resultsAggregator;
	}

	public void setResultsAggregator(List<ServiceResponse<Map<String, String>>> resultsAggregator) {
		this.resultsAggregator = resultsAggregator;
	}
}

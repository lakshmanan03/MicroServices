package com.bfa.investment.account.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;


public class PersonalDetailsDTO {
	

	private Integer customerId;
	
	private Integer countryId;
	
	private Integer birthCountryId;
	
	private String nationalityCode;
	
	private String fullName;
	
	private String firstName;
	
	private String lastName;
	
	private String nricNumber;
	private String passportNumber;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date passportExpiryDate;
	private Integer passportIssuedCountryId;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date dateOfBirth;
	
	private String gender;
	
	private String race;
	
	private String salutation;
	
	
	
	
	public Integer getBirthCountryId() {
		return birthCountryId;
	}
	public void setBirthCountryId(Integer birthCountryId) {
		this.birthCountryId = birthCountryId;
	}
	public String getRace() {
		return race;
	}
	public void setRace(String race) {
		this.race = race;
	}
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public String getNationalityCode() {
		return nationalityCode;
	}
	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}


	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getNricNumber() {
		return nricNumber;
	}
	public void setNricNumber(String nricNumber) {
		this.nricNumber = nricNumber;
	}
	public String getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	public Date getPassportExpiryDate() {
		return passportExpiryDate;
	}
	public void setPassportExpiryDate(Date passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}
	public Integer getPassportIssuedCountryId() {
		return passportIssuedCountryId;
	}
	public void setPassportIssuedCountryId(Integer passportIssuedCountryId) {
		this.passportIssuedCountryId = passportIssuedCountryId;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
}

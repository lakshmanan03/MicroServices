package com.bfa.application.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tracking_master")
public class Tracker {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "track_code")
	private String trackCode;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "last_updated_time_stamp")
	private Date lastupdatedtimeStamp;
}

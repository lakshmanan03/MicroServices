package com.bfa.notification.messenger.templates;

public interface TemplateType {	
	
	public static int EMAIL_WELCOME_TEMPLATE = 1;
	
	public static int EMAIL_NEW_MESSAGE_UPDATES = 2;
	
	public static int EMAIL_UNSUBSCRIPTION_NOTIFICATION = 3;
	
	public static int ERROR_MESSAGE_TEMPLATE = 4;
	
	public static int SMS_OTP_TEMPLATE = 5;
	
}

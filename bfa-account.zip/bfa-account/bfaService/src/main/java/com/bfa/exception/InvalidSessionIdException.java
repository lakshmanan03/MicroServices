/**
 * 
 */
package com.bfa.exception;

/**
 * @author pradheep
 *
 */
public class InvalidSessionIdException extends RuntimeException {

	public InvalidSessionIdException(String message){
		super(message);
	}
	
}

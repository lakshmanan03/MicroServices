/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveRetirementLumpSumDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private Integer customerId;

	private Integer enquiryId;

	private Integer maturityAmount;

	private Integer maturityYear;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getMaturityAmount() {
		return maturityAmount;
	}

	public void setMaturityAmount(Integer maturityAmount) {
		this.maturityAmount = maturityAmount;
	}

	public Integer getMaturityYear() {
		return maturityYear;
	}

	public void setMaturityYear(Integer maturityYear) {
		this.maturityYear = maturityYear;
	}

}

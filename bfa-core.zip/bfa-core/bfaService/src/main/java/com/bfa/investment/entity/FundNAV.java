package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = "fund_nav")
public class FundNAV {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "nav_date")
	private Date navDate;
	
	@Column(name = "nav")
	private Double latestNavPrice;
	
	@Column(name = "fund_id")
	private String fundId;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "actual_date")
	private String actualNavDate;
	
	@Column(name = "last_modified_date")
	private Date lastModifiedDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getNavDate() {
		return navDate;
	}

	public void setNavDate(Date navDate) {
		this.navDate = navDate;
	}

	public Double getLatestNavPrice() {
		return latestNavPrice;
	}

	public void setLatestNavPrice(Double latestNavPrice) {
		this.latestNavPrice = latestNavPrice;
	}

	public String getFundId() {
		return fundId;
	}

	public void setFundId(String fundId) {
		this.fundId = fundId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getActualNavDate() {
		return actualNavDate;
	}

	public void setActualNavDate(String actualNavDate) {
		this.actualNavDate = actualNavDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	
}

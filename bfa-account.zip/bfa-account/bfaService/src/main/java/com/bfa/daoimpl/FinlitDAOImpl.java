/**
 * 
 */
package com.bfa.daoimpl;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.bfa.application.core.security.FinlitAccessCode;
import com.bfa.insurance.core.PrevilageMaster;

/**
 * @author pradheep
 *
 */
public class FinlitDAOImpl extends BaseDaoImpl {

	public List<PrevilageMaster> getRobo3LiteRolesByCode(String accessCode) {
		String hql = "select pm from FinlitAccessCode fac,FinlitAccessCodePrivilege facp,PrevilageMaster pm where facp.privilegeId = pm.previlegeId and fac.id = facp.finlitAccessCodeId and fac.accessCode =:accessCode";
		List<PrevilageMaster> previlegeMasterData = getObjectByHql(hql, "accessCode", accessCode);
		if (previlegeMasterData == null) {
			return Collections.emptyList();
		}
		return previlegeMasterData;
	}

	public List<FinlitAccessCode> isValidAccessCode(String accessCode) {
		getLogger().info("Trying to find if the access code is valid :" + accessCode);
		Date currentDay = new Date();
		java.sql.Timestamp timeStamp = new Timestamp(currentDay.getTime());
		String hql = "from FinlitAccessCode as AC where :currentDay between AC.startTimestamp and AC.endTimestamp AND AC.accessCode=:accessCode";
		String[] paramNames = new String[] { "currentDay", "accessCode" };
		Object[] values = new Object[] { timeStamp, accessCode };
		getLogger().info("Printing the HQL :" + hql);
		List<FinlitAccessCode> accessCodeList = getObjectByHql(hql, paramNames, values);
		return accessCodeList;
	}
}

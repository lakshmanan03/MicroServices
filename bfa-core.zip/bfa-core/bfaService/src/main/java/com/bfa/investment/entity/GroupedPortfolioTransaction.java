package com.bfa.investment.entity;

import java.util.List;


public class GroupedPortfolioTransaction {
	
	private String groupName;
	
	
	private List<PortfolioTransaction> transactions;


	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	public List<PortfolioTransaction> getTransactions() {
		return transactions;
	}


	public void setTransactions(List<PortfolioTransaction> portfolioTransactions) {
		this.transactions = portfolioTransactions;
	}



	
	
}

/**
 * 
 */
package com.bfa.service;

/**
 * @author pradheep.p
 *
 */
public class AccountServiceConstants {

	private AccountServiceConstants(){
		//Constructor created
	}
	public static final String EMAIL_LINK_VALIDITY = "email.link.validity.in.seconds";
	
	public static final String EMAIL_LINK_DATE_FORMAT = "yyyy.MM.dd HH:mm:SS";
}

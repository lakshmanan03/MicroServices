package com.bfa.common.dto;


public class CriticalIllnessNeedsDTO {
	
private int id;
	
	private int enquiryId;
	
	private int customerId;
	
	private String coverageYears;
	
	private double coverageAmount;	
	
	private boolean isEarlyCriticalIllness;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCoverageYears() {
		return coverageYears;
	}

	public void setCoverageYears(String coverageYears) {
		this.coverageYears = coverageYears;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public boolean isEarlyCriticalIllness() {
		return isEarlyCriticalIllness;
	}

	public void setEarlyCriticalIllness(boolean isEarlyCriticalIllness) {
		this.isEarlyCriticalIllness = isEarlyCriticalIllness;
	}
	
	

}

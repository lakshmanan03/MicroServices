/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.application.core.EnquiryByEmail;
import com.bfa.application.core.EnquiryByEmailModel;
import com.bfa.application.core.ValidateCaptchaBean;
import com.bfa.components.ValidateCaptcha;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.DependentProtectionNeeds;
import com.bfa.insurance.core.DependentsProtectionNeedsJoined;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.UpdateCustomerRequest;
import com.bfa.request.entity.UpdateCustomerRequestByEmail;
import com.bfa.service.AccountsService;
import com.bfa.service.BundleService;
import com.bfa.service.EnquiryService;
import com.bfa.service.MailChimpService;
import com.bfa.service.SecurityService;
import com.bfa.util.ApplicationConstants;

/**
 * @author pradheep
 *
 */
public class DefaultEnquiryService extends DefaultServiceImpl implements EnquiryService {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private AccountsService accountsService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private AccountsDao accountsDAO;

	@Autowired
	private DelegateHandler delegatehandler;

	@Autowired
	private BundleService bundleService;
	
	@Autowired
	private MailChimpService mailChimpService;

	/**
	 * This method is called when the insurance enquiry is only done by email
	 * address. BFA-1578
	 */
	@Override
	@ValidateCaptcha
	public String updateSelectedProductsByEmail(ValidateCaptchaBean validateCaptchaBean, EnquiryByEmail enquiryByEmail)
			throws RuntimeException {
		getLogger().info("Trying to update the selected products by email " + enquiryByEmail.toString());
		try {
			
			if(!validateEmailAddress(enquiryByEmail.getEmail())){
				getLogger().error(
						"Invalid email address given as input - cannot process the request " + enquiryByEmail.getEmail());
				return INVALID_EMAIL_ADDRESS;
			}		

			// Step 1: Validate the captcha details.
			if (enquiryByEmail.getValidateCaptchaBean().isApplicable) {
				if (!enquiryByEmail.getValidateCaptchaBean().isValidCaptcha) {
					getLogger().error("Captcha validation failed");
					return INVALID_CAPTCHA;
				}
			} else {
				getLogger().info("Captcha validation was not applicable.");
			}

			/*
			 * Step 2: Look for existing customer records for the given email
			 * address.
			 */
			String email = enquiryByEmail.getEmail();
			Integer customerId = -1;
			Customer customerObj = getCustomerByEmail(email);
			if (customerObj == null) {
				getLogger().info("No existing customer found by this email");
				/*
				 * Update the selected products only if you dont find a customer
				 */
				updateSelectedProducts(enquiryByEmail);
			} else {
				getLogger().info("Existing customer found for the email :" + email);
				updateExistingCustomer(enquiryByEmail, customerObj);
				customerId = customerObj.getId();
			}
			/*
			 * Step 3: Persist the customer record in the
			 * email_request_for_enquiry
			 */
			NewEnquiryStatus newEnquiryStatus = makeEntryForRequestByEmail(enquiryByEmail, customerId);

			/*
			 * Step 4: Make the CRM call and welcome the user. Makes a call to
			 * CRM for existing user/ or enquiry by email
			 */

			makeCRMCall(enquiryByEmail, customerObj, newEnquiryStatus.isNewCustomer(),newEnquiryStatus.getEnquiryByEmailModel().getId());

		} catch (Exception err) {
			getLogger().error("Error while updating the enquiry by email ", err);
			return ApplicationConstants.INTERNAL_SERVER_ERROR;
		}
		return SUCCESS;
	}

	private void updateSelectedProducts(EnquiryByEmail enquiryByEmail) {
		getLogger().info("> BFA-1578 > Updating the selected products of the user by email");
		Integer customerId = 0;
		/* As do not have a customer id we register it as 0 */
		Integer enquiryId = enquiryByEmail.getEnquiryId();
		UpdateCustomerRequest updateCustomerRequest = new UpdateCustomerRequest();
		updateCustomerRequest.setCustomerId(customerId);
		updateCustomerRequest.setEnquiryId(enquiryId);
		delegatehandler.updateCustomerIdAndProducts(updateCustomerRequest, enquiryByEmail.getSelectedProducts());
	}

	/**
	 * This method is to update the existing customer records and uses the
	 * 
	 * existing workflow as it is used in signup and login flow.
	 * 
	 * @param enquiryByEmail
	 */
	private void updateExistingCustomer(EnquiryByEmail enquiryByEmail, Customer customerObj) {
		getLogger().info(" > > Updating the existing customer records ");
		Integer enquiryId = enquiryByEmail.getEnquiryId();
		UpdateCustomerRequest updateCustomerRequest = new UpdateCustomerRequest();
		updateCustomerRequest.setCustomerId(customerObj.getId());
		updateCustomerRequest.setEnquiryId(enquiryId);
		delegatehandler.updateCustomerIdAndProducts(updateCustomerRequest, enquiryByEmail.getSelectedProducts());
		/*
		 * Customer custObj =
		 * accountsService.updateCustomerdetails(enquiryByEmail.getEnquiryId(),
		 * customerId, enquiryByEmail.getSelectedProducts());
		 */
	}

	/**
	 * This method is called by default to update the enquiry records if it is
	 * called by email.
	 */
	private NewEnquiryStatus makeEntryForRequestByEmail(EnquiryByEmail enquiryByEmail, Integer customerId) {
		/*
		 * Look for the existing email address in the email_request_for_enquiry
		 */
		boolean isNewCustomer = true;
		EnquiryByEmailModel enquiryByEmailModel = null;
		enquiryByEmailModel = getEnquiryByEmail(enquiryByEmail.getEmail());
		if (enquiryByEmailModel == null) {
			enquiryByEmailModel = new EnquiryByEmailModel();
			getLogger().info(
					"Unable to find a existing instance of enquiry by email record :" + enquiryByEmail.getEmail());
		} else {
			isNewCustomer = false;
			getLogger().info("Found an existing instance of enquiry by email record :" + enquiryByEmail.getEmail());
		}
		/*
		 * Based on the discussion with Edwin Toh we update the first name and
		 * the last name every time even if there is email address already
		 * exists.
		 */
		enquiryByEmailModel.setEmail(enquiryByEmail.getEmail());
		enquiryByEmailModel.setFirstName(enquiryByEmail.getFirstName());
		enquiryByEmailModel.setLastName(enquiryByEmail.getLastName());
		enquiryByEmailModel.setAcceptMarketingEmails(enquiryByEmail.isAcceptMarketingEmails());
		enquiryByEmailModel.setLastUpdated(new Date());
		enquiryByEmailModel.setLastUpdatedBy("system");
		enquiryByEmailModel.setMobileNumber(enquiryByEmail.getMobileNumber());
		enquiryByEmailModel.setContactViaMobile(enquiryByEmail.isContactViaMobile());
		enquiryByEmailModel = (EnquiryByEmailModel) accountsDAO.saveOrUpdateObject(enquiryByEmailModel);
		getLogger().info("Successfully saved the enquiry by email model " + enquiryByEmail.getEmail());
		updateEnquiryRecords(enquiryByEmailModel.getId(), enquiryByEmail.getEnquiryId(), customerId);
		NewEnquiryStatus newEnquiryStatus = new NewEnquiryStatus();
		newEnquiryStatus.setNewCustomer(isNewCustomer);
		newEnquiryStatus.setEnquiryByEmailModel(enquiryByEmailModel);
		return newEnquiryStatus;
	}

	/*
	 * Make a service to service call for recommendations to update the
	 * enquiry_by_email_id in the enquiry table.
	 */
	private void updateEnquiryRecords(Integer enquiryByEmailId, Integer enquiryId, Integer customerId) {
		getLogger().info("Updating the enquiryByEmailId in enquiry table. ");
		UpdateCustomerRequestByEmail updateCustomerRequestByEmail = new UpdateCustomerRequestByEmail();
		updateCustomerRequestByEmail.setCustomerId(customerId);
		updateCustomerRequestByEmail.setEmailEnquiryId(enquiryByEmailId);
		updateCustomerRequestByEmail.setEnquiryId(enquiryId);
		delegatehandler.updateCustomerIdAndEmailEnqId(updateCustomerRequestByEmail);
	}

	private Customer getCustomerByEmail(String email) {
		return accountsService.getCustomerDetails(email);
	}

	private void makeCRMCall(EnquiryByEmail enquiryByEmail, Customer customerObj, boolean isNewCustomer,int emailEnquiryId) {
		getLogger().info("Updating the customer records to CRM " + enquiryByEmail.getEmail());
		int customerId = -1;
		if (customerObj != null) {
			customerId = customerObj.getId();
			securityService.updateCRMEnqByEmail(customerId, enquiryByEmail.getSelectedProducts(), false,
					enquiryByEmail.getEnquiryId(), enquiryByEmail.getFirstName(), enquiryByEmail.getLastName());
		} else {
			getLogger().info("Updating the crm records for the enquiry made by email request");
			String firstName = enquiryByEmail.getFirstName();
			String lastName = enquiryByEmail.getLastName();
			String email = enquiryByEmail.getEmail();
			List<ProductList> selectedProducts = enquiryByEmail.getSelectedProducts();
			Integer enquiryId = enquiryByEmail.getEnquiryId();
			delegatehandler.updateCRMForEnquiryByEmail(firstName, lastName, email, selectedProducts, enquiryId,
					isNewCustomer,emailEnquiryId,enquiryByEmail.getMobileNumber().toString());
		}
	}

	/**
	 * @param emailAddress
	 * @return
	 */
	private EnquiryByEmailModel getEnquiryByEmail(String emailAddress) {
		String hql = "from EnquiryByEmailModel where email =:emailAddress";
		List<Object> collection = accountsDAO.getObjectByHql(hql,"emailAddress",emailAddress);
		if (collection == null || collection.isEmpty()) {
			return null;
		} else {
			return (EnquiryByEmailModel) collection.get(0);
		}
	}

	/**
	 * This method is used for subscribing to mailchimp, currently this is not
	 * used. Can re plugged in for use in near future.
	 * 
	 * Kindly do not remove this code.
	 * 
	 * @param enquiryByEmail
	 */
	private void subscribeForMarketingEmails(EnquiryByEmail enquiryByEmail) {
		if (enquiryByEmail.isAcceptMarketingEmails()) {
			getLogger().info("User has subscribed for marketing emails " + enquiryByEmail.getEmail());
			mailChimpService.subscribeForMarketingEmails(enquiryByEmail.getFirstName(), enquiryByEmail.getLastName(),
					enquiryByEmail.getEmail(),0L);
		} else {
			getLogger().info("The user has not subscribed to receive the marketing emails");
		}
	}
	
	class NewEnquiryStatus {
		
		private boolean newCustomer;
		
		private EnquiryByEmailModel enquiryByEmailModel;

		public boolean isNewCustomer() {
			return newCustomer;
		}

		public void setNewCustomer(boolean newCustomer) {
			this.newCustomer = newCustomer;
		}

		public EnquiryByEmailModel getEnquiryByEmailModel() {
			return enquiryByEmailModel;
		}

		public void setEnquiryByEmailModel(EnquiryByEmailModel enquiryByEmailModel) {
			this.enquiryByEmailModel = enquiryByEmailModel;
		}
		
	}

	@Override
	public List<DependentMapping> getDependentDetails(Integer enquiryId) {		
		getLogger().info("Tring to get the dependent details of the customer  -> enquiryid:" + enquiryId);
		List<DependentMapping> dependentMappingList = new ArrayList<DependentMapping>();
		String hql = "from DependentsProtectionNeedsJoined dpn where dpn.dependent.enquiryId=:enquiryId";
		String[] paramNames = new String[] {"enquiryId"};
		Object[] paramValues = new Integer[] {enquiryId};
		List<DependentsProtectionNeedsJoined> collection = (List<DependentsProtectionNeedsJoined>) accountsDAO.getObjectByHql(hql,paramNames,paramValues);
		if (collection == null || collection.isEmpty()) {
			return null;
		} else {			
			for (DependentsProtectionNeedsJoined obj : collection) {
				    DependentMapping target = new DependentMapping();
				    DependentProtectionNeeds dpn = new DependentProtectionNeeds();
					BeanUtils.copyProperties(obj, dpn);
					BeanUtils.copyProperties(obj.getDependent(), target);
					target.setDependentProtectionNeeds(dpn);
					dependentMappingList.add(target);
			}
		}
		return dependentMappingList;
	}
}

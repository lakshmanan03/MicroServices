SET foreign_key_checks = 0;
DROP TABLE customer_previlege;
CREATE TABLE customer_previlege (
  customer_id int(11) NOT NULL,
  previlege_id int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


drop table previlege_master if exists;
CREATE TABLE previlege_master (
  id int(100) NULL primary auto_increment,
  previlege_name varchar(100) NOT NULL,
  description varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into customers(id,email,mobile_number) values(1,'testemail@yopmail.com','98001122');

insert into previlege_master(previlege_name,description) values ('ROLE_USER','ROLE_USER');
insert into previlege_master(previlege_name,description) values ('ROLE_SIGNED_USER','ROLE_SIGNED_USER');

insert into customer_previlege values(1,1);
insert into customer_previlege values(1,2);

insert into customer_document_details values ('1', '1', 'https://abc.com/NRIC_BACK.PNG', 'NRIC_BACK', '1', 'Success', '2018-11-09 15:00:44', '2019-02-15 15:29:06');
insert into customer_employment_details values ('1', '18', NULL, '9', '5', 'Specialist');
insert into customer_additional_details values ('1', '1', '0', '0', NULL, NULL, 'PASSPORT', '0', '1', '1')


commit;
/**
 * 
 */
package com.bfa.service;

import javax.servlet.http.HttpServletRequest;

import com.bfa.promotion.model.PromotionBundleModel;

/**
 * @author pradheep
 *	
 * Modified During release 2.22 for seperation of child bundles
 */
public interface BundleService {
	
	/* BFA-1643  */
	public String CHILD_BUNDLE_PRO_TYPE_ENQ = "child-protection-bundle";
	
	/* BFA-1647 */
	public String CHILD_BUNDLE_EDU_TYPE_ENQ = "child-education-bundle";
	
	/* BFA-1701 */
	public String RETIREMENT_BUNDLE_TYPE_ENQ = "retirement-bundle";
	
	public String notifyBundleEnquiry(PromotionBundleModel model,HttpServletRequest httpServletRequest);	
	
	public void updateBundleDataInCRM(PromotionBundleModel promotionBundleModel);
	
}

package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.CustomerDocumentDAO;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.DocumentStatusMaster;
import com.bfa.util.AmazonS3ClientService;

@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerDocumentDetailsServiceImplTest {

	@InjectMocks
	private CustomerDocumentDetailsServiceImpl mCustDocumentDetailsServiceImpl;

	@Mock
	private CustomerDocumentDAO mCustomerDocDao;

	@Mock
	private CustomerDocumentDetails mCustomerDocumentDetails;

	@Mock
	private DocumentStatusMaster mDocumentStatusMaster;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private AmazonS3ClientService mAmazonS3Client;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}

	int cusId = 1;

	String filePath = "C:doc/path";

	String status = "success";

	String doctype = ".txt";

	@Test
	public void testDeleteCustomerDocument() {
		when(mCustomerDocDao.getAwsFileName(cusId)).thenReturn("aswfile");
		when(mAmazonS3Client.deleteFileFromS3Bucket(filePath)).thenReturn(status);
		String response = mCustDocumentDetailsServiceImpl.deleteCustomerDocument(cusId);
		assertNotNull(response);
	}

	@Test
	public void testSaveOrUpdateCustomerDocument() {
		when(mCustomerDocDao.getDocumentStatus("TO-BE-REVIEWED")).thenReturn(mDocumentStatusMaster);
		when(mCustomerDocDao.getCustomerDocument(cusId, doctype)).thenReturn(mCustomerDocumentDetails);
		mCustDocumentDetailsServiceImpl.saveOrUpdateCustomerDocument(cusId, filePath, doctype);
	}

	@Test(expected=RuntimeException.class)
	public void testSaveOrUpdateCustomerDocumentException() {
		when(mCustomerDocDao.getCustomerDocument(cusId, doctype)).thenReturn(null);
		when(mAmazonS3Client.deleteFileFromS3Bucket(filePath)).thenReturn(status);
		when(mCustomerDocDao.getDocumentStatus("TO-BE-REVIEWED")).thenThrow(new RuntimeException());
		mCustDocumentDetailsServiceImpl.saveOrUpdateCustomerDocument(cusId, filePath, doctype);
	}

	@Test
	public void testSaveCustomerDocument() {
		mCustDocumentDetailsServiceImpl.saveCustomerDocument(cusId, filePath, mCustomerDocumentDetails, status);
	}

	@Test
	public void testSaveCustomerDocumentException() {
		doThrow(new RuntimeException()).when(mCustomerDocDao).saveCustomerDocument(mCustomerDocumentDetails, status);
		mCustDocumentDetailsServiceImpl.saveCustomerDocument(cusId, filePath, mCustomerDocumentDetails, status);
	}

	@Test
	public void testGetAllDetails(){
		List<CustomerDocumentDetails> response = mCustDocumentDetailsServiceImpl.getAllDetails();
		assertNotNull(response);
	}
	
}

package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.common.entity.OptionItem;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;

@Entity
@Table(name = "customer_portfolio")
public class CustomerPortfolio {
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "id")
	  private int id;
	  
	  @OneToOne
	  @JoinColumn(name = "customer_id")
	  private Customer customer;

	  
	  @OneToOne
	  @JoinColumn(name = "enquiry_id")
	  private Enquiry enquiry;
	  
	  @Column(name = "portfolio_id")
	  private String portfolioId;
	  
	  @Column(name = "portfolio_status")
	  private String portfolioStatus;
	  
	  @Column(name = "account_type")
	  private String accountType;
	  
	  @Column(name = "ifast_trust_id")
	  private String ifastTrustId;
	  
	  @Column(name = "value_on_transaction_date")
	  private Double valueOnTransactionDate;
	  
	  @Column(name = "returns_on_transaction_date")
	  private Double returnsOnTransactionDate;

	  @Column(name = "created_date")
	  private Date createdDate;

	  @Column(name = "last_updated_time_stamp")
	  private Date lastUpdatedTimeStamp;
	  
	  @Column(name = "last_monthly_topup_date")
	  private Date lastMonthlyTopupDate;
	  
	  @Column(name = "first_transaction_date")
	  private Date firstTransactionDate;
	  
	  @Column(name = "closing_portfolio_value")
      private Double closingPortfolioValue;
	  
	  @Column(name ="portfolio_name")
	  private String portfolioName;
	  
	  @OneToOne
	  @JoinColumn(name ="funding_type")
	  private OptionItem fundingType;

	public Date getFirstTransactionDate() {
		return firstTransactionDate;
	}

	public void setFirstTransactionDate(Date firstTransactionDate) {
		this.firstTransactionDate = firstTransactionDate;
	}

	public Enquiry getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(Enquiry enquiry) {
		this.enquiry = enquiry;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Double getValueOnTransactionDate() {
		return valueOnTransactionDate;
	}

	public void setValueOnTransactionDate(Double valueOnTransactionDate) {
		this.valueOnTransactionDate = valueOnTransactionDate;
	}

	public Double getReturnsOnTransactionDate() {
		return returnsOnTransactionDate;
	}

	public void setReturnsOnTransactionDate(Double returnsOnTransactionDate) {
		this.returnsOnTransactionDate = returnsOnTransactionDate;
	}

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIfastTrustId() {
		return ifastTrustId;
	}

	public void setIfastTrustId(String ifastTrustId) {
		this.ifastTrustId = ifastTrustId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public Date getLastMonthlyTopupDate() {
		return lastMonthlyTopupDate;
	}

	public void setLastMonthlyTopupDate(Date lastMonthlyTopupDate) {
		this.lastMonthlyTopupDate = lastMonthlyTopupDate;
	}

	public Double getClosingPortfolioValue() {
		return closingPortfolioValue;
	}

	public void setClosingPortfolioValue(Double closingPortfolioValue) {
		this.closingPortfolioValue = closingPortfolioValue;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	/**
	 * @return the fundingType
	 */
	public OptionItem getFundingType() {
		return fundingType;
	}

	/**
	 * @param fundingType the fundingType to set
	 */
	public void setFundingType(OptionItem fundingType) {
		this.fundingType = fundingType;
	}

	
	
}

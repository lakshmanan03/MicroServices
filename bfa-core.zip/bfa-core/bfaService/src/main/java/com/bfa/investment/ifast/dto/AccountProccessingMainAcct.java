package com.bfa.investment.ifast.dto;

public class AccountProccessingMainAcct {

	private String accountName;
	private String usPermanentResident;
	private Tin[] tin;
	private String employerName;
	private String occupation;
	private String occupationDescription;
	private String directorOfInvestmentFirm;
	private String sourceOfFunds;
	private String homeAddressCountry;
	private String homeAddressZip;
	private String homeAddress1;
	private String homeAddress2;
	private String homeAddressState;
	private String mailingAddressOption;
	private String addressDiffReason;
	private String addressDiffOtherReason;
	private String mailAddressCountry;
	private String mailAddressZip;
	private String mailAddress1;
	private String mailAddress2;
	private String mailAddressState;
	private String singaporeTaxResident;
	private String updateAddressType;
	private String cpfAcctNo;
	private String cpfAgentBank;
	private String cpfInvestmentAcctNo;
	private String srsAcctNo;
	private String srsOperator;
	private String bankAgreeFlag;
	private String bankCode;
	private String bankAcctNo;
	private String bankAcctName;
	private String bank1AcctNo;
	private String bank1Name;
	private String bank1SwiftCode;
	private String bank2Name;
	private String bank2SwiftCode;
	private String salutation;
	private String salaryRange;

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getUsPermanentResident() {
		return usPermanentResident;
	}

	public void setUsPermanentResident(String usPermanentResident) {
		this.usPermanentResident = usPermanentResident;
	}

	public Tin[] getTin() {
		return tin;
	}

	public void setTin(Tin[] tin) {
		this.tin = tin;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getOccupationDescription() {
		return occupationDescription;
	}

	public void setOccupationDescription(String occupationDescription) {
		this.occupationDescription = occupationDescription;
	}

	public String getDirectorOfInvestmentFirm() {
		return directorOfInvestmentFirm;
	}

	public void setDirectorOfInvestmentFirm(String directorOfInvestmentFirm) {
		this.directorOfInvestmentFirm = directorOfInvestmentFirm;
	}

	public String getSourceOfFunds() {
		return sourceOfFunds;
	}

	public void setSourceOfFunds(String sourceOfFunds) {
		this.sourceOfFunds = sourceOfFunds;
	}

	public String getHomeAddressCountry() {
		return homeAddressCountry;
	}

	public void setHomeAddressCountry(String homeAddressCountry) {
		this.homeAddressCountry = homeAddressCountry;
	}

	public String getHomeAddressZip() {
		return homeAddressZip;
	}

	public void setHomeAddressZip(String homeAddressZip) {
		this.homeAddressZip = homeAddressZip;
	}

	public String getHomeAddress1() {
		return homeAddress1;
	}

	public void setHomeAddress1(String homeAddress1) {
		this.homeAddress1 = homeAddress1;
	}

	public String getHomeAddress2() {
		return homeAddress2;
	}

	public void setHomeAddress2(String homeAddress2) {
		this.homeAddress2 = homeAddress2;
	}

	public String getHomeAddressState() {
		return homeAddressState;
	}

	public void setHomeAddressState(String homeAddressState) {
		this.homeAddressState = homeAddressState;
	}

	public String getMailingAddressOption() {
		return mailingAddressOption;
	}

	public void setMailingAddressOption(String mailingAddressOption) {
		this.mailingAddressOption = mailingAddressOption;
	}

	public String getAddressDiffReason() {
		return addressDiffReason;
	}

	public void setAddressDiffReason(String addressDiffReason) {
		this.addressDiffReason = addressDiffReason;
	}

	public String getAddressDiffOtherReason() {
		return addressDiffOtherReason;
	}

	public void setAddressDiffOtherReason(String addressDiffOtherReason) {
		this.addressDiffOtherReason = addressDiffOtherReason;
	}

	public String getMailAddressCountry() {
		return mailAddressCountry;
	}

	public void setMailAddressCountry(String mailAddressCountry) {
		this.mailAddressCountry = mailAddressCountry;
	}

	public String getMailAddressZip() {
		return mailAddressZip;
	}

	public void setMailAddressZip(String mailAddressZip) {
		this.mailAddressZip = mailAddressZip;
	}

	public String getMailAddress1() {
		return mailAddress1;
	}

	public void setMailAddress1(String mailAddress1) {
		this.mailAddress1 = mailAddress1;
	}

	public String getMailAddress2() {
		return mailAddress2;
	}

	public void setMailAddress2(String mailAddress2) {
		this.mailAddress2 = mailAddress2;
	}

	public String getMailAddressState() {
		return mailAddressState;
	}

	public void setMailAddressState(String mailAddressState) {
		this.mailAddressState = mailAddressState;
	}

	public String getSingaporeTaxResident() {
		return singaporeTaxResident;
	}

	public void setSingaporeTaxResident(String singaporeTaxResident) {
		this.singaporeTaxResident = singaporeTaxResident;
	}

	public String getUpdateAddressType() {
		return updateAddressType;
	}

	public void setUpdateAddressType(String updateAddressType) {
		this.updateAddressType = updateAddressType;
	}

	public String getCpfAcctNo() {
		return cpfAcctNo;
	}

	public void setCpfAcctNo(String cpfAcctNo) {
		this.cpfAcctNo = cpfAcctNo;
	}

	public String getCpfAgentBank() {
		return cpfAgentBank;
	}

	public void setCpfAgentBank(String cpfAgentBank) {
		this.cpfAgentBank = cpfAgentBank;
	}

	public String getCpfInvestmentAcctNo() {
		return cpfInvestmentAcctNo;
	}

	public void setCpfInvestmentAcctNo(String cpfInvestmentAcctNo) {
		this.cpfInvestmentAcctNo = cpfInvestmentAcctNo;
	}

	public String getSrsAcctNo() {
		return srsAcctNo;
	}

	public void setSrsAcctNo(String srsAcctNo) {
		this.srsAcctNo = srsAcctNo;
	}

	public String getSrsOperator() {
		return srsOperator;
	}

	public void setSrsOperator(String srsOperator) {
		this.srsOperator = srsOperator;
	}

	public String getBankAgreeFlag() {
		return bankAgreeFlag;
	}

	public void setBankAgreeFlag(String bankAgreeFlag) {
		this.bankAgreeFlag = bankAgreeFlag;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankAcctNo() {
		return bankAcctNo;
	}

	public void setBankAcctNo(String bankAcctNo) {
		this.bankAcctNo = bankAcctNo;
	}

	public String getBankAcctName() {
		return bankAcctName;
	}

	public void setBankAcctName(String bankAcctName) {
		this.bankAcctName = bankAcctName;
	}

	public String getBank1AcctNo() {
		return bank1AcctNo;
	}

	public void setBank1AcctNo(String bank1AcctNo) {
		this.bank1AcctNo = bank1AcctNo;
	}

	public String getBank1Name() {
		return bank1Name;
	}

	public void setBank1Name(String bank1Name) {
		this.bank1Name = bank1Name;
	}

	public String getBank1SwiftCode() {
		return bank1SwiftCode;
	}

	public void setBank1SwiftCode(String bank1SwiftCode) {
		this.bank1SwiftCode = bank1SwiftCode;
	}

	public String getBank2Name() {
		return bank2Name;
	}

	public void setBank2Name(String bank2Name) {
		this.bank2Name = bank2Name;
	}

	public String getBank2SwiftCode() {
		return bank2SwiftCode;
	}

	public void setBank2SwiftCode(String bank2SwiftCode) {
		this.bank2SwiftCode = bank2SwiftCode;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getSalaryRange() {
		return salaryRange;
	}

	public void setSalaryRange(String salaryRange) {
		this.salaryRange = salaryRange;
	}
	

}


package com.bfa.admin.dto;

public class CustomerDocumentDTO {

	
	private String bucketName;

	public String getBucketName() {
		return bucketName;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}
	
	
}

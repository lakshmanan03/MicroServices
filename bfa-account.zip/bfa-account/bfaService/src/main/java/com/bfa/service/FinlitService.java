/**
 * 
 */
package com.bfa.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.bfa.application.core.security.FinlitAuthenticationRequest;
import com.bfa.application.exception.CustomerNotFoundException;
import com.bfa.insurance.core.PrevilageMaster;
import com.bfa.util.ResponseMessageList;

/**
 * @author pradheep
 *
 */
@Service
public interface FinlitService {

	public String finlitDateFormat = "yyyy-MM-dd HH:mm:ss";

	public static String INVALID_ACCESS_CODE = "Invalid access code";
	
	public boolean isValidAccessCode(String accessCode);

	public void assignFinlitRolesForCustomer(List<PrevilageMaster> privileges,Integer customerId) throws CustomerNotFoundException;	
	
	public boolean validateInputs(FinlitAuthenticationRequest request) throws IllegalArgumentException;
	
	public void provideJWTTokenAndSessionDetails(String email,String mobileNumber,ResponseMessageList responseMessageList,HttpServletRequest servletRequest);
	
	public List<PrevilageMaster> getRobo3LiteRolesByCode(String accessCode);	

}

package com.bfa.serviceimpl;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;

import com.bfa.application.core.CustomerPromo;
import com.bfa.application.core.PromoCode;
import com.bfa.application.discovery.ComprehensiveEnquiryPreferencesHelper;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.ComprehensiveHouseHoldDTO;
import com.bfa.common.dto.ComprehensivePromoCodeDTO;
import com.bfa.common.dto.ComprehensiveResult;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.common.entity.Common;
import com.bfa.common.entity.CustomerData;
import com.bfa.common.entity.EmailContentWrapper;
import com.bfa.common.entity.EmailData;
import com.bfa.serviceimpl.CreateHubspotContactService;
import com.bfa.comprehensive.core.ComprehensiveHouseHold;
import com.bfa.comprehensive.core.DependentEducationPreferences;
import com.bfa.comprehensive.core.DependentEntity;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;
import com.bfa.comprehensive.dto.InsuranceAgentCallback;
import com.bfa.dao.ComprehensiveDao;
import com.bfa.insurance.core.ComprehensiveDependentMapping;
import com.bfa.insurance.core.ComprehensiveEndowmentPlanMapping;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.notification.messenger.MessengerDelegate;
import com.bfa.repository.CustomerPromoRepository;
import com.bfa.repository.PromoCodeRepository;
import com.bfa.request.entity.ComprehensiveEnquiryPostRequest;
import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;
import com.bfa.request.entity.ValidatePromoCodeRequest;
import com.bfa.service.ComprehensiveService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.MOEmailSQSClient;
import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.bfa.investment.account.dto.ComprehensivePricingDTO;
import com.bfa.investment.entity.ComprehensivePricing;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.util.InvestmentAccountStatus;

public class ComprehensiveServiceImpl extends DefaultServiceImpl
		implements ComprehensiveService, ApplicationContextAware {

	@Autowired
	private ComprehensiveDao comprehensiveDAO;

	@Autowired
	private MessengerDelegate messengerDelegate;

	@Autowired
	private PromoCodeRepository promoCodeRepository;

	@Autowired
	private Environment environment;
	
	@Autowired
	private CreateHubspotContactService createHubspotContactService;

	public PromoCodeRepository getPromoCodeRepository() {
		return promoCodeRepository;
	}

	public void setPromoCodeRepository(PromoCodeRepository promoCodeRepository) {
		this.promoCodeRepository = promoCodeRepository;
	}

	@Autowired
	private CustomerPromoRepository customerPromoRepository;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	ComprehensiveEnquiryPreferencesHelper comprehensiveEnquiryPreferencesHelper;

	@Autowired
	ClassPathResource classPathResourceObj;

	@Autowired
	Properties propObj;

	@Autowired
	MOEmailSQSClient moemailObj;

	@Override
	public void updateCustomerBasicDetails(UpdateCustomerBasicInfo custmerBasicInfo, Integer customerId)
			throws DatabaseAccessException {
		try {
			Customer customerObj = getCustomer(customerId);
			if (customerObj != null) {
				//customerObj.setGender(custmerBasicInfo.getGender());
				customerObj.setNationalityStatus(custmerBasicInfo.getNationalityStatus());
				//customerObj.setDateOfBirth(custmerBasicInfo.getDateOfBirth());

				//getLogger().info("The DOB updated by: " + customerObj.getDobUpdatedBy() + " for the customer: " + customerId);

				/*if (null == customerObj.getDobUpdatedBy()
						|| ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE.equals(customerObj.getDobUpdatedBy())) {

					customerObj.setDobUpdatedBy(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
				}*/

				comprehensiveDAO.saveOrUpdateObject(customerObj);
			}
			getLogger().info("Successfully updated the custemer gender, nationalityCode and dob ");

			// saving the comprehensive preferences as the user comprehensive
			// journey started.
			//ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = getComprehensiveEnquiry(customerId, null);
			ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = getComprehensiveEnquiry(customerId, custmerBasicInfo.getEnquiryId());

			if (null != comprehensiveEnquiryDTO) {
				comprehensiveEnquiryDTO.setHasComprehensive(true);
				//MO3-1844-Handling functionality for report_status in addpersonaldetails api
//				if(null == comprehensiveEnquiryDTO.getIsLocked()) {
//					getLogger().info("Feature is locked, new report status for customer:" + customerId);
//					comprehensiveEnquiryDTO.setReportStatus(ApplicationConstants.NEW_CONSTANT);
//				}else if(null != comprehensiveEnquiryDTO.getIsLocked() && !comprehensiveEnquiryDTO.getIsLocked()) {
//					getLogger().info("Feature is false, new report status for customer:" + customerId);
//					comprehensiveEnquiryDTO.setReportStatus(ApplicationConstants.NEW_CONSTANT);
//				}
//
//				
//				getLogger().info("Setting the value isLocked to null, as new customer journey is enabled");
//				comprehensiveEnquiryDTO.setIsLocked(null);
				persistComprehensiveEnquiry(comprehensiveEnquiryDTO, custmerBasicInfo);

			} else {

				getLogger().info("The returned enquiry Object is null..");
			}

		} catch (Exception err) {
			getLogger().error("Error while saving the customer gender, nationality and dob data in customer table",
					err);
			throw new DatabaseAccessException(err.getMessage());
		}
	}

	/**
	 * @param customerId
	 * 
	 *            This method get the promocode from properties file and save
	 *            into DB and sends to the customer mail.
	 * 
	 */

	@Override
	public ComprehensiveResult requestPromoCodeDetails(Integer customerId, String promoCodeCategory) {

		ComprehensiveResult comprehensiveResult = new ComprehensiveResult();

		try {

			if (null != customerId && customerId >= 0) {

				PromoCode promoCodeObj = promoCodeRepository.findByCategoryAndIsDefault(promoCodeCategory, "Y");
				Customer customerObj = getCustomer(customerId);
				
				getLogger().info("Promocode printing to be send to customer :: " + promoCodeObj.getCode());
				
				boolean isSentEmail = notifyUserForPromoCode(customerObj, promoCodeObj.getCode(), promoCodeCategory);
				if (null != promoCodeCategory && promoCodeCategory.equalsIgnoreCase("COMPRE")) {
					createHubspotContactService.updateCustomerInformationInHubspot(customerObj,
							JourneyTypeEnum.Comprehensive);
				}
				if (isSentEmail && null != customerObj) {

					String email = customerObj.getEmail();
					comprehensiveResult.setNotificationSentTo(email);
					getLogger().debug(
							"Promocode sent to the customer email successfully and customerID is :: " + customerId);

					if (null != email) {
						getLogger().info("Promocode saved in Database successfully for the customerId:: " + customerId);
					}
				} else {
					getLogger().info(
							"Unable to sent the promocode to the customer's email and customerId is :: " + customerId);
				}

			}

			else {
				getLogger().error("Unable to process the requestPromoCode for the customer:: " + customerId);
			}

		} catch (Exception e) {
			e.getStackTrace();
			getLogger().error("Exception occurred " + e.getStackTrace());
		}

		return comprehensiveResult;
	}

	/**
	 * This method validate the promocode entered by Customer with DB start date
	 * and end date.
	 * 
	 * @param promoCodeByCustomer
	 * @param customerId
	 */

	@Override
	public boolean validatePromoCodeByUser(ValidatePromoCodeRequest validatePromoCodeRequest, Integer customerId) {

		boolean isExpired = true;

		String promoCodeByUser = validatePromoCodeRequest.getComprehensivePromoCodeToken();
		Integer enquiryId = validatePromoCodeRequest.getEnquiryId();
		String journeyType = validatePromoCodeRequest.getPromoCodeCat();

		PromoCode promoCodeObj = promoCodeRepository.findByCodeAndCategory(promoCodeByUser, journeyType);
		if (null != promoCodeObj && null != promoCodeObj.getStartDate() && null != promoCodeObj.getEndDate()
				&& "A".equalsIgnoreCase(promoCodeObj.getStatus())) {

			LocalDate now = LocalDate.now();
			java.sql.Date startdate = (Date) promoCodeObj.getStartDate();
			java.sql.Date enddate = (Date) promoCodeObj.getEndDate();
			if ((now.isAfter(startdate.toLocalDate()) || now.isEqual(startdate.toLocalDate()))
					&& (now.isBefore(enddate.toLocalDate()) || now.isEqual(enddate.toLocalDate()))) {
				isExpired = false;
				getLogger().info("Setting Promo code to valid for the customer: " + customerId);

				saveOrUpdatePromoCode(promoCodeByUser, journeyType, customerId, promoCodeObj);

				/*ComprehensiveEnquiryDTO enquiry = getComprehensiveEnquiry(customerId, enquiryId);

				if (null != enquiry) {
					enquiry.setIsValidatedPromoCode(true);
					persistComprehensiveEnquiry(enquiry, null);
				}*/
			}

		} else {
			getLogger().error("Invalid Promo code for the customer:: " + customerId);
		}

		return isExpired;
	}
	
	private void saveOrUpdatePromoCode(String promoCodeByUser, String journeyType, Integer customerId,
			PromoCode promoCodeObj) {

		boolean promoCodeAndCatExists = StringUtils.isNotBlank(promoCodeByUser) && StringUtils.isNotBlank(journeyType);

		if (null != customerId && customerId >= 0 && (promoCodeAndCatExists)) {

			CustomerPromo customerPromoObj = null;
			CustomerPromo customerPromoDB = customerPromoRepository.findByCustomerIdAndPromoCodeCategory(customerId,
					journeyType);

			if (null != customerPromoDB) {
				customerPromoDB.setPromoCodeId(promoCodeObj.getId());
				customerPromoObj = customerPromoDB;
			} else {
				customerPromoObj = new CustomerPromo();
				customerPromoObj.setCustomerId(customerId);
				customerPromoObj.setPromoCodeId(promoCodeObj.getId());
			}

			customerPromoRepository.save(customerPromoObj);
		}

	}

	public ComprehensiveEnquiryDTO getComprehensiveEnquiry(Integer customerId, Integer enquiryId) {

		getLogger().info(
				"Getting the Comprehensive Enquiry By: customer id and enquiry id: " + customerId + " / " + enquiryId);

		ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();

		ComprehensiveEnquiryDTO comprehensiveEnquiryDTO = new ComprehensiveEnquiryDTO();

		comprehensiveEnquiryDTO.setCustomerId(customerId);

		comprehensiveEnquiryDTO.setEnquiryId(enquiryId);

		comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);

		ComprehensiveEnquiryPostResponse comprehensiveEnquiryPostResponse = comprehensiveEnquiryPreferencesHelper
				.getComprehensiveEnquiry(comprehensiveEnquiryPostRequest);

		if (null != comprehensiveEnquiryPostResponse) {

			comprehensiveEnquiryDTO = comprehensiveEnquiryPostResponse.getComprehensiveEnquiry();

		} else {

			getLogger().info("The received comprehensive response: " + comprehensiveEnquiryPostResponse);
		}

		return comprehensiveEnquiryDTO;
	}

	private void persistComprehensiveEnquiry(ComprehensiveEnquiryDTO comprehensiveEnquiryDTO,
			UpdateCustomerBasicInfo customerBasicInfo) {

		getLogger().info("Saving the Comprehensive Enquiry By: customer id and enquiry id: "
				+ comprehensiveEnquiryDTO.getCustomerId() + " / " + comprehensiveEnquiryDTO.getEnquiryId());
		ComprehensiveEnquiryPostRequest comprehensiveEnquiryPostRequest = new ComprehensiveEnquiryPostRequest();
		comprehensiveEnquiryPostRequest.setEnquiryObject(comprehensiveEnquiryDTO);
		comprehensiveEnquiryPostRequest.setCustomerBasicInfo(customerBasicInfo);

		comprehensiveEnquiryPreferencesHelper.saveComprehensiveEnquiry(comprehensiveEnquiryPostRequest);

	}

	private Customer getCustomer(Integer customerId) {
		String hql = "from Customer where id=" + customerId;
		List<Object> objectList = comprehensiveDAO.getObjectByHql(hql);
		if (objectList == null || objectList.isEmpty()) {
			getLogger().error("No customer details found for customer id " + customerId);
			return null;
		}
		return (Customer) objectList.get(0);

	}
	
	private CustomerIFastAccount getCustomerIfastAccountDetails(Integer customerId) {
		String hql = "from CustomerIFastAccount where customer=" + customerId;
		List<Object> dbObjectList = comprehensiveDAO.getObjectByHql(hql);
		if (dbObjectList == null || dbObjectList.isEmpty()) {
			getLogger().error("No customer details found in getCustomerIfastAccountDetails customer id " + customerId);
			return null;
		}
		return (CustomerIFastAccount) dbObjectList.get(0);

	}

	@Override
	public BaseProfileDTO getCustomerBasicDetails(Integer customerId,String journeyType) {
		getLogger().info("Trying to obtain the basic details of the customer " + customerId);
		BaseProfileDTO baseProfileDTO = (BaseProfileDTO) this.applicationContext.getBean("baseProfileDTO");
		if (customerId == -1) {
			getLogger().error("Invalid customer id " + customerId);
			return baseProfileDTO;
		}
		Customer customerObj = getCustomer(customerId);
		CustomerIFastAccount customerIfastAccountObj = getCustomerIfastAccountDetails(customerId);
		if (null != customerObj) {

			baseProfileDTO.setFirstName(customerObj.getGivenName());
			baseProfileDTO.setLastName(customerObj.getSurName());
			baseProfileDTO.setNationalityStatus(customerObj.getNationalityStatus());
			//baseProfileDTO.setGender(customerObj.getGender());
			
			// Added temporary fix to address date issue in DD/MM/YYYY format,to
			// be removed as permanent fix to be addressed
			getLogger()
					.info("customerId : " + customerId + "customerObj.getDateOfBirth()" + customerObj.getDateOfBirth());
			if (null != customerObj.getDateOfBirth() && !"".equals(customerObj.getDateOfBirth()) 
					&& null != customerObj.getGender() && !"".equals(customerObj.getGender())) {
				
				getLogger().info("customerId:" + customerId + "customerObj.getDateOfBirth()::" + customerObj.getDateOfBirth());
				
				//MO3-1815 handling the dob format issue, for current & old customers dob.
				Pattern datePattern = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");
				boolean isNewPattern = datePattern.matcher(customerObj.getDateOfBirth()).matches();
				getLogger().info("DOB Pattern new?"+isNewPattern);
				
				String dobPattern ="";
				if(isNewPattern) {
					dobPattern = "yyyy-MM-dd";
				}else {
					dobPattern = "MM/dd/yyyy";
				}
				java.util.Date dob = PublicUtility.parseDateString(customerObj.getDateOfBirth(), dobPattern, null);
				getLogger().info("customerId:" + customerId + "dob" + dob);
				
				String convertedDate = PublicUtility.dateToString(dob, "dd/MM/yyyy");
				getLogger().info("customerId===>" + customerId + "convertedDate" + convertedDate);
				
				baseProfileDTO.setDateOfBirthInvestment(convertedDate);
				baseProfileDTO.setGenderInvestment(customerObj.getGender());
				
			} else {
				baseProfileDTO.setDateOfBirthInvestment(customerObj.getDateOfBirth());
				baseProfileDTO.setGenderInvestment(customerObj.getGender());
			}
			
			
			Enquiry enquiryObj = null;
			//String journeyType = "Comprehensive";
			
			enquiryObj = comprehensiveDAO.getCustomerEnquiryDetails(customerObj.getId(), journeyType);
			
			if(enquiryObj != null){
				
				if (null != enquiryObj.getDateOfBirth() && !"".equals(enquiryObj.getDateOfBirth())
						&& null != enquiryObj.getGender() && !"".equals(enquiryObj.getGender())) {
					
					getLogger().info("EnquiryId:" + enquiryObj.getId() + "::enquiryObj.getDateOfBirth()::" + enquiryObj.getDateOfBirth());
					
					/*java.util.Date dob = PublicUtility.parseDateString(enquiryObj.getDateOfBirth(), "MM/dd/yyyy", null);
					getLogger().info("EnquiryId:" + enquiryObj.getId() + "dob" + dob);
					String convertedDate = PublicUtility.dateToString(dob, "MM/dd/yyyy");
					getLogger().info("EnquiryId===>" + enquiryObj.getId() + "convertedDate" + convertedDate);*/
					
					String dobFromDb = enquiryObj.getDateOfBirth();
					String convertedDob = PublicUtility.fetchStandardTimeStamp(dobFromDb);
					
					convertedDob = convertedDob.replaceAll("-", "/");
					
					baseProfileDTO.setDateOfBirth(convertedDob);
					baseProfileDTO.setGender(enquiryObj.getGender());
					
				} else {
					baseProfileDTO.setDateOfBirth(enquiryObj.getDateOfBirth());
					baseProfileDTO.setGender(enquiryObj.getGender());
				}
				
			}

			baseProfileDTO.setEmail(customerObj.getEmail());
			baseProfileDTO.setMobileNumber(customerObj.getMobileNumber());
			baseProfileDTO.setSmoker(customerObj.isSmoker());
			
			if (null != customerObj.getDobUpdatedBy()) {

				baseProfileDTO.setDobUpdateable(Boolean.TRUE);

				if (customerObj.getDobUpdatedBy().equals(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE)) {
					baseProfileDTO.setJourneyType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
				}else if (customerObj.getDobUpdatedBy().equals(ApplicationConstants.COMPREHENSIVE_LITE_JOURNEY_TYPE)) {
					baseProfileDTO.setJourneyType(ApplicationConstants.COMPREHENSIVE_LITE_JOURNEY_TYPE);
				} else if (null != customerObj.getDobUpdatedBy()
						&& customerObj.getDobUpdatedBy().equals(ApplicationConstants.INVESTMENT_JOURNEY_TYPE)) {
					if(null != customerIfastAccountObj.getInvestmentAccountStatus() &&
							customerIfastAccountObj.getInvestmentAccountStatus().equals(InvestmentAccountStatus.BLOCKED_NATIONALITY))
					{
						baseProfileDTO.setDobUpdateable(Boolean.TRUE);	
					}else
					{
						baseProfileDTO.setDobUpdateable(Boolean.FALSE);
					}
					
					baseProfileDTO.setJourneyType(ApplicationConstants.INVESTMENT_JOURNEY_TYPE);
				}
			} else {
				baseProfileDTO.setDobUpdateable(Boolean.TRUE);	
				baseProfileDTO.setJourneyType(null);

			}

		}
		return baseProfileDTO;

	}

	@Override
	public void saveDependents(List<ComprehensiveDependentMapping> dependents, Integer customerId,
			boolean hasDependents) throws DatabaseAccessException {

		List<DependentEntity> dependentList = new ArrayList<>();

		Iterator<ComprehensiveDependentMapping> dep = dependents.iterator();
		
		int enquiryId = dependents.get(0).getEnquiryId();

		List<DependentEntity> existingDependentList = comprehensiveDAO.getDependentDetails(customerId,enquiryId);

		ComprehensiveEnquiryDTO enquiry = getComprehensiveEnquiry(customerId, enquiryId);

		enquiry.setEnquiryId(enquiryId);
		enquiry.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);

		// hasDependents = false means all the dependents needs to be
		// soft-deleted by change the status to inactive.
		if (!hasDependents) {

			for (DependentEntity entity : existingDependentList) {

				entity.setStatus("Inactive");
				dependentList.add(entity);
			}

			comprehensiveDAO.deleteChildEndowmentPlans(enquiryId, customerId, ApplicationConstants.HAS_NO_ENDOWMENTS);

			enquiry.setHasDependents(false);
			enquiry.setHasEndowments(ApplicationConstants.HAS_NO_ENDOWMENTS);

		} else {

			enquiry.setHasDependents(true);
			
			List<DependentEntity> inactiveDependentList = new ArrayList<>(existingDependentList);

			while (dep.hasNext()) {
				ComprehensiveDependentMapping mapping = dep.next();
				if (mapping.getGender() == null) {
					getLogger().error("Gender cannot be null for a dependent");
					continue;
				}

				DependentEntity dependent = null;

				if (mapping.getId() == 0) {

					dependent = new DependentEntity();
				} else {

					dependent = getExistingEntity(existingDependentList, inactiveDependentList, mapping.getId());
				}

				if (dependent != null) {
					dependent.setStatus("active");
					dependent.setId(mapping.getId());
					dependent.setCustomerId(customerId);
					dependent.setEnquiryId(mapping.getEnquiryId());
					dependent.setName(mapping.getName());
					dependent.setGender(mapping.getGender());
					String enqDob = mapping.getDateOfBirth();
					enqDob = enqDob.replaceAll("/", "-");
					dependent.setDateOfBirth(PublicUtility.setStandardTimeStamp(enqDob));
					dependent.setNation(mapping.getNation());
					dependent.setRelationship(mapping.getRelationship());
					dependent.setIsInsuranceNeeded(Boolean.FALSE);
					dependentList.add(dependent);
				} else {
					getLogger().info("dependent is null" + dependent);
				}

			}
			// the existing dependents other than passed in the request will be
			// soft deleted.
			for (DependentEntity obj : inactiveDependentList) {

				obj.setStatus("Inactive");

			}
			dependentList.addAll(inactiveDependentList);
		}
		comprehensiveDAO.saveDependentList(dependentList);
		
		//MO3-1422 deleting existing dependent child education preferences
		comprehensiveDAO.deleteChildEndowmentPlans(enquiryId, customerId, ApplicationConstants.HAS_NO_ENDOWMENTS);
		enquiry.setHasEndowments(ApplicationConstants.HAS_NO_ENDOWMENTS);

		// saving comprehensive enquiry
		persistComprehensiveEnquiry(enquiry, null);
		
		
	}

	@Override
	public void saveComprehensiveHouseHold(ComprehensiveHouseHoldDTO houseHoldDTO,Integer enquiryId) throws DatabaseAccessException {
		
		ComprehensiveHouseHold houseHoldEntiry = comprehensiveDAO.getComprehensiveHouseHold(houseHoldDTO.getCustomerId(),enquiryId);
				
		if(null == houseHoldEntiry){
			
			houseHoldEntiry = new ComprehensiveHouseHold();
			houseHoldEntiry.setCustomerId(houseHoldDTO.getCustomerId());
			houseHoldEntiry.setEnquiryId(houseHoldDTO.getEnquiryId());
		}
		// saving comprehensive house hold details				
		houseHoldEntiry.setHouseHoldIncome(houseHoldDTO.getHouseHoldIncome());
		houseHoldEntiry.setNoOfHouseholdMembers(houseHoldDTO.getNoOfHouseholdMembers());
		houseHoldEntiry.setNoOfYears(houseHoldDTO.getNoOfYears());
		
		comprehensiveDAO.saveOrUpdateObject(houseHoldEntiry);

	}
	
	@Override
	public ComprehensiveHouseHoldDTO getComprehensiveHouseHold(Integer customerId,Integer enquiryId) throws DatabaseAccessException {

		try {

			ComprehensiveHouseHold houseHoldEntity = comprehensiveDAO.getComprehensiveHouseHold(customerId,enquiryId);			

			ComprehensiveHouseHoldDTO dto = null;

			if(null != houseHoldEntity) {

				dto = new ComprehensiveHouseHoldDTO();

				BeanUtils.copyProperties(houseHoldEntity, dto);				
			}

			return dto;

		} catch (DatabaseAccessException e) {
			getLogger().error("DatabaseAccessException occured in getComprehensiveHouseHold(): " + e);
			throw new DatabaseAccessException(
					"DatabaseAccessException catched while getComprehensiveHouseHold: " + e.getMessage());
		}

	}

	private DependentEntity getExistingEntity(List<DependentEntity> existingDependentList,
			List<DependentEntity> inactiveDependentList, int id) {

		DependentEntity entity = null;

		for (DependentEntity obj : existingDependentList) {

			entity = obj;

			if (obj.getId() == id) {

				entity.setStatus("active");

				inactiveDependentList.remove(obj);

				break;

			}

		}

		return entity;
	}

	@Override
	public List<DependentDTO> getDependentDetailList(Integer customerId,Integer enquiryId) throws DatabaseAccessException {

		try {

			List<DependentEntity> entityList = comprehensiveDAO.getDependentDetails(customerId,enquiryId);

			List<DependentDTO> dtoList = new ArrayList<>();

			DependentDTO dto = null;

			for (DependentEntity entity : entityList) {

				dto = new DependentDTO();

				BeanUtils.copyProperties(entity, dto);
				
				String enqDob = PublicUtility.fetchStandardTimeStamp(dto.getDateOfBirth());
				enqDob = enqDob.replaceAll("-", "/");
				dto.setDateOfBirth(enqDob);
				dtoList.add(dto);
			}

			return dtoList;

		} catch (DatabaseAccessException e) {
			getLogger().error("DatabaseAccessException occured in getDependentDetailList(): " + e);
			throw new DatabaseAccessException(
					"DatabaseAccessException catched while getDependentDetailList: " + e.getMessage());
		}

	}

	/**
	 * This method using to persist the dependent education preferences and
	 * endowment plans
	 * 
	 * @param childEndowmentPlan
	 * @param hasEndowments
	 * @param customerId
	 */
	@Override
	public void saveChildEndowmentPlanDetails(List<ComprehensiveEndowmentPlanMapping> childEndowmentPlan,
			String hasEndowments, Integer customerId) {

		try {

			if (!childEndowmentPlan.isEmpty()) {

				ComprehensiveEndowmentPlanMapping toGetEnquiryId = childEndowmentPlan.get(0);
				int enquiryId = toGetEnquiryId.getEnquiryId();

				ComprehensiveEnquiryDTO enquiry = getComprehensiveEnquiry(customerId, enquiryId);

				enquiry.setEnquiryId(enquiryId);
				enquiry.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
				enquiry.setHasEndowments(hasEndowments);

				List<DependentEducationPreferences> dependentEducationPreferencesList = new ArrayList<>();

				Iterator<ComprehensiveEndowmentPlanMapping> depEndowmentPlanning = childEndowmentPlan.iterator();

				while (depEndowmentPlanning.hasNext()) {

					ComprehensiveEndowmentPlanMapping endowmentPlanningMapping = depEndowmentPlanning.next();
					DependentEducationPreferences dependentEducationPreferences = new DependentEducationPreferences();

					dependentEducationPreferences.setId(endowmentPlanningMapping.getId());
					dependentEducationPreferences.setDependentId(endowmentPlanningMapping.getDependentId());
					dependentEducationPreferences.setCustomerId(customerId);
					dependentEducationPreferences.setEnquiryId(endowmentPlanningMapping.getEnquiryId());
					dependentEducationPreferences.setLocation(endowmentPlanningMapping.getLocation());
					dependentEducationPreferences.setEducationCourse(endowmentPlanningMapping.getEducationCourse());
					dependentEducationPreferences
							.setEndowmentMaturityAmount(endowmentPlanningMapping.getEndowmentMaturityAmount());
					dependentEducationPreferences
							.setEndowmentMaturityYears(endowmentPlanningMapping.getEndowmentMaturityYears());
					
					dependentEducationPreferences.setEducationSpendingShare(endowmentPlanningMapping.getEducationSpendingShare());

					dependentEducationPreferencesList.add(dependentEducationPreferences);
				}

				getLogger().debug("Saving the child endowment plans for the customer :" + customerId);
				comprehensiveDAO.saveDependentEndowmentPlan(dependentEducationPreferencesList, hasEndowments, enquiryId,
						customerId);

				// After savings we are updating Comprehensive Enquiry
				persistComprehensiveEnquiry(enquiry, null);
			} else {
				getLogger().info("Request object is empty and unable to process for endowment plans ");
			}

		} catch (DatabaseAccessException e) {
			getLogger().error("Error while saving Child EndowmentPlans", e);
			throw e;
		}

	}

	/**
	 * This method using for if customer doesn't opt any endowment preference
	 * delete if existing plans
	 * 
	 * @param childEndowmentPlan
	 * @param hasEndowments
	 */
	@Override
	public void deleteChildEndowmentPlans(Integer enquiryId, String hasEndowments, Integer customerId) {

		ComprehensiveEnquiryDTO enquiry = getComprehensiveEnquiry(customerId, enquiryId);
		enquiry.setType(ApplicationConstants.COMPREHENSIVE_JOURNEY_TYPE);
		enquiry.setHasEndowments(hasEndowments);

		comprehensiveDAO.deleteChildEndowmentPlans(enquiryId, customerId, hasEndowments);

		// After deleting records we are updating Comprehensive Enquiry
		persistComprehensiveEnquiry(enquiry, null);
	}

	@Override
	public void updateDependentsForInsuranceNeed(List<ComprehensiveEndowmentPlanMapping> childEndowmentPlanning,
			Integer customerId,Integer enquiryId,String hasEndowments) throws DatabaseAccessException {
		getLogger().info("Reached updateDependentsForInsuranceNeed");
		
		getLogger().info("updateDependentsForInsuranceNeed customerId || enquiryId"+customerId +"||"+enquiryId);
		try {
			List<DependentEntity> dependentsList = comprehensiveDAO.getDependentDetails(customerId,enquiryId);

			List<DependentEntity> dependentsUpdateList = new ArrayList<>();

			boolean isuranceNedded = false;

			if ("2".equals(hasEndowments)) {

				isuranceNedded = true;
			}

			// Default setting the dependents to insurance needed to be false
			for (DependentEntity entity : dependentsList) {
				getLogger().info("default value set entity" + entity.getId());
				entity.setIsInsuranceNeeded(false);
			}

			for (ComprehensiveEndowmentPlanMapping inputReq : childEndowmentPlanning) {

				int dependentId = inputReq.getDependentId();
				getLogger().info("dependentId" + dependentId);

				for (DependentEntity entity : dependentsList) {

					getLogger().info("entity.getId()" + entity.getId());
					if (dependentId == entity.getId()) {

						getLogger().info("isuranceNedded" + isuranceNedded);
						entity.setIsInsuranceNeeded(isuranceNedded);

					}

					dependentsUpdateList.add(entity);
				}

			}

			getLogger().info("The dependents update list size: " + dependentsUpdateList.size());

			if (!dependentsUpdateList.isEmpty()) {

				comprehensiveDAO.saveDependentList(dependentsUpdateList);
			}
		} catch (Exception e) {
			getLogger().error("Exception at updateDependentsForInsuranceNeed" + e);
		}

	}

	/**
	 * This method used for to get dependent education prefs and endowment plans
	 * 
	 * @param customerId
	 * @return enquiryId
	 */
	@Override
	public List<DependentEducationPreferencesDTO> getDependentEducationPreferences(Integer enquiryId,
			Integer customerId) {
		try {

			List<DependentEducationPreferences> dependentEducationPref = comprehensiveDAO
					.getDependentEducationPreferences(enquiryId, customerId);

			List<DependentEducationPreferencesDTO> dependentEducationPrefList = new ArrayList<>();

			if (dependentEducationPref != null && !dependentEducationPref.isEmpty()) {

				for (DependentEducationPreferences dependentEducationObj : dependentEducationPref) {

					DependentEducationPreferencesDTO dependentEducationPreferencesDTO = new DependentEducationPreferencesDTO();

					dependentEducationPreferencesDTO.setId(dependentEducationObj.getId());
					dependentEducationPreferencesDTO.setDependentId(dependentEducationObj.getDependentId());
					dependentEducationPreferencesDTO.setEnquiryId(dependentEducationObj.getEnquiryId());
					dependentEducationPreferencesDTO.setLocation(dependentEducationObj.getLocation());
					dependentEducationPreferencesDTO.setEducationCourse(dependentEducationObj.getEducationCourse());
					dependentEducationPreferencesDTO
							.setEndowmentMaturityAmount(dependentEducationObj.getEndowmentMaturityAmount());
					dependentEducationPreferencesDTO
							.setEndowmentMaturityYears(dependentEducationObj.getEndowmentMaturityYears());
					dependentEducationPreferencesDTO.setEducationSpendingShare(dependentEducationObj.getEducationSpendingShare());

					dependentEducationPrefList.add(dependentEducationPreferencesDTO);
				}

				return dependentEducationPrefList;
			} else {
				getLogger().info("unable get getDependentEducationPreferences() for the customer::" + customerId);

				return Collections.emptyList();
			}

		} catch (DatabaseAccessException e) {
			getLogger().error("Error while getting getDependentEducationPreferences()");
			throw e;
		}
	}

	@Override
	public InsuranceAgentCallback generateCustomerToken(Integer customerId) throws DatabaseAccessException {

		// Token Generation
		try {

			Customer customer = getCustomerById(customerId);

			InsuranceAgentCallback insCallBackObj = new InsuranceAgentCallback();

			String customerName = customer.getGivenName();
			getLogger().info("Sending email .. " + new java.util.Date() + " to " + customerName);
			PublicUtility utility = PublicUtility.getInstance(appKey);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			java.util.Date obj = new java.util.Date();
			String encryptedData = sdf.format(obj) + ApplicationConstants.DELIMITER + customer.getEmail()
					+ ApplicationConstants.DELIMITER + customer.getId();
			encryptedData = utility.EncryptText(encryptedData);
			String token = Base64.getEncoder().encodeToString(encryptedData.getBytes());
			getLogger().info("Printing the base 64 encoded " + token);
			insCallBackObj.setCustId(customerId);
			insCallBackObj.setCustToken(token);
			insCallBackObj.setCustomerEmail(customer.getEmail());
			insCallBackObj.setCustomerGivenName(customer.getGivenName());
			insCallBackObj.setCustomerLastName(customer.getSurName());

			return insCallBackObj;

		} catch (Exception e) {
			getLogger().error("Exception occurred at sendCallInsuranceAgentMail", e);
			throw e;

		}

	}

	protected Customer getCustomerById(int id) {
		List<Object> customerList = accountsDao.getObjectsById(Customer.class, "id", id);
		if (customerList == null || customerList.isEmpty()) {
			getLogger().error("No such user found for customer id :" + id);
			return null;
		}
		return (Customer) customerList.get(0);
	}

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.applicationContext = context;
	}

	public ComprehensiveEnquiryPreferencesHelper getComprehensiveEnquiryPreferencesHelper() {
		return comprehensiveEnquiryPreferencesHelper;
	}

	public void setComprehensiveEnquiryPreferencesHelper(
			ComprehensiveEnquiryPreferencesHelper comprehensiveEnquiryPreferencesHelper) {
		this.comprehensiveEnquiryPreferencesHelper = comprehensiveEnquiryPreferencesHelper;
	}

	private Boolean notifyUserForPromoCode(Customer customerObj, String promoCode, String category) {

		if (customerObj == null) {
			getLogger().info("Requested customer data unavailable, unable to send mail");
			return false;
		}

		Boolean response = false; String domainRoot="";String subDomain="";String imagePath="";

		try {
			Map<String,Object> additionalInfo = null;
			
			getLogger().info("print notifyUserForPromoCode :: " + promoCode);
			
			InputStream input = classPathResourceObj.getInputStream();
			propObj.load(input);
			
			if (additionalInfo == null) {
				additionalInfo = new HashMap<>();
			}
			for(String key : propObj.stringPropertyNames()) {
				if (key.startsWith("data.additionalInfo.")) {
					additionalInfo.put(key.replace("data.additionalInfo.", ""), propObj.getProperty(key));
				}
			}
			if(additionalInfo.containsKey("subdomain")) {
				imagePath = (String) additionalInfo.get("subdomain");
			}
			
			if(additionalInfo.containsKey("domainRoot")) {
				 domainRoot = (String) additionalInfo.get("domainRoot")+imagePath;
			}

			String baseUrl = environment.getProperty("discovery.base.url");
			
			getLogger().info("getting the baseUrl notifyUserForPromoCode :: " + baseUrl);
			
			String appendBaseUrl = baseUrl.concat("/#/comprehensive");

			EmailContentWrapper emailObj = new EmailContentWrapper();
			EmailData emailDataObj = new EmailData();
			emailDataObj.setAdditionalInfo(additionalInfo);
			CustomerData custDataObj = new CustomerData();
			ComprehensivePromoCodeDTO compPromoCodeDto = new ComprehensivePromoCodeDTO();
			custDataObj.setFirstName(customerObj.getGivenName());
			custDataObj.setLastName(customerObj.getSurName());

			compPromoCodeDto.setComprehensivePromoCode(promoCode);
			emailDataObj.setCustomer(custDataObj);
			
			getLogger().info("getting the customer Email notifyUserForPromoCode :: " + customerObj.getEmail());

			List<String> toAddress = new ArrayList<>();
			toAddress.add(customerObj.getEmail());

			Common commonObj = new Common();
			
			List<String> bccEmailAddress = new ArrayList<>();
			bccEmailAddress.add("enquiries@moneyowl.com.sg");
			
			String advisorNumber = propObj.getProperty("common.mo.advisorynumber");
			String generalEmail = propObj.getProperty("common.mo.generalemail");
			String generalEnquiry = propObj.getProperty("common.mo.generalenquiry");
			
			getLogger().info("getting the property values :: " + advisorNumber + "::" + generalEmail + "::" + generalEnquiry);

			commonObj.setAdvisorynumber(advisorNumber);
			commonObj.setContactEmail(generalEmail);
			commonObj.setGeneralenquiry(generalEnquiry);
			commonObj.setBaseUrl(appendBaseUrl);
			commonObj.setDomainUrl(domainRoot);

			emailDataObj.setCommon(commonObj);
			emailDataObj.setComprehensivePromoCode(compPromoCodeDto);
			emailObj.setData(emailDataObj);

			ObjectMapper mapper = new ObjectMapper();

			emailObj.setFromEmailAddress("notifications@moneyowl.sg");
			emailObj.setToEmailAddress(toAddress);
			emailObj.setBccEmailAddress(bccEmailAddress);
			String subjectOfEmail = propObj.getProperty("comprehensive.promocode.subject");
			
			getLogger().info("printing the subjectOfEmail:" + subjectOfEmail);
			
			emailObj.setSubjectOfEmail(subjectOfEmail);
			emailObj.setAcknowledgeURL("https://test");
			emailObj.setScheduledEmailTime(new java.util.Date());
			emailObj.setNumberOfRetry(1);
			emailObj.setEmailRequestId("123");
			
			if ("COMPRE".equalsIgnoreCase(category)) {
				emailObj.setEmailTemplateName("PromoCode.ftl");
			} else if ("WILLS".equalsIgnoreCase(category)) {
				emailObj.setEmailTemplateName("");
			}
			
			mapper.setSerializationInclusion(Include.NON_NULL);

			String mailJsonObj = mapper.writeValueAsString(emailObj);
			
			getLogger().info("MAIL OBJ PREPARED" + mailJsonObj);
			
			response = moemailObj.sendMessage(mailJsonObj);
			
			getLogger().info("Mail Sent");

		} catch (JsonProcessingException e) {
			getLogger().info("JsonProcessingException while mail obj build : " + moemailObj + " for the customer: "
					+ customerObj.getId() + "==>" + e);

		} catch (IOException e1) {
			getLogger().error("Exception while loading properties" + e1);

		} catch (Exception ex) {
			getLogger().info("Exception while loading properties" + ex);
		}

		return response;
	}
	
	private String formatDOB(String dateOfBirth) {
		if (dateOfBirth.equals("")) {
			return dateOfBirth;
		}
		java.util.Date defaultDateFormat = null;
		java.util.Date alternateFormat = null;
		String convertedDOB = null;
		defaultDateFormat = PublicUtility.parseDateString(dateOfBirth, "dd/MM/yyyy", null);
		if (defaultDateFormat != null) {

			convertedDOB = PublicUtility.dateToString(defaultDateFormat, "dd/MM/yyyy");
		}
		if (defaultDateFormat == null) {
			alternateFormat = PublicUtility.parseDateString(dateOfBirth, "yyyy-M-d", null);
			convertedDOB = PublicUtility.dateToString(alternateFormat, "dd/MM/yyyy");
		}
		if (defaultDateFormat == null && alternateFormat == null) {
			convertedDOB = null;
		}
		return convertedDOB;
	}
	
	@Override
	public ComprehensivePricingDTO getComprehensiveProductPricing(String productType, String promotion) {
		ComprehensivePricingDTO productPricingDTO = new ComprehensivePricingDTO();
		try {
			List<ComprehensivePricing> productPricing = comprehensiveDAO.getComprehensiveProductPricing(productType, promotion);
			
			if (productPricing != null && !productPricing.isEmpty()) {
					ComprehensivePricing productPricingObj = productPricing.get(0); 
					productPricingDTO = new ComprehensivePricingDTO();
					productPricingDTO.setPrice(productPricingObj.getPrice());
					productPricingDTO.setIncludingGst(productPricingObj.getIncludingGst());
					productPricingDTO.setGstPercentage(productPricingObj.getGstPercentage());
					HashMap<String,Double> priceResult = calculateGstPrice(productPricingObj.getPrice(),productPricingObj.getGstPercentage());
					getLogger().info("getComprehensiveProductPricing priceResult map || :" + priceResult);
					if(priceResult.containsKey("gstPriceAmount")){
					productPricingDTO.setGstAmount(priceResult.get("gstPriceAmount"));
					}
					if(priceResult.containsKey("gstSumPriceAmount")){
						productPricingDTO.setTotalAmount(priceResult.get("gstSumPriceAmount"));
					}
			} else {
				getLogger().info("unable get getProductPricing() for the productType::" + productType);
			}

		} catch (DatabaseAccessException e) {
			getLogger().error("Error while getting getProductPricing", e);
			throw e;
		}
		return productPricingDTO;
	}

	private HashMap<String,Double> calculateGstPrice(Integer price, Double gstPercentage) {
		HashMap<String,Double> gstMap = new HashMap<String,Double>();
		Double gstPriceAmount=0.0d;Double gstSumPriceAmount=0.0d;
		getLogger().info("calculateGstPrice price || gstPercentage:" + price + "||" + gstPercentage);
		try{
			gstMap = new HashMap<String,Double>();
			gstPriceAmount = price * (gstPercentage/100);
			getLogger().info("calculategstprice before roundoff:" + gstPriceAmount);
			gstPriceAmount = PublicUtility.round(gstPriceAmount, 0.1);
			gstSumPriceAmount=price+gstPriceAmount;
			gstMap.put("gstPriceAmount", gstPriceAmount);
			gstMap.put("gstSumPriceAmount", gstSumPriceAmount);
		}catch (Exception e) {
			getLogger().error("Error while calculating GSTPrice", e);
			throw e;
		}
		getLogger().info("calculategstprice after roundoff:" + gstPriceAmount);
		return gstMap;
	}

}

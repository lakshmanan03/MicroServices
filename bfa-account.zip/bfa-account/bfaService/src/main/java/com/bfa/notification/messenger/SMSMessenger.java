package com.bfa.notification.messenger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.notification.MessageObject;
import com.bfa.notification.messenger.templates.SMSMessageObject;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.PublicUtility;

public class SMSMessenger implements Messenger {

	private String appKey = "IMXYlDmP4f4=";

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	ThreadPoolTaskExecutor threadPoolExecutor;

	private Properties prop = new Properties();

	PublicUtility utility = PublicUtility.getInstance(appKey);

	@Autowired
	private BFAHttpClient httpClient;
	@Autowired
	private SMSGatewayActivator smsGatewayActivator;

	private String basePath = "/opt/tomcat/conf/account/";

	private String propertiesFile = "sms.properties";

	public SMSMessenger() {
		
	}

	public boolean isSmsFeatureEnabled() {
		String propName = "sms_feature_enabled";
		String isFeatureEnabled = prop.getProperty(propName);
		getLogger().info("Printing the sms feature enabled " + isFeatureEnabled);
		if("true".equalsIgnoreCase(isFeatureEnabled)){
			return true;
		}
		return false;
	}

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	public void loadProperties() {
		File f = new File(basePath + propertiesFile);
		getLogger().info("Loading properties file " + f.getAbsolutePath());
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(f);
		} catch (FileNotFoundException e1) {
			getLogger().error("FileNotFoundException while loading properties: " + e1);
		}
		try {
			prop.load(fis);
		} catch (IOException e) {
			getLogger().error("Error while loading SMS properties ", e);
			getLogger().error("IOException while loading SMS properties " + e.fillInStackTrace());
		}
	}

	public String getActiveSMSGateway() {
		return smsGatewayActivator.getGatewayProvider();
	}

	@Override
	public Object communicate(MessageObject messageObject) {
		Thread d = new Thread() {
			public void run() {
				loadProperties();
				getLogger().info("Inside SMS communicate method ");
				if (messageObject instanceof SMSMessageObject) {
					if(!isSmsFeatureEnabled()){
						getLogger().info("---- SMS Feature is disabled ------");
						return;
					}
					SMSMessageObject smsMessageObj = (SMSMessageObject) messageObject;
					String messageToBeSent = messageObject.getBodyOfMessage();
					messageToBeSent = messageToBeSent.replace(" ", "+");
					SMSMessageObject smsMessageobj = (SMSMessageObject) messageObject;
					String messageBody = smsMessageobj.getBodyOfMessage();
					String contactNumber = smsMessageobj.getContactNumber();
					String countryCode = smsMessageobj.getDestinationCountryCode();
					countryCode = countryCode.replace("+", "");
					contactNumber = countryCode + contactNumber;
					// -------- Primary SMS Gateway provider ----------//

					if ("primary".equalsIgnoreCase(getActiveSMSGateway())) {
						getLogger().info("Using the primary gateway to send SMS");
						String finalUrl = constructURLPrimary(messageBody, contactNumber, smsMessageObj.isResend());
						boolean flag = sendSMS(finalUrl);
						if (flag) {
							getLogger().info("Sending SMS passed in Account 1");
						} else {
							getLogger().error(
									"Sending SMS failed in Account 1 .. Trying to dial with Account 2 - SMS Gateway 1");
							String secUrl = constructURLPrimary(messageBody, contactNumber, !smsMessageObj.isResend());
							boolean smsStatus = sendSMS(secUrl);
							if (smsStatus) {
								getLogger().info("Sending SMS by first gateway : Account 2 Passed ");
							}
						}
					} else {
						// ------- Secondary SMS gateway ---------//
						getLogger().info("Sending SMS by secondary gateway to send SMS");
						String finalUrl = constructURLSecondary(messageBody, contactNumber, smsMessageObj.isResend());
						boolean flag = sendSMS(finalUrl);
						if (flag) {
							getLogger().info("Sending SMS by secondary SMS gateway passed by account 1");
						} else {
							getLogger().info("Sending SMS by secondary SMS gateway failed : using account 2");
							String secUrl = constructURLSecondary(messageBody, contactNumber,
									!smsMessageObj.isResend());
							boolean smsStatus = sendSMS(secUrl);
							if (smsStatus) {
								getLogger().info("Sending SMS by secondary gateway : Account 2 passed");
							} else {
								getLogger().error("Sending SMS by gateway by secondary failed in account 2 Failed");
							}
						}
					}
				}
			}
		};
		threadPoolExecutor.execute(d);
		return true;
	}

	/**
	 * 
	 * @param message
	 *            Message to be sent to the user
	 * @param contactNumberWithCountryCode
	 *            Country code has to be appended without + sign in contact
	 *            number. (65110033445)
	 * @return
	 */
	private String constructURLPrimary(String message, String contactNumberWithCountryCode, boolean isResend) {
		if (contactNumberWithCountryCode == null) {
			getLogger().error("Contact number is null, cannot send a SMS");
			return null;
		}
		StringBuffer urlObj = new StringBuffer();
		loadProperties();
		String baseUrl = prop.getProperty("sms_gateway_primary_base_url");
		String user = "";
		String password = "";
		if (isResend) {
			user = prop.getProperty("sms_primary_second_user");
			password = prop.getProperty("sms_primary_second_password");
		} else {
			user = prop.getProperty("sms_primary_first_user");
			password = prop.getProperty("sms_primary_first_password");
		}

		String charEncoding = prop.getProperty("sms_primary_char_encoding");
		String servid = prop.getProperty("sms_primary_servid");
		String details = prop.getProperty("sms_primary_details");
		// -------------------------------------------------------------
		urlObj.append(baseUrl);
		urlObj.append("?");
		urlObj.append("user=");
		urlObj.append(user);

		urlObj.append("&");
		urlObj.append("pass=");
		String decryptPassword = utility.DecryptText(password);
		urlObj.append(decryptPassword);

		urlObj.append("&");
		urlObj.append("type=");
		urlObj.append(charEncoding);

		urlObj.append("&");
		urlObj.append("to=");
		urlObj.append(contactNumberWithCountryCode);

		urlObj.append("&");
		urlObj.append("from=MoneyOwl");

		urlObj.append("&");
		urlObj.append("text=");
		message = message.replace(" ", "+");
		urlObj.append(message);

		urlObj.append("&");
		urlObj.append("servid=");
		urlObj.append(servid);

		urlObj.append("&");
		urlObj.append("title=Verify+OTP");

		urlObj.append("&");
		urlObj.append("detail=");
		urlObj.append(details);

		// #http://www.etracker.cc/bulksms/mesapi.aspx?user=TEST031&pass=53'rsSRT&type=0&to=6586065841&from=MoneyOwl&text=889955+is+your+MoneyOwl+OTP+Code.+It+will+expire+in+2+minutes.&servid=MES01&title=Verify
		// OTP&detail=1
		String finalUrl = urlObj.toString();
		getLogger().info("Printing the final URL " + finalUrl);
		return finalUrl;
	}

	/**
	 * Secondary SMS gateway providers.
	 * 
	 * @param message
	 *            Message to be sent to the user
	 * @param contactNumberWithCountryCode
	 *            Country code has to be appended without + sign in contact
	 *            number. (65110033445)
	 * @return
	 */
	private String constructURLSecondary(String message, String contactNumberWithCountryCode, boolean isResend) {
		if (contactNumberWithCountryCode == null) {
			getLogger().error("Contact number is null, cannot send a SMS");
			return null;
		}
		StringBuffer urlObj = new StringBuffer();
		loadProperties();
		String baseUrl = prop.getProperty("sms_gateway_secondary_base_url");
		String user = "";
		String password = "";
		if (isResend) {
			user = prop.getProperty("sms_secondary_first_user");
			password = prop.getProperty("sms_secondary_first_password");
		} else {
			user = prop.getProperty("sms_secondary_second_user");
			password = prop.getProperty("sms_secondary_second_password");
		}
		// -------------------------------------------------------------
		urlObj.append(baseUrl);
		urlObj.append("?");
		urlObj.append("username=");
		urlObj.append(user);

		urlObj.append("&");
		urlObj.append("password=");
		String decryptPassword = utility.DecryptText(password);
		urlObj.append(decryptPassword);

		urlObj.append("&");
		urlObj.append("to=");
		urlObj.append(contactNumberWithCountryCode);

		urlObj.append("&");
		urlObj.append("from=MoneyOwl");

		urlObj.append("&");
		urlObj.append("message=");
		message = message.replace(" ", "+");
		urlObj.append(message);

		String finalUrl = urlObj.toString();
		getLogger().info("Printing the final URL " + finalUrl);
		return finalUrl;
	}

	private boolean sendSMS(String URL) {
		try {
			getLogger().info("Sending SMS .. " + URL);
			HashMap header = new HashMap();
			BFAHttpResponse response = httpClient.doGetCall(URL, header, null);
			getLogger().info("Printing the response after SMS " + response.getResponseBody());
			if (response.getResponseCode() == 200) {
				return true;
			}
			return false;
		} catch (Exception err) {
			getLogger().error("URL : " + URL);
			getLogger().error("Unable to send SMS ", err);
			return false;
		}
	}

	private void dialSecondary(String URL) {
		getLogger().info("Dialing secondary SMS gateway ..");
	}
}

/**
 * 
 */
package com.bfa.notification.messenger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.notification.EmailMessageObject;

/**
 * @author pradheep.p
 *
 */
public class EmailHelper implements Runnable {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	private String[] ccList = null;
	
	private String fromAddress = null;
	
	private String htmlTemplate = "";
	
	private String subject;
	
	String[] toList = null;

	@Autowired
	@Qualifier("notificationDelegator")
	private MessengerDelegate messengerDelegate;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	private String getWelcomeEmailBody() {
		Resource res = new ClassPathResource("welcome_email.template");
		InputStream ins = null;
		try {
			ins = res.getInputStream();
		} catch (IOException e) {			
			getLogger().error("Exception while get welcome email body: " + e);
		}
		StringBuffer buffer = new StringBuffer();
		InputStreamReader reader = new InputStreamReader(ins);
		BufferedReader bReader = new BufferedReader(reader);
		String str = null;
		try {
			while ((str = bReader.readLine()) != null) {
				buffer.append(str);
			}
		} catch (IOException e) {
			getLogger().error("IOException while loading properties: " + e);
		} finally {
			try {
				if (ins != null) {
					ins.close();
				}
			} catch (IOException e) {
				getLogger().error("Exception while loading properties : " + e);
			}
		}
		return buffer.toString();
	}

	@Override
	public void run() {		
		EmailMessageObject emailMessageObj = new EmailMessageObject();
		emailMessageObj.setBodyOfMessage(htmlTemplate);
		emailMessageObj.setFooterInformation("");
		emailMessageObj.setToList(toList);
		emailMessageObj.setCcList(ccList);
		emailMessageObj.setFromAddress(fromAddress);
		emailMessageObj.setSubjectOfMessage(subject);
		messengerDelegate.communicateMessage(emailMessageObj, Messenger.EMAIL_MESSAGE);
	}

	private void loadTemplate(String templateName) {

		Resource res = new ClassPathResource(templateName);
		InputStream ins = null;
		try {
			ins = res.getInputStream();
		} catch (IOException e) {			
			getLogger().error("IOException while loading properties: " + e);
		}
		StringBuffer buffer = new StringBuffer();
		InputStreamReader reader = new InputStreamReader(ins);
		BufferedReader bReader = new BufferedReader(reader);
		String str = null;
		try {
			while ((str = bReader.readLine()) != null) {
				buffer.append(str);
			}
		} catch (IOException e) {
			getLogger().error("IOException while loading property : " + e);
		} finally {
			try {
				if (ins != null) {
					ins.close();
				}
			} catch (IOException e) {
				getLogger().error("Exception while property loading... " + e);
			}
		}
		htmlTemplate = buffer.toString();
	}
	public void setParam(String key,String value) {
		String keyToReplace = "\\{\\$"+key+"\\}";
		htmlTemplate = htmlTemplate.replaceAll(keyToReplace, Matcher.quoteReplacement(value));
	}	
	
	public void setSubject(String subject) {
		this.subject = subject;
	}	
	
	public void setToEmail(String... email) {
		this.toList = email;
	}
	
	
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}
	
	public void setEmailDetails(String fromEmail, String toEmail, String subject, String templateName) {
		this.loadTemplate(templateName);
		this.setFromAddress(fromEmail);
		this.setToEmail(toEmail);
		this.setSubject(subject);
	}

	public String[] getCcList() {
		return ccList;
	}

	public void setCcList(String[] ccList) {
		this.ccList = ccList;
	}


}

/**
 * 
 */
package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This is a mapping class for MailChimp Bundle Campaign.
 * 
 * Please do not change any fields in this class. 
 * 
 * This is as is mapping in MailChimp
 * 
 * Reference : https://ntuclink.atlassian.net/browse/BFA-1565
 * 
 * @author pradheep
 *
 */
public class MailChimpBundleRequestParameters {
	
	@JsonProperty("FNAME")
	private String FNAME;
	
	@JsonProperty("LNAME")
	private String LNAME;
	
	@JsonProperty("PHONE")
	private String PHONE;
	
	@JsonProperty("DOB")
	private String DOB;
	
	@JsonProperty("GENDER")
	private String GENDER;

	public String getFNAME() {
		return FNAME;
	}

	public void setFNAME(String fNAME) {
		FNAME = fNAME;
	}

	public String getLNAME() {
		return LNAME;
	}

	public void setLNAME(String lNAME) {
		LNAME = lNAME;
	}

	public String getPHONE() {
		return PHONE;
	}

	public void setPHONE(String pHONE) {
		PHONE = pHONE;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getGENDER() {
		return GENDER;
	}

	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}
}

package com.bfa.controllers;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.service.CustomerDocumentDetailService;

@RunWith(SpringJUnit4ClassRunner.class)
public class FileUploadControllerTest {
	
	@InjectMocks
	private  FileUploadController mFileUploadController;
	
	@Mock
	private MultipartFile mMultipartFile;
	
	@Mock
    private CustomerDocumentDetailService mCustomerService;
	
	@Mock
	private CustomerDocumentDetails mCustomerDocumentDetails;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	int cusId=1;
	
	String status="status";
	

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	@Test
	public void testUploadFile() {
			List<String> response = mFileUploadController.uploadFile(cusId, status, mMultipartFile, mMultipartFile);
			assertNotNull(response);
	}

	@Test
	public void testUploadDocuments() {
			List<String> response = mFileUploadController.uploadDocuments(cusId, status, mMultipartFile, mMultipartFile,"details");
			assertNotNull(response);
	}

	@Test
	public void testDeleteFile() {
			when(mCustomerService.deleteCustomerDocument(cusId)).thenReturn("success");
			String response = mFileUploadController.deleteFile(cusId);
			assertNotNull(response);
	}

}

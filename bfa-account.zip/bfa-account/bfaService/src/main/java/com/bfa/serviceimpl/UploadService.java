/**
 * 
 */
package com.bfa.serviceimpl;

import java.io.File;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.exception.BfaException;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.service.CustomerDocumentDetailService;
import com.bfa.util.AmazonS3ClientService;
import com.bfa.util.ServiceResponse;

/**
 * @author pradheep.p
 *
 */
public class UploadService {
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	private AmazonS3ClientService amazonS3ClientService;

	@Autowired
	private CustomerDocumentDetailService customerDocService;
	
	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	public ServiceResponse<Map<String, String>> saveDocument(Integer customerId, MultipartFile uploadedFile,
			String type) {
		getLogger().info("------- Saving document ---------- ");
		ServiceResponse<Map<String, String>> response = new ServiceResponse<>();
		response.addResponseInfo("step", "SAVING_DOCUMENT");
		response.setSuccess(true);
		// Upload document to AWS S3 Bucket
		try {
		boolean status = true;
		if(uploadedFile.equals(null)) {
			getLogger().debug("uploadedFile null value");
			throw new BfaException("uploadedFile null object");
		}
		String[] fileFrags = uploadedFile.getOriginalFilename().split("\\.");
		getLogger().info("Original filename:"+uploadedFile.getOriginalFilename());
		getLogger().info("fileFrags length"+fileFrags.length);
		if(fileFrags.length < 2) {
			throw new BfaException("fileFrags length less than two, no extension found");
		}
		String extension = fileFrags[fileFrags.length - 1];
		getLogger().info("extension"+extension);
		String fileName = customerId + "_";
		getLogger().info("fileName"+fileName);
		fileName += type + "." + extension;
		File file = null;	

			String fileUrl = this.amazonS3ClientService.uploadFileToS3Bucket(fileName, uploadedFile);
			getLogger().info("fileUrl"+fileUrl);
			CustomerDocumentDetails docDetails = new CustomerDocumentDetails();
			customerDocService.saveOrUpdateCustomerDocument(customerId, fileUrl, type);
			response.addResponseInfo("filePath", fileUrl);
			response.addResponseInfo("type", type);
		} catch (Exception e) {
			response.addExceptionInfo(e);		
			getLogger().error("exception while saving the document : " + e);
			getLogger().debug("exception at saveDocument"+e.getMessage());
		}

		return response;
	}
}

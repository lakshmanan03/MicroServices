package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "portfolio_funds")
public class PortfolioFund {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@OneToOne
	@JoinColumn(name = "portfolio_id")
	private Portfolio portfolio;
	
	@OneToOne
	@JoinColumn(name = "fund_id")
	private Fund fund;
	
	@Column(name = "percentage")
	private int percentage;
	
	
	  @Column(name = "holdings") 
	  private Integer holdings;
	 

	public String getPortfolioId() {
		if (portfolio != null) {
			return portfolio.getPortfolioId();
		}
		else {
			return null;
		}
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public Fund getFund() {
		return fund;
	}

	public void setFund(Fund fund) {
		this.fund = fund;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	
	  public Integer getHoldings() { 
		  return holdings; 
		  }
	  
	  public void setHoldings(Integer holdings) {
		  this.holdings = holdings; 
		  }
	 

}

package com.bfa.insurance.core;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "profile_protection_type")
public class ProfileProtectionType {

	@Id
	@Column(name = "protection_type_id")
	private int protectionTypeId;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "id")
	private List<ProtectionType> protectionType;
	
	@Column(name="profile_id")
	private int profileId;
	
	public List<ProtectionType> getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(List<ProtectionType> protectionType) {
		this.protectionType = protectionType;
	}

	public int getProtectionTypeId() {
		return protectionTypeId;
	}

	public void setProtectionTypeId(int protectionTypeId) {
		this.protectionTypeId = protectionTypeId;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

}

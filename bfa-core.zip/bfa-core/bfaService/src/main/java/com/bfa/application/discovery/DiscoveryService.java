/**
 * 
 */
package com.bfa.application.discovery;

import java.util.List;

import org.springframework.security.core.GrantedAuthority;

/**
 * @author pradheep.p
 *
 */
public interface DiscoveryService {
	
	public String getServiceInstanceByName(int port,String contextPath,String serviceName);
	
	public String preAuthorize();
	
	public String preAuthorizeV2(Integer customerId);
	
	String preAuthorizeScheduler();
	
	public String preAuthorize(List<GrantedAuthority> grantedAuthorities);
}


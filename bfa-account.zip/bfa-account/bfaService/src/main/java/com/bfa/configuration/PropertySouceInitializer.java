/**
 * 
 */
package com.bfa.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.MapPropertySource;
import org.springframework.stereotype.Component;

/**
 * @author pradheep.p
 *
 */
@Component
public class PropertySouceInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

	
	private String basePath = "/opt/tomcat/conf/account/";

	private String propertyFileName = "application";

	private HashMap<String, String> propertyMap = new HashMap<>();

	private HashMap<String,String> getProperties(String fileName) {
		
		Properties properties = new Properties();
		File file = new File(fileName);
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			System.out.println("Exception occured in getProperties() : FileNotFoundException ");
			e.printStackTrace();
		}
		try {
			properties.load(fileInputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (final String name : properties.stringPropertyNames()) {
			propertyMap.put(name, properties.getProperty(name));
		}
		return propertyMap;
	}

	@Override
	public void initialize(ConfigurableApplicationContext applicationContext) {
		String[] environment = applicationContext.getEnvironment().getActiveProfiles();
		System.out.println("---------- Configuring the application properties --------");
		if (environment.length > 0) {
			String env = environment[0];			
			String fileName = basePath + propertyFileName +"-" + env + ".properties";
			System.out.println("Loading :" + fileName);
			HashMap propertiesMap = getProperties(fileName);
			applicationContext.getEnvironment().getPropertySources()
					.addLast(new MapPropertySource("application.properties", propertiesMap));

		} else {
			
		}
	}

}
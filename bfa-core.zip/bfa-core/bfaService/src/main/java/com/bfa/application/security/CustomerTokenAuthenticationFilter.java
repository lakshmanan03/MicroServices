/**
 * 
 */
package com.bfa.application.security;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.bfa.common.entity.CustomerLoginData;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.PublicUtility;
import com.google.gson.Gson;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

/**
 * @author pradheep.p
 *
 */
public class CustomerTokenAuthenticationFilter extends OncePerRequestFilter implements TokenValidator, Serializable {

	@Autowired
	private SecurityConstants constants;	

	@Autowired
	private LogoutService logoutService;

	@Autowired
	private TokenEncryptor tokenEncryptor;

	private String appKey = "IMXYlDmP4f4=";

	private PublicUtility publicUtility = PublicUtility.getInstance(appKey);

	public CustomerTokenAuthenticationFilter() {

	}

	String[] allowedAuthorities = new String[] { "ROLE_SIGNED_USER" };
	ArrayList<String> authorizedUsers = new ArrayList<String>();

	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException, IOException, ServletException {
		String requestURL = request.getRequestURL().toString();

		if (requestURL.contains("authenticate") || requestURL.contains("TestApi")
				|| requestURL.contains("testIFastAccountCreation") || requestURL.contains("processAMLStatus")
				|| requestURL.contains("/v2/api-docs") || requestURL.contains("swagger-ui")
				|| requestURL.contains("/webjars") || requestURL.contains("/swagger-resources")
				|| requestURL.contains("document") || requestURL.contains("actuator")
				|| !requestURL.contains("/api/customer/")) {
			return null;
		}
		//	System.out.println("BFA-Token-Filter - Printing the token name :" + constants.TOKEN_NAME);
		String token = request.getHeader(constants.TOKEN_NAME);
		boolean authorized = false;
		//	logger.info("token found:" + token);
		
		AbstractAuthenticationToken userAuthenticationToken = null;
		// -------------------------------------
		try {
			if (token != null) {
				userAuthenticationToken = getTokenInfo(token);
				SecurityContextHolder.getContext().setAuthentication(userAuthenticationToken);
			} else {
				response.sendError(HttpServletResponse.SC_FORBIDDEN, "Un Authorized");
				throw new BadCredentialsException("Invalid Token");
			}
			if (userAuthenticationToken == null) {
				System.out.println("No authentication details found");
				throw new BadCredentialsException("Invalid Token");
			} else {
				Collection<GrantedAuthority> authorities = userAuthenticationToken.getAuthorities();
				List<String> givenAuthorities = new ArrayList<String>();
				Iterator<GrantedAuthority> iter = authorities.iterator();
				while (iter.hasNext()) {
					givenAuthorities.add(iter.next().getAuthority());
				}
				if(requestURL.contains("/api/customer/")){
					for(int i=0;i<allowedAuthorities.length ;i++){
						String authority  = allowedAuthorities[i];
						if(givenAuthorities.contains(authority)){
							authorized = true;
							break;
						}
					}
				} else {
					return null;
				}
			}
		} catch (BadTokenException exception) {
			print403ErrorResponse(response, "Bad token");	
		} catch (AuthenticationException err) {		
			print403ErrorResponse(response, "Authorization failed - Bad token");
			logger.error("Bad token found", err);
		}
		if (!authorized) {
			print403ErrorResponse(response, "Unauthorized to view this link");			
			throw new BadCredentialsException("Invalid Token");
		}
		return userAuthenticationToken;
	}

	public String getTokenString(String principal, Collection<? extends GrantedAuthority> grantedAuthorities) {
		Iterator iter = grantedAuthorities.iterator();
		String roles = "";
		while (iter.hasNext()) {
			GrantedAuthority authority = (GrantedAuthority) iter.next();
			roles = roles + authority.getAuthority() + ",";
		}
		String jwtToken = Jwts.builder().setSubject(principal).claim("roles", roles).setIssuedAt(new Date())
				.setIssuer(constants.TOKEN_NAME).setExpiration(getExpiryTimeForDelay(constants.timeToLive))
				.signWith(SignatureAlgorithm.HS256, constants.base64SecretBytes).compact();
		return jwtToken;
	}

	protected Date getExpiryTimeForDelay(int seconds) {
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		calendar.add(GregorianCalendar.SECOND, seconds);
		return calendar.getTime();
	}

	protected JWTAuthenticationToken getTokenInfo(String token) throws BadTokenException {
		try {
			Claims claims = Jwts.parser().setSigningKey(constants._secret).parseClaimsJws(token).getBody();
			String roles = (String) claims.get("roles");
			roles.replace("[", "");
			roles.replace("]", "");
			List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			String[] args = roles.split(",");
			for (String auth : args) {
				GrantedAuthority obj = new BFAGrandtedAuthority(auth.trim().toUpperCase());
				authorities.add(obj);
			}
			logger.info("Printing the claims " + claims.getIssuer());
			JWTAuthenticationToken tokenObj = new JWTAuthenticationToken(claims.getSubject());
			tokenObj.setAuthorities(authorities);
			String customerReference = tokenObj.getPrincipal().toString();
			CustomerLoginData customerLoginData = new CustomerLoginData();
			customerLoginData.setCustomerIdEncrypted(customerReference);
			tokenObj.setDetails(customerLoginData);
			return tokenObj;
		} catch (ExpiredJwtException expiredJwtException) {
			throw new BadTokenException(ApplicationConstants.SESSION_TIMEOUT_LOGOUT);
		} catch (final MalformedJwtException | UnsupportedJwtException | SignatureException JwtException) {
			System.out.println("Token error:" + JwtException.getMessage());
			throw new BadTokenException("Invalid token");
		} catch (Exception err) {
			System.out.println("Token parsing error.." + err.getLocalizedMessage());
			throw new BadTokenException("Invalid token");
		}
	}

	class JWTAuthenticationToken extends AbstractAuthenticationToken {
		private static final long serialVersionUID = 1L;
		private final Object principal;
		private Object details;

		Collection<GrantedAuthority> authorities;

		public JWTAuthenticationToken(String jwtToken) {
			super(null);
			super.setAuthenticated(true);
			principal = jwtToken;
			logger.info("Principal :" + principal);

		}

		public Object getCredentials() {
			return "";
		}

		public Object getPrincipal() {
			return principal;
		}		

		@Override
		public Collection<GrantedAuthority> getAuthorities() {
			return authorities;
		}

		public void setAuthorities(Collection<GrantedAuthority> authorities) {
			this.authorities = authorities;
		}
	}

	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
		/*
		 * if (request.getRequestURL().toString().contains("authenticate")) {
		 * return true; }
		 */
		return false;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws ServletException, IOException {
	//	System.out.println("#####Customer Based Filter ######");
		Authentication authentication = attemptAuthentication(req, res);
		if (authentication != null) {
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}
		super.doFilter(req, res, chain);
	}

	@Override
	public AbstractAuthenticationToken validateToken(String token) throws BadTokenException {
		return getTokenInfo(token);
	}


	private void print403ErrorResponse(HttpServletResponse servletResponse, String errorMessage) {
		if (servletResponse.getStatus() == 403) {
			return;
		}
		ErrorMessage errorMessageObj = new ErrorMessage();
		errorMessageObj.setCode(403);
		errorMessageObj.setErrorMessage(errorMessage);

		Gson gson = new Gson();
		String printMsg = gson.toJson(errorMessageObj);
		PrintWriter out = null;
		try {
			out = servletResponse.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		servletResponse.setContentType("application/json");
		servletResponse.setCharacterEncoding("UTF-8");
		servletResponse.setStatus(403);
		out.print(printMsg);
		out.flush();
	}
}

package com.bfa.investment.dto;

import java.util.Date;

public class CustomerPortfolioDTO {
	
	private String portfolioId;
	private String portfolioStatus;
	private String portfolioName;
	private Integer customerPortfolioId;
	private Double totalPortfolioValue;
	private Double portfolioValue;
	private PortfolioActionBean entitlements;
	private Double initialInvestment;
	private Double monthlyInvestment;
	private String refNo;
	private Double cashAccountBalance;
	private Integer buyRequestCount;
	private String createdDate;
	private Double totalReturns;
	private Double simpleReturns;
	private int riskProfileId;
	private String riskProfileType;
	private PendingRequestDTO pendingRequestDTO;
	private Double yearlyReturns;
	private Double totalInvested;
	private String fundingTypeValue;
	private String portfolioType;
	private String portfolioCategory;
	private String lastUpdatedTimeStamp;
	
	public String getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(String portfolioType) {
		this.portfolioType = portfolioType;
	}

	public Integer getFundingTypeId() {
		return fundingTypeId;
	}

	public void setFundingTypeId(Integer fundingTypeId) {
		this.fundingTypeId = fundingTypeId;
	}

	private Integer fundingTypeId;
	
	
	public String getFundingTypeValue() {
		return fundingTypeValue;
	}

	public void setFundingTypeValue(String fundingTypeValue) {
		this.fundingTypeValue = fundingTypeValue;
	}

	public PendingRequestDTO getPendingRequestDTO() {
		return pendingRequestDTO;
	}

	public void setPendingRequestDTO(PendingRequestDTO pendingRequestDTO) {
		this.pendingRequestDTO = pendingRequestDTO;
	}

	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	
	public int getRiskProfileId() {
		return riskProfileId;
	}

	public void setRiskProfileId(int riskProfileId) {
		this.riskProfileId = riskProfileId;
	}

	public String getRiskProfileType() {
		return riskProfileType;
	}

	public void setRiskProfileType(String riskProfileType) {
		this.riskProfileType = riskProfileType;
	}

	public Double getTotalReturns() {
		return totalReturns;
	}

	public void setTotalReturns(Double totalReturns) {
		this.totalReturns = totalReturns;
	}

	public Double getSimpleReturns() {
		return simpleReturns;
	}

	public void setSimpleReturns(Double simpleReturns) {
		this.simpleReturns = simpleReturns;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	

	public Double getPortfolioValue() {
		return portfolioValue;
	}

	public void setPortfolioValue(Double portfolioValue) {
		this.portfolioValue = portfolioValue;
	}

	
	public Double getTotalPortfolioValue() {
		return totalPortfolioValue;
	}

	public void setTotalPortfolioValue(Double totalPortfolioValue) {
		this.totalPortfolioValue = totalPortfolioValue;
	}
	
	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	
	public Double getCashAccountBalance() {
		return cashAccountBalance;
	}

	public void setCashAccountBalance(Double cashAccountBalance) {
		this.cashAccountBalance = cashAccountBalance;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}


	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public PortfolioActionBean getEntitlements() {
		return entitlements;
	}

	public void setEntitlements(PortfolioActionBean entitlements) {
		this.entitlements = entitlements;
	}

	public Double getInitialInvestment() {
		return initialInvestment;
	}

	public void setInitialInvestment(Double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}

	public Double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(Double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public Double getYearlyReturns() {
		return yearlyReturns;
	}

	public void setYearlyReturns(Double yearlyReturns) {
		this.yearlyReturns = yearlyReturns;
	}

	public Double getTotalInvested() {
		return totalInvested;
	}

	public void setTotalInvested(Double totalInvested) {
		this.totalInvested = totalInvested;
	}

	public Integer getBuyRequestCount() {
		return buyRequestCount;
	}

	public void setBuyRequestCount(Integer buyRequestCount) {
		this.buyRequestCount = buyRequestCount;
	}
	
	public String getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(String lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getPortfolioCategory() {
		return portfolioCategory;
	}

	public void setPortfolioCategory(String portfolioCategory) {
		this.portfolioCategory = portfolioCategory;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerPortfolioDTO [portfolioId=");
		builder.append(portfolioId);
		builder.append(", portfolioStatus=");
		builder.append(portfolioStatus);
		builder.append(", portfolioName=");
		builder.append(portfolioName);
		builder.append(", customerPortfolioId=");
		builder.append(customerPortfolioId);
		builder.append(", totalPortfolioValue=");
		builder.append(totalPortfolioValue);
		builder.append(", portfolioValue=");
		builder.append(portfolioValue);
		builder.append(", entitlements=");
		builder.append(entitlements);
		builder.append(", initialInvestment=");
		builder.append(initialInvestment);
		builder.append(", monthlyInvestment=");
		builder.append(monthlyInvestment);
		builder.append(", refNo=");
		builder.append(refNo);
		builder.append(", cashAccountBalance=");
		builder.append(cashAccountBalance);
		builder.append(", buyRequestCount=");
		builder.append(buyRequestCount);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", totalReturns=");
		builder.append(totalReturns);
		builder.append(", riskProfileId=");
		builder.append(riskProfileId);
		builder.append(", riskProfileType=");
		builder.append(riskProfileType);
		builder.append(", pendingRequestDTO=");
		builder.append(pendingRequestDTO);
		builder.append(", yearlyReturns=");
		builder.append(yearlyReturns);
		builder.append(", totalInvested=");
		builder.append(totalInvested);
		builder.append(", portfolioCategory=");
		builder.append(portfolioCategory);
		builder.append("]");
		return builder.toString();
	}

}
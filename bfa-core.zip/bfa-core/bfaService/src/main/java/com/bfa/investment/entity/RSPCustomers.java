package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author divakaru
 *
 */

@Entity
@Table(name = "vw_rsp_customers")
public class RSPCustomers {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "customer_id")
	private Integer customerid;
	
	@Column(name = "portfolio_id")
	private String portfolioid;
	
	@Column(name = "portfolio_status")
	private String portfolioStatus;
	
	@Column(name = "monthly_investment")
	private Double monthlyinvestment;
	
	@Column(name = "portfolio_transaction_id")
	private Integer portfolioTransactionId;
	
	@Column(name = "transaction_status")
	private String transactionStatus;

	/**
	 * @return the customerid
	 */
	public Integer getCustomerid() {
		return customerid;
	}

	/**
	 * @param customerid the customerid to set
	 */
	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}

	/**
	 * @return the portfolioid
	 */
	public String getPortfolioid() {
		return portfolioid;
	}

	/**
	 * @param portfolioid the portfolioid to set
	 */
	public void setPortfolioid(String portfolioid) {
		this.portfolioid = portfolioid;
	}

	/**
	 * @return the portfolioStatus
	 */
	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	/**
	 * @param portfolioStatus the portfolioStatus to set
	 */
	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	/**
	 * @return the monthlyinvestment
	 */
	public Double getMonthlyinvestment() {
		return monthlyinvestment;
	}

	/**
	 * @param monthlyinvestment the monthlyinvestment to set
	 */
	public void setMonthlyinvestment(Double monthlyinvestment) {
		this.monthlyinvestment = monthlyinvestment;
	}

	/**
	 * @return the portfolioTransactionId
	 */
	public Integer getPortfolioTransactionId() {
		return portfolioTransactionId;
	}

	/**
	 * @param portfolioTransactionId the portfolioTransactionId to set
	 */
	public void setPortfolioTransactionId(Integer portfolioTransactionId) {
		this.portfolioTransactionId = portfolioTransactionId;
	}

	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

}


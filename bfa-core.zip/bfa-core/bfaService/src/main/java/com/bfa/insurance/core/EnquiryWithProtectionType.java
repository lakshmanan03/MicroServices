/**
 * 
 */
package com.bfa.insurance.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author pradheep
 *
 */
@Entity
@Table(name = "enquiry_protection_type")
public class EnquiryWithProtectionType {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@OneToOne
	@JoinColumn(name = "enquiry_id", referencedColumnName="id")
	private Enquiry enquiryDetails;

	@OneToOne
	@JoinColumn(name = "protection_type_id", referencedColumnName="id")
	private ProtectionType protectionType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Enquiry getEnquiryDetails() {
		return enquiryDetails;
	}

	public void setEnquiryDetails(Enquiry enquiryDetails) {
		this.enquiryDetails = enquiryDetails;
	}

	public ProtectionType getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(ProtectionType protectionType) {
		this.protectionType = protectionType;
	}
	
}

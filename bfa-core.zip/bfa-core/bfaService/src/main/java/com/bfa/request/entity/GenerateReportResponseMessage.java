package com.bfa.request.entity;

import java.util.List;

public class GenerateReportResponseMessage {

	private List<GenerateReportPostResponse> objectList;

	/**
	 * @return the objectList
	 */
	public List<GenerateReportPostResponse> getObjectList() {
		return objectList;
	}

	/**
	 * @param objectList the objectList to set
	 */
	public void setObjectList(List<GenerateReportPostResponse> objectList) {
		this.objectList = objectList;
	}
	
	
	
}

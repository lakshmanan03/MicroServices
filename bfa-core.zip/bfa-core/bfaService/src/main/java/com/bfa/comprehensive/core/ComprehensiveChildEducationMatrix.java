package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "comprehensive_child_education_matrix")
public class ComprehensiveChildEducationMatrix {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "nationality")
	private String nationality;
	
	@Column(name = "location")
	private String location;
	
	@Column(name = "course")
	private String course;
	
	@Column(name = "helper")
	private String helper;
	
	@Column(name = "university_fees")
	private double universityFees;
	
	@Column(name = "living_expenses")
	private double livingExpenses;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getHelper() {
		return helper;
	}

	public void setHelper(String helper) {
		this.helper = helper;
	}

	public double getUniversityFees() {
		return universityFees;
	}

	public void setUniversityFees(double universityFees) {
		this.universityFees = universityFees;
	}

	public double getLivingExpenses() {
		return livingExpenses;
	}

	public void setLivingExpenses(double livingExpenses) {
		this.livingExpenses = livingExpenses;
	}
	
	

}

package com.bfa.notification;

public abstract class NotificationMessage {
	public abstract MessageObject getMessage();
}

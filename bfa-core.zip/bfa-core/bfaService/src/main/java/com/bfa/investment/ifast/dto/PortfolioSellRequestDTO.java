package com.bfa.investment.ifast.dto;

import com.bfa.common.entity.CustomerBankDetail;

public class PortfolioSellRequestDTO {

	private String portfolioId;
	private String redemptionAmount;
	private String withdrawType;
	private CustomerBankDetail customerBankDetail;
	private boolean redeemAll;

	public String getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getRedemptionAmount() {
		return redemptionAmount;
	}

	public void setRedemptionAmount(String redemptionAmount) {
		this.redemptionAmount = redemptionAmount;
	}

	public String getWithdrawType() {
		return withdrawType;
	}

	public void setWithdrawType(String withdrawType) {
		this.withdrawType = withdrawType;
	}

	public CustomerBankDetail getCustomerBankDetail() {
		return customerBankDetail;
	}

	public void setCustomerBankDetail(CustomerBankDetail customerBankDetail) {
		this.customerBankDetail = customerBankDetail;
	}

	public boolean isRedeemAll() {
		return redeemAll;
	}

	public void setRedeemAll(boolean redeemAll) {
		this.redeemAll = redeemAll;
	}

	@Override
	public String toString() {
		return "PortfolioSellRequestDTO [portfolioId=" + portfolioId + ", redemptionAmount=" + redemptionAmount
				+ ", withdrawType=" + withdrawType + ", customerBankDetail=" + customerBankDetail + ", redeemAll="
				+ redeemAll + "]";
	}

	
	
}

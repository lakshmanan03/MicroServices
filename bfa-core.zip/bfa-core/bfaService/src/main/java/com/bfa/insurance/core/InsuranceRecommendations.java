/**
 * 
 */
package com.bfa.insurance.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */

@Entity
@Table(name = "insurance_recommendations")
public class InsuranceRecommendations {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "product_id")
	private String productId;
	
	@Column(name="status")
	private String status;
	//'RECOMMENDED,SELECTED_FOR_QUOTE,QUOTE_SENT_TO_CUSTOMER,BOUGHT',
	
	@Column(name="coverage_name")
	private String coverageName;
	
	@Column(name="duration_name")
	private String durationName;	
	
	@Column(name="premium_term")
	private String premiumTerm;
	
	@Column(name="retirement_payout_amount")
	private String retirementPayoutAmount;
	
	@Column(name="retirement_payout_duration")
	private String retirementPayoutDuration;
	
	@Column(name="savings_duration")
	private String savingsDuration;
	
	@Column(name="premium_id")
	private Integer premiumId;
	
	@Column(name="protection_type")
	private String protectionType;
	
	@Column(name="ranking_group_id")
	private Integer rankingGroupId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCoverageName() {
		return coverageName;
	}

	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	public String getDurationName() {
		return durationName;
	}

	public void setDurationName(String durationName) {
		this.durationName = durationName;
	}

	public String getPremiumTerm() {
		return premiumTerm;
	}

	public void setPremiumTerm(String premiumTerm) {
		this.premiumTerm = premiumTerm;
	}

	public String getRetirementPayoutAmount() {
		return retirementPayoutAmount;
	}

	public void setRetirementPayoutAmount(String retirementPayoutAmount) {
		this.retirementPayoutAmount = retirementPayoutAmount;
	}

	public String getRetirementPayoutDuration() {
		return retirementPayoutDuration;
	}

	public void setRetirementPayoutDuration(String retirementPayoutDuration) {
		this.retirementPayoutDuration = retirementPayoutDuration;
	}

	public String getSavingsDuration() {
		return savingsDuration;
	}

	public void setSavingsDuration(String savingsDuration) {
		this.savingsDuration = savingsDuration;
	}

	public Integer getPremiumId() {
		return premiumId;
	}

	public void setPremiumId(Integer premiumId) {
		this.premiumId = premiumId;
	}
	
	public Integer getRankingGroupId() {
		return rankingGroupId;
	}

	public void setRankingGroupId(Integer rankingGroupId) {
		this.rankingGroupId = rankingGroupId;
	}

	public String getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(String protectionType) {
		this.protectionType = protectionType;
	}
	
}

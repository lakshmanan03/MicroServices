package com.bfa.service;

import com.bfa.util.ErrorCodes;

public class PasswordResetStatus {

	public int code;
	public String message;

	public PasswordResetStatus(int code, String message) {
		this.code = code;
		this.message = message;
	}

	public static PasswordResetStatus createPasswordAlreadyResetStatus() {
		return new PasswordResetStatus(ErrorCodes.PASSWORD_ALREADY_RESET, "Password was already reset");
	}

	public static PasswordResetStatus createLinkExpiredStatus() {
		return new PasswordResetStatus(ErrorCodes.PASSWORD_RESET_LINK_EXPIRED,
				"Reset password link is no longer valid");
	}

	public static PasswordResetStatus createSuccessStatus() {
		return new PasswordResetStatus(ErrorCodes.SUCCESSFUL_RESPONSE, "Password successfully reset");
	}

	public static PasswordResetStatus createInvalidCredentialsStatus() {
		return new PasswordResetStatus(ErrorCodes.USER_CREDENTIALS_INVALID, "User credentials are invalid");
	}

	public static PasswordResetStatus createInvalidTokenStatus() {
		return new PasswordResetStatus(ErrorCodes.INVALID_TOKEN_DETAILS, "Invalid token details");
	}

	public static PasswordResetStatus createPasswordSameAsOldStatus() {
		return new PasswordResetStatus(ErrorCodes.NEW_PASSWORD_CANNOT_BE_SAME_AS_OLD,
				"The new password cannot be same as the old password");
	}

	public static PasswordResetStatus createFailureStatus() {
		return new PasswordResetStatus(ErrorCodes.PASSWORD_RESET_FAILED, "Password reset failed. Please try again");
	}

}

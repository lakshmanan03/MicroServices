package com.bfa.service;

import java.util.List;

import com.bfa.investment.entity.CustomerDocumentDetails;

public interface CustomerDocumentDetailService {
	
	List<CustomerDocumentDetails> getAllDetails();
	
	void saveOrUpdateCustomerDocument(int customerId, String filePath, String docType);
	
	public void saveCustomerDocument(int customerId, String file, CustomerDocumentDetails customerDocumentDetails, String status);
	
	public String deleteCustomerDocument(int customerId);
	
	public String deleteCustomerDocument(String awsFilePath);


}

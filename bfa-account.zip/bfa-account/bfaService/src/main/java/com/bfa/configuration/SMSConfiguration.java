/**
 * 
 */
package com.bfa.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import com.bfa.notification.messenger.SMSGatewayActivator;
import com.bfa.notification.messenger.SMSGatewayPoller;

/**
 * @author pradheep.p
 *
 */
@Configuration
public class SMSConfiguration {

	@Bean("threadPoolTaskScheduler")
	public ThreadPoolTaskScheduler getThreadPoolTaskScheduler() {
		ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
		return scheduler;
	}

	@Bean("smsGatewayPoller")
	public SMSGatewayPoller getSMSGatewayPoller() {
		SMSGatewayPoller poller = new SMSGatewayPoller();
		return poller;
	}

	@Bean("smsGatewayActivator")
	public SMSGatewayActivator getSMSGatewayActivator() {
		SMSGatewayActivator smsGatewayActivator = new SMSGatewayActivator();
		return smsGatewayActivator;
	}
}

package com.bfa.investment.dto;

public class CommonPortfolioSummaryDTO {
	
	private Double totalPortfolioValue;
	private Double totalCashAccountBalance;
	
	public Double getTotalPortfolioValue() {
		return totalPortfolioValue;
	}
	public void setTotalPortfolioValue(Double totalPortfolioValue) {
		this.totalPortfolioValue = totalPortfolioValue;
	}
	public Double getTotalCashAccountBalance() {
		return totalCashAccountBalance;
	}
	public void setTotalCashAccountBalance(Double totalCashAccountBalance) {
		this.totalCashAccountBalance = totalCashAccountBalance;
	}
	
	

}

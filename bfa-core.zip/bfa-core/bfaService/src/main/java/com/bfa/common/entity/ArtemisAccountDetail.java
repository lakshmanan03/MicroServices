package com.bfa.common.entity;


public class ArtemisAccountDetail {
	private String baseUrl = "https://p4.cynopsis.co/artemis_moneyowl_uat/";
	private String apiAccessToken;
	
	public String getBaseUrl() {
		return baseUrl;
	}
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	public String getApiAccessToken() {
		return apiAccessToken;
	}
	public void setApiAccessToken(String apiAccessToken) {
		this.apiAccessToken = apiAccessToken;
	}
	
	
}

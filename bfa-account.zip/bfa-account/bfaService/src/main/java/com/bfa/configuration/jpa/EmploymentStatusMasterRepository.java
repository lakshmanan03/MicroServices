/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.repository.CrudRepository;

import com.bfa.insurance.core.EmploymentStatusMaster;

/**
 * @author pradheep.p 
 *
 */
public interface EmploymentStatusMasterRepository extends CrudRepository<EmploymentStatusMaster, Integer> {
	
	public EmploymentStatusMaster findElementById(Integer id);
	
}

package com.bfa.admin.dto;

import java.util.List;

import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Expenses;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.dto.CustomerAdditionalDetailsDTO;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;
import com.bfa.investment.entity.Portfolio;

public class AdminCustomerDetails {
	
	private String investmentAccountStatus;
	private int customerPortfolioId;
	private Double totalPortfolioValue;
	private Double totalCashAccountBalance;
	private AdminCustomerPortfolioDetailsSummary cpdetailsSummary;
	private Customer customer;
	private String ifastReferenceNumber;
	private Income income;
	private Assets assets;
	private Liabilities liabilities;
	private List<CustomerTaxDetails> taxDetails;
	private String investemntSource;
	private CustomerPEPDetails pepDetails;
	private CustomerAdditionalDetailsDTO additionalDetails;
	private CustomerIdentityDetails identityDetails;
	private CustomerInvestmentObjective investmentObjective;
	private Portfolio portfolio;
	private CustomerEmploymentInformation employmentInformation;
	private String employmentStatus;
	private List<CustomerDocumentDetails> documentDetails;
	private Expenses expenses;
	
	
	
	public String getInvestmentAccountStatus() {
		return investmentAccountStatus;
	}

	public void setInvestmentAccountStatus(String investmentAccountStatus) {
		this.investmentAccountStatus = investmentAccountStatus;
	}

	public AdminCustomerPortfolioDetailsSummary getCpdetailsSummary() {
		return cpdetailsSummary;
	}

	public void setCpdetailsSummary(AdminCustomerPortfolioDetailsSummary cpdetailsSummary) {
		this.cpdetailsSummary = cpdetailsSummary;
	}
	
	public Double getTotalPortfolioValue() {
		return totalPortfolioValue;
	}

	public void setTotalPortfolioValue(Double totalPortfolioValue) {
		this.totalPortfolioValue = totalPortfolioValue;
	}

	public Double getTotalCashAccountBalance() {
		return totalCashAccountBalance;
	}

	public void setTotalCashAccountBalance(Double totalCashAccountBalance) {
		this.totalCashAccountBalance = totalCashAccountBalance;
	}


	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Income getIncome() {
		return income;
	}

	public void setIncome(Income income) {
		this.income = income;
	}

	public Assets getAssets() {
		return assets;
	}

	public void setAssets(Assets assets) {
		this.assets = assets;
	}

	public Liabilities getLiabilities() {
		return liabilities;
	}

	public void setLiabilities(Liabilities liabilities) {
		this.liabilities = liabilities;
	}

	public CustomerPEPDetails getPepDetails() {
		return pepDetails;
	}

	public void setPepDetails(CustomerPEPDetails pepDetails) {
		this.pepDetails = pepDetails;
	}

	public CustomerAdditionalDetailsDTO getAdditionalDetails() {
		return additionalDetails;
	}

	public void setAdditionalDetails(CustomerAdditionalDetailsDTO additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	public CustomerIdentityDetails getIdentityDetails() {
		return identityDetails;
	}

	public void setIdentityDetails(CustomerIdentityDetails identityDetails) {
		this.identityDetails = identityDetails;
	}

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public List<CustomerTaxDetails> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(List<CustomerTaxDetails> taxDetails) {
		this.taxDetails = taxDetails;
	}

	public CustomerInvestmentObjective getInvestmentObjective() {
		return investmentObjective;
	}

	public void setInvestmentObjective(CustomerInvestmentObjective investmentObjective) {
		this.investmentObjective = investmentObjective;
	}

	public CustomerEmploymentInformation getEmploymentInformation() {
		return employmentInformation;
	}

	public void setEmploymentInformation(CustomerEmploymentInformation employmentInformation) {
		this.employmentInformation = employmentInformation;
	}

	public List<CustomerDocumentDetails> getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(List<CustomerDocumentDetails> documentDetails) {
		this.documentDetails = documentDetails;
	}

	public String getIfastReferenceNumber() {
		return ifastReferenceNumber;
	}

	public void setIfastReferenceNumber(String ifastReferenceNumber) {
		this.ifastReferenceNumber = ifastReferenceNumber;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public Expenses getExpenses() {
		return expenses;
	}

	public void setExpenses(Expenses expenses) {
		this.expenses = expenses;
	}

	public String getInvestemntSource() {
		return investemntSource;
	}

	public void setInvestemntSource(String investemntSource) {
		this.investemntSource = investemntSource;
	}

	public int getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	public void setCustomerPortfolioId(int customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

}

package com.bfa.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.bfa.common.dto.AddressDTO;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.dto.CustomerTaxDetailsDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.common.entity.EmployerAddress;
import com.bfa.common.entity.EmployerDetails;
import com.bfa.common.entity.Household;
import com.bfa.common.entity.Industry;
import com.bfa.common.entity.Occupation;
import com.bfa.common.entity.OptionItem;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.CustomerDocumentDAO;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.account.dto.CustomerDetailsDTO.AccountVerificationMode;
import com.bfa.investment.account.dto.PersonalDetailsDTO;
import com.bfa.investment.dto.PEPAdditionalDeclarationDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;
import com.bfa.investment.entity.DocumentStatusMaster;
import com.bfa.investment.entity.DocumentStatusMaster.DocumentStatusTypes;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.service.CustomerDocumentDetailService;
import com.bfa.service.InvestmentAccountService;
import com.bfa.util.AmazonS3ClientService;
import com.bfa.util.PublicUtility;
import com.bfa.util.ServiceResponse;


public class InvestmentAccountServiceImpl implements InvestmentAccountService {

	
	@Autowired
	private CustomerDocumentDAO customerDocDao;
	
	@Autowired
	InvestmentAccountDao dao;
	
    @Autowired
    AmazonS3ClientService amazonS3ClientService;
    
    @Autowired
    CustomerDocumentDetailService customerDocService;
	
    @Autowired
	protected ApplicationLoggerBean applicationLoggerBean;
    
    protected Logger getLogger() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}
    
    public DetailedCustomerSummary getIFastParameters(Integer customerId) {
    	
    	DetailedCustomerSummary parameters = new DetailedCustomerSummary();
    	
    	Assets assets = dao.getCustomerAssetDetails(customerId);
    	parameters.setAssets(assets);
    	
    	Income income = dao.getCustomerIncomeDetails(customerId);
    	parameters.setIncome(income);
    	
    	Liabilities liabilities = dao.getCustomerLiabilitiesDetails(customerId);
    	parameters.setLiabilities(liabilities);
    	
    	List<CustomerTaxDetails> taxDetails = dao.getCustomerTaxDetails(customerId);
    	parameters.setTaxDetails(taxDetails);
    	
    	CustomerInvestmentObjective investmentObjective = dao.getCustomerInvestmentObjective(customerId);
    	parameters.setInvestmentObjective(investmentObjective);
    	
    	CustomerAdditionalDetails additionalDetails = dao.getCustomerAdditionalDetails(customerId);
    	parameters.setAdditionalDetails(additionalDetails);
    	
    	CustomerPEPDetails pepDetails = dao.getCustomerPEPDetails(customerId);
    	parameters.setPepDetails(pepDetails);
    	
    	CustomerIdentityDetails identityDetails = dao.getCustomerIdentityDetails(customerId);
    	parameters.setIdentityDetails(identityDetails);
    	
    	Customer customer = dao.getCustomer(customerId);
    	parameters.setCustomer(customer);
    	
    	CustomerEmploymentInformation employmentInfo = dao.getCustomerEmploymentInformation(customerId);
    	parameters.setEmploymentInformation(employmentInfo);
    	
    	List<CustomerDocumentDetails> documentDetails = dao.getCustomerDocumentDetails(customerId);
    	parameters.setDocumentDetails(documentDetails);
    	
    	
    	return parameters;
    }
    
	public ServiceResponse<Map<String,String>> saveDocument(Integer customerId, MultipartFile uploadedFile, String type) {
		
		ServiceResponse<Map<String,String>> response = new ServiceResponse<>();
		response.addResponseInfo("step", "SAVING_DOCUMENT");
		response.setSuccess(true);
		// Upload document to AWS S3 Bucket
		boolean status = true;
		String[] fileFrags = uploadedFile.getOriginalFilename().split("\\.");
		String extension = fileFrags[fileFrags.length-1];
		String fileName = customerId + "_";
		fileName += type + "." + extension;
		File file = null;
		try {
			String fileUrl = this.amazonS3ClientService.uploadFileToS3Bucket(fileName , uploadedFile);
			CustomerDocumentDetails docDetails = new CustomerDocumentDetails();
			customerDocService.saveOrUpdateCustomerDocument(customerId, fileUrl, type);
			response.addResponseInfo("filePath", fileUrl);
			response.addResponseInfo("type", type);
		} catch (Exception e) {
			response.addExceptionInfo(e);
			getLogger().error("Exception caught in saveDocument(): " + e);
		}
		
		return response;
	}
	
	public boolean deleteDocument(Integer customerId, String docType) {
		boolean status = true;
		try {
			// Upload document to AWS S3 Bucket
			CustomerDocumentDetails docDetail = dao.getCustomerDocumentDetails(customerId, docType);
			if (docDetail != null) {
				amazonS3ClientService.deleteFileFromS3Bucket(docDetail.getFileName());
				DocumentStatusMaster docStatus = customerDocDao.getDocumentStatus(DocumentStatusTypes.DELETED);
				docDetail.setDocumentStatus(docStatus);
				docDetail.setLastUpdatedTimeStamp(PublicUtility.getCurrentUTC());
				dao.saveOrUpdateDetails(docDetail);
			}
		}
		catch(Exception ex) {
			status = false;
			getLogger().error("Exception while delete document for the customer:   " + customerId + " ===> " + ex);
		}
		return status;
	}
	
	
	@Override
	public ServiceResponse<Map<String,String>>  saveInvestmentAccountDetails(CustomerDetailsDTO accountDetails, Integer customerId) {

		ServiceResponse<Map<String,String>> response = new ServiceResponse<>();
		response.addResponseInfo("step", "SAVING_INVESTMENT_DETAILS");
		response.setSuccess(true);
		try {
			Integer residentialAddressId = null;
			Integer mailingAddressId = null;
			Customer customer = getCustomerDetails(customerId);
			CustomerEmploymentInformation customerEmploymentInfo = null;
			if (accountDetails != null && customer != null) {
				// Save customer identity details
				saveCustomerIdentityDetails(accountDetails, customer);
				
				// Update customer informations
				saveCustomerInformations(accountDetails, customer);
				
				// Update Addresses
				updateCustomerAddress(customer,accountDetails);
				
				// Save employer details
				if (accountDetails.getEmploymentDetails() != null) {
					Integer employerAddressId = null;
					Integer employerId = null;
					Integer employerContactDetailsId = null;
					customerEmploymentInfo = dao.getCustomerEmploymentInformation(customerId);
					// To store employer address in 'address' table 
					employerAddressId = updateEmployerAddress(customerEmploymentInfo,accountDetails);
					// To store employer details in 'employer' table
					employerId = updateEmployerDetails(customerEmploymentInfo,accountDetails);
				
					// To save employer address, contact number in 'employer_address' table
					if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerAddress() != null) {
						employerContactDetailsId = customerEmploymentInfo.getEmployerAddress().getId();
					}
					updateEmployerContactDetails(employerContactDetailsId, employerId, employerAddressId, accountDetails);
					
					// To save customer employment details in 'customer_employment_details'
					updateCustomerEmploymentDetails(customerId,employerId,accountDetails);
				}
				
				// Save customer household details
				saveHouseholdDetails(accountDetails, customer);
				
				// save user financial details
				saveFinancialDetails(accountDetails, customer);
				
				// save asset and liabilities
				saveAssetLiabilitiesDetails(accountDetails, customer);
				
				// Save Tax Details
				saveTaxDetails(accountDetails, customer);
				
				// Save additional details
				saveAdditionsDetails(accountDetails, customer);
			}
			else {
				if (accountDetails != null)
					response.addErrorInfo("accountDetailsError", "accountDetails object is null");
				 if (customer != null)
					 response.addErrorInfo("customerObjectError", "customer is null");
			}

		}
		catch(Exception ex) {
			getLogger().error("Exception while saveInvestmentAccountDetails(): " + ex);
			response.addExceptionInfo(ex);
		}
		return response;
	}
	
	
	private void saveCustomerInformations(CustomerDetailsDTO accountDetails, Customer customer) {

		if (accountDetails != null && accountDetails.getPersonalInfo() != null && customer != null) {
			PersonalDetailsDTO dto = accountDetails.getPersonalInfo();
			customer.setNationalityCode(dto.getNationalityCode());
			customer.setRace(dto.getRace());
			customer.setSalutation(dto.getSalutation());
			customer.setNricName(dto.getFullName());
			customer.setGivenName(dto.getFirstName());
			customer.setSurName(dto.getLastName());
			customer.setGender(dto.getGender());
			customer.setDateOfBirth(PublicUtility.dateToString(dto.getDateOfBirth()));
			if (dto.getBirthCountryId() != null) {
				Country countryOfBirth = new Country();
				countryOfBirth.setId(dto.getBirthCountryId());
				customer.setCountryOfBirth(countryOfBirth);
			}
			else {
				customer.setCountryOfBirth(null);
			}
			dao.saveOrUpdateDetails(customer);
		}
	}
	
	private boolean saveCustomerIdentityDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		boolean status = true;
		if (accountDetails != null && accountDetails.getPersonalInfo() != null && customer != null) {
			PersonalDetailsDTO dto = accountDetails.getPersonalInfo();
			CustomerIdentityDetails details = dao.getCustomerIdentityDetails(customer.getId());
			if (details == null) {
				details = new CustomerIdentityDetails();
				details.setCreatedDate(PublicUtility.getCurrentUTC());
			}
			details.setCustomer(customer);
			details.setLastModifiedDate(PublicUtility.getCurrentUTC());
			details.setNricNumber(dto.getNricNumber());
			details.setPassportNumber(dto.getPassportNumber());
			details.setPassportExpiryDate(dto.getPassportExpiryDate());
			if (dto.getPassportIssuedCountryId() != null) {
				Country country = new Country();
				country.setId(dto.getPassportIssuedCountryId());
				details.setPassportIssuedCountry(country);
			}
			else {
				details.setPassportIssuedCountry(null);
			}

			dao.saveOrUpdateDetails(details);
		}
		return true;
	}

	private void saveAdditionsDetails(CustomerDetailsDTO accountDetails, Customer customer) {

		if (accountDetails != null && accountDetails.getPersonalDeclarations() != null) {
			// Save customer investment souce details
			saveCustomerInvestmentSource(accountDetails, customer);
			// Save customer additional details
			saveCustomerAdditionalDetails(accountDetails, customer);
		}
	}


	private void saveCustomerAdditionalDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			if (accountDetails != null && accountDetails.getPersonalDeclarations() != null) {
				CustomerAdditionalDetails details = dao.getCustomerAdditionalDetails(customer.getId());
				if (details == null) {
					details = new CustomerAdditionalDetails();
					details.setCustomer(customer);
				}
				if (accountDetails.isMyInfoVerified()) {
					details.setRegistrationProofType(AccountVerificationMode.MY_INFO);
				}
				else {
					details.setRegistrationProofType(AccountVerificationMode.PASSPORT);
				}
				details.setBeneficialOwner(accountDetails.getPersonalDeclarations().isBeneficialOwner());
				details.setPoliticallyExposed(accountDetails.getPersonalDeclarations().isPoliticallyExposed());
				if (accountDetails.getPersonalDeclarations().isPoliticallyExposed())
					savePEPDetails(accountDetails,customer);
				details.setConnectedToInvestmentFirm(accountDetails.getPersonalDeclarations().isConnectedToInvestmentFirm());
				dao.saveOrUpdateDetails(details);
			}
		}
		catch (Exception ex) {
			getLogger().error("Exception caught in saveCustomerAdditionalDetails(): " + ex);
		}
	}
	
	private void savePEPDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			if (accountDetails != null && accountDetails.getPersonalDeclarations() != null 
					&& accountDetails.getPersonalDeclarations().getPepDeclaration() != null) {
				PEPAdditionalDeclarationDTO dto = accountDetails.getPersonalDeclarations().getPepDeclaration();
				CustomerPEPDetails details = dao.getCustomerPEPDetails(customer.getId());
				if (details == null) {
					details = new CustomerPEPDetails();
					details.setCustomer(customer);
				}
				details.setFirstName(dto.getFirstName());
				details.setLastName(dto.getLastName());
				details.setCompanyName(dto.getCompanyName());
				Occupation occupation = new Occupation();
				occupation.setId(dto.getOccupationId());
				details.setOccupation(occupation);
				
				Address pepAddress = details.getPepAddress();
				if (details.getPepAddress() == null) {
					pepAddress = new Address();
				}
				
				copyAddress(dto.getPepAddress(),pepAddress);

				dao.saveOrUpdateDetails(pepAddress);
				
				details.setPepAddress(pepAddress);
				
				dao.saveOrUpdateDetails(details);
			}
		}
		catch (Exception ex) {
			getLogger().error("Exception caught in savePEPDetails(): " + ex);
		}
	}


	private void saveCustomerInvestmentSource(CustomerDetailsDTO accountDetails, Customer customer) {

		try {
			if (accountDetails != null && accountDetails.getPersonalDeclarations() != null && accountDetails.getPersonalDeclarations().getInvestmentSourceId() != null) {
				CustomerInvestmentObjective objective = dao.getCustomerInvestmentObjective(customer.getId());
				OptionItem source = new OptionItem();
				source.setId(accountDetails.getPersonalDeclarations().getInvestmentSourceId());
				objective.setInvestmentSource(source);
				dao.saveOrUpdateDetails(objective);
			}
		}
		catch (Exception ex) {
			getLogger().error("Exception caught in saveCustomerInvestmentSource(): " + ex);
		}
	}


	private void saveTaxDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		
		if (accountDetails != null && accountDetails.getTaxDetails() != null) {

			List<CustomerTaxDetails> taxDetails = dao.getCustomerTaxDetails(customer.getId());

			if (taxDetails != null) {
				for (CustomerTaxDetails taxDetail : taxDetails) {
					taxDetail.setCustomer(null);
					dao.saveOrUpdateDetails(taxDetail);
				}
			}
			for (CustomerTaxDetailsDTO taxDetailDTO : accountDetails.getTaxDetails()) {
				CustomerTaxDetails taxDetail = new CustomerTaxDetails();
				Country country = new Country();
				country.setId(taxDetailDTO.getTaxCountryId());
				taxDetail.setCustomer(customer);
				taxDetail.setTaxCountry(country);
				taxDetail.setTinNumber(taxDetailDTO.getTinNumber());
				taxDetail.setNoTinReason(taxDetailDTO.getNoTinReason());
				taxDetail.setCreatedDate(PublicUtility.getCurrentUTC());
				taxDetail.setLastModifiedDate(PublicUtility.getCurrentUTC());
				dao.saveOrUpdateDetails(taxDetail);
			}
		}
	}
		


	private void saveAssetLiabilitiesDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			Enquiry enquiry = null;
			if (accountDetails.getFinancialDetails() != null && customer != null) {
				// Save asset details
				Assets asset = dao.getCustomerAssetDetails(customer.getId());
				if (asset == null) {
					asset = new Assets();
					asset.setCustomerId(customer.getId());
					enquiry = dao.getCustomerEnquiryDetails(customer.getId());
					if (enquiry != null) {
						asset.setEnquiryId(enquiry.getId());
					}
				}
				asset.setTotalAssets(accountDetails.getFinancialDetails().getTotalAssets());
				dao.saveOrUpdateDetails(asset);
				
				// Save liabilities details
				Liabilities liabilities = dao.getCustomerLiabilitiesDetails(customer.getId());
				if (liabilities == null) {
					liabilities = new Liabilities();
					liabilities.setCustomerId(customer.getId());
					if (enquiry != null)
						liabilities.setEnquiryId(enquiry.getId());
					else {
						enquiry = dao.getCustomerEnquiryDetails(customer.getId());
						if (enquiry != null) {
							liabilities.setEnquiryId(enquiry.getId());
						}
					}
				}
				liabilities.setTotalLiabilities(accountDetails.getFinancialDetails().getTotalLoans());
				dao.saveOrUpdateDetails(liabilities);
			}
		}
		catch (Exception ex) {
			getLogger().error("Exception while save Asset Liabilities Details: " + ex);
		}
	}


	private void saveFinancialDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		try {
			Enquiry enquiry = null;
			if (accountDetails.getFinancialDetails() != null && customer != null) {
				Income income = dao.getCustomerIncomeDetails(customer.getId());
				if (income == null) {
					income = new Income();
					income.setCustomerId(customer.getId());
					enquiry = dao.getCustomerEnquiryDetails(customer.getId());
					if (enquiry != null) {
						income.setEnquiryId(enquiry.getId());
					}
				}
				income.setAnnualSalary(accountDetails.getFinancialDetails().getAnnualIncome());
				income.setPercentageOfSaving(accountDetails.getFinancialDetails().getPercentageOfSaving());
				income.setIncomeRange(accountDetails.getFinancialDetails().getIncomeRange());
				dao.saveOrUpdateDetails(income);
			}
		}
		catch (Exception ex) {
			getLogger().error("Exception while save financial details : " + ex);
		}
	}


	private void saveHouseholdDetails(CustomerDetailsDTO accountDetails, Customer customer) {
		if (accountDetails.getHouseholdDetails() != null) {
			if (customer.getHouseHoldDetail() != null) {
				Household household = customer.getHouseHoldDetail();
				
				if (accountDetails.getHouseholdDetails().getHouseHoldIncomeId() != null) {
					OptionItem houseHoldIncome = new OptionItem();
					houseHoldIncome.setId(accountDetails.getHouseholdDetails().getHouseHoldIncomeId());
					household.setHouseHoldIncome(houseHoldIncome);
				}
				household.setNumberOfMembers(accountDetails.getHouseholdDetails().getNumberOfMembers());
				dao.saveOrUpdateDetails(household);
			}
			else {
				Household houseHold = new Household();
				if (accountDetails.getHouseholdDetails().getHouseHoldIncomeId() != null) {
					OptionItem houseHoldIncome = new OptionItem();
					houseHoldIncome.setId(accountDetails.getHouseholdDetails().getHouseHoldIncomeId());
					houseHold.setHouseHoldIncome(houseHoldIncome);					
				}
				houseHold.setNumberOfMembers(accountDetails.getHouseholdDetails().getNumberOfMembers());
				customer.setHouseHoldDetail(houseHold);
				dao.saveOrUpdateDetails(houseHold);
				dao.saveOrUpdateDetails(customer);
			}
		}
	}
	
	private Integer updateEmployerAddress(CustomerEmploymentInformation customerEmploymentInfo, CustomerDetailsDTO accountDetails) {
		Integer employerAddressId = null;
		try {
			if (accountDetails != null && accountDetails.getEmploymentDetails() != null && accountDetails.getEmploymentDetails().getEmployerAddress() != null) {
				if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerAddress() != null) {
					employerAddressId = customerEmploymentInfo.getEmployerAddress().getEmployerAddress().getId();
				}					
				employerAddressId = updateAddressDetails(accountDetails.getEmploymentDetails().getEmployerAddress(), employerAddressId);
				
			}			
		}
		catch(Exception ex) {
			getLogger().error("Exception while updateEmployerAddress(): " + ex);
		}
		return employerAddressId;
	}

	private void updateCustomerEmploymentDetails(Integer customerId, Integer employerId, CustomerDetailsDTO accountDetails) {
		try {
			if (customerId > 0 && employerId > 0 && accountDetails != null && accountDetails.getEmploymentDetails() != null) {					
				
				CustomerEmploymentDetails details = new CustomerEmploymentDetails();
				details.setCustomerId(customerId);
				details.setEmployerId(employerId);
				Occupation occupation = new Occupation();
				occupation.setId(accountDetails.getEmploymentDetails().getOccupationId());
				details.setOccupation(occupation);
				details.setUnemployedReason(accountDetails.getEmploymentDetails().getUnemployedReason());
				details.setEmploymentStatusId(accountDetails.getEmploymentDetails().getEmploymentStatusId());
				dao.saveOrUpdateDetails(details);
			}
		}
		catch(Exception ex) {
			getLogger().error("Exception while updateCustomerEmploymentDetails() for the customer: " + customerId + " ; " +  ex);
		}
	}
	
	
	private Integer updateEmployerDetails(CustomerEmploymentInformation customerEmploymentInfo, CustomerDetailsDTO accountDetails) {
		Integer employerId = null;
		try {
			if (accountDetails.getEmploymentDetails() != null) {
				if (customerEmploymentInfo != null && customerEmploymentInfo.getEmployerDetails() != null) {
						employerId = customerEmploymentInfo.getEmployerDetails().getId();
				}						
				
				EmployerDetails details = new EmployerDetails();
				Industry industry = new Industry();
				industry.setId(accountDetails.getEmploymentDetails().getIndustryId());
				details.setIndustry(industry);
				details.setEmployerName(accountDetails.getEmploymentDetails().getEmployerName());
				if (employerId != null && employerId > 0) {
					details.setId(employerId);
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				}
				else {
					details.setId(null);
					details.setCreatedDate(PublicUtility.getCurrentUTC());
					details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				}
				dao.saveOrUpdateDetails(details);
				employerId = details.getId();
			}
		}
		catch(Exception ex) {
			getLogger().error("Exception while update employer details: " + ex);
		}
		
		return employerId;
	}
	
	private Integer updateEmployerContactDetails(Integer contactDetailsId,Integer employerId, Integer employerAddressId, CustomerDetailsDTO accountDetails) {

		try {
			if (accountDetails != null && accountDetails.getEmploymentDetails() != null && employerId != null
					&& employerId > 0) {
				EmployerAddress details = new EmployerAddress();
				details.setContactNumber(accountDetails.getEmploymentDetails().getContactNumber());
				if (employerAddressId != null) {
					Address address = new Address();
					address.setId(employerAddressId);
					details.setEmployerAddress(address);
				}
				details.setEmployerId(employerId);
				details.setLastModifiedDate(PublicUtility.getCurrentUTC());
				details.setId(contactDetailsId);
				dao.saveOrUpdateDetails(details);
			}
		}
		catch(Exception ex) {
			getLogger().error("Exception caught in updateEmployerContactDetails() for the employee: " + employerId);
		}
		
		return employerId;
	}
	
	private void updateCustomersTable() {
		
	}
	
	private Customer getCustomerDetails(Integer customerId) {
		return dao.getCustomer(customerId);
	}
	
	private void updateCustomerAddress(Customer customer, CustomerDetailsDTO accountDetails) {
		if (customer != null) {
			boolean isAddressAdded = false;
			if (accountDetails.getResidentialAddress() != null) {
				Address homeAddress = customer.getHomeAddress();
				if (homeAddress == null) {
					homeAddress = new Address();
					customer.setHomeAddress(homeAddress);
					isAddressAdded = true;
				}
				copyAddress(accountDetails.getResidentialAddress(),homeAddress);
				dao.saveOrUpdateDetails(homeAddress);
			}
			if (accountDetails.getMailingAddress() != null) {
				Address mailingAddress = customer.getMailingAddress();
				if (mailingAddress == null) {
					mailingAddress = new Address();
					customer.setMailingAddress(mailingAddress);
					isAddressAdded = true;
				}
				copyAddress(accountDetails.getMailingAddress(),mailingAddress);
				dao.saveOrUpdateDetails(mailingAddress);
			}
			if (isAddressAdded) {
				dao.saveOrUpdateDetails(customer);
			}
		}
	}
	
	
	private void copyAddress(AddressDTO source, Address target) {
		if (source.getCountryId() != null) {
			Country country = new Country();
			country.setId(source.getCountryId());
			target.setCountry(country);
		}
	
		target.setAddressLine1(source.getAddressLine1());
		target.setAddressLine2(source.getAddressLine2());
		target.setState(source.getState());
		target.setPostalCode(source.getPostalCode());
		target.setUnitNumber(source.getUnitNumber());
		target.setTownName(source.getTownName());
		if (target.getCreatedDate() == null) {
			target.setCreatedDate(PublicUtility.getCurrentUTC());
		}
		target.setLastModifiedDate(PublicUtility.getCurrentUTC());
	}
	
	private Integer updateAddressDetails(AddressDTO address,Integer addressId) {
		
		Address addressEntity = new Address();
		
		if (address.getCountryId() != null) {
			Country country = new Country();
			country.setId(address.getCountryId());
			addressEntity.setCountry(country);
		}
		addressEntity.setAddressLine1(address.getAddressLine1());
		addressEntity.setAddressLine2(address.getAddressLine2());
		addressEntity.setState(address.getState());
		addressEntity.setPostalCode(address.getPostalCode());
		addressEntity.setUnitNumber(address.getUnitNumber());
		addressEntity.setTownName(address.getTownName());
		if (addressId != null && addressId > 0) {
			addressEntity.setId(addressId);
			addressEntity.setCreatedDate(PublicUtility.getCurrentUTC());
			addressEntity.setLastModifiedDate(PublicUtility.getCurrentUTC());
		}
		else {
			addressEntity.setId(null);
			addressEntity.setCreatedDate(PublicUtility.getCurrentUTC());
			addressEntity.setLastModifiedDate(PublicUtility.getCurrentUTC());
		}
		dao.saveOrUpdateAddress(addressEntity);
		addressId = addressEntity.getId();
		return addressId;
	}

	@Override
	public Customer getCustomer() {
		return null;
	}
	
}

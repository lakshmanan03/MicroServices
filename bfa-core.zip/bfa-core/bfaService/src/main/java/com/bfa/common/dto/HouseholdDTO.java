package com.bfa.common.dto;

public class HouseholdDTO {
	

	private Integer numberOfMembers;
	
	private Integer houseHoldIncomeId;

	public Integer getNumberOfMembers() {
		return numberOfMembers;
	}

	public void setNumberOfMembers(Integer numberOfMembers) {
		this.numberOfMembers = numberOfMembers;
	}

	public Integer getHouseHoldIncomeId() {
		return houseHoldIncomeId;
	}

	public void setHouseHoldIncomeId(Integer houseHoldIncome) {
		this.houseHoldIncomeId = houseHoldIncome;
	}
	
	
	
}

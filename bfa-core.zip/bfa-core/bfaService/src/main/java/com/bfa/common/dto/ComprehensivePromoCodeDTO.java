package com.bfa.common.dto;

public class ComprehensivePromoCodeDTO {
	
	private String comprehensivePromoCode;

	public String getComprehensivePromoCode() {
		return comprehensivePromoCode;
	}

	public void setComprehensivePromoCode(String comprehensivePromoCode) {
		this.comprehensivePromoCode = comprehensivePromoCode;
	}
	
}

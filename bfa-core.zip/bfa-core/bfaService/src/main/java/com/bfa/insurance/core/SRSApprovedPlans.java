/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "srs_approved_plans")
public class SRSApprovedPlans implements Serializable{
	

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "single_premium")
	private double singlePremium;
	
	@Column(name = "payout_start_age")
	private int payoutStartAge;
	
	@Column(name = "payout_type")
	private String payoutType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getSinglePremium() {
		return singlePremium;
	}

	public void setSinglePremium(double singlePremium) {
		this.singlePremium = singlePremium;
	}

	public int getPayoutStartAge() {
		return payoutStartAge;
	}

	public void setPayoutStartAge(int payoutStartAge) {
		this.payoutStartAge = payoutStartAge;
	}

	public String getPayoutType() {
		return payoutType;
	}

	public void setPayoutType(String payoutType) {
		this.payoutType = payoutType;
	}
	
}

package com.bfa.common.dto;

public class ComprehensiveStepCompletedReq {
	
	private Integer enquiryId;
	
	private Integer stepCompleted;
	
	private Integer subStepCompleted;

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getStepCompleted() {
		return stepCompleted;
	}

	public void setStepCompleted(Integer stepCompleted) {
		this.stepCompleted = stepCompleted;
	}

	public Integer getSubStepCompleted() {
		return subStepCompleted;
	}

	public void setSubStepCompleted(Integer subStepCompleted) {
		this.subStepCompleted = subStepCompleted;
	}

	
}

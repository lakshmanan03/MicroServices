package com.bfa.daoimpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.CustomerPreference;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerLiabilitiesDetail;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.common.entity.CustomerTaxDetails;
import com.bfa.common.entity.EmployerAddress;
import com.bfa.common.entity.EmployerDetails;
import com.bfa.common.entity.OptionItem;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.EmploymentStatus;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.Expenses;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;
import com.bfa.investment.entity.CustomerPortfolio;
import com.bfa.investment.entity.DocumentStatusMaster.DocumentStatusTypes;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.CustomerPortfolioStatus;
import com.bfa.util.DAOResponse;

@Transactional
@Repository
public class InvestmentAccountDaoImpl extends BaseDaoImpl implements InvestmentAccountDao {

	public CustomerIFastAccount getCustomerIFastAccountDetails(Integer customerId) {
		CustomerIFastAccount item = null;
		try {
			List<CustomerIFastAccount> list = getList(
					"FROM CustomerIFastAccount where customer.id = '" + customerId + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCustomerIFastAccountDetails():  " + ex);
		}
		return item;
	}

	public CustomerIdentityDetails getCustomerIdentityDetails(int customerId) {
		CustomerIdentityDetails item = null;
		try {
			List<CustomerIdentityDetails> list = getList(
					"FROM CustomerIdentityDetails where customer.id = '" + customerId + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCustomerIdentityDetails():  " + ex);
		}
		return item;
	}

	public CustomerPEPDetails getCustomerPEPDetails(int customerId) {
		CustomerPEPDetails item = null;
		try {
			List<CustomerPEPDetails> list = getList("FROM CustomerPEPDetails where customer.id = '" + customerId + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCustomerPEPDetails():  " + ex);
		}
		return item;
	}

	public CustomerAdditionalDetails getCustomerAdditionalDetails(int customerId) {
		CustomerAdditionalDetails item = null;
		try {
			List<CustomerAdditionalDetails> list = getList(
					"FROM CustomerAdditionalDetails where customer.id = " + customerId);
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCustomerAdditionalDetails():  " + ex);
		}
		return item;
	}

	public CustomerInvestmentObjective getCustomerInvestmentObjective(int customerId) {
		CustomerInvestmentObjective item = null;
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("customerId", customerId);
		parameters.put("type", ApplicationConstants.INVESTMENT_JOURNEY_TYPE);
		try {
			List<CustomerInvestmentObjective> list = getList(
					"FROM CustomerInvestmentObjective where enquiry.customerId = :customerId AND enquiry.type = :type order by id desc", parameters);
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCustomerInvestmentObjective():  " + ex);
		}
		return item;
	}

	public Country getCountry(int countryId) {
		Country item = null;
		try {
			List<Country> list = getList("FROM Country where id = '" + countryId + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCountry():  " + ex);
		}
		return item;
	}

	public Country getNationality(String nationalityCode) {
		Country item = null;
		try {
			List<Country> list = getList("FROM Country where nationalityCode = '" + nationalityCode + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in getNationality():  " + ex);
		}
		return item;
	}

	public List<CustomerDocumentDetails> getCustomerDocumentDetails(int customerId) {
		List<CustomerDocumentDetails> list = null;
		try {
			 list = getList("FROM CustomerDocumentDetails where customer.id = '"
					+ customerId + "' AND documentStatus.status !='" + DocumentStatusTypes.DELETED + "'");
		} catch (Exception ex) {
			getLogger().error("Exception occured in getCustomerDocumentDetails():  " + ex);
		}
		return list;
	}

	public CustomerDocumentDetails getCustomerDocumentDetails(int customerId, String docType) {
		CustomerDocumentDetails item = null;
		try {
			List<CustomerDocumentDetails> list = getList("FROM CustomerDocumentDetails where customer.id = '"
					+ customerId + "' AND docType='" + docType + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerDocumentDetails():  " + ex);
		}
		return item;
	}

	public List<CustomerTaxDetails> getCustomerTaxDetails(int customerId) {

		List<CustomerTaxDetails> list = null;
		try {
			list = getList("FROM CustomerTaxDetails where customer.id = '" + customerId + "'");

			return list;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerTaxDetails():  " + ex);
		}
		return list;
	}

	public Enquiry getCustomerEnquiryDetails(int customerId) {
		Enquiry item = null;
		try {
			List<Enquiry> list = getList("FROM Enquiry where customerId = '" + customerId + "' order by id desc");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerEnquiryDetails():  " + ex);
		}
		return item;
	}

	public Assets getCustomerAssetDetails(int customerId) {
		Assets item = null;
		try {
			List<Assets> list = getList("FROM Assets where customerId = '" + customerId + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerAssetDetails():  " + ex);
		}
		return item;
	}

	public Liabilities getCustomerLiabilitiesDetails(int customerId) {
		Liabilities item = null;
		try {
			List<Liabilities> list = getList("FROM Liabilities where customerId = '" + customerId + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerLiabilitiesDetails():  " + ex);
		}
		return item;
	}

	@Override
	public Income getCustomerIncomeDetails(int customerId) {
		Income income = null;
		try {
			List<Income> incomeDetails = getList("FROM Income where customerId = '" + customerId + "'");
			if (incomeDetails != null && !incomeDetails.isEmpty()) {
				income = incomeDetails.get(0);
			}
			return income;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerIncomeDetails():  " + ex);
		}
		return income;
	}

	@Override
	public Customer getCustomer(int customerId) {
		Customer customer = null;
		try {
			List<Customer> customers = getList("FROM Customer where id = '" + customerId + "'");
			if (customers != null && !customers.isEmpty()) {
				customer = customers.get(0);
			}
			return customer;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomer():  " + ex);
		}
		return customer;
	}

	@Override
	public void updateCustomer(Customer customer) {
		try {
			update(customer);
		} catch (Exception ex) {
			getLogger().error("Exception occured while updateCustomer():  " + ex);
		}
	}

	@Override
	public CustomerEmploymentInformation getCustomerEmploymentInformation(int customerId) {
		CustomerEmploymentInformation employmentInfo = new CustomerEmploymentInformation();
		CustomerEmploymentDetails employmentDetails = null;
		EmployerDetails employerDetails = null;
		EmployerAddress employerAddress = null;

		try {
			// Get employment details
			List<CustomerEmploymentDetails> employmentInfoList = getList(
					"FROM CustomerEmploymentDetails where customerId = '" + customerId + "'");
			if (employmentInfoList != null && !employmentInfoList.isEmpty()) {
				employmentDetails = employmentInfoList.get(0);
			}
			// Get employer details
			if (employmentDetails != null) {
				List<EmployerDetails> employerDetailsList = getList(
						"FROM EmployerDetails where id = '" + employmentDetails.getEmployerId() + "'");
				if (employerDetailsList != null && !employerDetailsList.isEmpty()) {
					employerDetails = employerDetailsList.get(0);
				}

				List<EmployerAddress> employerAddressList = getList(
						"FROM EmployerAddress where employerId = '" + employmentDetails.getEmployerId() + "'");
				if (employerAddressList != null && !employerAddressList.isEmpty()) {
					employerAddress = employerAddressList.get(0);
				}
			}
			if (employerDetails != null)

				employmentInfo.setCustomerEmploymentDetails(employmentDetails);
			employmentInfo.setEmployerDetails(employerDetails);
			employmentInfo.setEmployerAddress(employerAddress);
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerEmploymentInformation():  " + ex);
		}
		return employmentInfo;
	}

	@Override
	public void saveOrUpdateDetails(Object details) {
		try {
			saveOrUpdate(details);
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.saveOrUpdateDetails():  " + ex);
		}
	}

	@Override
	public DAOResponse mapCustomerToEnquiry(int customerId, int enquiryId) {
		DAOResponse response = new DAOResponse();
		response.setSuccess(true);
		try {
			Enquiry enquiry = (Enquiry) getFirst("FROM Enquiry WHERE id = " + enquiryId);
			if (enquiry != null) {
				enquiry.setCustomerId(customerId);
				update(enquiry);
				response.setMessage("Enquiry successfully mapped to the customer");
			} else {
				response.setSuccess(false);
				response.setMessage("Invalid enquiryId");
			}
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setMessage("Error in mapping enquiry to the customer");
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.mapCustomerToEnquiry():  " + ex);
		}
		return response;
	}

	@Override
	public void saveOrUpdateAddress(Address address) {
		try {
			saveOrUpdate(address);
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.saveOrUpdateAddress():  " + ex);
		}
	}

	@Override
	public Integer insertDetails(String query) {
		int id = 0;

		try {
			List<Integer> list = getList(query);
			if (list != null && !list.isEmpty())
				id = list.get(0);
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.insertDetails():  " + ex);
		}
		return id;
	}

	@Override
	public OptionItem getCustomerEmploymentStatus(Integer employmentStatusId) {

		OptionItem item = null;
		try {
			List<OptionItem> list = getList("FROM OptionItem where id = '" + employmentStatusId + "' order by id desc");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerEmploymentStatus():  " + ex);
		}
		return item;
	}

	@Override
	public List<Customer> getCustomerByAdvisor(int adviserId) {

		List<Customer> customer = null;
		try {
			customer = getList("FROM Customer where advisorId = '" + adviserId + "'");

			return customer;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerByAdvisor():  " + ex);
		}
		return customer;

	}

	@Override
	public List<CustomerIFastAccount> customerSearch(AdminSearchRequestDTO searchRequest) {
		// TODO Auto-generated method stub
		List<Customer> customer = null;
		List<String> conditions = new ArrayList<>();

		String fieldPrefix = "customer.";
		if (searchRequest.getiFastRefNo() != null && !searchRequest.getiFastRefNo().isEmpty()) {
			fieldPrefix = "customer.";
		}
		if (searchRequest.getMobileNumber() != null && !searchRequest.getMobileNumber().isEmpty()) {
			conditions.add(fieldPrefix + "mobileNumber = '" + searchRequest.getMobileNumber() + "'");
		}

		if (searchRequest.getEmailId() != null && !searchRequest.getEmailId().isEmpty()) {
			conditions.add(fieldPrefix + "email = '" + searchRequest.getEmailId() + "'");
		}
		if (searchRequest.getCustomerName() != null && !searchRequest.getCustomerName().isEmpty()) {
			conditions.add(fieldPrefix + "nricName = '" + searchRequest.getEmailId() + "'");
		}

		if (searchRequest.getMoCustomerId() != null && searchRequest.getMoCustomerId() > 0) {
			conditions.add(fieldPrefix + " id = '" + searchRequest.getMoCustomerId() + "'");
		}
		String whereClause = "";
		for (String cond : conditions) {
			if (whereClause != "") {
				whereClause += " AND ";
			}
			whereClause += cond;

		}
		List<CustomerIFastAccount> customerIFastDetailsList = null;

		try {
			customerIFastDetailsList = getList("FROM CustomerIFastAccount where " + whereClause);
			customer = customerIFastDetailsList.stream().map(a -> a.getCustomer()).collect(Collectors.toList());
			return customerIFastDetailsList;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.customerSearch():  " + ex);
		}

		return customerIFastDetailsList;
	}

	@Override
	public Expenses getCustomerExpenses(Integer id) {
		Expenses item = null;
		try {
			List<Expenses> list = getList("FROM Expenses where customerId = '" + id + "'");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerExpenses():  " + ex);
		}
		return item;
	}

	@Override
	public CustomerLiabilitiesDetail getCustomerLiabilityDetailByEnquiryId(Integer customerId) {
		CustomerLiabilitiesDetail item = null;
		try {
			List<CustomerLiabilitiesDetail> list = getList("FROM CustomerLiabilitiesDetail where customerId = '"
					+ customerId + "' order by enquiryId desc");
			if (list != null && !list.isEmpty()) {
				item = list.get(0);
			}
			return item;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerLiabilityDetailByEnquiryId():  " + ex);
		}
		return item;
	}

	@Override
	public List<Income> getCustomerIncomeDetailsList(int customerId) {
		 List<Income> incomeDetails =null;
		try {
			 incomeDetails = getList("FROM Income where customerId = '" + customerId + "'");
			
			return incomeDetails;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerIncomeDetailsList():  " + ex);
		}
		return incomeDetails;
		
	}

	@Override
	public Income getCustomerIncomeByEnquiryId(int enquiryId) {
		Income income = null;
		try {
			List<Income> incomeDetails = getList("FROM Income where enquiryId = '" + enquiryId + "'");
			if (incomeDetails != null && !incomeDetails.isEmpty()) {
				income = incomeDetails.get(0);
			}
			return income;
		} catch (Exception ex) {
			getLogger().error("Exception occured in InvestmentAccountDaoImpl.getCustomerIncomeByEnquiryId():  " + ex);
		}
		return income;
	}
   
	@Override
	public CustomerSrsAccount getCustomerSrsBankbyId(Integer customerId) {
		return (CustomerSrsAccount) getFirst("FROM  CustomerSrsAccount where customerId='" + customerId + "' order by id desc");
	}

	@Override
	public CustomerInvestmentObjective getCustomerInvestmentObjective(Integer customerId, Integer enquiryId) {
		CustomerInvestmentObjective customerInvetmentObjective = null;
		Map<String,Object> parameters = new HashMap<>();
		parameters.put("customerId", customerId);
		parameters.put("enquiryId", enquiryId);
		customerInvetmentObjective = (CustomerInvestmentObjective) getFirst("FROM CustomerInvestmentObjective where enquiry.customerId = :customerId AND enquiry.id = :enquiryId", parameters);
		return customerInvetmentObjective;
	}

}

package com.bfa.insurance.core;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author RethinavelMoorthy.S
 *
 */
@Entity
@Table(name = "previlege_master")

public class PrevilageMaster {

	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int previlegeId;

	@Column(name = "previlege_name")
	private String PrvilegeName;

	@Column(name = "description")
	private String description;

	public int getPrevilegeId() {
		return previlegeId;
	}

	public void setPrevilegeId(int previlegeId) {
		this.previlegeId = previlegeId;
	}

	public String getPrvilegeName() {
		return PrvilegeName;
	}

	public void setPrvilegeName(String prvilegeName) {
		PrvilegeName = prvilegeName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}

/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.core.DependentMapping;

/**
 * @author pradheep.p
 *
 */
public class DependentMappingRequest {
	
	private List<DependentMapping> dependentMappingList;
	
	private String sessionId;

	public List<DependentMapping> getDependentMappingList() {
		return dependentMappingList;
	}

	public void setDependentMappingList(List<DependentMapping> dependentMappingList) {
		this.dependentMappingList = dependentMappingList;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
}

package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author DivakarU
 *
 */
@Entity
@Table(name = "vw_fund_units")
public class FundUnits {
	
	@Id
	@Column(name = "id")
	private int id;
	

	private String fundId;
	

	private Integer fundRefId;
	

	private Double totalUnits;
	
	private Double amount;
	

	private Integer customerId;
	

	private Integer portfolioId;
	

	private Date transactionCompletedDate;
	
	
	private Integer portfolioTransactionId;

	
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	/**
	 * @return the fundId
	 */
	public String getFundId() {
		return fundId;
	}
	/**
	 * @param fundId the fundId to set
	 */
	public void setFundId(String fundId) {
		this.fundId = fundId;
	}
	/**
	 * @return the fundRefId
	 */
	public Integer getFundRefId() {
		return fundRefId;
	}
	/**
	 * @param fundRefId the fundRefId to set
	 */
	public void setFundRefId(Integer fundRefId) {
		this.fundRefId = fundRefId;
	}
	/**
	 * @return the totalUnits
	 */
	public Double getTotalUnits() {
		return totalUnits;
	}
	/**
	 * @param totalUnits the totalUnits to set
	 */
	public void setTotalUnits(Double totalUnits) {
		this.totalUnits = totalUnits;
	}
	/**
	 * @return the transactionCompletedDate
	 */
	public Date getTransactionCompletedDate() {
		return transactionCompletedDate;
	}
	/**
	 * @param transactionCompletedDate the transactionCompletedDate to set
	 */
	public void setTransactionCompletedDate(Date transactionCompletedDate) {
		this.transactionCompletedDate = transactionCompletedDate;
	}
	/**
	 * @return the customerId
	 */
	public Integer getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the portfolioId
	 */
	public Integer getPortfolioId() {
		return portfolioId;
	}
	/**
	 * @param portfolioId the portfolioId to set
	 */
	public void setPortfolioId(Integer portfolioId) {
		this.portfolioId = portfolioId;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	public Integer getPortfolioTransactionId() {
		return portfolioTransactionId;
	}
	public void setPortfolioTransactionId(Integer portfolioTransactionId) {
		this.portfolioTransactionId = portfolioTransactionId;
	}

}


package com.bfa.investment.dto;

import java.util.List;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.entity.CustomerPortfolio;

public class InvestementDashboardStatusDTO {

	private Boolean isPoliticallyExposed;
	private Boolean beneficialOwner;
	private Boolean connectedToInvestmentFirm;
	private List<CustomerPortfolioDTO> portfolios;
	private CustomerIFasteAccountDTO account;
	private Double totalValue;
	private Double totalReturns;
	private Double investmentReturns;
	private Double totalInvested;
	private Boolean myInfoVerified;
	private Boolean showTotalReturn;
	private Double totalCashAccountBalance;
	private Double wisesaverTotalValue;
	private Double wisesaverTotalCashAccountBalance;
	private Double wisesaverTotalInvested;
	private Double overallPortfolioValue;
	private Double overallCashAccountBalance;
	private String portfolioType;
	
	
	public Double getTotalCashAccountBalance() {
		return totalCashAccountBalance;
	}

	public void setTotalCashAccountBalance(Double totalCashAccountBalance) {
		this.totalCashAccountBalance = totalCashAccountBalance;
	}

	

	public Boolean getShowTotalReturn() {
		return showTotalReturn;
	}

	public void setShowTotalReturn(Boolean showTotalReturn) {
		this.showTotalReturn = showTotalReturn;
	}

	public Boolean getIsPoliticallyExposed() {
		return isPoliticallyExposed;
	}

	public void setIsPoliticallyExposed(Boolean isPoliticallyExposed) {
		this.isPoliticallyExposed = isPoliticallyExposed;
	}

	public Boolean getBeneficialOwner() {
		return beneficialOwner;
	}

	public void setBeneficialOwner(Boolean beneficialOwner) {
		this.beneficialOwner = beneficialOwner;
	}

	public Boolean getConnectedToInvestmentFirm() {
		return connectedToInvestmentFirm;
	}

	public void setConnectedToInvestmentFirm(Boolean connectedToInvestmentFirm) {
		this.connectedToInvestmentFirm = connectedToInvestmentFirm;
	}

	public List<CustomerPortfolioDTO> getPortfolios() {
		return portfolios;
	}

	public void setPortfolios(List<CustomerPortfolioDTO> portfolios) {
		this.portfolios = portfolios;
	}

	public CustomerIFasteAccountDTO getAccount() {
		return account;
	}

	public void setAccount(CustomerIFasteAccountDTO account) {
		this.account = account;
	}

	public Double getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(Double totalValue) {
		this.totalValue = totalValue;
	}

	public Double getTotalReturns() {
		return totalReturns;
	}

	public void setTotalReturns(Double totalReturns) {
		this.totalReturns = totalReturns;
	}

	public Double getInvestmentReturns() {
		return investmentReturns;
	}

	public void setInvestmentReturns(Double investmentReturns) {
		this.investmentReturns = investmentReturns;
	}

	public Double getTotalInvested() {
		return totalInvested;
	}

	public void setTotalInvested(Double totalInvested) {
		this.totalInvested = totalInvested;
	}

	public Boolean getMyInfoVerified() {
		return myInfoVerified;
	}

	public void setMyInfoVerified(Boolean myInfoVerified) {
		this.myInfoVerified = myInfoVerified;
	}
	

	public Double getWisesaverTotalValue() {
		return wisesaverTotalValue;
	}

	public void setWisesaverTotalValue(Double wisesaverTotalValue) {
		this.wisesaverTotalValue = wisesaverTotalValue;
	}

	public Double getWisesaverTotalCashAccountBalance() {
		return wisesaverTotalCashAccountBalance;
	}

	public void setWisesaverTotalCashAccountBalance(Double wisesaverTotalCashAccountBalance) {
		this.wisesaverTotalCashAccountBalance = wisesaverTotalCashAccountBalance;
	}

	public Double getWisesaverTotalInvested() {
		return wisesaverTotalInvested;
	}

	public void setWisesaverTotalInvested(Double wisesaverTotalInvested) {
		this.wisesaverTotalInvested = wisesaverTotalInvested;
	}
	
	public Double getOverallPortfolioValue() {
		return overallPortfolioValue;
	}

	public void setOverallPortfolioValue(Double overallPortfolioValue) {
		this.overallPortfolioValue = overallPortfolioValue;
	}

	public Double getOverallCashAccountBalance() {
		return overallCashAccountBalance;
	}

	public void setOverallCashAccountBalance(Double overallCashAccountBalance) {
		this.overallCashAccountBalance = overallCashAccountBalance;
	}
	
	

	public String getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(String portfolioType) {
		this.portfolioType = portfolioType;
	}

	@Override
	public String toString() {
		return "InvestementDashboardStatusDTO [isPoliticallyExposed=" + isPoliticallyExposed + ", beneficialOwner="
				+ beneficialOwner + ", connectedToInvestmentFirm=" + connectedToInvestmentFirm + ", portfolios="
				+ portfolios + ", account=" + account + ", totalValue=" + totalValue + ", totalReturns=" + totalReturns
				+ ", investmentReturns=" + investmentReturns + ", totalInvested=" + totalInvested + ", myInfoVerified="
				+ myInfoVerified + ", showTotalReturn=" + showTotalReturn + ", getShowTotalReturn()="
				+ getShowTotalReturn() + ", getIsPoliticallyExposed()=" + getIsPoliticallyExposed()
				+ ", getBeneficialOwner()=" + getBeneficialOwner() + ", getConnectedToInvestmentFirm()="
				+ getConnectedToInvestmentFirm() + ", getPortfolios()=" + getPortfolios() + ", getAccount()="
				+ getAccount() + ", getTotalValue()=" + getTotalValue() + ", getTotalReturns()=" + getTotalReturns()
				+ ", getInvestmentReturns()=" + getInvestmentReturns() + ", getTotalInvested()=" + getTotalInvested()
				+ ", getMyInfoVerified()=" + getMyInfoVerified() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}

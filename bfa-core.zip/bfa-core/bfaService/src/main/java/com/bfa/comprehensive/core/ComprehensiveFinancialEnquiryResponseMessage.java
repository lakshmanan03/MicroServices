
package com.bfa.comprehensive.core;

import java.util.List;

import com.bfa.request.entity.ComprehensiveFinancialEnquiryPostResponse;
import com.bfa.util.ResponseMessage;

public class ComprehensiveFinancialEnquiryResponseMessage {

	private ResponseMessage responseMessage;

	private List<ComprehensiveFinancialEnquiryPostResponse> objectList;

	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<ComprehensiveFinancialEnquiryPostResponse> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<ComprehensiveFinancialEnquiryPostResponse> objectList) {
		this.objectList = objectList;
	}

	

}

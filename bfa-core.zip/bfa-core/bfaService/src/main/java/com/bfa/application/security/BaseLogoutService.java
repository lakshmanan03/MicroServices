/**
 * 
 */
package com.bfa.application.security;

import java.util.HashMap;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.common.entity.TokenValidityRequest;
import com.bfa.common.entity.TokenValidityResponse;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

/**
 * @author pradheep.p
 *
 */
public class BaseLogoutService extends DiscoveryHelper implements LogoutService {

	private String API_NAME = "/api/isAlreadyLogout";

	@Autowired
	private BFAHttpClient bfaHttpClient;

	@Autowired
	private Environment environment;


	private String apiURL = "";

	/**
	 * Make a service call to find if the given token is black listed.
	 */
	@Override
	public String isTokenBlackListed(String token) throws Exception {
		init();
		return isBlackListed(token);
	}

	private String isBlackListed(String token) {
		loadSecurityHeader(SecurityConstants.TOKEN_NAME);
		HashMap header = super.header;
		Gson gson = new Gson();
		TokenValidityRequest request = new TokenValidityRequest();
		request.setToken(token);
		String requestBody = gson.toJson(request);
		System.out.println("---------------------------------------------------");
		System.out.println("Printing the request body :" + requestBody);
		System.out.println("Printing the API URL :" + apiURL);
		System.out.println("---------------------------------------------------");
		BFAHttpResponse response = bfaHttpClient.doPostCall(requestBody, apiURL, header, null);
		if (response.getResponseCode() == 200) {
			String responseObj = response.getResponseBody();
			String jsonFormated = "";
			if (responseObj.contains("objectList")) {
				int beginIndex = responseObj.indexOf("[");
				int endIndex = responseObj.indexOf("]");
				jsonFormated = responseObj.substring(beginIndex + 1, endIndex);
			}
			TokenValidityResponse tvResponse = gson.fromJson(jsonFormated, TokenValidityResponse.class);
			System.out.println("Printing the response :" + jsonFormated);
			System.out.println("--- " + gson.toJson(tvResponse));
			if (tvResponse != null) {
				String bListTokenResponse = tvResponse.getReason();
				return bListTokenResponse;
			}
			return BaseLogoutService.NOT_BLACKLISTED;
		}
		if (response.getResponseCode() == 403) {
			System.out.println("Error - 403" + response.getResponseBody());
			return "";
		} else {
			System.out.println("Unable to get response from " + API_NAME);
			return BaseLogoutService.NOT_BLACKLISTED;
		}

	}

	private void init() {
		setEnvironment(this.environment);
		setAPIURL();
	}

	private void setAPIURL() {
		String baseUrl = getBaseUrl(ServiceNames.ACCOUNT_MICROSERVICE) + API_NAME;
		apiURL = removePortNumbers(baseUrl);
		System.out.println("Printing the API URL :" + apiURL);
	}

	public static void main(String args[]) {
		String arg = "{\"responseMessage\":{\"responseCode\":6000,\"responseDescription\":\"Successful response\"},\"objectList\":[{\"tokenBlackListed\":false}]}";
		
		System.out.println(arg.length());
		int x = arg.indexOf("[");
		System.out.println(x);
		int y = arg.indexOf("]");
		System.out.println(y);
		System.out.println(arg.substring(x + 1, y));
	}
}

/**
 * 
 */
package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
public class OTPVerificationResponse {

	/**
	 * This flag is used for setting the status of the OTP verification.
	 */
	@JsonIgnore
	private boolean verified;

	/**
	 * This code is provided for setting the password for user.
	 */

	private String resetCode;

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public String getResetCode() {
		return resetCode;
	}

	public void setResetCode(String resetCode) {
		this.resetCode = resetCode;
	}

}

package com.bfa.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.bfa.admin.dto.AdminCustomerDetails;
import com.bfa.admin.dto.AdminCustomerSummary;
import com.bfa.admin.dto.AdminSearchRequestDTO;
import com.bfa.application.core.AccountStatus;
import com.bfa.application.core.AuthenticationErrorResponse;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.core.CustomerAndPrevilegeV2;
import com.bfa.application.core.CustomerPreference;
import com.bfa.application.core.UpdateMobileNumberRequest;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.exception.NoSuchUserException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.CustomerProfileDetails;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.UpdateContactDetailsDTO;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Advisor;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.CustomerOverview;
import com.bfa.common.entity.CustomerSrsAccount;
import com.bfa.insurance.core.CRMResponse;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.EmploymentStatusMaster;
import com.bfa.insurance.core.Profile;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.insurance.product.ProductList;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.dto.CustomerSrsAccountDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.UpdatePasswordDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.ifast.dto.DetailedCustomerSummary;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.request.entity.CustomerCreationPostRequestV2;
import com.bfa.util.ServiceResponse;

public interface AccountsService {	

	public List<Profile> getProfileList() throws DatabaseAccessException;

	public List<EmploymentStatusMaster> getEmploymentList() throws DatabaseAccessException;

	public void saveDependents(List<DependentMapping> dependents) throws DatabaseAccessException;

	public BFAUserDetails getUserByEmail(String email) throws DatabaseAccessException, NoSuchUserException;

	public BFAUserDetails getUserById(Integer customerId) throws DatabaseAccessException, NoSuchUserException;

	public ProfileSummaryDTO getProfileSummary(String email);

	public ProfileSummaryDTO getProfileSummaryById(Integer customerId);

	public SessionDetails saveSessionDetails(HttpServletRequest request) throws DatabaseAccessException;

	public CustomerAndPrevilege signup(CustomerCreationPostRequest customer) throws DatabaseAccessException;

	public String validateUser(CustomerCreationPostRequest customer);

	public String getAuthToken(Customer customer, List<BFAGrandtedAuthority> authorities);

	public List<BFAGrandtedAuthority> getAuthorities(Customer customer);

	public void updateCustomerInformation(int enquiryId, Customer customerObj, List<ProductList> selectedProducts,
			boolean isNewCustomer);

	public boolean isOTPValid(String customerRef, String OTPString) throws DatabaseAccessException, NoSuchUserException;

	public String encryptUserResponseData(String toBeEncrypted);

	public boolean updatePassword(String customerRef, String password)
			throws DatabaseAccessException, NoSuchUserException;

	public void updateCRMDetailsOfCustomer(CRMResponse crmAndCustomerData) throws DatabaseAccessException;

	public Customer updateCustomerdetails(int enquiryId, String customerId, List<ProductList> selectedProducts);

	public Customer getCustomerDetails(String email);

	public Customer getDetailsByCustomerId(Integer customerId);

	public String updateCustomerAddress(Integer customerId, Integer advisorId, UpdateCustomerAddressDTO updateCustomerAddress);

	public boolean editPassword(Customer customerDetails, UpdatePasswordDTO newPasswordDetails);

	public CustomerContactVerification editContactDetails(ContactDetailsDTO updateCustomercontact, Integer customerId);

	public void updateEmployment(Customer customerDetails, EmploymentDetailsDTO employmentDetails);

	public CustomerPreference getTrackStatus(Integer customerId, String trackCode);
		
	public ServiceResponse<Boolean> setTrackStatus(Integer customerId, Boolean check, String trackCode);
	
	CustomerAdditionalDetails getCustomerAdditionalDetails(Integer customerId);

	void updateCustomerAdditionalDetails(CustomerAdditionalDetails additionalInfo);

	ServiceResponse<Map<String, String>> saveCustomerDetails(CustomerDetailsDTO accountDetails, Integer customerId);

	ServiceResponse<Map<String, String>> saveDocument(Integer customerId, MultipartFile uploadedFile, String type);

	ServiceResponse<Map<String, String>> saveDocumentV2(Integer customerId, HttpServletRequest servletRequest,
			String type);

	boolean deleteDocument(Integer customerId, String docType);

	DetailedCustomerSummary getDetailedCustomerSummary(Integer customerId, Integer enquiryId);

	CustomerProfileDetails getCustomerDetailsById(Integer customerId);

	Customer getCustomer();

	List<CustomerBankDetail> getCustomerBankDetails(Integer customerId);
	
	CustomerSrsAccount getCustomerSrsBankDetails(Integer customerId);

	CustomerBankDetail saveCustomerBankDetail(CustomerBankDetail bank);

	Map<String, Address> getCustomerAddresses(Integer customerId);

	public String validateNewMobileNumber(String mobileNumber);

	public String validateNewEmail(String emailId);

	public ServiceResponse<Boolean> updateCustomerContactDetails(Integer customerId, ContactDetailsDTO contactDetails,
			HttpServletRequest servletRequest);

	public InvestementDashboardStatusDTO getInvestmentDashboardStatus(Integer customerId);

	public ProfileSummaryDTO getCustomerProfileDetails(String email);

	public ProfileSummaryDTO getCustomerProfileDetails(Integer customerId);

	public List<AdminCustomerDetails> getCustomerSummaryByAdvisor(int id);

	public List<CustomerOverview> findCustomers(AdminSearchRequestDTO searchRequest);

	public AdminCustomerDetails fetchIndividualCustomerDetails(Integer customerId, Integer advisorId);

	public AdminCustomerSummary fetchCustomerSummary(Integer customerId, Integer advisorId);

	public Customer addAdvisor(int customerId, int advisorId);

	public Advisor getAdvisorbyId(Integer custId);

	public AuthenticationErrorResponse validateUserV2(CustomerCreationPostRequestV2 customer);

	public CustomerAndPrevilegeV2 signupV2(CustomerCreationPostRequestV2 customer) throws DatabaseAccessException;

	public void updateCustomerInformationV2(int enquiryId, Customer customerObj, boolean isNewCustomer);

	public boolean doesMobileExistsForOtherCustomer(String mobileNumber, int enquiryId);

	public boolean doesEmailExistsForOtherCustomer(String email, int enquiryId);
	
	public void sendOTP(String contactNumber, String countryCode, String otp, boolean isResend);

	public boolean reIssueOTP(String customerRef, Integer customerId);

	public void sendContactUsEmail(String toEmail, String subject, String body, String custEmail, String custContactNo);

	public void sendEmail(Customer customerObj);
	
	public void updateMobileAndEmailUniqueness(String mobileNumber,String emailAddress, AccountStatus accountStatus);

	public String encryptCustomerId(String toBeEncrypted);

	public ServiceResponse<Boolean> updateMobileNumber(UpdateMobileNumberRequest updateMobileNumberRequest);
	public ServiceResponse<Boolean> saveCustomerSrsBankDetail(Integer customerPortfolioId,CustomerSrsAccountDTO srsDetailsRequest,Integer customerId);
	
	public String generateOTP();
	
	public void updateCustomer(Customer customerObj);
}

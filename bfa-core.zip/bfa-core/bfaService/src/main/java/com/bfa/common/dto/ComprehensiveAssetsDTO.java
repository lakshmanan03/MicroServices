/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;
import java.util.Set;

import com.bfa.comprehensive.dto.AssetsInvestmentSet;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveAssetsDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private Integer customerId;

	private Integer enquiryId;

	private Double cashInBank;

	private Double savingsBonds;

	private Double cpfOrdinaryAccount;

	private Double cpfSpecialAccount;

	private Double cpfMediSaveAccount;
	
	private Double cpfRetirementAccount;
	
	private String schemeType;
	
	private Integer estimatedPayout;
	
	private Integer topupAmount;
	
	private Integer withdrawalAmount;
	
	private Integer retirementSum;

	private Double homeMarketValue;

	private Double investmentPropertiesValue;

	private Set<AssetsInvestmentSet> assetsInvestmentSet;

	private Double otherAssetsValue;
	
	private String source;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Double getCashInBank() {
		return cashInBank;
	}

	public void setCashInBank(Double cashInBank) {
		this.cashInBank = cashInBank;
	}

	public Double getSavingsBonds() {
		return savingsBonds;
	}

	public void setSavingsBonds(Double savingsBonds) {
		this.savingsBonds = savingsBonds;
	}

	public Double getCpfOrdinaryAccount() {
		return cpfOrdinaryAccount;
	}

	public void setCpfOrdinaryAccount(Double cpfOrdinaryAccount) {
		this.cpfOrdinaryAccount = cpfOrdinaryAccount;
	}

	public Double getCpfSpecialAccount() {
		return cpfSpecialAccount;
	}

	public void setCpfSpecialAccount(Double cpfSpecialAccount) {
		this.cpfSpecialAccount = cpfSpecialAccount;
	}

	public Double getCpfMediSaveAccount() {
		return cpfMediSaveAccount;
	}

	public void setCpfMediSaveAccount(Double cpfMediSaveAccount) {
		this.cpfMediSaveAccount = cpfMediSaveAccount;
	}

	public Double getHomeMarketValue() {
		return homeMarketValue;
	}

	public void setHomeMarketValue(Double homeMarketValue) {
		this.homeMarketValue = homeMarketValue;
	}

	public Double getInvestmentPropertiesValue() {
		return investmentPropertiesValue;
	}

	public void setInvestmentPropertiesValue(Double investmentPropertiesValue) {
		this.investmentPropertiesValue = investmentPropertiesValue;
	}

	public Double getOtherAssetsValue() {
		return otherAssetsValue;
	}

	public void setOtherAssetsValue(Double otherAssetsValue) {
		this.otherAssetsValue = otherAssetsValue;
	}

	public Set<AssetsInvestmentSet> getAssetsInvestmentSet() {
		return assetsInvestmentSet;
	}

	public void setAssetsInvestmentSet(Set<AssetsInvestmentSet> assetsInvestmentSet) {
		this.assetsInvestmentSet = assetsInvestmentSet;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Double getCpfRetirementAccount() {
		return cpfRetirementAccount;
	}

	public void setCpfRetirementAccount(Double cpfRetirementAccount) {
		this.cpfRetirementAccount = cpfRetirementAccount;
	}

	public String getSchemeType() {
		return schemeType;
	}

	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}

	public Integer getEstimatedPayout() {
		return estimatedPayout;
	}

	public void setEstimatedPayout(Integer estimatedPayout) {
		this.estimatedPayout = estimatedPayout;
	}

	public Integer getRetirementSum() {
		return retirementSum;
	}

	public void setRetirementSum(Integer retirementSum) {
		this.retirementSum = retirementSum;
	}

	public Integer getTopupAmount() {
		return topupAmount;
	}

	public void setTopupAmount(Integer topupAmount) {
		this.topupAmount = topupAmount;
	}

	public Integer getWithdrawalAmount() {
		return withdrawalAmount;
	}

	public void setWithdrawalAmount(Integer withdrawalAmount) {
		this.withdrawalAmount = withdrawalAmount;
	}
}

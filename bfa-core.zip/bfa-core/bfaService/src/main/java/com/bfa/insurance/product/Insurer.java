/**
 * 
 */
package com.bfa.insurance.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name="insurer")
public class Insurer {

	
	@Id
	@GenericGenerator(name="bfa" , strategy="increment")
	@GeneratedValue(generator="bfa")
	@Column(name = "insurer_id")
	private String id;
	
	@Column(name="insurer_name")
	private String insurerName;
	
	@Column(name="logo")
	private String logoName;
	
	@Column(name="url")
	private String url;
	
	@JsonIgnore
	@Column(name="last_update")
	private Date lastUpdatedTime;
	
	@Column(name="rating")
	private String rating;
	
	@JsonIgnore
	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	
	public String getInsurerName() {
		return insurerName;
	}

	public void setInsurerName(String insurerName) {
		this.insurerName = insurerName;
	}

	public String getLogoName() {
		return logoName;
	}

	public void setLogoName(String logoName) {
		this.logoName = logoName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Date getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(Date lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}

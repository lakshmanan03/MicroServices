/**
 * 
 */
package com.bfa.serviceimpl;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.condition.ConditionsReportEndpoint.ApplicationConditionEvaluation;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.request.entity.ads.RetirementPlanningModel;
import com.bfa.service.RetirementLeadService;
import com.bfa.util.ApplicationConstants;

/**
 * 
 * @author pradheep
 * 
 * @since Release 4.0
 *
 */
public class RetirementServiceImpl implements RetirementLeadService {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private DelegateHandler delegateHandler;

	@Autowired
	private Environment environment;

	private String email_template = "retirement_lead.template";
	
	private final String dateFormat = "yyyy-MM-dd";

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	/**
	 * Generic function to update the data in CRM.
	 */
	@Override
	public void updateDataInCRM(Object obj) {
		if (obj instanceof RetirementPlanningModel) {
			RetirementPlanningModel retirementPlanningModel = (RetirementPlanningModel) obj;
			getLogger().info("Updating the data in CRM :" + retirementPlanningModel.toString());
			delegateHandler.updateCRMForRetirementLeads(retirementPlanningModel);
		}
	}

	/**
	 * Sends an email communication to the advisors about the leads.
	 */
	@Override
	public void notifyAdvisors(Object obj) {
		getLogger().info("---Notifying the advisors.---");
		if (obj instanceof RetirementPlanningModel) {
			RetirementPlanningModel retirementPlanningModel = (RetirementPlanningModel) obj;
			String fromEmail = environment.getProperty("email.notification.address");
			String toEmail = environment.getProperty("email.enquiries.address");
			String templateName = "bundle_enquiry.template";
			String category = RetirementLeadService.RETIREMENT_PLAN_CATEGORY;
			String email_subject = RetirementLeadService.RETIREMENT_PLAN_EMAIL_SUBJECT;
			Map<String, String> params = new HashMap<String, String>();
			params.put("body", getEmailBody(retirementPlanningModel, category));
			if (isNonProduction()) {
				String[] ccList = new String[1];
				ccList[0] = environment.getProperty("email.dev.support.address");
				// Copy the email to dev support for testing purposes //
				delegateHandler.sendEmail(fromEmail, toEmail, email_subject, templateName, params, ccList);
			} else {
				delegateHandler.sendEmail(fromEmail, toEmail, email_subject, templateName, params);
			}
		}
	}

	/* To check and send email for lower environments */
	private boolean isNonProduction() {
		String[] profiles = environment.getActiveProfiles();
		for (int i = 0; i < profiles.length; i++) {
			if (profiles[i].toLowerCase().contains("pro")) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Prepares the email content for the advisors.
	 * 
	 * @param RetirementPlanningModel
	 * @param Subject
	 *            of the email
	 * @return Email Body as String
	 */
	private String getEmailBody(RetirementPlanningModel model, String subject) {

		String emailContent = readEmailTemplate();
		/* BFA-1744 */
		/* Full name of the user */ 
		emailContent = emailContent.replace("applicant_full_name_var", model.getFirstName() + " " + model.getLastName()); 

		emailContent = emailContent.replace("email_subject_var", subject); // Email Subject

		emailContent = emailContent.replace("applicant_first_name_var", model.getFirstName()); // First Name

		emailContent = emailContent.replace("applicant_last_name_var", model.getLastName()); // Last Name

		emailContent = emailContent.replace("dobPrefix_var", "Date of birth"); // Date of birth Prefix

		emailContent = emailContent.replace("applicant_date_of_birth_var", model.getDateOfBirth()); // Date of birth

		emailContent = emailContent.replace("applicant_email_address_var", model.getEmailAddress()); // Email Address

		emailContent = emailContent.replace("applicant_mobile_number_var", model.getMobileNumber()); // Mobile Number

		/* Retirement  Age */
		emailContent = emailContent.replace("applicant_retirement_age_var", String.valueOf(model.getRetirementAge())); 

		/* Retirement Income */
		emailContent = emailContent.replace("retirement_income_monthly_var", printCurrencyFormat(model.getMonthlyRetirementIncome())); 

		/* Retirement Lumpsum amount */
		emailContent = emailContent.replace("retirement_available_lumpsum_var", printCurrencyFormat(model.getLumpSumAmount())); 

		/* Monthly desired amount */
		emailContent = emailContent.replace("retirement_available_monthly_amount_var", printCurrencyFormat(model.getMonthlyAmount()));									

		Iterator<String> retirementSchemeIterator = model.getRetirementSchemeList().iterator();

		StringBuffer retirementSchemeList = new StringBuffer();

		while (retirementSchemeIterator.hasNext()) {
			retirementSchemeList.append("<li>" + retirementSchemeIterator.next().toString() + "</li>");
		}
		/* Retirement Scheme List */
		emailContent = emailContent.replace("retirement_scheme_var", retirementSchemeList); 

		/* receive marketing emails */ 
		emailContent = emailContent.replace("receive_marketing_email_var", String.valueOf(model.isReceiveMarketingMaterials())); 																						

		/* Can contact by mobile */
		emailContent = emailContent.replace("contacted_by_mobile_var", String.valueOf(model.isContactedByMobile())); 

		return emailContent;
	}

	private String printCurrencyFormat(Double value) {
		DecimalFormat numberFormat = new DecimalFormat("S$###,###,###.##");
		return numberFormat.format(value);
	}

	private String readEmailTemplate() {
		/* BFA-1744 */
		Resource templateResource = new ClassPathResource(email_template);
		InputStream templateInputStream;
		try {
			templateInputStream = templateResource.getInputStream();
			String template = IOUtils.toString(templateInputStream, StandardCharsets.UTF_8);
			return template;
		} catch (IOException e) {
			getLogger().error("Error while reading the template " + email_template, e);
		}
		return "";
	}
	

	/**
	 * Basic encapsulation of the business logic for Retirement Planning *
	 * 
	 */
	@Override
	public void updateRetirementPlanningData(Object obj){		
		updateDataInCRM(obj);
		notifyAdvisors(obj);
	}

}

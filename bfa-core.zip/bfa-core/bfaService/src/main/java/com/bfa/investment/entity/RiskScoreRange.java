package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "risk_score_master")
public class RiskScoreRange {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "min_value")
	private int minValue;
	
	@Column(name = "max_value")
	private int maxValue;
	
	@Column(name = "score")
	private int score;
	
	@OneToOne
	@JoinColumn(name = "risk_level_master_id")
	private RiskLevelType riskLevelType;

	

	public RiskLevelType getRiskLevelType() {
		return riskLevelType;
	}

	public void setRiskLevelType(RiskLevelType riskLevelType) {
		this.riskLevelType = riskLevelType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMinValue() {
		return minValue;
	}

	public void setMinValue(int minValue) {
		this.minValue = minValue;
	}

	public int getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(int maxValue) {
		this.maxValue = maxValue;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	
	
}

/**
 * 
 */
package com.bfa.application.security;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.bfa.common.entity.CustomerLoginData;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.PublicUtility;
import com.google.gson.Gson;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

/**
 * @author pradheep.p
 *
 */
public class BaseTokenAuthenticationFilter extends OncePerRequestFilter implements TokenValidator,Serializable {
	
	public final long serialVersionUID = 1L;

	@Autowired
	private SecurityConstants constants;

	@Autowired
	private LogoutService logoutService;

	@Autowired
	private TokenEncryptor tokenEncryptor;

	private String appKey = "IMXYlDmP4f4=";
	
	private PublicUtility publicUtility = PublicUtility.getInstance(appKey);

	public String getHeaderName() {
		return SecurityConstants.TOKEN_NAME;
	}

	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException, IOException, ServletException {
		if (request.getRequestURL().toString().contains("authenticate")
				|| request.getRequestURL().toString().contains("/v2/api-docs")
				|| request.getRequestURL().toString().contains("swagger-ui")
				|| request.getRequestURL().toString().contains("/webjars")
				|| request.getRequestURL().toString().contains("/v2/")
				|| request.getRequestURL().toString().contains("/swagger-resources")
				|| request.getRequestURL().toString().contains("actuator")) {
			return null;
		}
		
		//	System.out.println("BFA-Token-Filter - Printing the token name :" + getHeaderName());
		String token = request.getHeader(getHeaderName());
		boolean authorized = false;
		//	System.out.println("token found:" + token);
		AbstractAuthenticationToken userAuthenticationToken = null;

		try {
			if (token != null) {
				userAuthenticationToken = validateToken(token);
			} else {
				response.sendError(HttpServletResponse.SC_FORBIDDEN, "Un Authorized");
				throw new BadCredentialsException("Invalid Token");
			}
			if (userAuthenticationToken == null) {
				System.out.println("No authentication details found");
			} else {
				System.out.println("Principal " + userAuthenticationToken.getPrincipal());
				Collection<GrantedAuthority> authorities = userAuthenticationToken.getAuthorities();
				authorities.forEach(x -> System.out.println("Authority:" + x.getAuthority()));
				System.out.println("Authorities set in context");
				setUserIdInRequest(request, (JWTToken) userAuthenticationToken);
				authorized = true;
			}
		} catch (BadTokenException err) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bad Token");
			System.out.println("Bad token found" + err.getLocalizedMessage());
		}
		if (!authorized) {
			throw new BadCredentialsException("Invalid Token");
		}
		return userAuthenticationToken;
	}

	@Override
	public AbstractAuthenticationToken validateToken(String token) throws BadTokenException {
		try {
			Claims claims = Jwts.parser().setSigningKey(constants._secret).parseClaimsJws(token).getBody();
			String roles = (String) claims.get("roles");
			roles = roles.replace("[", "");
			roles = roles.replace("]", "");
			List<GrantedAuthority> authorities = new ArrayList<>();
			String[] args = roles.split(",");
			for (String auth : args) {
				GrantedAuthority obj = new BFAGrandtedAuthority(auth.trim().toUpperCase());
				authorities.add(obj);
			}
			System.out.println("Printing the claims " + claims.getIssuer());
			JWTToken tokenObj = new JWTToken(claims.getSubject(), authorities);
			String customerReference = tokenObj.getPrincipal().toString();
			CustomerLoginData customerLoginData = new CustomerLoginData();
			customerLoginData.setCustomerIdEncrypted(customerReference);
			tokenObj.setDetails(customerLoginData);
			return tokenObj;
		} catch (ExpiredJwtException expiredJwtException) {
			throw new BadTokenException(ApplicationConstants.SESSION_TIMEOUT_LOGOUT);
		} catch (final MalformedJwtException | UnsupportedJwtException | SignatureException JwtException) {
			System.out.println("Token error:" + JwtException.getMessage());
			throw new BadTokenException("Invalid token");
		} catch (Exception err) {
			System.out.println("Token parsing error.." + err.getLocalizedMessage());
			throw new BadTokenException("Invalid token");
		}

	}

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws ServletException, IOException {		
		Authentication authentication = attemptAuthentication(req, res);
		if (authentication != null) {
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}
		super.doFilter(req, res, chain);

	}

	class JWTToken extends AbstractAuthenticationToken {

		private String principal;
		private String credentials;

		public JWTToken(String principal, Collection<GrantedAuthority> grantedAuthorities) {
			super(grantedAuthorities);
			this.principal = principal;
		}

		@Override
		public Object getCredentials() {
			return this.credentials;
		}

		@Override
		public Object getPrincipal() {
			return this.principal;
		}
	}

	private void setUserIdInRequest(HttpServletRequest httpServletRequest, JWTToken token) {
		System.out.println("Setting the customer details in the servlet request");
		Object obj = token.getDetails();
		if (obj instanceof CustomerLoginData) {
			CustomerLoginData loginData = (CustomerLoginData) obj;
			String customerRef = loginData.getCustomerIdEncrypted();
			Integer custId = getCustomerId(customerRef);
			httpServletRequest.setAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST, custId);
			System.out.println("Successfully set the customer id in the HTTP Servlet request.");
		}
	}

	private Integer getCustomerId(String encryptedCustomerReference) {
		if (null == encryptedCustomerReference || encryptedCustomerReference.isEmpty()) {
			System.out.println("Invalid customer reference ");
			return -1;
		}
		String decrypted = publicUtility.DecryptText(encryptedCustomerReference);
		String delimiter = "###";
		StringTokenizer tokenizer = new StringTokenizer(decrypted, delimiter);
		if (tokenizer.hasMoreTokens()) {
			String customerId = tokenizer.nextToken();
			Integer custId = Integer.parseInt(customerId);
			System.out.println("---- Printing the customer id : " + custId);
			if (tokenizer.hasMoreTokens()) {
				String issuedDate = tokenizer.nextToken();
				System.out.println("--- Token issued at :" + issuedDate);
			}
			return custId;
		}
		System.out.println("Error : unable to obtain the customer id");
		return -1;
	}	
	
}

package com.bfa.common.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class BFAUserDetails implements UserDetails {

	private static final long serialVersionUID = 1L;

	private int id;
	
	private String userName;
	
	private String password;
	
	private boolean isEmailVerified;
	
	private boolean isMobileVerified;
	
	private String mobileNumber;
	
	private ArrayList<BFAGrantedAuthority> grantedAuthorities;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {		
		return this.grantedAuthorities;
	}

	public void setAuthorities(List<BFAGrantedAuthority> grantedAuthorities) {
		this.grantedAuthorities = new ArrayList<>(grantedAuthorities);
	}

	public void setPassword(String password) {		
		this.password = password;
	}

	@Override
	public String getPassword() {		
		return password;
	}

	@Override
	public String getUsername() {		
		return userName;
	}

	public void setUsername(String userName) {		
		this.userName = userName;
	}

	@Override
	public boolean isAccountNonExpired() {		
		return false;
	}

	@Override
	public boolean isAccountNonLocked() {		
		return false;
	}

	@Override
	public boolean isCredentialsNonExpired() {		
		return true;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isEmailVerified() {
		return isEmailVerified;
	}

	public void setEmailVerified(boolean isEmailVerified) {
		this.isEmailVerified = isEmailVerified;
	}

	public boolean isMobileVerified() {
		return isMobileVerified;
	}

	public void setMobileVerified(boolean isMobileVerified) {
		this.isMobileVerified = isMobileVerified;
	}

	@Override
	public boolean isEnabled() {		
		return isEmailVerified && isMobileVerified;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

}

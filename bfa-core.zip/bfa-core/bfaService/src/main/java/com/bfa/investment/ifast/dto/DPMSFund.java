package com.bfa.investment.ifast.dto;



import java.util.HashMap;
import java.util.Map;

public class DPMSFund {

    private String productName;
    private String productCode;
    private String productType;
    private Double availableUnits;
    private Double investmentAmount;
    private Double indicativePrice;
    private Double currentValue;
    private Double profit;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Double getAvailableUnits() {
        return availableUnits;
    }

    public void setAvailableUnits(Double availableUnits) {
        this.availableUnits = availableUnits;
    }

    public Double getInvestmentAmount() {
        return investmentAmount;
    }

    public void setInvestmentAmount(Double investmentAmount) {
        this.investmentAmount = investmentAmount;
    }

    public Double getIndicativePrice() {
        return indicativePrice;
    }

    public void setIndicativePrice(Double indicativePrice) {
        this.indicativePrice = indicativePrice;
    }

    public Double getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(Double currentValue) {
        this.currentValue = currentValue;
    }

    public Double getProfit() {
        return profit;
    }

    public void setProfit(Double profit) {
        this.profit = profit;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

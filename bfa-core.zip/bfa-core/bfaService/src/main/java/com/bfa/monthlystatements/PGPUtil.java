/**
 * 
 */
package com.bfa.monthlystatements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

/**
 * @author HCL
 *
 * PGPUtil.java Created on Dec 11, 2018, 5:46:26 PM by Vimala Shan
 */

public class PGPUtil {
	
	@Autowired
	private Environment environment;
	
	private String privateKey;
	private String privateKeyPassword;

	/**
	 * @param encryptedZipFilePath
	 * @param privateKey
	 * @param privateKeyPassword
	 * @param decryptedFilePath
	 */
	public PGPUtil() {
	}
	private void loadProperties() {
		
		this.privateKey = this.environment.getProperty("sftp.privateKey");
		this.privateKeyPassword = this.environment.getProperty("sftp.privateKeyPassword");
	}

	/*
	 * Decrypt the zip
	 */
	public String PGPDecrypt(String encryptedZipFilePath, String decryptedFilePath)  {
		return "abc";
	}
}


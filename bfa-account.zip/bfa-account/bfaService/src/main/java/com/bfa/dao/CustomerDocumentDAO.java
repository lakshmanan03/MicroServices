package com.bfa.dao;

import java.util.List;

import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.DocumentStatusMaster;

public interface CustomerDocumentDAO {
	
	List<CustomerDocumentDetails> getAllDetails();
	
	public void saveCustomerDocument(CustomerDocumentDetails customerDocumentDetails, String status);
	
	public String getAwsFileName(int customerId);
	
	public String deleteCustomerDocument(int customerId);

	CustomerDocumentDetails getCustomerDocument(int customerId, String docType);
	
	void saveCustomerDocument(CustomerDocumentDetails customerDocumentDetails);
	
	DocumentStatusMaster getDocumentStatus(String docStatus);

}

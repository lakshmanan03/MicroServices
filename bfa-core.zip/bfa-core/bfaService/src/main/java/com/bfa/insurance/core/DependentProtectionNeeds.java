/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "dependent_protection_needs")
public class DependentProtectionNeeds implements Serializable{

	@JsonIgnore
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private int id;
	
	@JsonIgnore
	@Column(name = "dependent_id")
	private int dependentId;
	
	@JsonIgnore
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "education_course")
	private String educationCourse;
	
	@Column(name = "monthly_support_amount")
	private double monthlySupportAmount;
	
	@Column(name = "education_country")
	private String countryOfEducation;
	
	@Column(name = "nationality")
	private String nationality;
	
	@Column(name = "university_entry_age")
	private int universityEntryAge;
	
	@Column(name = "years_needed")
	private int yearsNeeded;
	
	@Column(name = "premium_waiver")
	private boolean premiumWaiver;	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDependentId() {
		return dependentId;
	}

	public void setDependentId(int dependentId) {
		this.dependentId = dependentId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getEducationCourse() {
		return educationCourse;
	}

	public void setEducationCourse(String educationCourse) {
		this.educationCourse = educationCourse;
	}

	public double getMonthlySupportAmount() {
		return monthlySupportAmount;
	}

	public void setMonthlySupportAmount(double monthlySupportAmount) {
		this.monthlySupportAmount = monthlySupportAmount;
	}

	public String getCountryOfEducation() {
		return countryOfEducation;
	}

	public void setCountryOfEducation(String countryOfEducation) {
		this.countryOfEducation = countryOfEducation;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public int getUniversityEntryAge() {
		return universityEntryAge;
	}

	public void setUniversityEntryAge(int universityEntryAge) {
		this.universityEntryAge = universityEntryAge;
	}

	public int getYearsNeeded() {
		return yearsNeeded;
	}

	public void setYearsNeeded(int yearsNeeded) {
		this.yearsNeeded = yearsNeeded;
	}

	public boolean isPremiumWaiver() {
		return premiumWaiver;
	}

	public void setPremiumWaiver(boolean premiumWaiver) {
		this.premiumWaiver = premiumWaiver;
	}	
}

package com.bfa.investment.ifast.dto;

public class IFastFundDetail {
	private String productId;
	private String managercode;
	private String latestNavDate;
	private Double latestNavPrice;
	private String launchDate;
	private Integer launchPrice;
	private Integer annualExpenseRatio;
	private String fundSizeCurrency;
	private Long fundSize;
	private Double annualManagementCharge;
	private String fmFundCode;
	private Double minRedemptionAmount;
	private String minRedemptionType;
	private Double minimumHolding;
	private String minRetainType;
	private Integer settlementSubscription;
	private Integer settlementRedemption;
	private Integer riskRating;
	private String buyEnabled;
	private String rspEnabled;
	private String cancellable;
	private String masRegistration;
	private String subscriptionDealingFrequency;
	private String redemptionDealingFrequency;
	private String valuationFrequency;
	private String fundCurrency;
	private String switchBuyEnabled;
	private String switchSellEnabled;
	private String intraSwitchEnabled;
	private String dividendFrequency;
	private String dividendOption;
	private Double minimumInitialAmount;
	private Double minimumSubsequentAmount;
	private Object annualisedVolatility3Yr;
	private Object sharpeRatio3Yr;
	private Double allTimeHigh;
	private Double allTimeLow;
	private String fundHouse;
	private String fundName;
	private String assetClass;
	private String sector;
	private String geographicalAllocation;
	private String prospectus;
	private String semiAnnualReport;
	private String fundFactSheet;
	private String annualReport;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getManagercode() {
		return managercode;
	}

	public void setManagercode(String managercode) {
		this.managercode = managercode;
	}

	public String getLatestNavDate() {
		return latestNavDate;
	}

	public void setLatestNavDate(String latestNavDate) {
		this.latestNavDate = latestNavDate;
	}

	public Double getLatestNavPrice() {
		return latestNavPrice;
	}

	public void setLatestNavPrice(Double latestNavPrice) {
		this.latestNavPrice = latestNavPrice;
	}

	public String getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(String launchDate) {
		this.launchDate = launchDate;
	}

	public Integer getLaunchPrice() {
		return launchPrice;
	}

	public void setLaunchPrice(Integer launchPrice) {
		this.launchPrice = launchPrice;
	}

	public Integer getAnnualExpenseRatio() {
		return annualExpenseRatio;
	}

	public void setAnnualExpenseRatio(Integer annualExpenseRatio) {
		this.annualExpenseRatio = annualExpenseRatio;
	}

	public String getFundSizeCurrency() {
		return fundSizeCurrency;
	}

	public void setFundSizeCurrency(String fundSizeCurrency) {
		this.fundSizeCurrency = fundSizeCurrency;
	}



	public Long getFundSize() {
		return fundSize;
	}

	public void setFundSize(Long fundSize) {
		this.fundSize = fundSize;
	}

	public Double getAnnualManagementCharge() {
		return annualManagementCharge;
	}

	public void setAnnualManagementCharge(Double annualManagementCharge) {
		this.annualManagementCharge = annualManagementCharge;
	}

	public String getFmFundCode() {
		return fmFundCode;
	}

	public void setFmFundCode(String fmFundCode) {
		this.fmFundCode = fmFundCode;
	}

	
	public String getMinRedemptionType() {
		return minRedemptionType;
	}

	public void setMinRedemptionType(String minRedemptionType) {
		this.minRedemptionType = minRedemptionType;
	}

	

	public String getMinRetainType() {
		return minRetainType;
	}

	public void setMinRetainType(String minRetainType) {
		this.minRetainType = minRetainType;
	}

	public Integer getSettlementSubscription() {
		return settlementSubscription;
	}

	public void setSettlementSubscription(Integer settlementSubscription) {
		this.settlementSubscription = settlementSubscription;
	}

	public Integer getSettlementRedemption() {
		return settlementRedemption;
	}

	public void setSettlementRedemption(Integer settlementRedemption) {
		this.settlementRedemption = settlementRedemption;
	}

	public Integer getRiskRating() {
		return riskRating;
	}

	public void setRiskRating(Integer riskRating) {
		this.riskRating = riskRating;
	}

	public String getBuyEnabled() {
		return buyEnabled;
	}

	public void setBuyEnabled(String buyEnabled) {
		this.buyEnabled = buyEnabled;
	}

	public String getRspEnabled() {
		return rspEnabled;
	}

	public void setRspEnabled(String rspEnabled) {
		this.rspEnabled = rspEnabled;
	}

	public String getCancellable() {
		return cancellable;
	}

	public void setCancellable(String cancellable) {
		this.cancellable = cancellable;
	}

	public String getMasRegistration() {
		return masRegistration;
	}

	public void setMasRegistration(String masRegistration) {
		this.masRegistration = masRegistration;
	}

	public String getSubscriptionDealingFrequency() {
		return subscriptionDealingFrequency;
	}

	public void setSubscriptionDealingFrequency(String subscriptionDealingFrequency) {
		this.subscriptionDealingFrequency = subscriptionDealingFrequency;
	}

	public String getRedemptionDealingFrequency() {
		return redemptionDealingFrequency;
	}

	public void setRedemptionDealingFrequency(String redemptionDealingFrequency) {
		this.redemptionDealingFrequency = redemptionDealingFrequency;
	}

	public String getValuationFrequency() {
		return valuationFrequency;
	}

	public void setValuationFrequency(String valuationFrequency) {
		this.valuationFrequency = valuationFrequency;
	}

	public String getFundCurrency() {
		return fundCurrency;
	}

	public void setFundCurrency(String fundCurrency) {
		this.fundCurrency = fundCurrency;
	}

	public String getSwitchBuyEnabled() {
		return switchBuyEnabled;
	}

	public void setSwitchBuyEnabled(String switchBuyEnabled) {
		this.switchBuyEnabled = switchBuyEnabled;
	}

	public String getSwitchSellEnabled() {
		return switchSellEnabled;
	}

	public void setSwitchSellEnabled(String switchSellEnabled) {
		this.switchSellEnabled = switchSellEnabled;
	}

	public String getIntraSwitchEnabled() {
		return intraSwitchEnabled;
	}

	public void setIntraSwitchEnabled(String intraSwitchEnabled) {
		this.intraSwitchEnabled = intraSwitchEnabled;
	}

	public Object getDividendFrequency() {
		return dividendFrequency;
	}

	

	public Object getAnnualisedVolatility3Yr() {
		return annualisedVolatility3Yr;
	}

	public void setAnnualisedVolatility3Yr(Object annualisedVolatility3Yr) {
		this.annualisedVolatility3Yr = annualisedVolatility3Yr;
	}

	public Object getSharpeRatio3Yr() {
		return sharpeRatio3Yr;
	}

	public void setSharpeRatio3Yr(Object sharpeRatio3Yr) {
		this.sharpeRatio3Yr = sharpeRatio3Yr;
	}

	public Double getAllTimeHigh() {
		return allTimeHigh;
	}

	public void setAllTimeHigh(Double allTimeHigh) {
		this.allTimeHigh = allTimeHigh;
	}

	public Double getAllTimeLow() {
		return allTimeLow;
	}

	public void setAllTimeLow(Double allTimeLow) {
		this.allTimeLow = allTimeLow;
	}

	public String getFundHouse() {
		return fundHouse;
	}

	public void setFundHouse(String fundHouse) {
		this.fundHouse = fundHouse;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getGeographicalAllocation() {
		return geographicalAllocation;
	}

	public void setGeographicalAllocation(String geographicalAllocation) {
		this.geographicalAllocation = geographicalAllocation;
	}

	public String getProspectus() {
		return prospectus;
	}

	public void setProspectus(String prospectus) {
		this.prospectus = prospectus;
	}

	public String getSemiAnnualReport() {
		return semiAnnualReport;
	}

	public void setSemiAnnualReport(String semiAnnualReport) {
		this.semiAnnualReport = semiAnnualReport;
	}

	public String getFundFactSheet() {
		return fundFactSheet;
	}

	public void setFundFactSheet(String fundFactSheet) {
		this.fundFactSheet = fundFactSheet;
	}

	public String getAnnualReport() {
		return annualReport;
	}

	public void setAnnualReport(String annualReport) {
		this.annualReport = annualReport;
	}

	public Double getMinRedemptionAmount() {
		return minRedemptionAmount;
	}

	public void setMinRedemptionAmount(Double minRedemptionAmount) {
		this.minRedemptionAmount = minRedemptionAmount;
	}

	public Double getMinimumHolding() {
		return minimumHolding;
	}

	public void setMinimumHolding(Double minimumHolding) {
		this.minimumHolding = minimumHolding;
	}

	public String getDividendOption() {
		return dividendOption;
	}

	public void setDividendOption(String dividendOption) {
		this.dividendOption = dividendOption;
	}

	public Double getMinimumInitialAmount() {
		return minimumInitialAmount;
	}

	public void setMinimumInitialAmount(Double minimumInitialAmount) {
		this.minimumInitialAmount = minimumInitialAmount;
	}

	public Double getMinimumSubsequentAmount() {
		return minimumSubsequentAmount;
	}

	public void setMinimumSubsequentAmount(Double minimumSubsequentAmount) {
		this.minimumSubsequentAmount = minimumSubsequentAmount;
	}

	public void setDividendFrequency(String dividendFrequency) {
		this.dividendFrequency = dividendFrequency;
	}
	
	

}

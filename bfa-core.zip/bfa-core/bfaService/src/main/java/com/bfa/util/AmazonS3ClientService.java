package com.bfa.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;



public interface AmazonS3ClientService
{
	String upload(String bucketName, String fileName, File file);
	String upload(String bucketName, String fileName, MultipartFile file);
	String uploadFileToS3Bucket(String bucketName, MultipartFile multipartFile);
	String deleteFileFromS3Bucket(String fileName);
	
	/**
	 * Upload a file to Amazon S3 bucket
	 * 
	 * @param bucketName - name of S3 bucket
	 * @param fileName - name of file
	 * @param file - the actual file
	 * @param cannedACL - Amazon Access Control List (i.e CannedAccessControlList.Private / CannedAccessControlList.PublicRead)
	 * @return
	 * @throws AmazonServiceException
	 * @throws SdkClientException
	 */
	String upload(String bucketName, String fileName, File file, CannedAccessControlList cannedACL);
	
	/**
	 * 
	 * @param statementBucketName
	 * @param folderName
	 * @return
	 * @throws AmazonServiceException
	 * @throws SdkClientException
	 */
	String createFolder(String statementBucketName, String folderName)
			throws AmazonServiceException, SdkClientException;
	
	/**
	 * 
	 * @param bucketName
	 * @return
	 */
	List<S3ObjectSummary> getS3ObjectsSummaries(String bucketName);
	
	/**
	 * 
	 * @param bucketName
	 * @param fileName
	 * @return
	 */
	S3Object getS3Object(String bucketName, String fileName);
	
	/**
	 * Upload a file to Amazon S3 bucket (For IAM implementation)
	 * 
	 * @param bucketName - name of S3 bucket
	 * @param fileName - name of file
	 * @param file - the actual file
	 * @param cannedACL - Amazon Access Control List (i.e CannedAccessControlList.Private / CannedAccessControlList.PublicRead)
	 * @return
	 */
	String uploadWithIAM(String bucketName, String fileName, File file, CannedAccessControlList cannedACL);
	
	/**
	 * Download a file from Amazon S3 bucket (For IAM implementation)
	 * @param bucketName
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	S3ObjectInputStream downloadStream(String bucketName, String fileName) throws IOException;
}
package com.bfa.admin.dto;

public class CustomerOverviewDTO {

	private Integer moCustomerId;
	private String customerIdEncrypted;
	private String customerName;
	private String mobileNumber;
	private String email;
	private String accountStatus;
	private String advisorId;
	private String advisorName;
	private String journeys;
	private String nricNumber;
	private String passportNumber;

	

	public Integer getMoCustomerId() {
		return moCustomerId;
	}

	public void setMoCustomerId(Integer moCustomerId) {
		this.moCustomerId = moCustomerId;
	}

	public String getCustomerIdEncrypted() {
		return customerIdEncrypted;
	}

	public void setCustomerIdEncrypted(String customerIdEncrypted) {
		this.customerIdEncrypted = customerIdEncrypted;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(String advisorId) {
		this.advisorId = advisorId;
	}

	public String getAdvisorName() {
		return advisorName;
	}

	public void setAdvisorName(String advisorName) {
		this.advisorName = advisorName;
	}

	public String getJourneys() {
		return journeys;
	}

	public void setJourneys(String journeys) {
		this.journeys = journeys;
	}

	public String getNricNumber() {
		return nricNumber;
	}

	public void setNricNumber(String nricNumber) {
		this.nricNumber = nricNumber;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	

}

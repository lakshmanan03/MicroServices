/**
 * 
 */
package com.bfa.request.aggregate;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.bfa.insurance.core.DependentMapping;
import com.bfa.insurance.core.ExistingInsurance;
import com.bfa.insurance.core.FinancialStatusMapping;
import com.bfa.request.entity.RecommendationPostRequest;
import com.bfa.request.processor.HttpProcessorCommand;
import com.bfa.request.processor.ProcessorCommand;
import com.bfa.request.processor.SuccessHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * 
 * This class is meant for composing the insurance data results for the dashboard.
 * BFA-1232
 * @author pradheep
 * @param <T>
 * @since Release 2.16
 * @see BFADataComposer
 */
public class InsuranceDataComposer<T extends HttpProcessorCommand> implements BFADataComposer<T> {

	private Logger logger;

	private Gson gson = new Gson();

	/**
	 * Set the logger before calling this method, use the setLogger method.
	 */
	@Override
	public Object composeAllData(List<T> collection) throws RuntimeException {
		Logger logger = getLogger();
		if (logger == null) {
			throw new RuntimeException("Try setting a logger instance to setLogger() method");
		}
		logger.info("Composing all data for  -" + getComposerName());
		RecommendationPostRequest request = new RecommendationPostRequest();
		try {
			for (ProcessorCommand obj : collection) {
				if (obj.getCommandName().equals(BFADataComposer.INSURANCE_DATA_FINANCE_NEEDS)) {
					logger.info("Setting the assets data in the results ");
					SuccessHandler handler = obj.getSuccessHandler();
					if (handler instanceof DefaultSuccessHandler) {
						DefaultSuccessHandler sHandler = (DefaultSuccessHandler) handler;
						try{
						String response = sHandler.getPreOpreratedResponse().getResponseBody();
						logger.info("Response :" + response);
						String res = response.substring(response.indexOf(":[")+2,response.lastIndexOf("]}"));					
						getLogger().info("Printing the financial response " + res);					
						FinancialStatusMapping financialStatusMapping = gson.fromJson(res,FinancialStatusMapping.class);
						request.setFinancialStatusMapping(financialStatusMapping);
						}
						catch(Exception err){
							getLogger().error("Error while obtaining the financial needs data" , err);
						}
					}
				}
				if (obj.getCommandName().equals(BFADataComposer.INSURANCE_DEPENDENTS_NEEDS_DATA)) {
					logger.info("Setting the dependents data in the results ");
					SuccessHandler handler = obj.getSuccessHandler();
					if (handler instanceof DefaultSuccessHandler) {
						DefaultSuccessHandler sHandler = (DefaultSuccessHandler) handler;
						try{
						String response = sHandler.getPreOpreratedResponse().getResponseBody();						
						logger.info("Response :" + response);
						String res = response.substring(response.indexOf(":[")+1,response.length() -1);				
						logger.info("Response filtered :" + res);
						if(!res.contains("objectList\":null")){
						ObjectMapper objectMapper = new ObjectMapper();						
						List<DependentMapping> dependentMappingList = objectMapper.readValue(res, new TypeReference<List<DependentMapping>>(){});
						request.setDependentsData(dependentMappingList);
						}
						}
						catch(Exception err){
							getLogger().error("Error while collecting the data for the dependents ",err);
						}
					}
				}
				if (obj.getCommandName().equals(BFADataComposer.INSURANCE_NEEDS_DATA)) {
					logger.info("Setting the insurance needs data in the results ");
					SuccessHandler handler = obj.getSuccessHandler();
					if (handler instanceof DefaultSuccessHandler) {
						DefaultSuccessHandler sHandler = (DefaultSuccessHandler) handler;
						try{
						String response = sHandler.getPreOpreratedResponse().getResponseBody();
						logger.info("Response :" + response);
						String res = response.substring(response.indexOf(":[")+2,response.lastIndexOf("]}"));					
						logger.info("Response filtered :" + res);
						InsuranceDetails insuranceDetails = gson.fromJson(res, InsuranceDetails.class);
						request.setLifeProtectionNeeds(insuranceDetails.getLifeProtectionNeeds());
						request.setOccupationalDisabilityNeeds(insuranceDetails.getOccupationalDisabilityNeeds());
						if(null != insuranceDetails.getExistingInsurance()){
						List<ExistingInsurance> existingInsuranceList = new ArrayList<ExistingInsurance>();
						existingInsuranceList.add(insuranceDetails.getExistingInsurance());
						request.setExistingInsuranceList(existingInsuranceList);
						}
						if(null != insuranceDetails.getCriticalIllnessNeedsData()){
							request.setCriticalIllnessNeedsData(insuranceDetails.getCriticalIllnessNeedsData());
						}						
						if(null != insuranceDetails.getHospitalizationNeeds()){
							request.setHospitalizationNeeds(insuranceDetails.getHospitalizationNeeds());
						}
						if(null != insuranceDetails.getLongTermCareNeeds()){
							request.setLongTermCareNeeds(insuranceDetails.getLongTermCareNeeds());
						}
						if(null != insuranceDetails.getSrsApprovedPlans()){
							request.setSrsApprovedPlans(insuranceDetails.getSrsApprovedPlans());
						}
						if(null != insuranceDetails.getRetirementIncomePlan()){
							request.setRetirementIncomePlan(insuranceDetails.getRetirementIncomePlan());
						}
						}
						catch(Exception err){
							getLogger().error("Error while obtaining the insurance needs data", err);
						}
					}
				}
				
			}
		} catch (Exception err) {
			logger.error("Error while aggregating the results ", err);
		}
		return request;
	}

	@Override
	public String getComposerName() {
		return BFADataComposer.INSURANCE_COMPOSER;
	}

	public Logger getLogger() {		
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

}

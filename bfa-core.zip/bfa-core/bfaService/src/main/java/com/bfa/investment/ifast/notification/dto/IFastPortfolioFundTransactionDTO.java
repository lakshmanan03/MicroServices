package com.bfa.investment.ifast.notification.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IFastPortfolioFundTransactionDTO {
	
    private String fundId;
    @JsonProperty("Units")
    private int units;
    private int unitPrice;
    
    
	public String getFundId() {
		return fundId;
	}
	public void setFundId(String fundId) {
		this.fundId = fundId;
	}
	public int getUnits() {
		return units;
	}
	public void setUnits(int units) {
		this.units = units;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
    
    
			
}

/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.common.dto.BaseProfileDTO;
import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.common.dto.ComprehensiveHouseHoldDTO;
import com.bfa.common.dto.DependentDTO;
import com.bfa.common.dto.DependentEducationPreferencesDTO;
import com.bfa.comprehensive.dto.InsuranceAgentCallback;

public class ComprehensiveEnquiryPostResponse {
	
	private ComprehensiveEnquiryDTO comprehensiveEnquiry;		

	private List<DependentDTO> dependentsList;

	private BaseProfileDTO baseProfile;

	private List<DependentEducationPreferencesDTO> endowmentEducationList;
	
	private InsuranceAgentCallback insuranceAgentCallBack;
	
	private ComprehensiveHouseHoldDTO comprehensiveHouseHold;
	
	
	public ComprehensiveEnquiryDTO getComprehensiveEnquiry() {
		return comprehensiveEnquiry;
	}

	public void setComprehensiveEnquiry(ComprehensiveEnquiryDTO comprehensiveEnquiry) {
		this.comprehensiveEnquiry = comprehensiveEnquiry;
	}	

	public List<DependentDTO> getDependentsList() {
		return dependentsList;
	}

	public void setDependentsList(List<DependentDTO> dependentsList) {
		this.dependentsList = dependentsList;
	}

	public BaseProfileDTO getBaseProfile() {
		return baseProfile;
	}

	public void setBaseProfile(BaseProfileDTO baseProfile) {
		this.baseProfile = baseProfile;
	}

	public List<DependentEducationPreferencesDTO> getEndowmentEducationList() {
		return endowmentEducationList;
	}

	public void setEndowmentEducationList(List<DependentEducationPreferencesDTO> endowmentEducationList) {
		this.endowmentEducationList = endowmentEducationList;
	}

	public InsuranceAgentCallback getInsuranceAgentCallBack() {
		return insuranceAgentCallBack;
	}

	public void setInsuranceAgentCallBack(InsuranceAgentCallback insuranceAgentCallBack) {
		this.insuranceAgentCallBack = insuranceAgentCallBack;
	}

	public ComprehensiveHouseHoldDTO getComprehensiveHouseHold() {
		return comprehensiveHouseHold;
	}

	public void setComprehensiveHouseHold(ComprehensiveHouseHoldDTO comprehensiveHouseHold) {
		this.comprehensiveHouseHold = comprehensiveHouseHold;
	}

	
	

}

/**
 * 
 */
package com.bfa.insurance;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.configuration.AccountServiceConfiguration;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.EnquiryProtectionType;
import com.bfa.insurance.core.ProtectionTypeMaster;
import com.bfa.insurance.product.Insurer;
import com.bfa.insurance.product.Premium;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.UpdateProductEnquiryRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.PublicUtility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * CRM integration tests
 * 
 * BFA-1729
 * 
 * @author pradheep.p
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = AccountServiceConfiguration.class)
@AutoConfigureMockMvc(secure = false)
@ContextConfiguration
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CRMIntegrationTest {

	@Autowired
	private MockMvc mockMvc;

	private String updateCustomerEnqAPI = APIConstants.API_ACCOUNT_UPDATE_CUSTOMER_ENQUIRY;

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private AccountsDao accountsDao;

	@Autowired
	private SessionFactory sessionFactory;

	String authHeader = "";

	PublicUtility utility = PublicUtility.getInstance("IMXYlDmP4f4=");

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_USER");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		return tokenProvider.getTokenString("-1", authorities);
	}

	private void printDelimiter() {
		System.out.println("---------------------------------------------------------------");
	}

	private void printEndTest(String testName) {
		System.out.println("---------------End of " + testName + "--------------------");
	}

	private Object[] prepareSampleData() {
		clearForeignKeyChecks();
		Object[] obj = new Object[2];
		Enquiry enquiry = new Enquiry();
		enquiry.setCreatedTimeStamp(new Date());
		enquiry.setGender("male");
		enquiry.setCreatedBy("system");
		enquiry.setType(getRandomEnquiryType());
		enquiry = (Enquiry) accountsDao.saveObject(enquiry);

		// ---------------------------------//
		Customer customer = new Customer();
		customer.setAcceptMarketEmails(false);
		customer.setCountryCode("+65");
		customer.setCreatedBy("system");
		customer.setDateOfBirth(getRandomDateOfBirth());
		customer.setEmail(generateRandomEmail());
		customer.setMobileNumber(getRandomMobileNumber());
		customer.setEmailVerified("Yes");
		customer.setGivenName("Kevin");
		customer.setOtpVerfied("Yes");
		customer.setSurName("Goh");
		customer = (Customer) accountsDao.saveObject(customer);
		// ----------------------------------//
		printDelimiter();
		System.out.println("Printing the customer email: " + customer.getEmail());
		System.out.println("Printing the customer mobile :" + customer.getMobileNumber());
		printDelimiter();
		
		ProtectionTypeMaster protectionTypeMaster = null;
		protectionTypeMaster = new ProtectionTypeMaster();
		protectionTypeMaster.setProtectionType("Life Protection");
		protectionTypeMaster.setProtectionTypeDescription("Life Protection");
		accountsDao.saveObject(protectionTypeMaster);

		// ----------------------------------//
		EnquiryProtectionType enquiryProtectionType = new EnquiryProtectionType();
		enquiryProtectionType.setEnquiryId(enquiry.getId());
		enquiryProtectionType.setProtectionTypeId(protectionTypeMaster.getId());
		accountsDao.saveObject(enquiryProtectionType);
		obj[1] = enquiry;
		obj[0] = customer;
		return obj;
	}

	private String getRandomDateOfBirth() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		buffer.append("19");
		int yr = ran.nextInt(99);
		if (yr >= 10) {
			buffer.append(yr);
		} else {
			buffer.append("0");			
			buffer.append(yr);
		}
		buffer.append("-");
		int month = ran.nextInt(12);
		if (month >= 10) {
			buffer.append(month);
		} else {
			buffer.append("0");
			if(month == 0){
				month++;
			}
			buffer.append(month);
		}
		buffer.append("-");
		int day = ran.nextInt(28);
		if (day >= 10) {
			buffer.append(day);
		} else {
			buffer.append("0");
			if(day == 0){
				day++;
			}
			buffer.append(day);
		}
		return buffer.toString();
	}

	private String getRandomMobileNumber() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		buffer.append("8");
		for (int i = 0; i < 7; i++) {
			buffer.append(ran.nextInt(9));
		}
		return buffer.toString();
	}

	private String getRandomEnquiryType() {
		String[] journeyType = new String[] { "insurance-guided", "insurance-direct", "comprehensive" };		
		Random ran = new Random();
		return journeyType[ran.nextInt(2)];
	}

	private String generateRandomEmail() {
		String[] emailChars = new String[] { "a", "b", "c", "d", "e", "f", "g", "i", "j", "k", "l", "m", "n", "o", "p",
				"q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		for (int x = 0; x < 8; x++) {
			buffer.append(emailChars[ran.nextInt(emailChars.length - 1)]);
		}
		buffer.append("@testmail.com");
		return buffer.toString();
	}

	/* Sample test for signed in user. */
	@Test
	public void testCRMAPICall() {
		printDelimiter();
		System.out.println("Testing the CRM API call ");
		printDelimiter();
		Object[] collection = prepareSampleData();
		Customer cusObj = (Customer) collection[0];
		Enquiry enqObj = (Enquiry) collection[1];
		UpdateProductEnquiryRequest request = getUpdateProductEnquiryRequest(cusObj.getId(), enqObj.getId());
		Gson gson = new Gson();
		byte[] requestBody = null;
		try {
			requestBody = this.convertObjectToJsonBytes(request);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Request Body : " + gson.toJson(request));
		try {
			String responseMessage = "$.responseMessage[?(@.responseCode == '%s')]";
			authHeader = getAuthToken();
			System.out.println("Auth Token:" + authHeader);
			ResultActions result = mockMvc
					.perform(post(updateCustomerEnqAPI).contentType(this.APPLICATION_JSON_UTF8).content(requestBody)
							.header("Authorization", authHeader))
					.andExpect(content().contentType(this.APPLICATION_JSON_UTF8))
					.andExpect(jsonPath(responseMessage, "6000").exists());
			result.andDo(MockMvcResultHandlers.print());
		} catch (Exception err) {
			err.printStackTrace();
		}		
		printEndTest("testCRMAPICall");
	}

	private UpdateProductEnquiryRequest getUpdateProductEnquiryRequest(Integer customerId, Integer enquiryId) {
		UpdateProductEnquiryRequest updateProductEnquiryRequest = new UpdateProductEnquiryRequest();
		updateProductEnquiryRequest.setCustomerId(utility.EncryptTextURLSafe(customerId.toString()));
		updateProductEnquiryRequest.setEnquiryId(enquiryId);
		updateProductEnquiryRequest.setNewCustomer(true);
		updateProductEnquiryRequest.setSelectedProducts(getSampleProductList());
		return updateProductEnquiryRequest;
	}

	private void clearForeignKeyChecks() {
		try {
			Session session = sessionFactory.openSession();
			Query query = session.createSQLQuery("SET FOREIGN_KEY_CHECKS=0");
			query.executeUpdate();
		} catch (Exception err) {
			err.printStackTrace();
		}
	}

	private List<ProductList> getSampleProductList() {
		List<ProductList> productList = new ArrayList<ProductList>();
		ProductList obj = new ProductList();
		obj.setFeatures(
				"~Planned Overseas Treatment - As charged (pegged to Mt Elizabeth rates.)~Preventive Treatment for Cancer - As Charged~Pre-Hospitalisation Benefit - As charged (Up to 90 Days)~Post-Hosptialisation Benefit - As charged (Up to 90 days or 180 days for panel/re-structured/community hospital");
		obj.setCashPayoutFrequency("Monthly");
		obj.setProductName("MyShield Plan 1");
		obj.setAuthorised(false);
		obj.setCashValue("1000");
		obj.setCoverageDuration("Till Age 65");
		obj.setId("P090");

		Insurer insurer = new Insurer();
		insurer.setInsurerName("Aviva");
		insurer.setLogoName("logo-aviva.png");
		insurer.setUrl("https://www.aviva.com.sg");
		insurer.setRating("A+");
		insurer.setId("AVV");
		obj.setInsurer(insurer);

		Premium premium = new Premium();
		premium.setId(878583);
		premium.setClaimFeature("Test");
		premium.setDeferredPeriod(10);
		premium.setGender("female");
		premium.setProductId("P090");

		obj.setPremium(premium);
		productList.add(obj);
		return productList;
	}
}

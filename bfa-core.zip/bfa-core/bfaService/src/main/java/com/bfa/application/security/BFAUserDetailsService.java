/**
 * 
 */
package com.bfa.application.security;

import com.bfa.common.entity.BFAUserDetails;

/**
 * @author pradheep.p
 *
 */
public interface BFAUserDetailsService {
	
	public BFAUserDetails loadUserByEmail(String email);
	
	public BFAUserDetails loadUserByMobile(String mobileNumber);

	public BFAUserDetails loadAdminByEmail(String email);
	
}

package com.bfa.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.common.entity.BFAUserDetails;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.service.AccountsService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.DocumentType;
import com.bfa.util.ErrorCodes;
import com.bfa.util.InvestmentAccountStatus;
import com.bfa.util.ResponseMessageList;
import com.bfa.util.ServiceResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
public class UploadController extends BaseController {

	@Autowired
	private AccountsService accountsService;

	@Autowired
	ApplicationLoggerBean applicationLoggerBean;

	@Autowired
	private MOInvestmentService investmentService;

	protected Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	@RequestMapping(value = APIConstants.API_ACCOUNT_SAVE_DOCUMENTS, method = RequestMethod.POST)
	@Produces({ "application/xml", "application/json" })
	@POST
	@Path(APIConstants.API_ACCOUNT_SAVE_DOCUMENTS)
	@ApiOperation(value = "Save Investment details and files", notes = "Save Investment details and files", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList saveDocuments(
			@RequestPart(name = "nricFront", required = false) MultipartFile nricFrontFile,
			@RequestPart(name = "nricBack", required = false) MultipartFile nricBackFile,
			@RequestPart(name = "passport", required = false) MultipartFile passportFile,
			@RequestPart(name = "mailingAddressProof", required = false) MultipartFile mailingAddressProof,
			@RequestPart(name = "residentialAddressProof", required = false) MultipartFile residentialAddressProof,
			@RequestPart(name = "beneficiaryPassport", required = false) MultipartFile beneficiaryPassport,
			@RequestPart(name = "supportingDocument", required = false) MultipartFile supportingDocument,
			@RequestParam(name = "form", required = false) String details,HttpServletRequest httpServletRequest) {
		getLogger().info("reached saveDocuments");
		ResponseMessageList responseList = getDefaultMessageList();
		List<Object> objectList = new ArrayList<Object>();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
		Integer customerId = bfaUser.getId();
		// To get email from principal object
		if (customerId == null) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			return responseList;
		}
		try {
			boolean isSuccess = true;
			if (details == null && nricFrontFile == null && nricBackFile == null && passportFile == null
					&& mailingAddressProof == null && residentialAddressProof == null && beneficiaryPassport == null
					&& supportingDocument == null) {
				getLogger().debug("no details or files available");
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
				responseList.getResponseMessage()
						.setResponseDescription(ApplicationConstants.NO_INPUT_PARAMETERS_FOUND);
				return responseList;
			}
			getLogger().info("saving file document");
			if (details != null) {
				try {
					GsonBuilder gsonBuilder = new GsonBuilder();
					gsonBuilder.setDateFormat("dd-MM-yyyy");
					Gson gson = gsonBuilder.create();
					CustomerDetailsDTO accountDetails = gson.fromJson(details, CustomerDetailsDTO.class);
					ServiceResponse<Map<String, String>> response = accountsService.saveCustomerDetails(accountDetails,
							customerId);
					isSuccess = response.isSuccess();
					objectList.add(response);
				} catch (JsonSyntaxException jsonException) {
					getLogger().error("JsonSyntaxException occured in saveDocuments(): " + jsonException.fillInStackTrace());	
					getLogger().debug("jsonException saveDocuments " + jsonException);
					responseList.setExceptionDetails(jsonException);
					responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
					responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
					return responseList;
				} catch (Exception ex) {
					getLogger().error("Exception occured in saveDocuments(): " + ex.fillInStackTrace());
					getLogger().debug("Exception saveDocuments " + ex);
					responseList.setExceptionDetails(ex);
					responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
					responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
					return responseList;

				}
			}
			int fileUploadedCount = 0;
			if (nricFrontFile != null) {

				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId, nricFrontFile,
						DocumentType.NRIC_FRONT);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (nricBackFile != null) {
				fileUploadedCount += 1;
				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId, nricBackFile,
						DocumentType.NRIC_BACK);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (passportFile != null) {
				fileUploadedCount += 1;
				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId, passportFile,
						DocumentType.PASSPORT);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (mailingAddressProof != null) {
				fileUploadedCount += 1;
				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId,
						mailingAddressProof, DocumentType.MAILING_ADDRESS_PROOF);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (residentialAddressProof != null) {
				fileUploadedCount += 1;
				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId,
						residentialAddressProof, DocumentType.RESIDENTIAL_ADDRESS_PROOF);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (beneficiaryPassport != null) {
				fileUploadedCount += 1;
				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId,
						beneficiaryPassport, DocumentType.BENEFICIARY_OWNER_DOCUMENT);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (supportingDocument != null) {
				fileUploadedCount += 1;
				ServiceResponse<Map<String, String>> response = accountsService.saveDocument(customerId,
						supportingDocument, DocumentType.SUPPORTING_DOCUMENT);
				objectList.add(response);
				if (isSuccess) {
					isSuccess = response.isSuccess();
					fileUploadedCount += 1;
				}
			}

			if (isSuccess) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
			}

			if (fileUploadedCount >= 1) {
				getLogger().info("calling updateInvestmentAccountStatus");
				investmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED);
			}

			responseList.setObjectList(objectList);
		} catch (Exception ex) {
			getLogger().debug("savedocuments final exception" + ex);
			getLogger().debug("savedocuments final exception message" + ex.getMessage());
			responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			responseList.setExceptionDetails(ex);
		}

		return responseList;
	}

	@PostMapping("/newSaveDocuments")
	@Produces({ "application/xml", "application/json" })
	@Path("/newSaveDocuments")
	@ApiOperation(value = "Save Investment details and files", notes = "Save Investment details and files", response = ResponseMessageList.class)
	@ApiResponses(value = {
			@ApiResponse(code = ErrorCodes.INTERNAL_SERVER_ERROR, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE),
			@ApiResponse(code = ErrorCodes.DB_COMMUNICATION_FAILURE, message = ApplicationConstants.DATABASE_COMMUNICATION_FAILURE) })
	public @ResponseBody ResponseMessageList saveDocumentsV2(HttpServletRequest httpServletRequest,
			@RequestParam(name = "form", required = false) String details) {
		getLogger().info("reached saveDocuments");
		ResponseMessageList responseList = getDefaultMessageList();
		List<Object> objectList = new ArrayList<Object>();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		BFAUserDetails bfaUser = getAuthUser(httpServletRequest);
		Integer customerId = bfaUser.getId();
		// To get email from principal object
		if (customerId == null) {
			responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
			return responseList;
		}
		try {
			boolean isSuccess = true;
			getLogger().info("saving file document");
			if (details != null) {
				try {

				} catch (JsonSyntaxException jsonException) {
				} catch (Exception ex) {
					ex.printStackTrace();
					getLogger().debug("Exception saveDocuments " + ex);
					responseList.setExceptionDetails(ex);
					responseList.getResponseMessage().setResponseCode(ErrorCodes.NO_SUCH_USER);
					responseList.getResponseMessage().setResponseDescription(ApplicationConstants.NO_SUCH_USER);
					return responseList;

				}
			}
			int fileUploadedCount = 0;
			ServiceResponse<Map<String, String>> response = accountsService.saveDocumentV2(customerId,
					httpServletRequest, DocumentType.NRIC_FRONT);
			objectList.add(response);
			if (isSuccess) {
				isSuccess = response.isSuccess();
				fileUploadedCount += 1;
			}

			if (isSuccess) {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
			} else {
				responseList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_INPUT_FIELD);
			}

			if (fileUploadedCount >= 1) {
				getLogger().info("calling updateInvestmentAccountStatus");
				investmentService.updateInvestmentAccountStatus(InvestmentAccountStatus.DOCUMENTS_UPLOADED);
			}

			responseList.setObjectList(objectList);
		} catch (Exception ex) {
			getLogger().debug("savedocuments final exception" + ex);
			getLogger().debug("savedocuments final exception message" + ex.getMessage());
			responseList.getResponseMessage().setResponseCode(ErrorCodes.VALIDATION_ERROR);
			responseList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_INPUT);
			responseList.setExceptionDetails(ex);
		}

		return responseList;
	}

}

/**
 * 
 */
package com.bfa.request.entity;

public class ComprehensiveEarningsRequest {

	private Integer customerId;

	private Integer enquiryId;

	private String employmentType;

	private Double monthlySalary;

	private Double monthlyRentalIncome;

	private Double otherMonthlyWorkIncome;

	private Double otherMonthlyIncome;

	private Double annualBonus;

	private Double annualDividends;

	private Double otherAnnualIncome;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public Double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(Double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}

	public Double getMonthlyRentalIncome() {
		return monthlyRentalIncome;
	}

	public void setMonthlyRentalIncome(Double monthlyRentalIncome) {
		this.monthlyRentalIncome = monthlyRentalIncome;
	}

	public Double getOtherMonthlyWorkIncome() {
		return otherMonthlyWorkIncome;
	}

	public void setOtherMonthlyWorkIncome(Double otherMonthlyWorkIncome) {
		this.otherMonthlyWorkIncome = otherMonthlyWorkIncome;
	}

	public Double getOtherMonthlyIncome() {
		return otherMonthlyIncome;
	}

	public void setOtherMonthlyIncome(Double otherMonthlyIncome) {
		this.otherMonthlyIncome = otherMonthlyIncome;
	}

	public Double getAnnualBonus() {
		return annualBonus;
	}

	public void setAnnualBonus(Double annualBonus) {
		this.annualBonus = annualBonus;
	}

	public Double getAnnualDividends() {
		return annualDividends;
	}

	public void setAnnualDividends(Double annualDividends) {
		this.annualDividends = annualDividends;
	}

	public Double getOtherAnnualIncome() {
		return otherAnnualIncome;
	}

	public void setOtherAnnualIncome(Double otherAnnualIncome) {
		this.otherAnnualIncome = otherAnnualIncome;
	}

}

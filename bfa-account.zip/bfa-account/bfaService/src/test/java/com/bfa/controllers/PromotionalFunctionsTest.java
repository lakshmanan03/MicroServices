package com.bfa.controllers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.bfa.application.corporate.CorporateLeadGenRequest;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.TokenProvider;
import com.bfa.configuration.AccountServiceConfiguration;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = AccountServiceConfiguration.class)
@AutoConfigureMockMvc(secure = false)
public class PromotionalFunctionsTest {	

	private String authHeader = "";

	@Autowired
	private TokenProvider tokenProvider;

	@Autowired
	private MockMvc mockMvc;	

	private Random random = new Random();

	public final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	private Gson gson = new Gson();

	private String[] arg = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
			"p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };

	public byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	/**
	 * Test for - Corporate Lead Generation . 
	 */
	@Test
	public void testCorporateLeadGeneration() {
		/* BFA-1840 */
		System.out.println("-----------------------------------------");
		System.out.println("Testing BFA-1840 , Corporate Lead Generation");
		init();
		CorporateLeadGenRequest request = getRequest();
		try {
			System.out.println("Auth Token:" + authHeader);
			String requestBody = gson.toJson(request); 
			System.out.println(requestBody);
			System.out.println("-----------------------------------------");
			ResultActions result = mockMvc
					.perform(post(APIConstants.CORP_BIZ_LEAD_GEN).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(request)).header("Authorization", authHeader))
					.andExpect(status().isOk()).andExpect(content().contentType(this.APPLICATION_JSON_UTF8));
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test for Corporate Lead Gen Test. - Security Test
	 */
	@Test
	public void testRetirementPlanningForSecurity() {
		/* BFA-1840 */
		System.out.println("-----------------------------------------");
		System.out.println("Testing BFA-1840  -Corporate Lead Generation - Security testing.");
		CorporateLeadGenRequest request = getRequest();
		try {
			authHeader = "No Header Token";
			System.out.println("Auth Token:" + authHeader);
			System.out.println(gson.toJson(request));
			System.out.println("-----------------------------------------");
			ResultActions result = mockMvc
					.perform(post(APIConstants.CORP_BIZ_LEAD_GEN).contentType(this.APPLICATION_JSON_UTF8)
							.content(this.convertObjectToJsonBytes(request)).header("Authorization", authHeader))
					.andExpect(status().is(403));
			result.andDo(MockMvcResultHandlers.print());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() {
		authHeader = getAuthToken();
	}

	private String getAuthToken() {
		BFAGrandtedAuthority grantedAuthority1 = new BFAGrandtedAuthority("ROLE_USER");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(grantedAuthority1);
		return tokenProvider.getTokenString("-1", authorities);
	}

	private String getMobileNumber() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("8");
		Random ran = new Random();
		for (int i = 0; i < 7; i++) {
			buffer.append(ran.nextInt(9));
		}
		return buffer.toString();
	}

	private String getTargetEmail() {
		StringBuffer buffer = new StringBuffer();
		Random ran = new Random();
		for (int i = 0; i < 8; i++) {
			buffer.append(arg[ran.nextInt(arg.length - 1)]);
		}
		buffer.append("-test@gmail.com");
		return buffer.toString();
	}

	private String getRandomName() {
		StringBuffer buffer = new StringBuffer();
		for (int y = 0; y < 7; y++) {
			int index = random.nextInt(arg.length - 1);
			buffer.append(arg[index]);
		}
		return buffer.toString();
	}

	/* Generates the sample test data */
	private CorporateLeadGenRequest getRequest() {
		CorporateLeadGenRequest request = new CorporateLeadGenRequest();
		int randomNumber = random.nextInt(25000);		
		request.setCompanyName("TestCompany - " + randomNumber);
		request.setCompanySize("Below 300");
		request.setEmailAddress(getTargetEmail());
		request.setEnquiryType(ApplicationConstants.CORPORATE_BIZ);
		request.setFirstName(getRandomName());
		request.setJobFunction("Technical - " + randomNumber);
		request.setLastName(getRandomName());
		request.setPhoneNumber(getMobileNumber());
		return request;
	}

}

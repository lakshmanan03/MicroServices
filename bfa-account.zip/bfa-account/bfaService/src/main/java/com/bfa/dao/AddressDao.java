package com.bfa.dao;

import com.bfa.common.entity.Address;

public interface AddressDao {
	Address createOrUpdateAddress(Address address);
}

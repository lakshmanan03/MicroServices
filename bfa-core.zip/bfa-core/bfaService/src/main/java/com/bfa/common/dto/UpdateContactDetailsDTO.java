package com.bfa.common.dto;

public class UpdateContactDetailsDTO {
	public UpdateCustomerAddressDTO contactDetails;

	public UpdateCustomerAddressDTO getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(UpdateCustomerAddressDTO contactDetails) {
		this.contactDetails = contactDetails;
	}
	

}

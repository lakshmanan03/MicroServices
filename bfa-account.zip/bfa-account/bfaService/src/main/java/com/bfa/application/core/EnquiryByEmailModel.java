/**
 * 
 */
package com.bfa.application.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * BFA-1578
 * 
 * Entity introduced to capture the enquiry by email.
 * 
 * @author Pradheep
 *  
 */
@Entity
@Table(name = "email_request_for_enquiry")
public class EnquiryByEmailModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "email")
	private String email;
	
	@Column(name="last_updated")
	private Date lastUpdated;
	
	@Column(name = "last_updated_by")
	private String lastUpdatedBy;
	
	@Column(name="accept_marketing_emails")
	private boolean acceptMarketingEmails;
	
	@Column(name="mobile_number")
	private String mobileNumber;
	
    @Column(name="contact_via_mobile")
    private boolean contactViaMobile;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public boolean isAcceptMarketingEmails() {
		return acceptMarketingEmails;
	}

	public void setAcceptMarketingEmails(boolean acceptMarketingEmails) {
		this.acceptMarketingEmails = acceptMarketingEmails;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the contactViaMobile
	 */
	public boolean isContactViaMobile() {
		return contactViaMobile;
	}

	/**
	 * @param contactViaMobile the contactViaMobile to set
	 */
	public void setContactViaMobile(boolean contactViaMobile) {
		this.contactViaMobile = contactViaMobile;
	}
	
}

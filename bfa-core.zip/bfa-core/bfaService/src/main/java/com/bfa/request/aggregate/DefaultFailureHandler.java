/**
 * 
 */
package com.bfa.request.aggregate;

import com.bfa.request.processor.FailureHandler;
import com.bfa.request.processor.HttpProcessorGetCommand;
import com.bfa.request.processor.ProcessorCommand;
import com.bfa.request.processor.SuccessHandler;

/**
 * @author pradheep
 *
 */
public class DefaultFailureHandler extends FailureHandler {	

	@Override
	public void run() {
		System.out.println("--- Job Failed ---" );
	}	

}

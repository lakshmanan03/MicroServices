package com.bfa.util;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.ClassPathResource;

/**
 * @author Vimala Shan
 *
 */
public class BFALoggerBean implements InitializingBean {

	public Logger getLogBean(Class classObj) {
		return LogManager.getLogger(classObj);
	}	

	@Override
	public void afterPropertiesSet() throws Exception {
		ClassPathResource resource = new ClassPathResource("bfa-log.properties");
		try {
			PropertyConfigurator.configure(resource.getInputStream());
		} catch (Exception e) {
			getLogBean(this.getClass()).error(
					"Error while loading the logger properties : accounts - log.properties "+ e);
		}
	}
}
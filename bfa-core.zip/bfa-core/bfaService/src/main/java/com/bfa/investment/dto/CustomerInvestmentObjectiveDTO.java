package com.bfa.investment.dto;

import java.util.Date;

import javax.persistence.Column;

import com.bfa.common.entity.OptionItem;
import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerInvestmentObjectiveDTO {
	private Integer customerId;
	private Integer enquiryId;
    private int investmentPeriod;
    private double monthlyIncome;
    private double initialInvestment;
    private double monthlyInvestment;
    private Integer fundingTypeId;
	private Integer portfolioTypeId;
	private String portfolioType;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
    private Date dateOfBirth;
    private double percentageOfSaving;
    private double totalAssets;
    private double totalLiabilities;
	//private String gender;
    
    
	public Integer getCustomerId() {
		return customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	
	public int getInvestmentPeriod() {
		return investmentPeriod;
	}
	public void setInvestmentPeriod(int investmentPeriod) {
		this.investmentPeriod = investmentPeriod;
	}
	public double getMonthlyIncome() {
		return monthlyIncome;
	}
	public void setMonthlyIncome(double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
	public double getInitialInvestment() {
		return initialInvestment;
	}
	public void setInitialInvestment(double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}
	public double getMonthlyInvestment() {
		return monthlyInvestment;
	}
	public void setMonthlyInvestment(double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public double getPercentageOfSaving() {
		return percentageOfSaving;
	}
	public void setPercentageOfSaving(double percentageOfSaving) {
		this.percentageOfSaving = percentageOfSaving;
	}
	public double getTotalAssets() {
		return totalAssets;
	}
	public void setTotalAssets(double totalAssets) {
		this.totalAssets = totalAssets;
	}
	public double getTotalLiabilities() {
		return totalLiabilities;
	}
	public void setTotalLiabilities(double totalLiabilities) {
		this.totalLiabilities = totalLiabilities;
	}
	/*public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}*/

	public Integer getFundingTypeId() {
		return fundingTypeId;
	}

	public void setFundingTypeId(Integer fundingTypeId) {
		this.fundingTypeId = fundingTypeId;
	}

	public Integer getPortfolioTypeId() {
		return portfolioTypeId;
	}

	public void setPortfolioTypeId(Integer portfolioTypeId) {
		this.portfolioTypeId = portfolioTypeId;
	}

	public String getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(String portfolioType) {
		this.portfolioType = portfolioType;
	}
	
}

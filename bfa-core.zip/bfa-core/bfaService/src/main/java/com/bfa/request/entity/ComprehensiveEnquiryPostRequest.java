/**
 * 
 */
package com.bfa.request.entity;

import java.io.Serializable;

import com.bfa.common.dto.ComprehensiveEnquiryDTO;
import com.bfa.comprehensive.core.UpdateCustomerBasicInfo;

public class ComprehensiveEnquiryPostRequest implements Serializable {

	/**
	 * 
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	ComprehensiveEnquiryDTO enquiryObject;
	
	UpdateCustomerBasicInfo customerBasicInfo;
	
	Integer hospitalPlanId;
	
	boolean isForDashBoard;
	
	boolean baseProfileOnlyFlag;

	public Integer getHospitalPlanId() {
		return hospitalPlanId;
	}

	public void setHospitalPlanId(Integer hospitalPlanId) {
		this.hospitalPlanId = hospitalPlanId;
	}

	public ComprehensiveEnquiryDTO getEnquiryObject() {
		return enquiryObject;
	}

	public void setEnquiryObject(ComprehensiveEnquiryDTO enquiryObject) {
		this.enquiryObject = enquiryObject;
	}

	public boolean isBaseProfileOnlyFlag() {
		return baseProfileOnlyFlag;
	}

	public void setBaseProfileOnlyFlag(boolean baseProfileOnlyFlag) {
		this.baseProfileOnlyFlag = baseProfileOnlyFlag;
	}

	public UpdateCustomerBasicInfo getCustomerBasicInfo() {
		return customerBasicInfo;
	}

	public void setCustomerBasicInfo(UpdateCustomerBasicInfo customerBasicInfo) {
		this.customerBasicInfo = customerBasicInfo;
	}
	
	public boolean isForDashBoard() {
		return isForDashBoard;
	}

	public void setForDashBoard(boolean isForDashBoard) {
		this.isForDashBoard = isForDashBoard;
	}
	

}

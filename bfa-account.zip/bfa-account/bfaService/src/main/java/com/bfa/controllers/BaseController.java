package com.bfa.controllers;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.routines.EmailValidator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.BadTokenException;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.dto.CustomerProfileDetails;
import com.bfa.common.entity.BFAUserDetails;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerLoginData;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.ResponseList;
import com.bfa.security.twofa.core.TwoFactorAuthValidation;
import com.bfa.service.AccountsService;
import com.bfa.service.SecurityService;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ErrorCodes;
import com.bfa.util.PublicUtility;
import com.bfa.util.ResponseMessage;
import com.bfa.util.ResponseMessageList;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

public class BaseController {
	
	protected final String API_REGISTER_BUNDLE  = "/api/registerBundleEnquiry";
	
	protected final String API_ENQUIRY_BY_EMAIL_ONLY = "/api/enquiryByEmail";

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	@Autowired
	AccountsService accountService;
	
	@Autowired
	private SecurityConstants securityConstants;
	
	@Autowired
	private SecurityService securityService;
	
	private final int showLastFourChars = 4;
	
	public static final String MASK_STRING = "*";

	public Logger getLogger(Class classObj) {
		return applicationLoggerBean.getLogBean(classObj);
	}
	
	protected JWTAuthToken getAuthToken(HttpServletRequest httpServletRequest) {
		String token = httpServletRequest.getHeader(SecurityConstants.TOKEN_NAME);
		return getTokenInfo(token);
	}
	
	protected Integer getCustomerIdFromAuthToken(javax.servlet.http.HttpServletRequest httpServletRequest) {
		Integer customerId = 0;
		try {
			JWTAuthToken token = getAuthToken(httpServletRequest);
			if (token.getPrincipal() != null) {
				String principle = token.getPrincipal().toString();
				String strCustomerId = PublicUtility.getCustomerIdFromPrincipal(principle);
				getLogger(this.getClass()).info("The principle:" + principle);
				customerId = PublicUtility.tryParseInt(strCustomerId, 0);
			}
		} catch (Exception ex) {
			customerId = 0;
		}
		getLogger(this.getClass()).info("The decrypted customer id:" + customerId);
		
		return customerId;
	}
	
	protected JWTAuthToken getTokenInfo(String token) throws BadTokenException {
		try {
			Claims claims = Jwts.parser().setSigningKey(securityConstants._secret).parseClaimsJws(token).getBody();
			String roles = (String) claims.get("roles");
			roles = roles.replace("[", "");
			roles = roles.replace("]", "");
			List<GrantedAuthority> authorities = new ArrayList<>();
			String[] args = roles.split(",");
			for (String auth : args) {
				GrantedAuthority obj = new BFAGrandtedAuthority(auth.trim().toUpperCase());
				authorities.add(obj);
			}
			
			JWTAuthToken tokenObj = new JWTAuthToken(claims.getSubject());
			tokenObj.setAuthorities(authorities);
			String customerReference = tokenObj.getPrincipal().toString();
			CustomerLoginData customerLoginData = new CustomerLoginData();
			customerLoginData.setCustomerIdEncrypted(customerReference);
			tokenObj.setDetails(customerLoginData);
			return tokenObj;
		} catch (ExpiredJwtException expiredJwtException) {
			getLogger(this.getClass()).error("ExpiredJwtException : " + expiredJwtException);
			throw new BadTokenException(ApplicationConstants.SESSION_TIMEOUT_LOGOUT);
		} catch (final MalformedJwtException | UnsupportedJwtException | SignatureException jwtException) {
			getLogger(this.getClass()).info("Token error:" + jwtException);
			throw new BadTokenException("Invalid token");
		} catch (Exception err) {
			getLogger(this.getClass()).info("Token parsing error.." + err);
			throw new BadTokenException("Invalid token");
		}
	}

	public ResponseMessageList getDefaultMessageList() {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setResponseCode(ErrorCodes.SUCCESSFUL_RESPONSE);
		responseMessage.setResponseDescription(ApplicationConstants.SUCCESSFUL_RESPONSE);
		return new ResponseList(responseMessage);
	}	

	public ResponseMessage getInternalServerError() {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
		responseMessage.setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
		return responseMessage;
	}

	public ResponseMessage getDatabaseAccessExceptionResponse() {
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setResponseCode(ErrorCodes.DB_COMMUNICATION_FAILURE);
		responseMessage.setResponseDescription(ApplicationConstants.DATABASE_COMMUNICATION_FAILURE);
		return responseMessage;
	}
	    
	public List<Object> addObjects(List objects) {
		List<Object> objectCollection = new ArrayList<>();
		objectCollection.addAll(objects);
		return objectCollection;
	}

	public int calculateAge(LocalDate birthDate) {
		LocalDate currentDate = LocalDate.now();
		if ((birthDate != null) && (currentDate != null)) {
			return Period.between(birthDate, currentDate).getYears();
		} else {
			return 0;
		}
	}
	
	protected BFAUserDetails getAuthUser(HttpServletRequest httpServletRequest) {
		BFAUserDetails bfaUser = null;
		Integer customerId = getCustomerId(httpServletRequest);		
		bfaUser = accountService.getUserById(customerId);
		return bfaUser;
	}
	
	protected int getCustomerId(HttpServletRequest httpServletRequest) {
		String customerId = httpServletRequest.getAttribute(SecurityConstants.CUSTOMER_ID_IN_REQUEST).toString();
		getLogger(this.getClass()).info("Printing the customer id :" + customerId);
		if (customerId == null) {
			return -1;
		}
		return Integer.parseInt(customerId);
	}
	
	class JWTAuthToken extends AbstractAuthenticationToken implements Serializable{
		private static final long serialVersionUID = 1L;
		private final Object principal;
		private Object details;

		private Collection<GrantedAuthority> authorities; // Sonar:  Make "authorities" private or transient. 

		public JWTAuthToken(String jwtToken) {
			super(null);
			super.setAuthenticated(true);
			principal = jwtToken;
		}

		public Object getCredentials() {
			return "";
		}

		public Object getPrincipal() {
			return principal;
		}
		
		@Override
		public Collection<GrantedAuthority> getAuthorities() {
			return authorities;
		}

		public void setAuthorities(Collection<GrantedAuthority> authorities) {
			this.authorities = authorities;
		}
	}
	
	/**
	 * Masking the following details.
	 * 1. Mobile Number 
	 * 2. Email
	 * 3. Bank details.   
	 * @param customerProfileDetails
	 */
	public void maskCustomerDetails(CustomerProfileDetails customerProfileDetails){
		String email = customerProfileDetails.getPersonalInformation().getEmail();
		String mobileNumber = customerProfileDetails.getPersonalInformation().getMobileNumber();
		getLogger(this.getClass()).info("Masking the details of customer ,[Email]:" + email);		
		if (null != email) {
			email = maskEmailAddress(email);
			customerProfileDetails.getPersonalInformation().setEmail(email);
		}
		if (null != mobileNumber && mobileNumber.length() >= showLastFourChars) {
			mobileNumber = PublicUtility.maskNumber(mobileNumber).replaceAll("X", MASK_STRING);
			customerProfileDetails.getPersonalInformation().setMobileNumber(mobileNumber);
		}
		if (null != customerProfileDetails.getCustomerBankDetail()) {
			Iterator<CustomerBankDetail> iter = customerProfileDetails.getCustomerBankDetail().iterator();
			while (iter.hasNext()) {
				CustomerBankDetail customerBankDetail = iter.next();
				String bankAccountNumber = customerBankDetail.getAccountNumber();
				if (null != bankAccountNumber && !bankAccountNumber.isEmpty()) {
					bankAccountNumber = PublicUtility.maskBankAccountNumber(bankAccountNumber);					
				}
				customerBankDetail.setAccountNumber(bankAccountNumber);
			}
		}
	}
	
	public String maskEmailAddress(String emailAddress){
		if (EmailValidator.getInstance().isValid(emailAddress)) {
			String name = emailAddress.substring(0, emailAddress.indexOf("@"));
			if (name.length() == 1) {
				name = MASK_STRING;
			} else if (name.length() <= showLastFourChars) {
				name = maskString(name, 1, name.length(), MASK_STRING);
			} else {
				name = maskString(name, showLastFourChars, name.length(), MASK_STRING);
			}
			String email = name + emailAddress.substring(emailAddress.indexOf("@"));
			getLogger(this.getClass()).info("Printing the masked email address:" + email);
			return email;

		} else {
			getLogger(this.getClass()).error("Not a valid email address");			
		}
		return emailAddress;
	}
	
	public String maskString(String rawString, int start, int end, String maskChar) {
		if (rawString == null || rawString.equals("")) {
			return "";
		}
		if (start < 0) {
			start = 0;
		}
		if (end > rawString.length()) {
			end = rawString.length();
		}
		char[] charArr = rawString.toCharArray();
		if (end < start) {
			getLogger(this.getClass()).error("Cannot mask the given string: [Start]:" + start + ",[End]:" + end);
			throw new IllegalArgumentException("End index cannot be less than start index");
		}
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < rawString.length(); i++) {
			if (i >= start && i <= end) {
				buffer.append(maskChar);
			} else {
				buffer.append(charArr[i]);
			}
		}
		return buffer.toString();
	}
	
	public ResponseMessageList get2FAValidationMessage(String sessionId){
		ResponseMessageList responseMessageList = getDefaultMessageList();
		TwoFactorAuthValidation twoFactorAuthValidation = securityService.authenticate2FAWithReturnCode(sessionId);
		Integer returnCode = twoFactorAuthValidation.getReturnCode();
		getLogger(this.getClass()).debug("Printing the response code :" + returnCode);
		switch (returnCode) {
		case ErrorCodes.TWO_FACTOR_AUTH_SUCCESS:
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTH_SUCCESS);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_SUCCEEDED);
			break;
		case ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED:
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTHENTICATION_FAILED);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_FAILED);
			break;
		case ErrorCodes.TWO_FACTOR_AUTH_TIME_EXCEEDED:
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.TWO_FACTOR_AUTH_TIME_EXCEEDED);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.TWO_FA_EXCEEDED_TIME);
			break;
		case ErrorCodes.INVALID_SESSION_ID:
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INVALID_SESSION_ID);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INVALID_SESSION);
			break;
		default:
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
		}
		return responseMessageList;
	}

}


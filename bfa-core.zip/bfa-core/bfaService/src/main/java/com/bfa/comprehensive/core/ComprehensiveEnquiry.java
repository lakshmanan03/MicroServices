/**
 * 
 */
package com.bfa.comprehensive.core;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bfa.util.EnquiryDateAndTimeDeserialize;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * This class is for tracking the comprehensive enquiry changes.
 * 
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "comprehensive_preferences")
public class ComprehensiveEnquiry {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	@JsonIgnore
	private Integer id;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "customer_id")
	private Integer customerId;

	@JsonIgnore
	@Column(name = "session_tracker_id")
	private int sessionTrackerId;

	@Column(name = "type")
	private String type;

	@JsonIgnore
	@Column(name = "created_by")
	private String createdBy;

	@JsonIgnore
	@Column(name = "created_time_stamp")
	private Date createdTimeStamp;
	
	@JsonIgnore
	@Column(name = "updated_by")
	private String updatedBy;

	@JsonIgnore
	@Column(name = "updated_time_stamp")
	private Date updatedTimeStamp;

	@Column(name = "has_Comprehensive")
	private Boolean hasComprehensive;

	@Column(name = "has_Dependents")
	private Boolean hasDependents;

	@Column(name = "has_Endowments")
	private String hasEndowments;

	@Column(name = "has_regular_savings_plans")
	private Boolean hasRegularSavingsPlans;
	
	@Column(name = "generated_token")
	private String generatedToken;	
	
	@Column(name = "wait_for_call")
	private Boolean waitForCall;
	
	@Column(name = "step_completed")
	private Integer stepCompleted;
	
	@Column(name = "sub_step_completed")
	private Integer subStepCompleted;
	
	@Column(name = "report_status")
	private String reportStatus;
	
	@Column(name = "isvalidated_promocode")
	private Boolean isValidatedPromoCode;
	
	@Column(name = "homeloan_updated_by_liabilities")
	private Boolean homeLoanUpdatedByLiabilities;
	
	@Column(name = "is_locked")
	private Boolean isLocked;
	
	@Column(name = "is_DobUpdated")
	private Boolean isDobUpdated;
	
	@Column(name = "submitted_isDobChanged")
	private Boolean dobPopUpEnable;
	
	@Column(name = "isCrm_submitted")
	private Boolean isCrmSubmitted;
	
	@JsonDeserialize(using=EnquiryDateAndTimeDeserialize.class)
	@Column(name = "report_submitted_timestamp")
	private Date reportSubmittedTimeStamp;
	
	@Column(name = "isConfirmationEmail_sent")
	private Boolean isConfirmationEmailSent;
	
	public Boolean getHasComprehensive() {
		return hasComprehensive;
	}

	public void setHasComprehensive(Boolean hasComprehensive) {
		this.hasComprehensive = hasComprehensive;
	}

	public Boolean getHasDependents() {
		return hasDependents;
	}

	public void setHasDependents(Boolean hasDependents) {
		this.hasDependents = hasDependents;
	}

	public String getHasEndowments() {
		return hasEndowments;
	}

	public void setHasEndowments(String hasEndowments) {
		this.hasEndowments = hasEndowments;
	}

	public Boolean getHasRegularSavingsPlans() {
		return hasRegularSavingsPlans;
	}

	public void setHasRegularSavingsPlans(Boolean hasRegularSavingsPlans) {
		this.hasRegularSavingsPlans = hasRegularSavingsPlans;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public int getSessionTrackerId() {
		return sessionTrackerId;
	}

	public void setSessionTrackerId(int sessionTrackerId) {
		this.sessionTrackerId = sessionTrackerId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Date createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	
	public Integer getStepCompleted() {
		return stepCompleted;
	}

	public void setStepCompleted(Integer stepCompleted) {
		this.stepCompleted = stepCompleted;
	}

	public String getReportStatus() {
		return reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}
	
	public Boolean getIsValidatedPromoCode() {
		return isValidatedPromoCode;
	}

	public void setIsValidatedPromoCode(Boolean isValidatedPromoCode) {
		this.isValidatedPromoCode = isValidatedPromoCode;
	}

	@Override
	public String toString() {
		return "ComprehensiveEnquiry [id=" + id + ", enquiryId=" + enquiryId + ", customerId=" + customerId
				+ ", sessionTrackerId=" + sessionTrackerId + ", type=" + type + ", createdBy=" + createdBy
				+ ", createdTimeStamp=" + createdTimeStamp + ", hasComprehensive=" + hasComprehensive
				+ ", hasDependents=" + hasDependents + ", hasEndowments=" + hasEndowments + ", hasRegularSavingsPlans="
				+ hasRegularSavingsPlans + ", stepCompleted=" + stepCompleted + ", reportStatus=" + reportStatus
				+ ", isValidatedPromoCode=" + isValidatedPromoCode + "]";
	}

	public String getGeneratedToken() {
		return generatedToken;
	}

	public void setGeneratedToken(String generatedToken) {
		this.generatedToken = generatedToken;
	}

	public Boolean getWaitForCall() {
		return waitForCall;
	}

	public void setWaitForCall(Boolean waitForCall) {
		this.waitForCall = waitForCall;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedTimeStamp() {
		return updatedTimeStamp;
	}

	public void setUpdatedTimeStamp(Date updatedTimeStamp) {
		this.updatedTimeStamp = updatedTimeStamp;
	}

	public Boolean getHomeLoanUpdatedByLiabilities() {
		return homeLoanUpdatedByLiabilities;
	}

	public void setHomeLoanUpdatedByLiabilities(Boolean homeLoanUpdatedByLiabilities) {
		this.homeLoanUpdatedByLiabilities = homeLoanUpdatedByLiabilities;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public Date getReportSubmittedTimeStamp() {
		return reportSubmittedTimeStamp;
	}

	public void setReportSubmittedTimeStamp(Date reportSubmittedTimeStamp) {
		this.reportSubmittedTimeStamp = reportSubmittedTimeStamp;
	}
	
	public Boolean getIsDobUpdated() {
		return isDobUpdated;
	}

	public void setIsDobUpdated(Boolean isDobUpdated) {
		this.isDobUpdated = isDobUpdated;
	}

	public Boolean getDobPopUpEnable() {
		return dobPopUpEnable;
	}

	public void setDobPopUpEnable(Boolean dobPopUpEnable) {
		this.dobPopUpEnable = dobPopUpEnable;
	}
	
	public Boolean getIsCrmSubmitted() {
		return isCrmSubmitted;
	}

	public void setIsCrmSubmitted(Boolean isCrmSubmitted) {
		this.isCrmSubmitted = isCrmSubmitted;
	}

	public Integer getSubStepCompleted() {
		return subStepCompleted;
	}

	public void setSubStepCompleted(Integer subStepCompleted) {
		this.subStepCompleted = subStepCompleted;
	}

	public Boolean getIsConfirmationEmailSent() {
		return isConfirmationEmailSent;
	}

	public void setIsConfirmationEmailSent(Boolean isConfirmationEmailSent) {
		this.isConfirmationEmailSent = isConfirmationEmailSent;
	}

	

}

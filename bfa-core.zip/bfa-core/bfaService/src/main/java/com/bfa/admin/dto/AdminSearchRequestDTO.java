package com.bfa.admin.dto;

public class AdminSearchRequestDTO {
	
	private String customerName;
	private String iFastRefNo;
	private String mobileNumber;
	private String emailId;
	private Integer moCustomerId;
	private Integer advisorId;	
	private int pageNumber;
	private int recordsPerPage;
	private String orderBy;
	private String order;
	private String accountStatus;
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getiFastRefNo() {
		return iFastRefNo;
	}
	public void setiFastRefNo(String iFastRefNo) {
		this.iFastRefNo = iFastRefNo;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Integer getMoCustomerId() {
		return moCustomerId;
	}
	public void setMoCustomerId(Integer moCustomerId) {
		this.moCustomerId = moCustomerId;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getRecordsPerPage() {
		return recordsPerPage;
	}
	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}
	public Integer getAdvisorId() {
		return advisorId;
	}
	public void setAdvisorId(Integer advisorId) {
		this.advisorId = advisorId;
	}
	public String getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}	
	
	
	

}

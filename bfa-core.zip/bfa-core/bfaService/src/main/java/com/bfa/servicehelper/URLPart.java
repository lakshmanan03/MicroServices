package com.bfa.servicehelper;

import java.util.ArrayList;
import java.util.List;

public class URLPart {
	public String baseUrl;
	public List<String> urlParts;
	
	public URLPart(String baseUrl) {
		urlParts = new ArrayList<>();
		this.baseUrl = baseUrl;
	}
	
	public URLPart create() {
		return new URLPart(baseUrl);
	}
	
	public URLPart root(String root) {
		this.baseUrl = root;
		return this;
	}
	
	public URLPart part(String part) {
		urlParts.add(part);
		return this;
	}
	
	public String getUrlString() {
		String url = baseUrl;
		for(String urlPart : urlParts) {
			url = url + "/" + urlPart;
		}
		return url;
		
	}
}

package com.bfa.investment.dto;

public class UpdateCustomerInvestmentObjective {
	
	private int enquiryId;
	private int investmentPeriod;
	private double initialInvestment;
	 private double monthlyInvestment;
	public int getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}
	public int getInvestmentPeriod() {
		return investmentPeriod;
	}
	public void setInvestmentPeriod(int investmentPeriod) {
		this.investmentPeriod = investmentPeriod;
	}
	public double getInitialInvestment() {
		return initialInvestment;
	}
	public void setInitialInvestment(double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}
	public double getMonthlyInvestment() {
		return monthlyInvestment;
	}
	public void setMonthlyInvestment(double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

}

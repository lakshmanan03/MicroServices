/**
 * 
 */
package com.bfa.request.aggregate;

import java.util.concurrent.CompletableFuture;

import com.bfa.request.processor.ProcessorCommand;

/**
 *   Agrregates the API results cocurrently.
 *   
 * @author pradheep
 * 
 *  @since Release 2.16
 */
public abstract class ServiceAggregator<T extends ProcessorCommand> {			
			
	public abstract CompletableFuture getResults(T obj) throws RuntimeException;	
	
	public abstract void aggregateResults(CompletableFuture<T> ...completableFutures) throws RuntimeException;
	
	public abstract Object getComputedResults();

}

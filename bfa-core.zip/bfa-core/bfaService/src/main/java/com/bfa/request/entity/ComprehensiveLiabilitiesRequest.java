/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author gajendrak
 *
 */
public class ComprehensiveLiabilitiesRequest {
	
	private int enquiryId;
	
	private Double homeLoanOutstandingAmount;
	
	private Double otherPropertyLoanOutstandingAmount;
	
	private Double otherLoanOutstandingAmount;
	
	private Double carLoansAmount;

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}	

	public Double getOtherPropertyLoanOutstandingAmount() {
		return otherPropertyLoanOutstandingAmount;
	}

	public void setOtherPropertyLoanOutstandingAmount(Double otherPropertyLoanOutstandingAmount) {
		this.otherPropertyLoanOutstandingAmount = otherPropertyLoanOutstandingAmount;
	}

	public Double getOtherLoanOutstandingAmount() {
		return otherLoanOutstandingAmount;
	}

	public void setOtherLoanOutstandingAmount(Double otherLoanOutstandingAmount) {
		this.otherLoanOutstandingAmount = otherLoanOutstandingAmount;
	}

	public Double getHomeLoanOutstandingAmount() {
		return homeLoanOutstandingAmount;
	}

	public void setHomeLoanOutstandingAmount(Double homeLoanOutstandingAmount) {
		this.homeLoanOutstandingAmount = homeLoanOutstandingAmount;
	}

	public Double getCarLoansAmount() {
		return carLoansAmount;
	}

	public void setCarLoansAmount(Double carLoansAmount) {
		this.carLoansAmount = carLoansAmount;
	}
	
}

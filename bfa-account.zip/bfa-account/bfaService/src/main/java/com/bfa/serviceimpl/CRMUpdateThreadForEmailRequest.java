package com.bfa.serviceimpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.common.CRMDataTransformer;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.EnquiryWithProtectionType;
import com.bfa.insurance.product.ProductList;
import com.bfa.request.entity.CRMNewEnquiryRequest;
import com.bfa.request.entity.NewEnquiryRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * @author pradheep.p
 *
 */
public class CRMUpdateThreadForEmailRequest extends CRMDataTransformer implements Runnable {

	@Autowired
	private Environment environment;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private String API_NAME = APIConstants.CRM_API;	

	private List<ProductList> selectedProducts;
	
	private boolean isNewCustomer;	 
	
	private Integer enquiryId;
	
	private Integer emailEnquiryId;		
	
	private String firstName;
	
	private String lastName;
	
	private String emailAddress;
	
	private String mobileNumber;

	private Logger getLogger() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}
	
	private List<GrantedAuthority> getGrantedAuthorities(){
		List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
		grantedAuthorities.add(new BFAGrandtedAuthority("ROLE_USER"));
		grantedAuthorities.add(new BFAGrandtedAuthority("ROLE_SERVICE_CALL"));
		return grantedAuthorities;
	}
	

	public void updateCRM(List<ProductList> selectedProducts,int emailEnquiryId) {
		getLogger().info("Making a CRM request - for enquiry made by email");
		setEnvironment(environment);
		String commandName = "crm-new-enquiry-by-email";
		String targetURL = getBaseUrl(ServiceNames.CRM_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + API_NAME;
		NewEnquiryRequest crmEnquiryRequest = new NewEnquiryRequest();
		EnquiryWithProtectionType enquiryDetailsWithProtection = getEnquiryAndProtectionData(enquiryId);		
		mapCRMData(crmEnquiryRequest, selectedProducts,emailEnquiryId,enquiryDetailsWithProtection.getEnquiryDetails());		
		String requestBody = "";		
		// ---------------------------------------------------------------------//
		CRMNewEnquiryRequest crmEnquiryRequestObj = new CRMNewEnquiryRequest();
		crmEnquiryRequestObj.setFirstName(firstName);
		crmEnquiryRequestObj.setLastName(lastName);
		crmEnquiryRequestObj.setEmailAddress(emailAddress);
		
		crmEnquiryRequestObj.setCustomerId(0);
		crmEnquiryRequestObj.setNewEnquiryRequest(crmEnquiryRequest);
		crmEnquiryRequestObj.setSelectedProductList(selectedProducts);
		crmEnquiryRequestObj.setNewCustomer(isNewCustomer());
		crmEnquiryRequestObj.setRequestByEmail(true);
		crmEnquiryRequestObj.setEnquiryId(enquiryId);
		addCategoryAndProtectionType(crmEnquiryRequestObj,enquiryDetailsWithProtection);
		Gson gsonFormater = new GsonBuilder()
				   .setDateFormat("yyyy-MM-dd").create();
		requestBody = gsonFormater.toJson(crmEnquiryRequestObj);		
		getLogger().info("Printing the target URL :" + targetURL);
		getLogger().info(">> Calling crm microservice -" + "Request body :" + requestBody);
		addJobToQueue(targetURL, requestBody, commandName, 0);
		// ----------------------------------------------------------------------//
		getLogger().info("CRM Jobs added to queue");
	}	

	private void mapCRMData(NewEnquiryRequest newEnquiryRequest, List<ProductList> selectedProducts,int emailEnquiryId,Enquiry enquiryDetails) {
		try {
			String surName = "";
			StringBuffer eventPlans = new StringBuffer();
			Iterator<ProductList> productListIterator = selectedProducts.iterator();
			while (productListIterator.hasNext()) {
				ProductList productObj = productListIterator.next();
				eventPlans.append(productObj.getProductName());
				if (productListIterator.hasNext()) {
					eventPlans.append(" ");
				}
			}
			getLogger().info("Printing the event plans " + eventPlans.toString());
			newEnquiryRequest.setSubject(ApplicationConstants.CRM_REQUEST_SUBJECT);
			newEnquiryRequest.setEmail(emailAddress);
			if (StringUtils.isBlank(mobileNumber)) {
				newEnquiryRequest.setContact(getRandomContactNumber(emailEnquiryId));
			} else {
				newEnquiryRequest.setContact(mobileNumber);
			}
			newEnquiryRequest.setName(firstName);			
			surName = lastName;			
			String gender = "";
			String dateOB = "";
			if (null != enquiryDetails) {
				gender = enquiryDetails.getGender();
				dateOB = enquiryDetails.getDateOfBirth();
			} else {
				getLogger().error("Unable to obtain the date of birth and gender (BFA-1513)");
			}
			getLogger().info("Printing the gender :" + gender);
			newEnquiryRequest.setLast_name(surName);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf.setLenient(false);
			newEnquiryRequest.setEmail_date(sdf.format(new Date()));
			newEnquiryRequest.setGender(gender);
			String smoker = "No";			
			newEnquiryRequest.setSmoker(smoker);
			newEnquiryRequest.setContactTime("NA"); // As per Vadhani
			if (eventPlans.toString().isEmpty()) {
				newEnquiryRequest.setEventPlan("Protection Plan");
			} else {
				newEnquiryRequest.setEventPlan(eventPlans.toString());
			}
			newEnquiryRequest.setCategory("Protection");						
			getLogger().info("Printing the date of birth sent to CRM: " + dateOB);
			newEnquiryRequest.setDob(dateOB); // Set a empty date of birth for enquiry by email. //
			newEnquiryRequest.setDescription("New customer request");
		} catch (Exception err) {
			getLogger().error("Conversion of CRM data failed ", err);
			err.printStackTrace();
		}
	}
	
	/**
	 * Utility method to convert the date from Enquiry table to CRM
	 * acceptable date format.<BR></BR>
	 * 
	 * <B>DOB format from Enquiry table :</B>  dd-MM-yyyy<BR/>
	 * <B>DOB format to CRM call        :</B>  yyyy-MM-dd
	 * 
	 * @param dobFromEnquiryTable - String
	 * @param crmDateFormat - SimpleDateFormat
	 * @return - DOB with CRM acceptable format / Incoming format if any exception happened.
	 */
    private String convertDOBForCRM(String dobFromEnquiryTable, SimpleDateFormat crmDateFormat) {
        try {
            Date dobDateObj = new SimpleDateFormat("dd-MM-yyyy").parse(dobFromEnquiryTable);
            return crmDateFormat.format(dobDateObj);
        } catch (NullPointerException | IllegalArgumentException | ParseException  exc) {
            getLogger().error("Exception while converting DOB for CRM, Hence not converting further, returning as : " + dobFromEnquiryTable);
            return dobFromEnquiryTable;
        }    
    }

	@Override
	public void run() {
		getLogger().info("Updating the CRM Details ..");
		setEnvironment(environment);
		loadSecurityHeader(securityConstants.TOKEN_NAME,getGrantedAuthorities());
		updateCRM(getSelectedProducts(),getEmailEnquiryId());		
	}
	
	/**
	 * The logic is to generate a unique mobile number
	 *  It will be like 1 + <padding with zero> " + emailEnquiryId = Totally a valid 10 digit number 
	 * @param emailEnquiryId
	 * @return
	 */
	public String getRandomContactNumber(Integer emailEnquiryId) {
		StringBuffer contactNumber = new StringBuffer();
		contactNumber.append("1");
		String temp = emailEnquiryId.toString();
		// Pad the contact number with zero //
		for(int y=0;y<9-temp.length();y++){
			contactNumber.append("0");
		}
		contactNumber.append(temp);
		getLogger().info("Printing the contact number :" + contactNumber.toString());
		return contactNumber.toString();
	}
	
	public List<ProductList> getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(List<ProductList> selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public boolean isNewCustomer() {
		return isNewCustomer;
	}

	public void setNewCustomer(boolean isNewCustomer) {
		this.isNewCustomer = isNewCustomer;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Integer getEmailEnquiryId() {
		return emailEnquiryId;
	}

	public void setEmailEnquiryId(Integer emailEnquiryId) {
		this.emailEnquiryId = emailEnquiryId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}	
	
	}

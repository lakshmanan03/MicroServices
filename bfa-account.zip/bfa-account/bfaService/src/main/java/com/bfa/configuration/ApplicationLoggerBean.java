/**
 * 
 */
package com.bfa.configuration;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.ClassPathResource;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * @author pradheep.p
 *
 */
public class ApplicationLoggerBean implements InitializingBean{
	
	private LogManager logManager = new LogManager();

	public Logger getLogBean(Class classObj) {
		return logManager.getLogger(classObj);
	}	

	@Override
	public void afterPropertiesSet() throws Exception {
		ClassPathResource resource = new ClassPathResource("accounts-log.properties");
		try {
			PropertyConfigurator.configure(resource.getInputStream());
		} catch (Exception e) {
			getLogBean(this.getClass()).error(
					"Error while loading the logger properties : accounts - log.properties "+ e.getMessage());
		}
	}
}
package com.bfa.serviceimpl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.core.ApplicationContext;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.admin.dto.AdminCustomerDetails;
import com.bfa.admin.dto.AdminCustomerSummary;
import com.bfa.application.core.AccountStatus;
import com.bfa.application.core.CustomerAndPrevilege;
import com.bfa.application.core.UpdateMobileNumberRequest;
import com.bfa.application.exception.DatabaseAccessException;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.common.dto.AddressDTO;
import com.bfa.common.dto.ContactDetailsDTO;
import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.dto.CustomerProfileDetails;
import com.bfa.common.dto.EmploymentDetailsDTO;
import com.bfa.common.dto.HouseholdDTO;
import com.bfa.common.dto.ProfileSummaryDTO;
import com.bfa.common.dto.UpdateContactDetailsDTO;
import com.bfa.common.dto.UpdateCustomerAddressDTO;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerBankDetail;
import com.bfa.common.entity.CustomerContactVerification;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.CustomerIdentityDetails;
import com.bfa.common.entity.CustomerLiabilitiesDetail;
import com.bfa.common.entity.EmployerAddress;
import com.bfa.common.entity.EmployerDetails;
import com.bfa.common.entity.Household;
import com.bfa.common.entity.Occupation;
import com.bfa.common.entity.OptionItem;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.configuration.jpa.CustomerRepository;
import com.bfa.dao.AccountsDao;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.CRMResponse;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.account.dto.CustomerDetailsDTO;
import com.bfa.investment.account.dto.PersonalDetailsDTO;
import com.bfa.investment.dto.CustomerIFasteAccountDTO;
import com.bfa.investment.dto.FinancialDetailsDTO;
import com.bfa.investment.dto.InvestementDashboardStatusDTO;
import com.bfa.investment.dto.PEPAdditionalDeclarationDTO;
import com.bfa.investment.dto.PersonalDeclarationDTO;
import com.bfa.investment.dto.UpdatePasswordDTO;
import com.bfa.investment.entity.CustomerAdditionalDetails;
import com.bfa.investment.entity.CustomerDocumentDetails;
import com.bfa.investment.entity.CustomerIFastAccount;
import com.bfa.investment.entity.CustomerInvestmentObjective;
import com.bfa.investment.entity.CustomerPEPDetails;
import com.bfa.notification.messenger.SMSInitiator;
import com.bfa.request.entity.CustomerCreationPostRequest;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.ServiceResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class AccountsServiceImplTest {

	@InjectMocks
	private AccountsServiceImpl mAccountsServiceImpl;
	
	@Mock
	private HttpServletRequest mHttpServletRequest;
	
	@Mock
	private CustomerCreationPostRequest mCustomerReq;
	
	@Mock
	private Customer mCustomer;
	
	@Mock
	private AccountsDao mAccountsDao;
	
	@Mock
	private CustomerAndPrevilege mCustomerAndPrevilege;
	
	@Mock
	private CustomerAdditionalDetails mCustomerAdditionalDetails;
	
	@Mock
	private ContactDetailsDTO mContactDetailsDTO;
	
	@Mock
	private InvestmentAccountDao mInvestmentAccountDao;
	
	@Mock
	private UpdateContactDetailsDTO mUpdateContactDetailsDTO;
	
	@Mock
	private UpdateCustomerAddressDTO mUpdateCustomerAddressDTO;
	
	@Mock
	private AddressDTO mAddressDTO;
	
	@Mock
	private Address mAddress;
	
	@Mock
	private UpdatePasswordDTO mUpdatePasswordDTO;
	
	@Mock
	private CustomerContactVerification mCCVerification;
	
	@Mock
	private CustomerLiabilitiesDetail mLiabilitiesDetail;
	
	@Mock
	private Income mIncome;
	
	@Mock
	private MultipartFile mMultipartFile;
	
	@Mock
	private CustomerDocumentDetails mCustomertDetails;
	
	@Mock
	private CustomerDetailsDTO mCustomerDetailsDTO;
	
	@Mock
	private EmploymentDetailsDTO mEmploymentDetailsDTO;
	
	@Mock
	private CustomerEmploymentInformation mCustomerEmploymentInfo;
	
	@Mock
	private CustomerBankDetail mCustomerBankDetail;
	
	@Mock
	private CustomerIdentityDetails mCustomerIdentityDetails;
	
	@Mock
	private CustomerEmploymentDetails mCustomerEmploymentDetails;
	
	@Mock
	private Country mCountry;
	
	@Mock
	private EmployerAddress mEmployerAddress;
	
	@Mock
	private CustomerPEPDetails mCustomerPEPDetails;
	
	@Mock
	private Occupation mOccupation;
	
	@Mock
	private OptionItem mOptionItem;
	
	@Mock
	private CustomerIFastAccount mCustomerIFastAccount;
	
	@Mock
	private AdminCustomerDetails mAdminCustomerDetails;
	
	@Mock
	private AccountStatus mAccountStatus;
	
	@Mock 
	private UpdateMobileNumberRequest mUpdateMobileNumberRequest;
	
	@Mock
	private DefaultServiceImpl mDefaultServiceImpl;
	
	@Mock
	private List mCustomersList;
	
	@Mock
	private List mEnquiryList;
	
	@Mock
	private MOInvestmentService mMOInvestmentService;
	
	@Mock
	private InvestementDashboardStatusDTO mInvestementDashboardStatusDTO;
	
	@Mock
	private CustomerIFasteAccountDTO mCustomerIFasteAccountDTO;
	
	@Mock
	private Enquiry mEnquiry;
	
	@Mock
	private PersonalDetailsDTO mPersonalDetailsDTO;
	
	@Mock
	private EmployerDetails mEmployerDetails;
	
	@Mock
	private HouseholdDTO mHouseholdDTO;
	
	@Mock
	private Household mHousehold;
	
	@Mock
	private FinancialDetailsDTO mFinancialDetailsDTO;
	
	@Mock
	private Assets mAssets;
	
	@Mock
	private CRMResponse mCRMResponse;
	
	@Mock
	private PersonalDeclarationDTO mPersonalDeclarationDTO;
	
	@Mock
	private CustomerInvestmentObjective mCusInvestmentObj;
	
	@Mock
	private PEPAdditionalDeclarationDTO mPEPAdditionalDeclarationDTO;
	
	@Mock
	private Liabilities mLiabilities;
	
	@Mock
	private ApplicationContext mApplicationContext;
	
	List<Object> objectList =new ArrayList<>();
	
	int cusId = 1;

	int enqId = 1;

	int advId = 1;
	
	private String customerId = "1";
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;
	
	@Mock
	private SMSInitiator communicator;
	
	@Mock
	private CustomerRepository mCustomerRepository;
	
//	@Mock
	private Optional<Customer> mCustomerData;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
		
	@Test(expected = NullPointerException.class)
	public void testSignup() {
			when(mCustomerReq.getCustomer()).thenReturn(mCustomer);
			when(mCustomerReq.getCustomer().getMobileNumber()).thenReturn("6123357");
			when(mCustomerReq.getCustomer().getCountryCode()).thenReturn("+61");
			when(mCustomerReq.getJourneyType()).thenReturn("insurance");
			when(mCustomerAndPrevilege.getCustomer()).thenReturn(mCustomer);
			when(mAccountsDao.signup(mCustomerReq)).thenReturn(mCustomerAndPrevilege);
			CustomerAndPrevilege response = mAccountsServiceImpl.signup(mCustomerReq);
			assertNull(response);
	}

	@Test
	public void testGetCustomerAdditionalDetails() {

		CustomerAdditionalDetails response = mAccountsServiceImpl.getCustomerAdditionalDetails(cusId);
		assertNull(response);
	}


	@Test
	public void testGetCustomerAdditionalDetailsException() {
		when(mAccountsDao.getAdditionalDetails(cusId)).thenThrow(new RuntimeException());
		CustomerAdditionalDetails response = mAccountsServiceImpl.getCustomerAdditionalDetails(cusId);
		assertNull(response);
	}
	
	@Test
	public void testUpdateCustomerAdditionalDetails() {
		try {
			when(mCustomerAdditionalDetails.getConnectedToInvestmentFirm()).thenReturn(true);
			when(mCustomerAdditionalDetails.getCustomer()).thenReturn(mCustomer);
			mAccountsServiceImpl.updateCustomerAdditionalDetails(mCustomerAdditionalDetails);
		} catch (DatabaseAccessException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testUpdateCustomerAdditionalDetailsException() {

		doThrow(new RuntimeException()).when(mAccountsDao).saveOrUpdateObject(mCustomerAdditionalDetails);
		mAccountsServiceImpl.updateCustomerAdditionalDetails(mCustomerAdditionalDetails);

	}
	
	@Test
	public void testGetAuthorities() {
		List<BFAGrandtedAuthority> response = mAccountsServiceImpl.getAuthorities(mCustomer);
		assertNotNull(response);
	}

	@Test
	public void testReIssueOTP() {
		boolean response=mAccountsServiceImpl.reIssueOTP("",cusId);
		assertNotNull(response);
		assertFalse(response);
	}

	@Test
	public void testGetProfileSummary() {
		when(mCustomersList.get(0)).thenReturn(mCustomer);
		when(mAccountsDao.getObjectsByRef(Customer.class, "email", "abc@ntuc.com")).thenReturn(mCustomersList);
		ProfileSummaryDTO response = mAccountsServiceImpl.getProfileSummary("abc@ntuc.com");
		assertNotNull(response);
	}
	
	@Test
	public void testGetProfileSummaryById() {
		//when(mCustomersList.get(0)).thenReturn(mCustomer);
		mCustomersList.add(3);
	//	when(mAccountsDao.getObjectByHql("from Customer where id = 1")).thenReturn(mCustomersList);
		when(mAccountsDao.getObjectByHql("from Customer where id=:customerId","customerId", customerId)).thenReturn(mCustomersList);
		ProfileSummaryDTO response = mAccountsServiceImpl.getProfileSummaryById(cusId);
		assertNull(response);
	}

	@Test
	public void testGetCustomerProfileDetailsString() {
		when(mCustomer.getNationalityCode()).thenReturn("12");
		when(mInvestmentAccountDao.getNationality("12")).thenReturn(mCountry);
		when(mCustomersList.get(0)).thenReturn(mCustomer);
		when(mAccountsDao.getObjectsByRef(Customer.class, "email", "abc@ntuc.com")).thenReturn(mCustomersList);
		ProfileSummaryDTO response = mAccountsServiceImpl.getCustomerProfileDetails("abc@ntuc.com");
		assertNotNull(response);
	}

	@Test
	public void testGetCustomerProfileDetailsInteger() {
		when(mCustomerIFasteAccountDTO.getAccountStatus()).thenReturn("INVESTMENT_ACCOUNT_DETAILS_SAVED");
		when(mInvestementDashboardStatusDTO.getAccount()).thenReturn(mCustomerIFasteAccountDTO);
		when(mMOInvestmentService.customerInvestmentProfile(cusId)).thenReturn(mInvestementDashboardStatusDTO);
		when(mCustomer.getId()).thenReturn(1);
		when(mCustomersList.get(0)).thenReturn(mCustomer);
		when(mCustomer.getNationalityCode()).thenReturn("singaporian");
		when(mCustomerAdditionalDetails.getRegistrationProofType()).thenReturn("MY-INFO");
		when(mInvestmentAccountDao.getNationality("singaporian")).thenReturn(mCountry);
		when(mAccountsDao.getAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(mAccountsDao.getObjectByHql("from Customer where id = 1")).thenReturn(mCustomersList);
		when(mAccountsDao.getObjectByHql("from Enquiry where type = 'Comprehensive' and customerId = 1")).thenReturn(mEnquiryList);
		when(mEnquiryList.get(0)).thenReturn(mEnquiry);
		ProfileSummaryDTO response = mAccountsServiceImpl.getCustomerProfileDetails(cusId);
		assertNull(response);
		
	}

	@Test
	public void testGetCustomerDetails() {
		Customer response =  mAccountsServiceImpl.getCustomerDetails("gajendra@ntuc.com");
		assertNull(response);
	}

	@Test
	public void testGetDetailsByCustomerId() {
		Customer response =  mAccountsServiceImpl.getDetailsByCustomerId(cusId);
		assertNull(response);
	}

	@Test
	public void testUpdateCustomerContactDetails() {
		
		try {
			when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
			when(mCustomer.getMobileNumber()).thenReturn("63248185");
			when(mCustomer.getEmail()).thenReturn("xyz@ntuc.com");
			when(mContactDetailsDTO.getMobileNumber()).thenReturn("81218079");
			when(mContactDetailsDTO.getEmailId()).thenReturn("abc@ntuc.com");
			ServiceResponse<Boolean> response = mAccountsServiceImpl.updateCustomerContactDetails(cusId,mContactDetailsDTO, mHttpServletRequest);
			assertNotNull(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testUpdateCustomerAddress() {
		
		try {
			when(mUpdateContactDetailsDTO.getContactDetails()).thenReturn(mUpdateCustomerAddressDTO);
			when(mUpdateCustomerAddressDTO.getHomeAddress()).thenReturn(mAddressDTO);
			when(mUpdateCustomerAddressDTO.getMailingAddress()).thenReturn(mAddressDTO);
			when(mCustomer.getHomeAddress()).thenReturn(mAddress);
			when(mCustomer.getMailingAddress()).thenReturn(mAddress);
			mAccountsServiceImpl.updateCustomerAddress(mCustomer, mCustomerDetailsDTO);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testEditPassword() {
		String str = "passwrord";
		byte[] byteArr = str.getBytes();
		when(mCustomer.getPassword()).thenReturn(byteArr);
		boolean response = mAccountsServiceImpl.editPassword(mCustomer, mUpdatePasswordDTO);
		assertNotNull(response);
		assertFalse(response);
	}

	@Test
	public void testEditContactDetails() {
		try {
			when(mAccountsDao.getCustomerVerificationDetailsbyId(cusId)).thenReturn(mCCVerification);
			when(mCCVerification.getMobileNumber()).thenReturn("81218079");
			when(mCCVerification.getCountryCode()).thenReturn("+65");
			CustomerContactVerification res = mAccountsServiceImpl.editContactDetails(mContactDetailsDTO, cusId);
			assertNotNull(res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*@Test
	public void testGetDetailedCustomerSummary() {
		when(mCustomer.getDateOfBirth()).thenReturn("20/05/1983");
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		when(mInvestmentAccountDao.getCustomerLiabilityDetailByEnquiryId(cusId)).thenReturn(mLiabilitiesDetail);
		when(mInvestmentAccountDao.getCustomerIncomeDetails(cusId)).thenReturn(mIncome);
		DetailedCustomerSummary res = mAccountsServiceImpl.getDetailedCustomerSummary(cusId);
		assertNotNull(res);
	}*/

	@Test
	public void testSaveDocument() {
		when(mMultipartFile.getOriginalFilename()).thenReturn("abc\\.def\\.xyz");
		ServiceResponse<Map<String, String>> res = mAccountsServiceImpl.saveDocument(cusId, mMultipartFile, "jpg");
		assertNotNull(res);
	}

	@Test
	public void testDeleteDocument() {
		when(mInvestmentAccountDao.getCustomerDocumentDetails(cusId, "doc")).thenReturn(mCustomertDetails);
		boolean  response =	mAccountsServiceImpl.deleteDocument(cusId, "doc");
		assertFalse(response);
	}
	
	@Test
	public void testDeleteDocumentEXception() {
		when(mInvestmentAccountDao.getCustomerDocumentDetails(cusId, "doc")).thenThrow(new RuntimeException());
		boolean  response =	mAccountsServiceImpl.deleteDocument(cusId, "doc");
		assertNotNull(response);
		assertFalse(response);
	}

	
	@Test
	public void testSaveCustomerDetails() {
		Date mDate= new Date();
		when(mFinancialDetailsDTO.getAnnualIncome()).thenReturn(72000.00);
		when(mFinancialDetailsDTO.getPercentageOfSaving()).thenReturn(40.00);
		when(mFinancialDetailsDTO.getIncomeRange()).thenReturn("incrange");
		when(mAddressDTO.getReasonId()).thenReturn(1);
		when(mAddressDTO.getReasonForOthers()).thenReturn("reason");
		when(mCustomerDetailsDTO.getMailingAddress()).thenReturn(mAddressDTO);
		when(mCustomerDetailsDTO.getResidentialAddress()).thenReturn(mAddressDTO);
		when(mCustomerDetailsDTO.getFinancialDetails()).thenReturn(mFinancialDetailsDTO);
		when(mCustomerDetailsDTO.getPersonalDeclarations()).thenReturn(mPersonalDeclarationDTO);
		when(mCustomerDetailsDTO.isMyInfoVerified()).thenReturn(true);
		when(mCustomerDetailsDTO.getHouseholdDetails()).thenReturn(mHouseholdDTO);
		when(mCustomerDetailsDTO.getPersonalInfo()).thenReturn(mPersonalDetailsDTO);
		when(mCustomerDetailsDTO.getEmploymentDetails()).thenReturn(mEmploymentDetailsDTO);
		when(mCustomer.getMailingAddress()).thenReturn(mAddress);
		when(mCustomer.getId()).thenReturn(1);
		when(mCustomer.getHouseHoldDetail()).thenReturn(mHousehold);
		when(mPEPAdditionalDeclarationDTO.getFirstName()).thenReturn("abc");
		when(mPEPAdditionalDeclarationDTO.getLastName()).thenReturn("xyz");
		when(mPEPAdditionalDeclarationDTO.getCompanyName()).thenReturn("MoneyOwl");
		when(mPEPAdditionalDeclarationDTO.getInvestmentDuration()).thenReturn("60");
		when(mPEPAdditionalDeclarationDTO.getOccupationId()).thenReturn(10);
		when(mPEPAdditionalDeclarationDTO.getOtherOccupation()).thenReturn("eng");
		when(mPEPAdditionalDeclarationDTO.getExpectedAmountPerTransaction()).thenReturn(500.00);
		when(mPEPAdditionalDeclarationDTO.getExpectedNumberOfTransactions()).thenReturn(1);
		when(mPEPAdditionalDeclarationDTO.getAdditionalInfo()).thenReturn("addInfo");
		when(mPEPAdditionalDeclarationDTO.getInvestmentSourceId()).thenReturn(1);
		when(mPEPAdditionalDeclarationDTO.getEarningSourceId()).thenReturn(1);
		when(mPEPAdditionalDeclarationDTO.getInvestmentSourceId()).thenReturn(1);
		when(mPersonalDeclarationDTO.getPepDeclaration()).thenReturn(mPEPAdditionalDeclarationDTO);
		when(mPersonalDeclarationDTO.getInvestmentSourceId()).thenReturn(1);
		when(mPersonalDeclarationDTO.isBeneficialOwner()).thenReturn(true);
		when(mPersonalDeclarationDTO.isPoliticallyExposed()).thenReturn(true);
		when(mInvestmentAccountDao.getCustomerLiabilitiesDetails(cusId)).thenReturn(mLiabilities);
		when(mInvestmentAccountDao.getCustomerEnquiryDetails(cusId)).thenReturn(mEnquiry);
		when(mInvestmentAccountDao.getCustomerIncomeDetails(cusId)).thenReturn(mIncome);
		when(mInvestmentAccountDao.getCustomerPEPDetails(cusId)).thenReturn(mCustomerPEPDetails);
		when(mInvestmentAccountDao.getCustomerAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(mInvestmentAccountDao.getCustomerInvestmentObjective(cusId)).thenReturn(mCusInvestmentObj);
		when(mHouseholdDTO.getHouseHoldIncomeId()).thenReturn(1);
		when(mEmployerDetails.getId()).thenReturn(1);
		when(mPersonalDetailsDTO.getRace()).thenReturn("singaporian");
		when(mPersonalDetailsDTO.getSalutation()).thenReturn("Salutation");
		when(mPersonalDetailsDTO.getFullName()).thenReturn("abc");
		when(mPersonalDetailsDTO.getFirstName()).thenReturn("xyz");
		when(mPersonalDetailsDTO.getLastName()).thenReturn("abc");
		when(mPersonalDetailsDTO.getGender()).thenReturn("male");
		when(mPersonalDetailsDTO.getDateOfBirth()).thenReturn(mDate);
		when(mPersonalDetailsDTO.getBirthCountryId()).thenReturn(123);
		when(mEmploymentDetailsDTO.getEmployerAddress()).thenReturn(mAddressDTO);
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		when(mInvestmentAccountDao.getCustomerEmploymentInformation(cusId)).thenReturn(mCustomerEmploymentInfo);
		when(mCustomerEmploymentInfo.getEmployerDetails()).thenReturn(mEmployerDetails);
		ServiceResponse<Map<String, String>> res = mAccountsServiceImpl.saveCustomerDetails(mCustomerDetailsDTO, cusId);
		assertNotNull(res);
	}

	@Test
	public void testSaveCustomerDetailsElse(){
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		ServiceResponse<Map<String, String>> res = 	mAccountsServiceImpl.saveCustomerDetails(null,cusId);
		assertNotNull(res);
	}
	
	@Test
	public void testSaveCustomerDetailsElseIf(){
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(null);
		ServiceResponse<Map<String, String>> res = 	mAccountsServiceImpl.saveCustomerDetails(mCustomerDetailsDTO,cusId);
		assertNotNull(res);
	}
	
	
	@Test
	public void testUpdateEmployment() {
		when(mCustomer.getId()).thenReturn(cusId);
		when(mInvestmentAccountDao.getCustomerEmploymentInformation(cusId)).thenReturn(mCustomerEmploymentInfo);
		mAccountsServiceImpl.updateEmployment(mCustomer, mEmploymentDetailsDTO);
	}

	@Test
	public void testGetCustomerBankDetails() {
		List<CustomerBankDetail> res = mAccountsServiceImpl.getCustomerBankDetails(cusId);
		assertNotNull(res);
	}

	@Test
	public void testSaveCustomerBankDetail() {
		
		try {
			when(mCustomerBankDetail.getId()).thenReturn(1);
			when(mCustomerBankDetail.getCustomerId()).thenReturn(cusId);
			when(mAccountsDao.getCustomerBankDetail(1, cusId)).thenReturn(mCustomerBankDetail);
			CustomerBankDetail res = mAccountsServiceImpl.saveCustomerBankDetail(mCustomerBankDetail);
			assertNotNull(res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetCustomerAddresses() {
		when(mAccountsDao.getCustomerById(cusId)).thenReturn(mCustomer);
		when(mCustomer.getHomeAddress()).thenReturn(mAddress);
		when(mCustomer.getMailingAddress()).thenReturn(mAddress);
		Map<String, Address> res = mAccountsServiceImpl.getCustomerAddresses(cusId);
		assertNotNull(res);
	}

	@Test
	public void testGetCustomerDetailsById() {
		String str = "passwrord";
		byte[] byteArr = str.getBytes();
		when(mCustomer.getGivenName()).thenReturn("abc");
		when(mCustomer.getSurName()).thenReturn("ch");
		when(mCustomer.getNricName()).thenReturn("bunny");
		when(mCustomer.getGender()).thenReturn("male");
		when(mCustomer.getDateOfBirth()).thenReturn("20081995");
		when(mCustomer.getMobileNumber()).thenReturn("81218079");
		when(mCustomer.getCountryCode()).thenReturn("male");
		when(mCustomer.getEmail()).thenReturn("abc@ntuc.com");
		when(mCustomer.getPassword()).thenReturn(byteArr);
		when(mCustomer.getNationalityCode()).thenReturn("+65");
		when(mCustomer.getHomeAddress()).thenReturn(mAddress);
		when(mCustomer.getMailingAddress()).thenReturn(mAddress);
		when(mCustomer.getHomeAddress().getCountry()).thenReturn(mCountry);
		when(mCustomer.getMailingAddress().getCountry()).thenReturn(mCountry);
		when(mAddress.getCountry()).thenReturn(mCountry);
		when(mCountry.getId()).thenReturn(1);
		when(mCustomerIdentityDetails.getNricNumber()).thenReturn("123");
		when(mCustomerAdditionalDetails.getSingaporePR()).thenReturn(true);
		when(mCustomerEmploymentInfo.getCustomerEmploymentDetails()).thenReturn(mCustomerEmploymentDetails);
		when(mCustomerEmploymentInfo.getEmployerAddress()).thenReturn(mEmployerAddress);
		when(mEmployerAddress.getEmployerAddress()).thenReturn(mAddress);
		when(mInvestmentAccountDao.getNationality("+65")).thenReturn(mCountry);
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		when(mInvestmentAccountDao.getCustomerAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(mInvestmentAccountDao.getCustomerEmploymentInformation(cusId)).thenReturn(mCustomerEmploymentInfo);
		when(mInvestmentAccountDao.getCustomerIdentityDetails(cusId)).thenReturn(mCustomerIdentityDetails);
		CustomerProfileDetails res = mAccountsServiceImpl.getCustomerDetailsById(cusId);
		assertNotNull(res);
	}

	@Test
	public void testGetInvestmentDashboardStatus() {
		
		when(mAccountsDao.getAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		InvestementDashboardStatusDTO res = mAccountsServiceImpl.getInvestmentDashboardStatus(cusId);
		assertNotNull(res);
	}
	
	@Test
	public void testGetCustomerSummaryByAdvisor() {
		
        List<Customer> customerList = new ArrayList<>();
        customerList.add(mCustomer);
        when(mCustomer.getId()).thenReturn(cusId);
        when(mCustomerPEPDetails.getOccupation()).thenReturn(mOccupation);
        when(mCustomerPEPDetails.getEarningsGeneratedFromId()).thenReturn(mOptionItem);
        when(mCustomerPEPDetails.getInvestmentSourceId()).thenReturn(mOptionItem);
        when(mCustomerPEPDetails.getPepAddress()).thenReturn(mAddress);
        when(mAddress.getCountry()).thenReturn(mCountry);
		when(mInvestmentAccountDao.getCustomerByAdvisor(advId)).thenReturn(customerList);
		when(mInvestmentAccountDao.getCustomerAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(mInvestmentAccountDao.getCustomerPEPDetails(cusId)).thenReturn(mCustomerPEPDetails);
		List<AdminCustomerDetails> responseList = mAccountsServiceImpl.getCustomerSummaryByAdvisor(advId);
		assertNotNull(responseList);
	}

	@Test
	public void testFindCustomers() {
		
	}

	@Test
	public void testSendEmail() {
		when(mCustomer.getNricName()).thenReturn("bunny");
		when(mCustomer.getEmail()).thenReturn("abc@ntuc.com");
		mAccountsServiceImpl.sendEmail(mCustomer);
	}

	@Test(expected = NullPointerException.class)
	public void testFetchIndividualCustomerDetails() {
		when(mCustomer.getId()).thenReturn(1);
		when(mAccountsDao.getCustomerByAdvisor(cusId, advId)).thenReturn(mCustomer);
		when(mCustomerIFastAccount.getIfastRefno()).thenReturn("1234");
		when(mInvestmentAccountDao.getCustomerAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(mInvestmentAccountDao.getCustomerLiabilityDetailByEnquiryId(cusId)).thenReturn(mLiabilitiesDetail);
		when(mInvestmentAccountDao.getCustomerIFastAccountDetails(cusId)).thenReturn(mCustomerIFastAccount);
	
		when(mCustomerRepository.findByIdAndAdvisorId(cusId, advId)).thenReturn(mCustomerData);		
		
		AdminCustomerDetails response = mAccountsServiceImpl.fetchIndividualCustomerDetails(cusId, advId);
		assertNotNull(response);
	}

	@Test(expected = NullPointerException.class)
	public void testFetchCustomerSummary() {
		when(mCustomer.getId()).thenReturn(1);
		when(mAccountsDao.getCustomerByAdvisor(cusId, advId)).thenReturn(mCustomer);
		when(mCustomerIFastAccount.getIfastRefno()).thenReturn("1234");
		when(mInvestmentAccountDao.getCustomerAdditionalDetails(cusId)).thenReturn(mCustomerAdditionalDetails);
		when(mInvestmentAccountDao.getCustomerLiabilityDetailByEnquiryId(cusId)).thenReturn(mLiabilitiesDetail);
		when(mInvestmentAccountDao.getCustomerIFastAccountDetails(cusId)).thenReturn(mCustomerIFastAccount);
		when(mAdminCustomerDetails.getCustomer()).thenReturn(mCustomer);
		
		when(mCustomerRepository.findByIdAndAdvisorId(cusId, advId)).thenReturn(mCustomerData);		
		
		AdminCustomerSummary response = mAccountsServiceImpl.fetchCustomerSummary(cusId, advId);
		assertNotNull(response);
	}

	@Test
	public void testAddAdvisor() {
		try {
			when(mAccountsDao.getCustomerById(cusId)).thenReturn(mCustomer);
			Customer response = mAccountsServiceImpl.addAdvisor(cusId, advId);
			assertNotNull(response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSaveDocumentV2() {

		ServiceResponse<Map<String, String>> res = mAccountsServiceImpl.saveDocumentV2(cusId, mHttpServletRequest, "jpg");
		assertNotNull(res);
	}

	@Test(expected = NullPointerException.class)
	public void testUpdateCustomerInformationV2() {
		mAccountsServiceImpl.updateCustomerInformationV2(enqId, mCustomer, true);
	}

	@Test
	public void testUpdateMobileAndEmailUniqueness() {
		mAccountsServiceImpl.updateMobileAndEmailUniqueness("81218079", "abc@ntuc.com", mAccountStatus);
	}

	@Test
	public void testUpdateMobileNumber() {
		when(mDefaultServiceImpl.getCustomerByReferenceV1("IMXYlDmP4f4=")).thenReturn(mCustomer);
		when(mUpdateMobileNumberRequest.getCustomerRef()).thenReturn("IMXYlDmP4f4=");
		ServiceResponse<Boolean> response = mAccountsServiceImpl.updateMobileNumber(mUpdateMobileNumberRequest);
		assertNotNull(response);
	}
	
	@Test
	public void testSaveAssetLiabilitiesDetails() throws Exception {
		when(mCustomer.getId()).thenReturn(1);
		when(mCustomerDetailsDTO.getFinancialDetails()).thenReturn(mFinancialDetailsDTO);
		when(mInvestmentAccountDao.getCustomerAssetDetails(cusId)).thenReturn(mAssets);
		Whitebox.invokeMethod(mAccountsServiceImpl, "saveAssetLiabilitiesDetails", mCustomerDetailsDTO, mCustomer);
	}
	
	@Test
	public void testFormatDOB() throws Exception {
		String response = Whitebox.invokeMethod(mAccountsServiceImpl, "formatDOB", "1983-05-20");
		assertNotNull(response);
	}
	
	@Test
	public void testUpdateCRMDetailsOfCustomer() {
		objectList.add(mCustomer);
		when(mCRMResponse.getAgent_id()).thenReturn("456");
		when(mCRMResponse.getEntity_id()).thenReturn("989");
		when(mCRMResponse.getCustomerId()).thenReturn(12);
		when(mAccountsDao.getObjectsById(Customer.class, "id", 12)).thenReturn(objectList);
		mAccountsServiceImpl.updateCRMDetailsOfCustomer(mCRMResponse);
	}
	
	@Test
	public void testSaveHouseholdDetails() throws Exception {
		when(mCustomerDetailsDTO.getHouseholdDetails()).thenReturn(mHouseholdDTO);
		when(mHouseholdDTO.getHouseHoldIncomeId()).thenReturn(1);
		when(mCustomer.getHouseHoldDetail()).thenReturn(null);
		Whitebox.invokeMethod(mAccountsServiceImpl, "saveHouseholdDetails", mCustomerDetailsDTO, mCustomer);
	}
	
	@Test
	public void testSaveHouseholdDetailsElse() throws Exception {
		when(mCustomerDetailsDTO.getHouseholdDetails()).thenReturn(mHouseholdDTO);
		when(mHouseholdDTO.getNumberOfMembers()).thenReturn(1);
		when(mHouseholdDTO.getHouseHoldIncomeId()).thenReturn(null);
		when(mCustomer.getHouseHoldDetail()).thenReturn(null);
		Whitebox.invokeMethod(mAccountsServiceImpl, "saveHouseholdDetails", mCustomerDetailsDTO, mCustomer);
	}
	
}

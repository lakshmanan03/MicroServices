/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author gajendrak
 *
 */
public class ValidatePromoCodeRequest {
	
	private String comprehensivePromoCodeToken;
	
	private String promoCodeCat;
	
	private String sessionId;
	
	private Integer enquiryId;

	
	public String getComprehensivePromoCodeToken() {
		return comprehensivePromoCodeToken;
	}

	public void setComprehensivePromoCodeToken(String comprehensivePromoCodeToken) {
		this.comprehensivePromoCodeToken = comprehensivePromoCodeToken;
	}
	
	public String getPromoCodeCat() {
		return promoCodeCat;
	}

	public void setPromoCodeCat(String promoCodeCat) {
		this.promoCodeCat = promoCodeCat;
	}
	
	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
	
	
}

package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerAMLStatus;
import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.Occupation;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.CustomerAMLDao;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.insurance.core.Customer;
import com.bfa.util.AMLVerificationServiceResponse;
import com.bfa.util.AMLVerificationStatus;
@RunWith(SpringJUnit4ClassRunner.class)
public class ArtemisAMLVerificationServiceTest {

	@InjectMocks
	private ArtemisAMLVerificationService mArtemisAMLVerifService;
	
	@Mock
	private InvestmentAccountDao mInvestmentAccountDao;
	
	@Mock
	private CustomerAMLDao mCusAmlDao;
	
	@Mock
	private Customer mCustomer;

	@Mock
	private CustomerAMLStatus mCustomerAMLStatus;
	
	@Mock
	private CustomerEmploymentInformation mCusEmplInfo;
	
	@Mock
	private CustomerEmploymentDetails mCusEmpDetails;
	
	@Mock
	private Address mAddress;
	
	@Mock
	private Country mCountry;
	
	@Mock
	private Occupation mOccupation;

	Integer cusId = 1;

	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}
	
	@Test 
	public void testVerify() {

		when(mCusAmlDao.getCustomerAMLStatus(cusId)).thenReturn(mCustomerAMLStatus);
		when(mCustomerAMLStatus.getApprovalStatus()).thenReturn("ACCEPTED");
		when(mCustomerAMLStatus.getCheckStatusURL()).thenReturn("//sdjgks/adc.com");
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		when(mCustomer.getId()).thenReturn(cusId);
		AMLVerificationServiceResponse response = mArtemisAMLVerifService.verify(cusId);
		assertNotNull(response);
	}

	@Test
	public void testDoVerify(){
		try {
			when(mCountry.getNationality()).thenReturn("Singaporian");
			when(mCountry.getCountry()).thenReturn("Singapore");
			when(mAddress.getCountry()).thenReturn(mCountry);
			when(mAddress.getAddressLine1()).thenReturn("8 Shenton Way");
			when(mAddress.getAddressLine2()).thenReturn(" # 33-03 AXA Tower");
			when(mAddress.getState()).thenReturn("Singapore");
			when(mCustomer.getHomeAddress()).thenReturn(mAddress);
			when(mCustomer.getId()).thenReturn(cusId);
			when(mCustomer.getDateOfBirth()).thenReturn("05/20/1983");
			when(mCustomer.getNationalityCode()).thenReturn("1234");
			when(mInvestmentAccountDao.getNationality("1234")).thenReturn(mCountry);
			when(mInvestmentAccountDao.getCustomerEmploymentInformation(cusId)).thenReturn(mCusEmplInfo);
			when(mCusEmplInfo.getCustomerEmploymentDetails()).thenReturn(mCusEmpDetails);
			when(mCusEmpDetails.getOccupation()).thenReturn(mOccupation);
			AMLVerificationServiceResponse response = Whitebox.invokeMethod(mArtemisAMLVerifService, "doVerify", mCustomer);
			assertNotNull(response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testClearVerification() {
		when(mCusAmlDao.getCustomerAMLStatus(cusId)).thenReturn(mCustomerAMLStatus);
		when(mCustomerAMLStatus.getApprovalStatus()).thenReturn("ACCEPTED");
		when(mCustomerAMLStatus.getCheckStatusURL()).thenReturn("//sdjgks/adc.com");
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		when(mCustomer.getId()).thenReturn(cusId);
		AMLVerificationServiceResponse response = mArtemisAMLVerifService.clearVerification(cusId);
		assertNotNull(response);
	}

	@Test
	public void testClearVerificationException() {
		when(mCusAmlDao.getCustomerAMLStatus(cusId)).thenThrow(new RuntimeException());
		when(mInvestmentAccountDao.getCustomer(cusId)).thenReturn(mCustomer);
		when(mCustomer.getId()).thenReturn(cusId);
		AMLVerificationServiceResponse response = mArtemisAMLVerifService.clearVerification(cusId);
		assertNotNull(response);
	}

	@Test
	public void testCreateCustomerAMLStatus() {

		Map<String, Object> amlInfo = new HashMap<>();
		amlInfo.put("approval_status", "approved");
		amlInfo.put("status", "success");
		amlInfo.put("cust_rfr_id", "123");
		amlInfo.put("check_status_url", "https:localhost");
		try {
			CustomerAMLStatus response = Whitebox.invokeMethod(mArtemisAMLVerifService, "createCustomerAMLStatus", amlInfo);
			assertNotNull(response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetAMLVerificationStatus() {
		try {
			AMLVerificationStatus response = Whitebox.invokeMethod(mArtemisAMLVerifService, "getAMLVerificationStatus", "PENDING");
			assertNotNull(response);
			
			AMLVerificationStatus res1 = Whitebox.invokeMethod(mArtemisAMLVerifService, "getAMLVerificationStatus", "CLEARED");
			assertNotNull(res1);
			
			AMLVerificationStatus res2 = Whitebox.invokeMethod(mArtemisAMLVerifService, "getAMLVerificationStatus", "ACCEPTED");
			assertNotNull(res2);
			
			AMLVerificationStatus res3 = Whitebox.invokeMethod(mArtemisAMLVerifService, "getAMLVerificationStatus", "REJECTED");
			assertNotNull(res3);
			
			AMLVerificationStatus res4 = Whitebox.invokeMethod(mArtemisAMLVerifService, "getAMLVerificationStatus", "empty");
			assertNotNull(res4);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testBuildArtemisUserFrom() {
		try {
			when(mCustomer.getId()).thenReturn(cusId);
			when(mCustomer.getNricName()).thenThrow(new RuntimeException());
			ArtemisUser response = Whitebox.invokeMethod(mArtemisAMLVerifService, "buildArtemisUserFrom",mCustomer);
			assertNotNull(response);
		} catch (Exception e) {
		}
	}
}

package com.bfa.service;

import com.bfa.util.AMLVerificationServiceResponse;

public interface AMLVerificationService {

	AMLVerificationServiceResponse verify(Integer customerId);

	AMLVerificationServiceResponse clearVerification(Integer customerId);
	
}

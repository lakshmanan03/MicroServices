/**
 * 
 */
package com.bfa.service;

import java.util.List;

import com.bfa.application.core.EnquiryByEmail;
import com.bfa.application.core.ValidateCaptchaBean;
import com.bfa.insurance.core.DependentMapping;

/**
 * This class has the business methods to do enquiry related tasks.
 * 
 * @author pradheep
 *
 */
public interface EnquiryService {
	
	public final String SUCCESS = "Success";
	
	public final String ERROR = "Error";
	
	public final String INVALID_CAPTCHA = "Invalid captcha";
	
	public final String INVALID_EMAIL_ADDRESS = "Invalid email address";
	
	public String updateSelectedProductsByEmail(ValidateCaptchaBean validateCaptchaBean,EnquiryByEmail enquiryByEmail) throws RuntimeException;
	
	public List<DependentMapping> getDependentDetails(Integer enquiryId);
	
}

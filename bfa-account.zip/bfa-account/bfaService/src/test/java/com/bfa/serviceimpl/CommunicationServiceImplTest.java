package com.bfa.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.insurance.core.Customer;
@RunWith(SpringJUnit4ClassRunner.class)
public class CommunicationServiceImplTest {

	@InjectMocks
	private CommunicationServiceImpl mCommunicationServiceImpl;
    
	@Mock
	private AccountsDao mAccountsDao;
    
    @Mock
    private List custList;
    
	@Mock
	private Customer mCustomer;
    
	String mobileNumber = "61235987";

	String emailAddress = "abc@ntuc.com";

	String callBackUrl = "//sdjgks/adc.com";

	String hostedServerName = "tomcat";

	Integer expected = 0;
	
	@Mock
	private ApplicationLoggerBean mApplicationLoggerBean;

	@Mock
	private Logger mLogger;

	@Before 
	public void setUp() {
		when(mApplicationLoggerBean.getLogBean(Mockito.any())).thenReturn(mLogger);	      
	}


	@Test
	public void testResendVerificationEmailMain() {
		when(mAccountsDao.getObjectByHql("from Customer where mobileNumber = '61235987'")).thenReturn(custList);
		when(custList.size()).thenReturn(1);
		when(custList.get(0)).thenReturn(mCustomer);
		Integer res = mCommunicationServiceImpl.resendVerificationEmail(mobileNumber, emailAddress, callBackUrl, hostedServerName);
		assertNotNull(res);
	}
	
    
	@Test
	public void testResendVerificationEmail() {
		Integer res = mCommunicationServiceImpl.resendVerificationEmail(mobileNumber, emailAddress, callBackUrl, hostedServerName);
		assertNotNull(res);
		assertEquals(res, expected);
	}
	
	@Test
	public void testResendVerificationEmailExceptionMblNull() {
		when(mAccountsDao.getObjectByHql("from Customer where email = 'abc@ntuc.com'")).thenReturn(custList);
		when(custList.size()).thenReturn(1);
		when(custList.get(0)).thenReturn(mCustomer);
		Integer response = mCommunicationServiceImpl.resendVerificationEmail(null, emailAddress, callBackUrl, hostedServerName);
		assertNotNull(response);
	}

	
	@Test
	public void testResendVerificationEmailException() {
		Integer response = mCommunicationServiceImpl.resendVerificationEmail(null, emailAddress, callBackUrl, hostedServerName);
		assertNotNull(response);
		assertEquals(response, expected);
	}

	@Test
	public void testSendWelcomeEmailComprehensive(){
		try {
			when(mAccountsDao.getObjectByHql("from Customer where mobileNumber = '61235987'")).thenReturn(custList);
			when(custList.size()).thenReturn(1);
			when(custList.get(0)).thenReturn(mCustomer);
			Integer response = mCommunicationServiceImpl.sendWelcomeEmailComprehensive(mobileNumber, emailAddress, callBackUrl, hostedServerName);
			assertNotNull(response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testSendWelcomeEmailComprehensiveMbl(){
		try {
			when(mAccountsDao.getObjectByHql("from Customer where email = 'abc@ntuc.com'")).thenReturn(custList);
			when(custList.size()).thenReturn(1);
			when(custList.get(0)).thenReturn(mCustomer);
			Integer response = mCommunicationServiceImpl.sendWelcomeEmailComprehensive(null, emailAddress, callBackUrl, hostedServerName);
			assertNotNull(response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testSendWelcomeEmailComprehensiveEmail() throws Exception {
		Integer res = mCommunicationServiceImpl.sendWelcomeEmailComprehensive(mobileNumber, emailAddress, callBackUrl, hostedServerName);
		assertNotNull(res);
		assertEquals(res, expected);
	}
	
	@Test
	public void testSendWelcomeEmailComprehensiveMblExcpetion() throws Exception {
		Integer res = mCommunicationServiceImpl.sendWelcomeEmailComprehensive(null, emailAddress, callBackUrl, hostedServerName);
		assertNotNull(res);
		assertEquals(res, expected);
	}
	
	@Test
	public void testSendWelcomeEmailComprehensiveEmailExcpetion() throws Exception {
		Integer res = mCommunicationServiceImpl.sendWelcomeEmailComprehensive(null, null, callBackUrl, hostedServerName);
		assertNotNull(res);
	}
	
	@Test
	public void testResendVerificationEmailNull() throws Exception {
		Integer res = mCommunicationServiceImpl.resendVerificationEmail(null, null, callBackUrl, hostedServerName);
		assertNotNull(res);
	}
}

package com.bfa.investment.entity;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_purchased_portfolios")
public class CustomerPortfolioStatusView {
	
	@Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "id")
	  private int id;
	
	@Column(name = "portfolioid")
	private String portfolioid;
	
	@Column(name = "enquiryid")
	private Integer enquiryid;
	
	@Column(name = "customerid")
	private Integer customerid;
	
	@Column(name = "portfoliostatus")
	private String portfolioStatus;
	
	@Column(name = "lastmonthlytopupdate")
	private Date lastmonthlytopupdate;
	
	@Column(name = "monthlyinvestment")
	private Double monthlyinvestment;
	
	@Column(name = "referencenumber")
	private String refencenumber;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "customerPortfolioId")
	private Integer customerPortfolioId;
	

	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the refencenumber
	 */
	public String getRefencenumber() {
		return refencenumber;
	}

	/**
	 * @param refencenumber the refencenumber to set
	 */
	public void setRefencenumber(String refencenumber) {
		this.refencenumber = refencenumber;
	}

	public String getPortfolioid() {
		return portfolioid;
	}

	public void setPortfolioid(String portfolioid) {
		this.portfolioid = portfolioid;
	}

	public Integer getEnquiryid() {
		return enquiryid;
	}

	public void setEnquiryid(Integer enquiryid) {
		this.enquiryid = enquiryid;
	}

	public Integer getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}

	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	public Date getLastmonthlytopupdate() {
		return lastmonthlytopupdate;
	}

	public void setLastmonthlytopupdate(Date lastmonthlytopupdate) {
		this.lastmonthlytopupdate = lastmonthlytopupdate;
	}

	public Double getMonthlyinvestment() {
		return monthlyinvestment;
	}

	public void setMonthlyinvestment(Double monthlyinvestment) {
		this.monthlyinvestment = monthlyinvestment;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerPortfolioStatusView [id=");
		builder.append(id);
		builder.append(", portfolioid=");
		builder.append(portfolioid);
		builder.append(", enquiryid=");
		builder.append(enquiryid);
		builder.append(", customerid=");
		builder.append(customerid);
		builder.append(", portfolioStatus=");
		builder.append(portfolioStatus);
		builder.append(", lastmonthlytopupdate=");
		builder.append(lastmonthlytopupdate);
		builder.append(", monthlyinvestment=");
		builder.append(monthlyinvestment);
		builder.append(", refencenumber=");
		builder.append(refencenumber);
		builder.append(", email=");
		builder.append(email);
		builder.append("]");
		return builder.toString();
	}
	
	

}

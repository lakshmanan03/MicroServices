package com.bfa.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;

import com.bfa.util.ServiceResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class UploadServiceTest {

	@InjectMocks
    private UploadService mUploadService;
	
	@Mock
	private MultipartFile mUploadedFile;
	
	int cusId=1;
	
	@Test
	@Ignore
	public void testSaveDocument() {
		when(mUploadedFile.getOriginalFilename()).thenReturn("uploadfile.txt");
		ServiceResponse<Map<String, String>> response = mUploadService.saveDocument(cusId, mUploadedFile, "type");
		assertNotNull(response);
	}

}

/**
 * 
 */
package com.bfa.investment.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author divakaru
 *
 */
public class RSPRunDTO {
	
	private int month;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd",  timezone = "UTC")
	private Date executionTiming;
	private String status;
	private String errorDetails;
	/**
	 * @return the month
	 */
	public int getMonth() {
		return month;
	}
	/**
	 * @param month the month to set
	 */
	public void setMonth(int month) {
		this.month = month;
	}
	/**
	 * @return the executionTiming
	 */
	public Date getExecutionTiming() {
		return executionTiming;
	}
	/**
	 * @param executionTiming the executionTiming to set
	 */
	public void setExecutionTiming(Date executionTiming) {
		this.executionTiming = executionTiming;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the errorDetails
	 */
	public String getErrorDetails() {
		return errorDetails;
	}
	/**
	 * @param errorDetails the errorDetails to set
	 */
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RSPRunDTO [month=");
		builder.append(month);
		builder.append(", executionTiming=");
		builder.append(executionTiming);
		builder.append(", status=");
		builder.append(status);
		builder.append(", errorDetails=");
		builder.append(errorDetails);
		builder.append("]");
		return builder.toString();
	}

}


package com.bfa.investment.ifast.dto;

import java.util.List;
import java.util.Map;

public class DPMSHoldingsSummary {
	Double totalValue;
	Double totalReturns;
	Double investmentReturns;
	CashAccountDetail cashAccountDetails;
	Double totalInvested;

	public Double getTotalInvested() {
		return totalInvested;
	}

	public void setTotalInvested(Double totalInvested) {
		this.totalInvested = totalInvested;
	}

	List<DPMSPortfolio> portfolios;

	public Double getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(Double totalValue) {
		this.totalValue = totalValue;
	}

	public Double getTotalReturns() {
		return totalReturns;
	}

	public void setTotalReturns(Double totalReturns) {
		this.totalReturns = totalReturns;
	}

	public Double getInvestmentReturns() {
		return investmentReturns;
	}

	public void setInvestmentReturns(Double investmentReturns) {
		this.investmentReturns = investmentReturns;
	}

	public CashAccountDetail getCashAccountDetails() {
		return cashAccountDetails;
	}

	public void setCashAccountDetails(CashAccountDetail cashAccountDetails) {
		this.cashAccountDetails = cashAccountDetails;
	}

	public List<DPMSPortfolio> getPortfolios() {
		return portfolios;
	}

	public void setPortfolios(List<DPMSPortfolio> portfolios) {
		this.portfolios = portfolios;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DPMSHoldingsSummary [totalValue=");
		builder.append(totalValue);
		builder.append(", totalReturns=");
		builder.append(totalReturns);
		builder.append(", investmentReturns=");
		builder.append(investmentReturns);
		builder.append(", cashAccountDetails=");
		builder.append(cashAccountDetails);
		builder.append(", totalInvested=");
		builder.append(totalInvested);
		builder.append(", portfolios=");
		builder.append(portfolios);
		builder.append("]");
		return builder.toString();
	}

}

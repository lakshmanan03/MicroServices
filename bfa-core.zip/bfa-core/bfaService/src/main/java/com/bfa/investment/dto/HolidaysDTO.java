/**
 * 
 */
package com.bfa.investment.dto;

/**
 * @author divakaru
 *
 */
public class HolidaysDTO {
	
	private Boolean isHoliday;
	private String descryption;
	/**
	 * @return the isHoliday
	 */
	public Boolean getIsHoliday() {
		return isHoliday;
	}
	/**
	 * @param isHoliday the isHoliday to set
	 */
	public void setIsHoliday(Boolean isHoliday) {
		this.isHoliday = isHoliday;
	}
	/**
	 * @return the descryption
	 */
	public String getDescryption() {
		return descryption;
	}
	/**
	 * @param descryption the descryption to set
	 */
	public void setDescryption(String descryption) {
		this.descryption = descryption;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("HolidaysDTO [isHoliday=");
		builder.append(isHoliday);
		builder.append(", descryption=");
		builder.append(descryption);
		builder.append("]");
		return builder.toString();
	}

}

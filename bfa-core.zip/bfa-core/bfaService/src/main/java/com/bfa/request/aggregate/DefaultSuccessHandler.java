/**
 * 
 */
package com.bfa.request.aggregate;

import com.bfa.request.processor.BFAHttpOperations;
import com.bfa.request.processor.HttpProcessorGetCommand;
import com.bfa.request.processor.ProcessorCommand;
import com.bfa.request.processor.SuccessHandler;
import com.bfa.util.BFAHttpResponse;

/**
 * @author pradheep
 *
 */
public class DefaultSuccessHandler extends SuccessHandler implements BFAHttpOperations {	
	
	private BFAHttpResponse httpResponse;

	@Override
	public void run() {
		ProcessorCommand command = (ProcessorCommand) getSource();
		if (command instanceof HttpProcessorGetCommand) {
			HttpProcessorGetCommand httpProcessorGetCommand = (HttpProcessorGetCommand) command;
			setSource(httpProcessorGetCommand);
		}
	}

	@Override
	public void setNextCommand(ProcessorCommand processorCommand) {
		
	}

	@Override
	public BFAHttpResponse getPreOpreratedResponse() {		
		return this.httpResponse;
	}

	@Override
	public void setPreOpreratedResponse(BFAHttpResponse httpResponse) {
		this.httpResponse = httpResponse;		
	}

}

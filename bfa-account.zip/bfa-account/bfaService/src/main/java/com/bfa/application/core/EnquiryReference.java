/**
 * 
 */
package com.bfa.application.core;

/**
 * @author kianann
 *
 */
public class EnquiryReference {

	private Integer enquiryId;

	/**
	 * @return the enquiryId
	 */
	public Integer getEnquiryId() {
		return enquiryId;
	}

	/**
	 * @param enquiryId the enquiryId to set
	 */
	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}
}

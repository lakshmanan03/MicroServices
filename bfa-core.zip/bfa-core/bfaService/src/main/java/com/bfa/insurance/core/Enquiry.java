/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.bfa.util.EnquiryDateAndTimeDeserialize;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "enquiry")
public class Enquiry implements Serializable{	
	

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "profile_status_id")
	private int profileStatusId;	
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "care_giver_id")
	private int careGiverId;
	
	@Column(name = "hospital_class_id")
	private int hospitalClassId;	
	
	@Column(name = "session_tracker_id")
	private int sessionTrackerId;
	
	@Column(name = "type")
	private String type;
	
	@Column(name = "gender")
	private String gender;	
	
	@Column(name = "date_of_birth")
	private String dateOfBirth;
	
	@JsonProperty(value="isSmoker")	
	@Column(name = "is_smoker")
	private Boolean isSmoker = false;
	
	@Column(name = "employment_status_id")
	private int employmentStatusId;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "number_of_dependents")
	private int numberOfDependents;
	
	@Column(name = "premium_waiver")
	private boolean hasPremiumWaiver;
	
	@Column(name = "created_by")
	private String createdBy;	
	
	@JsonDeserialize(using=EnquiryDateAndTimeDeserialize.class)
	@Column(name = "created_time_stamp")
	private Date createdTimeStamp;
	
	@Column(name="promo_code_id")
	private String promoCodeId;
	
	@Column(name = "enquiry_by_email_id")
	private Integer enquiryByEmailId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getProfileStatusId() {
		return profileStatusId;
	}

	public void setProfileStatusId(int profileStatusId) {
		this.profileStatusId = profileStatusId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getCareGiverId() {
		return careGiverId;
	}

	public void setCareGiverId(int careGiverId) {
		this.careGiverId = careGiverId;
	}

	public int getHospitalClassId() {
		return hospitalClassId;
	}

	public void setHospitalClassId(int hospitalClassId) {
		this.hospitalClassId = hospitalClassId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}	

	@JsonProperty(value="isSmoker")
	public Boolean isSmoker() {
		return isSmoker;
	}

	public void setIsSmoker(Boolean isSmoker) {
		this.isSmoker = isSmoker;
	}

	public int getEmploymentStatusId() {
		return employmentStatusId;
	}

	public void setEmploymentStatusId(int employmentStatusId) {
		this.employmentStatusId = employmentStatusId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getNumberOfDependents() {
		return numberOfDependents;
	}

	public void setNumberOfDependents(int numberOfDependents) {
		this.numberOfDependents = numberOfDependents;
	}

	@JsonProperty(value="hasPremiumWaiver")
	public boolean isHasPremiumWaiver() {
		return hasPremiumWaiver;
	}

	public void setHasPremiumWaiver(boolean hasPremiumWaiver) {
		this.hasPremiumWaiver = hasPremiumWaiver;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Date createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public int getSessionTrackerId() {
		return sessionTrackerId;
	}

	public void setSessionTrackerId(int sessionTrackerId) {
		this.sessionTrackerId = sessionTrackerId;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPromoCodeId() {
		return promoCodeId;
	}

	public void setPromoCodeId(String promoCodeId) {
		this.promoCodeId = promoCodeId;
	}

	public Integer getEnquiryByEmailId() {
		return enquiryByEmailId;
	}

	public void setEnquiryByEmailId(Integer enquiryByEmailId) {
		this.enquiryByEmailId = enquiryByEmailId;
	}
	
}

package com.bfa.investment.ifast.dto;

public class UpdateAccountRequest {

	private String bankCode;
	private String bankAcctNo;
	private String bankAcctName;
	private String bankAgreeFlag;
	private String srsAcctNo;
	private String srsOperator;

	public String getSrsAcctNo() {
		return srsAcctNo;
	}

	public void setSrsAcctNo(String srsAcctNo) {
		this.srsAcctNo = srsAcctNo;
	}

	public String getSrsOperator() {
		return srsOperator;
	}

	public void setSrsOperator(String srsOperator) {
		this.srsOperator = srsOperator;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankAcctNo() {
		return bankAcctNo;
	}

	public void setBankAcctNo(String bankAcctNo) {
		this.bankAcctNo = bankAcctNo;
	}

	public String getBankAcctName() {
		return bankAcctName;
	}

	public void setBankAcctName(String bankAcctName) {
		this.bankAcctName = bankAcctName;
	}

	public String getBankAgreeFlag() {
		return bankAgreeFlag;
	}

	public void setBankAgreeFlag(String bankAgreeFlag) {
		this.bankAgreeFlag = bankAgreeFlag;
	}

	@Override
	public String toString() {
		return "UpdateAccountRequest [bankCode=" + bankCode + ", bankAcctNo=" + bankAcctNo + ", bankAcctName="
				+ bankAcctName + ", bankAgreeFlag=" + bankAgreeFlag + ", srsAcctNo=" + srsAcctNo + ", srsOperator="
				+ srsOperator + "]";
	}

	
	
	

}

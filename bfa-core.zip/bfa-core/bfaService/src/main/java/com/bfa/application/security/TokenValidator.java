/**
 * 
 */
package com.bfa.application.security;

import org.springframework.security.authentication.AbstractAuthenticationToken;

/**
 * @author pradheep.p
 *
 */
public interface TokenValidator {
	
	public AbstractAuthenticationToken validateToken(String token) throws BadTokenException;
	
}

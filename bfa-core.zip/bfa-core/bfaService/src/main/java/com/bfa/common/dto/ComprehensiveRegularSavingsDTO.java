/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ComprehensiveRegularSavingsDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private Integer id;
	
	@JsonIgnore
	private Integer customerId;

	private Integer enquiryId;

	private String regularUnitTrust;

	private Double regularPaidByCash;

	private Double regularPaidByCPF;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getRegularUnitTrust() {
		return regularUnitTrust;
	}

	public void setRegularUnitTrust(String regularUnitTrust) {
		this.regularUnitTrust = regularUnitTrust;
	}

	public Double getRegularPaidByCash() {
		return regularPaidByCash;
	}

	public void setRegularPaidByCash(Double regularPaidByCash) {
		this.regularPaidByCash = regularPaidByCash;
	}

	public Double getRegularPaidByCPF() {
		return regularPaidByCPF;
	}

	public void setRegularPaidByCPF(Double regularPaidByCPF) {
		this.regularPaidByCPF = regularPaidByCPF;
	}

}

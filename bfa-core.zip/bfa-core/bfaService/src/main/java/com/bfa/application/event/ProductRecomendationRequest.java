package com.bfa.application.event;

public class ProductRecomendationRequest {

	private String protection_type;
	
	private String smoker;
	
	private String gender;
	
	private String age;
	
	private String coverage_amount;
	
	private String type;
	
	private String purpose;
	
	private String objective;
	
	private String rider;
	
	private int pageNumber;
	
	private int recordsPerPage;

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getRecordsPerPage() {
		return recordsPerPage;
	}

	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	public String getProtection_type() {
		return protection_type;
	}

	public void setProtection_type(String protection_type) {
		this.protection_type = protection_type;
	}

	public String getSmoker() {
		return smoker;
	}

	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getCoverage_amount() {
		return coverage_amount;
	}

	public void setCoverage_amount(String coverage_amount) {
		this.coverage_amount = coverage_amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public String getRider() {
		return rider;
	}

	public void setRider(String rider) {
		this.rider = rider;
	}

}

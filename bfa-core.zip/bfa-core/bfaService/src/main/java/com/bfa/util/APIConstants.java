/**
 * 
 */
package com.bfa.util;

/**
 * @author pradheep.p
 *
 */
public interface APIConstants {

	public static String UPDATE_CUSTOMER_ID_API = "/api/updateCustomerId";

	/**
	 * To be used for calling CRM API in recommendations microservice.
	 */
	public static String UPDATE_CRM_API = "/api/updateCRM";

	/**
	 * This call is to make the request to CRM Microservice.
	 */
	public static String CRM_API = "/api/updateEnquiryInCRM";

	public static String GET_PRODUCTS_API = "/api/getRecommendedProducts";

	public static String UPDATE_SELECTED_PRODUCTS = "/api/updateSelectedProducts";

	public static String UPDATE_CUSTOMER_CRM_INFO = "/api/updateCustomerCrmInfo";

	public static String CREATE_ENQUIRY = "/api/createEnquiry";
	
	public static String CREATE_COMPRE_ENQUIRY = "/api/createComprehensiveEnquiry";

	public static String GET_SESSION_ID = "/api/getSessionDetails";

	public static String GET_COMPREHENSIVE_USER_SUMMARY = "/api/customer/comprehensive/getComprehensiveUserSummary";
	
	public static String FETCH_COMPREHENSIVE_STATUS = "/api/customer/comprehensive/fetchComprehensiveStatus";
	
	public static String GET_COMPREHENSIVE_RECOMMENDATIONS = "/api/customer/comprehensive/getComprehensiveRecommedations";

	public static String GET_COMPREHENSIVE_ENQUIRY_DETAILS = "/api/customer/comprehensive/getComprehensiveEnquiryDetails";

	public static String SAVE_COMPREHENSIVE_ENQUIRY_DETAILS = "/api/customer/comprehensive/saveComprehensivePreferences";

	public static String GET_COMPREHENSIVE_FINANCIAL_ENQUIRY_DETAILS = "/api/customer/comprehensive/getComprehensiveFinancialEnquiryDetails";

	public static String SAVE_COMPREHENSIVE_ASSETS = "/api/customer/comprehensive/saveComprehensiveAssets";

	public static String SAVE_COMPREHENSIVE_EXPENSES = "/api/customer/comprehensive/saveExpenses";

	public static String SAVE_INSURANCE_PLANNING = "/api/customer/comprehensive/saveInsurancePlanning";

	public static String SAVE_COMPREHENSIVE_RETIREMENT_PLANNING = "/api/customer/comprehensive/saveRetirementPlanning";

	public static String GET_COMPREHENSIVE_INSURANCE_NEEDS_DETAILS = "/api/customer/comprehensive/getComprehensiveInsuranceNeedsDetails";

	public static String GET_REPORT_NOTIFICATION_TOKEN = "/api/customer/comprehensive/generateReportNotificationToken";

	public static String GET_INSURANCE_SUMMARY = "/api/customer/getCustomerInsuranceDetails";

	public static String UPDATE_ENQUIRY_IN_WILLS = "/api/wills/updateWillsCustomerId";

	public static String UPDATE_CUSTOMER_ID_RECOMMEND = "/api/customer/updateCustomerId";
	
	public static String GET_ENQUIRY_DETAILS ="/api/service-calls/getEnquiry";
	
	public static String GET_ENQUIRY_DETAILS_WITH_PROTECTION = "/api/service-calls/getEnquiryWithProtection";

	public static String UPDATE_ENQUIRY_BY_EMAIL = "/api/service-calls/updateEnquiryByEmail";

	public static String GET_DETAILED_INSURANCE_SUMMARY = "/api/customer/getDetailedInsuranceSummary";
	
	public static String REQUEST_MAPPING_ROOT = "/api";
	
	public static String POST_RETIREMENT_PLANNING = "/api/postRetirementPlanning";
	
	public static String FETCH_ENQUIRY = "/api/Enquiry/{enquiryId}";

	/* Url Path Constants for Investment MIcro service */

	/* Constatnts for Investment Account Controller */

	/* Url Path Constants for Investment MIcro service */

	/* Constatnts for Investment Account Controller */
	

	public static String PROCESS_AML_STATUS = "/api/processAMLStatus";
	public static String CREATE_IFAST_ACCOUNT = "/api/customers/investment-accounts";
	public static String CALL_SUBSEQUENT_ACC_OPENING_API = "/api/customers/investment-accounts/subsequent";
	public static String UPDATE_SRS_BANK_LIST = "/api/customer/srs-bank";
	public static String BANK_LIST = "/api/customer/bank";
	public static String PROFILE_BANK_LIST = "/api/customer/profile/bank";
	public static String UPDATE_ACCOUNT = "/api/customer/updateAccount";
	public static String SET_NATIONALITY = "/api/customer/setNationality";
	public static String NOTIFY_INVESTMENT_ACCOUNT_SETUP = "/api/customer/notifyInvestmentAccountSetup";
	public static String INVESTMENT_ACCOUNT_STATUS = "/api/customer/investmentAccountStatus";
	public static String VERIFY_EDD_CHECK = "/api/customer/verifyEDDCheck";
	public static String FETCH_CUSTOMER_ID = "/api/customer/fetchCustId";
	public static String CUSTOMER_CASH_ACCOUNT ="/api/customers/portfolios/{customerPortfolioId}/cashAccount";
	public static String DEBUG_PROFILE_SUMMARY = "/api/customer/getProfileSummary_Debug";
	public static String CUSTOMER_INVESTMENT_PROFILE = "/api/customer/customerInvestmentProfile";
	public static String DEBUG_CUSTOMER_INVESTMENT_PROFILE = "/api/customer/customerInvestmentProfile_debug";
	public static String INSUFFICIENT_FUND_MAILER = "/api/customer/insufficientfundmailer";
	public static String GET_STATEMENTS = "/api/customers/portfolios/{customerPortfolioId}/statements/{year}/{month}";
	public static String GET_CUSTOMER_IFAST_ACCOUNT = "/api/customers/getCustomerIfastDetails";
	public static String UPDATE_TRUST_ID = "/api/customer/updateTrustId";
	public static String INVESTMENT_ACCOUNT_ACTIONS="/api/customer/investmentAccount/actions";
	
	public static String CUSTOMER_INVESTMENT_PROFILE_SUMMARY = "/api/customers/investment-profile";
	
	public static String PORTFOLIO_SUMMARY = "/api/customers/investment-profile/summary";
	
	public static String UPDATE_ADDRESS = "/api/customer/updateAddress";

	/* Constants for IFASTSERVICE CONTROLLER */
	public static String GET_IFAST_BANK_DETAILS = "/api/customers/portfolios/{customerPortfolioId}/ifast/bank-details";
	public static String IFAST_TOKEN = "/api/ifast/token";
	public static String IFAST_TOKEN_REGENERATE = "/api/ifast/token/regenerate";

	/* Constants for CashAccountController */
	public static String SAVE_CASH_TRANSACTION = "/api/customer/saveCashTransaction";

	/* Constants for CustomerEmailNotificationController */

	
	public static String MONTHLY = "/api/customerEmail/MonthlyStatement";
	public static String SEND_MONTHLY_INVESTMENT_REMINDER_EMAIL = "/api/customerEmail/sendMonthlyInvestmentReminderEmail";
	public static String TEST_MONTHLY_STATEMENT = "/api/customerEmail/testMonthlyStatement";

	/* Constants for InvestmentEnquiryController */

	public static String CUSTOMER_ENQUIRY = "/api/customer/enquiry";

	/* Constants for InvestmentObjectiveController */
	
	public static String POST_CUSTOMER_INVESTMENT_OBJECTIVE = "/api/CustomerInvestmentObjective";
	public static String GET_CUSTOMER_INVESTMENT_OBJECTIVE = "/api/customers/portfolios/{customerPortfolioId}/CustomerInvestmentObjective";
	public static String CUSTOMER_MONTHLY_INVESTMENT = "/api/customers/portfolios/{customerPortfolioId}/InvestmentObjective/monthlyInvestment";
	public static String UPDATE_CUSTOMER_INVESTMENT_OBJECTIVE = "/api/customers/portfolios/{customerPortfolioId}/UpdateCustomerInvestmentObjective";
	
	public static String  ADMIN_GET_CUSTOMER_INVESTMENT_OBJECTIVE_ADMIN = "/api/customers/portfolios/admin/CustomerInvestmentObjective";
	

	/* Constants for OptionListController */

	public static String COUNTRY_LIST = "/api/countrylist";
	public static String GROUPED_COUNTRY_LIST = "/api/groupedCountryList";
	public static String OPTIONS_SEARCH = "/api/options/search";
	public static String INDUSTRY_LIST = "/api/industrylist";
	public static String OCCUPATION_LIST = "/api/occupationlist";
	public static String OPTION_LIST_COLLECTION = "/api/optionListCollection";
	
	public static String OPTION_LIST_BY_ID = "/api/optionListCollectionById";

	/* Constants for PortfolioActionsController */

	public static String CUSTOMER_PORTFOLIO_ACTIONS = "/api/portfolio/{customerPortfolioId}/actions";
	public static String CUSTOMER_PORTFOLIO_ACTIONS_RELOAD = "/api/portfolio-actions/reload";
	public static String PORTFOLIO_ACTIONS ="/api/portfolio-actions";

	/* Constants for PortfolioCalculationController */
	public static String CUSTOMER_PORTFOLIO_RETURN_CALCULATION = "/api/portfolio/portfolioreturncalculation";
	public static String CUSTOMER_PORTFOLIO_UPDATE_HISTORICNAV = "/api/portfolio/updateHistoricalNAV";
	public static String CUSTOMER_PORTFOLIO_UPDATE_NAV = "/api/portfolio/updateNAV";
	public static String CUSTOMER_PORTFOLIO_CALCULATE_OLD_VALUES = "/api/calculateOldValues";
	public static String CUSTOMER_PORTFOLIO_RECALCULATE_TOTAL_UNITS = "/api/recalculateTotalUnits";
	public static String CUSTOMER_PORTFOLIO_RECALCULATE_PORTFOLIO_VALUES = "/api/recalculatePortfolioValues";

	/* Constants for PortfolioController */
	public static String PORTFOLIO_RECOMMEND = "/api/portfolio/recommend";
	public static String PORTFOLIO_RECOMMENDED = "/api/enquiries/{enquiryId}/portfolios/recommend";
	public static String PORTFOLIO_RECENT = "/api/portfolios/recent";
	public static String CUSTOMER_PORTFOLIO_SUMMARY = "/api/customer/portfolios/{customerPortfolioId}/summary";
	public static String PORTFOLIO_AWAITING_TRANSACTIONS = "/api/portfolios/{customerPortfolioId}/awaitingTransactions";
	public static String PORTFOLIO_BUY = "/api/customers/portfolios/{customerPortfolioId}/transactions/buy";
	public static String PORTFOLIO_SCHEDULED_BUY = "/api/portfolio/scheduledBuy";
	public static String PORTFOLIO_DETAILS = "/api/portfolios/detail/{portfolioId}";
	public static String PORTFOLIO_SELL = "/api/customers/portfolios/{customerPortfolioId}/transactions/sell";
	public static String PORTFOLIO_HOLDINGS = "/api/customers/portfolios/{customerPortfolioId}/holdings";
	public static String PORTFOLIO_HOLDINGS_ADMIN = "/api/portfolio/holdings/admin";
	public static String CUSTOMER_TRANSACTIONS = "/api/customers/portfolios/{customerPortfolioId}/transactions/search";
	public static String PORTFOLIO_TRANSACTIONS = "/api/portfolio/transactions";
	public static String PORTFOLIO_PURCHASED = "/api/customer/portfolio/purchased";
	public static String PORTFOLIO_UPDATE_BATCH = "/api/portfolio/updateBatch";
	public static String PORTFOLIO_SAVE_PORTFOLIO_TRANSACTION = "/api/customer/savePortfolioTransaction";
	public static String PORTFOLIO_SAVE_OR_UPDATE_PORTFOLIO_TRANSACTION = "/api/customer/saveOrUpdatePortfolioTransaction";
	public static String CUSTOMER_PORTFOLIO_DELETE = "/api/customer/portfolios/{customerPortfolioId}";
	public static String CUSTOMER_PORTFOLIO_ACCEPTANCE ="/api/customer/portfolios/{customerPortfolioId}/accept";
	public static String SAVE_OR_UPDATE_PORTFOLIO_NAME = "/api/customer/saveOrUpdatePortfolioName";
	/* Constants for RiskAssessmentController */
	public static String RISK_ASSESSMENT = "/api/RiskAssessment";
	public static String FETCH_RISK_ASSESSMENT_ANSWER = "/api/RiskAssessmentResponses/{enquiryId}";

	/* Constants for RSPController */
	public static String HOLIDAYS = "/api/holidays";
	public static String BATCH_RSP_MONTHLY = "/api/batches/rspRunMonthly";
	public static String BATCH_RSP_TIMINGS = "/api/batches/rspRunTimings";
	public static String HOLIDAY_ALERT = "/api/{type}/holiday/alert";
	public static String HOLIDAY_ALERT_LIST = "/api/holiday/alert";

	/* Constants for TESTCONTROLLER */
	public static String API_TEST_MAIL = "/api/mailApiTest";
	public static String API_TEST_IFAST = "/api/TestiFast";
	
	/* Url Path Constants for Admin MIcro service */
	
	public static String API_ADMIN_SEARCH ="/api/admin/search";
	public static String API_ADMIN_UPDATE_ADVISOR ="/api/admin/updateAdvisor";

	public static String API_ADMIN_PORTFOLIO_SUMMARY="/api/admin/portfolioSummary";

	
	public static String API_ADMIN_CUSTOMER_PROFILE_DETAILS="/api/admin/profileDetails";

	public static String API_ADMIN_ADVISOR_LIST="/api/admin/advisorList";
	public static String API_ADMIN_DPMS_SUMMARY= "/api/admin/dpmsSummary";
	public static String API_ADMIN_CUSTOMER_SUMMARY_TRANSACTION_DETAILS= "/api/admin/customerSummary/transactionDetails";
	
	public static String API_ADMIN_UNLOCK_COMPREHENSIVE_USER ="/api/admin/unlockComprehensiveUser";
	public static String API_ADMIN_FETCH_COMPREHENSIVE_UNLOCK_STATUS = "/api/admin/fetchComprehensiveUnlockStatus";
	
	public static String API_ADMIN_COMPREHENSIVE_ADVISOR_NOTES = "/api/admin/getComprehensiveAdvisorNotes";
	public static String API_ADMIN_POST_ADVISOR_COMMENTS ="/api/admin/postAndDeleteAdminComments";
	public static String API_ADMIN_CUSTOMER_NAMES_LIST = "/api/admin/customerList";
	public static String API_ADMIN_CUSTOMER_FLOW = "/api/admin/getCustomerFlow";
	public static String API_ADMIN_EDIT_ADDRESS = "/api/admin/editCustomerAddress"; 
	public static String API_ADMIN_SAVE_DOCUMENT = "/api/admin/saveDocument";
	public static String API_ADMIN_SHOW_EDIT = "/api/admin/showEdit";
	
	/* Url Path Constants for Account MIcro service */
	public static String API_ACCOUNT_TEST_UPDATE_INVSTATUS="/api/testUpdateInvStatus";	
	public static String API_ACCOUNT_PROFILE_TYPE_LIST="/api/getProfileTypeList";
	public static String API_ACCOUNT_SAVE_PROMO_CODE="/api/savePromocode";
	public static String API_ACCOUNT_EMPLOYMENT_STATUS="/api/getEmploymentStatus";
	public static String API_ACCOUNT_UPDATE_PERSONAL_DETAILS="/api/updatePersonalDetails";
	public static String API_ACCOUNT_UPDATE_EMPLOYMENT="/api/updateEmployment";
	public static String API_ACCOUNT_SAVE_DEPENDENTS="/api/saveDependents";
	public static String API_ACCOUNT_SIGNUP="/api/signup";
	public static String API_ACCOUNT_PROFILE_SUMMARY="/api/getProfileSummary";
	public static String API_ACCOUNT_CUSTOMER_PROFILE_DETAILS="/api/getCustomerProfileDetails";
	public static String API_ACCOUNT_DASHBOARD="/api/customer/dashboard";
	public static String API_ACCOUNT_DETAILED_CUSTOMER_SUMMARY="/api/getDetailedCustomerSummary";
	public static String API_ACCOUNT_FETCH_CUSTOMER_SUMMARY="/api/fetchCustomerSummary";
	public static String API_ACCOUNT_FETCH_CUSTOMER_DETAILS="/api/fetchCustomerDetails";
	public static String API_ACCOUNT_CUSTOMER_SUMMARY_BY_ADVISOR="/api/getCustomerSummaryByAdvisor";
	public static String API_ACCOUNT_UPDATE_CUSTOMER_ENQUIRY="/api/updateCustomerEnquiry";
	public static String API_ACCOUNT_CONTACT_US="/api/contactus";
	public static String API_ACCOUNT_UPDATE_ADDRESS="/api/updateAddress";
	public static String API_ACCOUNT_EDIT_PASSWORD="/api/editPassword";
	public static String API_ACCOUNT_SAVE_CUSTOMER_DETAILS="/api/saveCustomerDetails";
	public static String API_ACCOUNT_SAVE_DOCUMENTS_V2="/saveDocumentsV2";
	public static String API_ACCOUNT_ADD_ADVISOR="/api/addAdvisor";
	public static String API_ACCOUNT_VERIFY_AML="/api/verifyAML";
	public static String API_ACCOUNT_CLEAR_AML="/api/clearAML";
	public static String API_ACCOUNT_CUSTOMER_BANKS="/api/customer/banks";
	public static String API_ACCOUNT_CUSTOMER_BANK="/api/customer/bank";
	public static String API_ACCOUNT_CUSTOMER_SRS_BANK="/api/customer/{customerPortfolioId}/srsbankDetails";
	public static String API_ACCOUNT_GET_SRSBANK="/api/customer/getSrsBankDetails";
	public static String API_ACCOUNT_PROFILE_SAVE_SRS_BANK="/api/customer/profile/{customerPortfolioId}/srsbankDetails";
	public static String API_ACCOUNT_PROFILE_GET_SRSBANK="/api/customer/profile/getSrsBankDetails";
	
	public static String API_ACCOUNT_CUSTOMER_ADDRESS="/api/customer/address";
	public static String API_ACCOUNT_CUSTOMER_PROFILE="/api/customer/customerProfile";
	public static String API_ACCOUNT_TEST_OPTIONS_SEARCH="/api/testOptionsSearch";
	public static String API_ACCOUNT_CUSTOMERS_SEARCH="/customers/search";
	public static String API_ACCOUNT_CUSTOMERS_Summary ="/api/customerSummary";
	public static String API_ACCOUNT_CUSTOMERS_SIGNUP_V2  = "/api/signupV2";
	public static String API_ACCOUNT_CUSTOMERS_UPDATE_MOBILE_NO="/api/update-mobileno";
	public static String API_ACCOUNT_SAVE_DOCUMENTS="/api/saveDocuments";
	public static String API_ACCOUNT_PRODUCT_PRICING="/api/productPricing";
	
	public static String API_ACCOUNT_SAVE_DOCUMENTS_ADMIN="/admin/saveDocumentsV2";
	
	
	/* Url Path Constants for Finance MIcro service */
	public static String GET_FINANCIAL_DETAILS_BY_CUSTOMER_ID="/api/customer/getFinancialDetailsForInvestment";

	public static String SAVE_OR_UPDATE_PORTFOLIO_FUNDING_TYPE = "/api/portfolio/fundingType";
	
	public static String FINLIT_WORKSHOP_AUTHENTICATION = "/authenticateWorkshop";

	public static String PORTFOLIO_AWAITING_OR_PENDING_TRANSACTIONS = "api/portfolios/{customerPortfolioId}/transactions/{transactionStatus}";
	
	public static String API_FINANCIAL_DATA="/api/customer/financialData";
	
	public static String API_ADMIN_TEST = "/api/admin/advisorListTest";
		
	public static String CORP_BIZ_LEAD_GEN = "/api/corp/updateLeadGen";

	public static String FEATURE_PROMOTIONS_API = "/api/featurePromotions";

	public static String UPDATE_COMPREHENSIVE_REPORT_STATUS = "/api/customer/comprehensive/updateComprehensiveReportStatus";

	public static String GENERATE_COMPREHENSIVE_LITE_REPORT = "/api/createReportRequest";
	
	public static String LATEST_REPORT_BY_STATUS_AND_TYPE= "/api/getLatestReportByStatusAndType";
	
	public static String GET_INSURANCE_ENQUIRY_DETAILS ="/api/customer/getInsuranceDetails";
	
	public static String GET_INSURANCE_PROTECTION_MASTER ="/api/getProtectionMasterList";
	
	public static String CREATE_UPDATE_CONTACT_IN_HUBSPOT = "/api/createUpdateContactInHubspot";
	public static String DELETED_PORTFOLIO_DETAILS_ADMIN = "/api/customers/portfolios/admin/deletedPortfolioDetails";
	
	public static String API_ADMIN_DELETE_PORTFOLIO_SUMMARY="/api/admin/deletedPortfolioSummary";
	
	public static String API_IS_TWO_FACT_AUTHENTICATED = "/api/is2FAuthenticated";
	
	public static String API_SEND_2FA_OTP = "/api/send2FAOTP";
	
	public static String API_VALIDATE_2FA = "/api/validate2FA";
}
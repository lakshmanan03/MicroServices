package com.bfa.exception;

/**
 * @author Vimala Shan
 *
 */
public class BfaException extends RuntimeException {

	/**
	 * The serializable class BfaException declared a static final serialVersionUID
	 * field of type long
	 */
	private static final long serialVersionUID = -5885284887808953790L;

	/**
	 * @param exceptionMessage
	 */
	public BfaException(String exceptionMessage) {
		super(exceptionMessage);
	}

}

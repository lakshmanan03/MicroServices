/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "enquiry_protection_type")
public class EnquiryProtectionType implements Serializable{


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "enquiry_id")
	private int enquiryId;

	@Column(name = "protection_type_id")
	private int protectionTypeId;

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProtectionTypeId() {
		return protectionTypeId;
	}

	public void setProtectionTypeId(int protectionTypeId) {
		this.protectionTypeId = protectionTypeId;
	}

	public String toString() {
		return "Enquiry protection type enquiry id :" + enquiryId + " protectionTypeId :" + protectionTypeId;
	}

}

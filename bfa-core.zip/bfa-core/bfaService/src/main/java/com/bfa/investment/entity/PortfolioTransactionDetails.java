
package com.bfa.investment.entity;

import java.io.Serializable;
import java.util.List;

import com.bfa.investment.dto.FundInvestmentDTO;
import com.bfa.investment.dto.PendingTransactionDTO;

/**
 * @author Vimala Shan
 *
 */

public class PortfolioTransactionDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String portfolioName;
	
	private String refNo;

	private Double investmentAmount;

	private Double monthlyInvestment;

	private Double initialInvestment;

	private String contractNo; // Transaction Number

	private String fundName;

	private String lastUpdatedTimeStamp;

	private Integer units;

	private Double unitPrice;

	private String dateOfRequest;

	private String transactionCompletedDate; // Date Executed

	private Double redemptionAmount;

	private String accountNo;

	private Double amountReceived;

	private String dateReceived;

	private Double balanceAmount;

	private String frequency;

	private Integer customerId;

	List<PendingTransactionDTO> pendingTransactions;

	List<FundInvestmentDTO> fundDetails;
	
	List<FundInvestmentDTO> sellFundDetails;
	
	private String bankName;
	
	private String businessDays;
	
	private String dateExecuted;

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public Double getInvestmentAmount() {
		return investmentAmount;
	}

	public Double getMonthlyInvestment() {
		return monthlyInvestment;
	}

	public void setMonthlyInvestment(Double monthlyInvestment) {
		this.monthlyInvestment = monthlyInvestment;
	}

	public Double getInitialInvestment() {
		return initialInvestment;
	}

	public void setInitialInvestment(Double initialInvestment) {
		this.initialInvestment = initialInvestment;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public String getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(String lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public Integer getUnits() {
		return units;
	}

	public void setUnits(Integer units) {
		this.units = units;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getTransactionCompletedDate() {
		return transactionCompletedDate;
	}

	public void setTransactionCompletedDate(String transactionCompletedDate) {
		this.transactionCompletedDate = transactionCompletedDate;
	}

	public void setInvestmentAmount(Double investmentAmount) {
		this.investmentAmount = investmentAmount;
	}

	public String getDateOfRequest() {
		return dateOfRequest;
	}

	public void setDateOfRequest(String dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	
	

	public List<FundInvestmentDTO> getSellFundDetails() {
		return sellFundDetails;
	}

	public void setSellFundDetails(List<FundInvestmentDTO> sellFundDetails) {
		this.sellFundDetails = sellFundDetails;
	}

	public Double getRedemptionAmount() {
		return redemptionAmount;
	}

	public void setRedemptionAmount(Double redemptionAmount) {
		this.redemptionAmount = redemptionAmount;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public Double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public Double getAmountReceived() {
		return amountReceived;
	}

	public void setAmountReceived(Double amountReceived) {
		this.amountReceived = amountReceived;
	}

	public String getDateReceived() {
		return dateReceived;
	}

	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public List<PendingTransactionDTO> getPendingTransactions() {
		return pendingTransactions;
	}

	public void setPendingTransactions(List<PendingTransactionDTO> pendingTransactions) {
		this.pendingTransactions = pendingTransactions;
	}

	public List<FundInvestmentDTO> getFundDetails() {
		return fundDetails;
	}

	public void setFundDetails(List<FundInvestmentDTO> fundDetails) {
		this.fundDetails = fundDetails;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBusinessDays() {
		return businessDays;
	}

	public void setBusinessDays(String businessDays) {
		this.businessDays = businessDays;
	}

	public String getDateExecuted() {
		return dateExecuted;
	}

	public void setDateExecuted(String dateExecuted) {
		this.dateExecuted = dateExecuted;
	}
	
}
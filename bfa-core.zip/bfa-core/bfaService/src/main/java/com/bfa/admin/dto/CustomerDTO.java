package com.bfa.admin.dto;

import java.util.Date;

import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.Household;

public class CustomerDTO {
	
		private String id;		
		private String gender;		
		private String nationalityCode;
		private String dateOfBirth;		
		private boolean isSmoker;		
		private String professionStatus;		
		private String givenName;		
		private String surName;
		private Country countryOfBirth;		
		private String email;		
		private String mobileNumber;		
		private boolean notificationByEmail;		
		private byte[] password;		
		private String countryCode;		
		private boolean notificationByPhone;		
		private String otherInfo;		
		private String subscribe;		
		private String spam;		
		private String createdBy;		
		private Date createdDate;		
		private Integer crmId;		
		private String crmAgentId;		
		private String lastUpdatedBy;		
		private String crmEntityType;		
		private String lastUpdatedTime;		
		private String salutation;		
		private String middleName;		
		private String nricName;		
		private boolean isIdentityVerified;		
		private String race;		
		private String otpString;		
		private String otpVerfied;		
		private String emailVerified;		
		private boolean acceptMarketEmails;		
		private Address homeAddress;		
		private Address mailingAddress;		
		private Household houseHoldDetail;		
		private String differentMailingAddressReason;		
		private Integer differentMailingAddressReasonId;		

		
		


		public String getId() {
			return id;
		}


		public void setId(String id) {
			this.id = id;
		}


		public String getGender() {
			return gender;
		}


		public void setGender(String gender) {
			this.gender = gender;
		}


		public String getNationalityCode() {
			return nationalityCode;
		}


		public void setNationalityCode(String nationalityCode) {
			this.nationalityCode = nationalityCode;
		}


		public String getDateOfBirth() {
			return dateOfBirth;
		}


		public void setDateOfBirth(String dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}


		public boolean isSmoker() {
			return isSmoker;
		}


		public void setSmoker(boolean isSmoker) {
			this.isSmoker = isSmoker;
		}


		public String getProfessionStatus() {
			return professionStatus;
		}


		public void setProfessionStatus(String professionStatus) {
			this.professionStatus = professionStatus;
		}


		public String getGivenName() {
			return givenName;
		}


		public void setGivenName(String givenName) {
			this.givenName = givenName;
		}


		public String getSurName() {
			return surName;
		}


		public void setSurName(String surName) {
			this.surName = surName;
		}


		public Country getCountryOfBirth() {
			return countryOfBirth;
		}


		public void setCountryOfBirth(Country countryOfBirth) {
			this.countryOfBirth = countryOfBirth;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public String getMobileNumber() {
			return mobileNumber;
		}


		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}


		public boolean isNotificationByEmail() {
			return notificationByEmail;
		}


		public void setNotificationByEmail(boolean notificationByEmail) {
			this.notificationByEmail = notificationByEmail;
		}


		public byte[] getPassword() {
			return password;
		}


		public void setPassword(byte[] password) {
			this.password = password;
		}


		public String getCountryCode() {
			return countryCode;
		}


		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}


		public boolean isNotificationByPhone() {
			return notificationByPhone;
		}


		public void setNotificationByPhone(boolean notificationByPhone) {
			this.notificationByPhone = notificationByPhone;
		}


		public String getOtherInfo() {
			return otherInfo;
		}


		public void setOtherInfo(String otherInfo) {
			this.otherInfo = otherInfo;
		}


		public String getSubscribe() {
			return subscribe;
		}


		public void setSubscribe(String subscribe) {
			this.subscribe = subscribe;
		}


		public String getSpam() {
			return spam;
		}


		public void setSpam(String spam) {
			this.spam = spam;
		}


		public String getCreatedBy() {
			return createdBy;
		}


		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}


		public Date getCreatedDate() {
			return createdDate;
		}


		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}


		public Integer getCrmId() {
			return crmId;
		}


		public void setCrmId(Integer crmId) {
			this.crmId = crmId;
		}


		public String getCrmAgentId() {
			return crmAgentId;
		}


		public void setCrmAgentId(String crmAgentId) {
			this.crmAgentId = crmAgentId;
		}


		public String getLastUpdatedBy() {
			return lastUpdatedBy;
		}


		public void setLastUpdatedBy(String lastUpdatedBy) {
			this.lastUpdatedBy = lastUpdatedBy;
		}


		public String getCrmEntityType() {
			return crmEntityType;
		}


		public void setCrmEntityType(String crmEntityType) {
			this.crmEntityType = crmEntityType;
		}


		public String getLastUpdatedTime() {
			return lastUpdatedTime;
		}


		public void setLastUpdatedTime(String lastUpdatedTime) {
			this.lastUpdatedTime = lastUpdatedTime;
		}


		public String getSalutation() {
			return salutation;
		}


		public void setSalutation(String salutation) {
			this.salutation = salutation;
		}


		public String getMiddleName() {
			return middleName;
		}


		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}


		public String getNricName() {
			return nricName;
		}


		public void setNricName(String nricName) {
			this.nricName = nricName;
		}


		public boolean isIdentityVerified() {
			return isIdentityVerified;
		}


		public void setIdentityVerified(boolean isIdentityVerified) {
			this.isIdentityVerified = isIdentityVerified;
		}


		public String getRace() {
			return race;
		}


		public void setRace(String race) {
			this.race = race;
		}


		public String getOtpString() {
			return otpString;
		}


		public void setOtpString(String otpString) {
			this.otpString = otpString;
		}


		public String getOtpVerfied() {
			return otpVerfied;
		}


		public void setOtpVerfied(String otpVerfied) {
			this.otpVerfied = otpVerfied;
		}


		public String getEmailVerified() {
			return emailVerified;
		}


		public void setEmailVerified(String emailVerified) {
			this.emailVerified = emailVerified;
		}


		public boolean isAcceptMarketEmails() {
			return acceptMarketEmails;
		}


		public void setAcceptMarketEmails(boolean acceptMarketEmails) {
			this.acceptMarketEmails = acceptMarketEmails;
		}


		public Address getHomeAddress() {
			return homeAddress;
		}


		public void setHomeAddress(Address homeAddress) {
			this.homeAddress = homeAddress;
		}


		public Address getMailingAddress() {
			return mailingAddress;
		}


		public void setMailingAddress(Address mailingAddress) {
			this.mailingAddress = mailingAddress;
		}


		public Household getHouseHoldDetail() {
			return houseHoldDetail;
		}


		public void setHouseHoldDetail(Household houseHoldDetail) {
			this.houseHoldDetail = houseHoldDetail;
		}


		public String getDifferentMailingAddressReason() {
			return differentMailingAddressReason;
		}


		public void setDifferentMailingAddressReason(String differentMailingAddressReason) {
			this.differentMailingAddressReason = differentMailingAddressReason;
		}


		public Integer getDifferentMailingAddressReasonId() {
			return differentMailingAddressReasonId;
		}


		public void setDifferentMailingAddressReasonId(Integer differentMailingAddressReasonId) {
			this.differentMailingAddressReasonId = differentMailingAddressReasonId;
		}


		public Integer getAdvisorId() {
			return advisorId;
		}


		public void setAdvisorId(Integer advisorId) {
			this.advisorId = advisorId;
		}


		public Integer getVerificationEnquiryId() {
			return verificationEnquiryId;
		}


		public void setVerificationEnquiryId(Integer verificationEnquiryId) {
			this.verificationEnquiryId = verificationEnquiryId;
		}


		public String getResetToken() {
			return resetToken;
		}


		public void setResetToken(String resetToken) {
			this.resetToken = resetToken;
		}


		public byte[] getUniqueId() {
			return uniqueId;
		}


		public void setUniqueId(byte[] uniqueId) {
			this.uniqueId = uniqueId;
		}


		private Integer advisorId;
		
	
		
		private Integer verificationEnquiryId;
		
		
		private String resetToken;

	  
		private byte[] uniqueId;

}

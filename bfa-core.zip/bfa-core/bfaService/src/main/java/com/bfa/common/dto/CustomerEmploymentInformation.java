package com.bfa.common.dto;

import com.bfa.common.entity.CustomerEmploymentDetails;
import com.bfa.common.entity.EmployerAddress;
import com.bfa.common.entity.EmployerDetails;

public class CustomerEmploymentInformation {
	private CustomerEmploymentDetails customerEmploymentDetails;	
	private EmployerAddress employerAddress;
	private EmployerDetails employerDetails;
	
	
	public CustomerEmploymentDetails getCustomerEmploymentDetails() {
		return customerEmploymentDetails;
	}
	public void setCustomerEmploymentDetails(CustomerEmploymentDetails customerEmploymentDetails) {
		this.customerEmploymentDetails = customerEmploymentDetails;
	}
	public EmployerAddress getEmployerAddress() {
		return employerAddress;
	}
	public void setEmployerAddress(EmployerAddress employerAddress) {
		this.employerAddress = employerAddress;
	}
	public EmployerDetails getEmployerDetails() {
		return employerDetails;
	}
	public void setEmployerDetails(EmployerDetails employerDetails) {
		this.employerDetails = employerDetails;
	}
	
	
}

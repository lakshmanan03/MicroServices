/**
 * 
 */
package com.bfa.application.core;

import java.util.List;

import com.bfa.util.ResponseMessage;

/**
 * @author kianann
 *
 */
public class EnquiryResponseMessage {

	private ResponseMessage responseMessage;

	private List<EnquiryReference> objectList;

	/**
	 * @return the responseMessage
	 */
	public ResponseMessage getResponseMessage() {
		return responseMessage;
	}

	/**
	 * @param responseMessage the responseMessage to set
	 */
	public void setResponseMessage(ResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}

	/**
	 * @return the objectList
	 */
	public List<EnquiryReference> getObjectList() {
		return objectList;
	}

	/**
	 * @param objectList the objectList to set
	 */
	public void setObjectList(List<EnquiryReference> objectList) {
		this.objectList = objectList;
	}
}

package com.bfa.investment.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_get_investment_customer_basic_info")
public class CustomerInvestmentAccountInfo {
	
	@Id
	private Integer id;
	private String emailId;
	private String nricName;
	private String firstName;
	private String lastName;
	private String refNo;
	private String counterPartyAccountNumber;
	private String accountStatus;
	private Integer customerPortfolioId;
	private String portfolioName;
	private String fundingType;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getNricName() {
		return nricName;
	}
	public void setNricName(String nricName) {
		this.nricName = nricName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}
	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}

	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	/**
	 * @return the fundingType
	 */
	public String getFundingType() {
		return fundingType;
	}
	/**
	 * @param fundingType the fundingType to set
	 */
	public void setFundingType(String fundingType) {
		this.fundingType = fundingType;
	}
	
	
}

/**
 * 
 */
package com.bfa.comprehensive.core;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "comprehensive_assets")
public class ComprehensiveAssets {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;

	@Column(name = "cash_in_bank")
	private Double cashInBank;

	@Column(name = "savings_bond")
	private Double savingsBonds;

	@Column(name = "cpf_ordinary_account")
	private Double cpfOrdinaryAccount;

	@Column(name = "cpf_special_account")
	private Double cpfSpecialAccount;

	@Column(name = "cpf_medisave_account")
	private Double cpfMediSaveAccount;
	
	@Column(name = "cpf_retirement_account")
	private Double cpfRetirementAccount;
	
	@Column(name = "scheme_type")
	private String schemeType;

	@Column(name = "estimated_payout")
	private Integer estimatedPayout;
		
	@Column(name = "retirement_sum")
	private Integer retirementSum;
	
	@Column(name = "topup_amount")
	private Integer topupAmount;
	
	@Column(name = "withdrawal_amount")
	private Integer withdrawalAmount;
	
	@Column(name = "home_market_value")
	private Double homeMarketValue;

	@Column(name = "investment_properties_value")
	private Double investmentPropertiesValue;	

	@Column(name = "other_assets_value")
	private Double otherAssetsValue;
	
	@Column(name = "source")
	private String source;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "comprehensiveAssets")
	Set <ComprehensiveAssetsInvestment> comprehensiveAssetsInvestment = new HashSet<>();

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getCashInBank() {
		return cashInBank;
	}

	public void setCashInBank(Double cashInBank) {
		this.cashInBank = cashInBank;
	}

	public Double getSavingsBonds() {
		return savingsBonds;
	}

	public void setSavingsBonds(Double savingsBonds) {
		this.savingsBonds = savingsBonds;
	}

	public Double getCpfOrdinaryAccount() {
		return cpfOrdinaryAccount;
	}

	public void setCpfOrdinaryAccount(Double cpfOrdinaryAccount) {
		this.cpfOrdinaryAccount = cpfOrdinaryAccount;
	}

	public Double getCpfSpecialAccount() {
		return cpfSpecialAccount;
	}

	public void setCpfSpecialAccount(Double cpfSpecialAccount) {
		this.cpfSpecialAccount = cpfSpecialAccount;
	}

	public Double getCpfMediSaveAccount() {
		return cpfMediSaveAccount;
	}

	public void setCpfMediSaveAccount(Double cpfMediSaveAccount) {
		this.cpfMediSaveAccount = cpfMediSaveAccount;
	}

	public Double getHomeMarketValue() {
		return homeMarketValue;
	}

	public void setHomeMarketValue(Double homeMarketValue) {
		this.homeMarketValue = homeMarketValue;
	}

	public Double getInvestmentPropertiesValue() {
		return investmentPropertiesValue;
	}

	public void setInvestmentPropertiesValue(Double investmentPropertiesValue) {
		this.investmentPropertiesValue = investmentPropertiesValue;
	}

	public Double getOtherAssetsValue() {
		return otherAssetsValue;
	}

	public void setOtherAssetsValue(Double otherAssetsValue) {
		this.otherAssetsValue = otherAssetsValue;
	}

	public Set<ComprehensiveAssetsInvestment> getComprehensiveAssetsInvestment() {
		return comprehensiveAssetsInvestment;
	}

	public void setComprehensiveAssetsInvestment(Set<ComprehensiveAssetsInvestment> comprehensiveAssetsInvestment) {
		this.comprehensiveAssetsInvestment = comprehensiveAssetsInvestment;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Double getCpfRetirementAccount() {
		return cpfRetirementAccount;
	}

	public void setCpfRetirementAccount(Double cpfRetirementAccount) {
		this.cpfRetirementAccount = cpfRetirementAccount;
	}

	public String getSchemeType() {
		return schemeType;
	}

	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}

	public Integer getEstimatedPayout() {
		return estimatedPayout;
	}

	public void setEstimatedPayout(Integer estimatedPayout) {
		this.estimatedPayout = estimatedPayout;
	}

	public Integer getRetirementSum() {
		return retirementSum;
	}

	public void setRetirementSum(Integer retirementSum) {
		this.retirementSum = retirementSum;
	}

	public Integer getTopupAmount() {
		return topupAmount;
	}

	public void setTopupAmount(Integer topupAmount) {
		this.topupAmount = topupAmount;
	}

	public Integer getWithdrawalAmount() {
		return withdrawalAmount;
	}

	public void setWithdrawalAmount(Integer withdrawalAmount) {
		this.withdrawalAmount = withdrawalAmount;
	}

}

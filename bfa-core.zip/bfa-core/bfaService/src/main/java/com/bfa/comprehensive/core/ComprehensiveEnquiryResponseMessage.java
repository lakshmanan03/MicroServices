
package com.bfa.comprehensive.core;

import java.util.List;

import com.bfa.request.entity.ComprehensiveEnquiryPostResponse;

public class ComprehensiveEnquiryResponseMessage {


	private List<ComprehensiveEnquiryPostResponse> objectList;

	public List<ComprehensiveEnquiryPostResponse> getObjectList() {
		return objectList;
	}

	public void setObjectList(List<ComprehensiveEnquiryPostResponse> objectList) {
		this.objectList = objectList;
	}


}

/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "hospitalization_needs")
public class HospitalizationNeeds implements Serializable{


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "customer_id")
	private int customerId;

	@Column(name = "enquiry_id")
	private int enquiryId;

	@Column(name = "hospital_class_id")
	private int hospitalClassId;

	@JsonProperty(value = "isFullRider")
	@Column(name = "is_full_rider", columnDefinition = "TINYINT")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean isFullRider = false;

	@Column(name = "hospital_plan_type")
	private String hospitalPlanType;
	
	@JsonProperty(value = "isPartialRider")
	@Column(name = "is_partial_rider", columnDefinition = "TINYINT")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean isPartialRider = false;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getHospitalClassId() {
		return hospitalClassId;
	}

	public void setHospitalClassId(int hospitalClassId) {
		this.hospitalClassId = hospitalClassId;
	}

	public String getHospitalPlanType() {
		return hospitalPlanType;
	}

	public void setHospitalPlanType(String hospitalPlanType) {
		this.hospitalPlanType = hospitalPlanType;
	}

	@JsonProperty(value = "isFullRider")
	public Boolean isFullRider() {
		return isFullRider;
	}

	public void setIsFullRider(Boolean isFullRider) {
		this.isFullRider = isFullRider;
	}
	
	@JsonProperty(value = "isPartialRider")
	public Boolean isPartialRider() {
		return isPartialRider;
	}

	public void setIsPartialRider(Boolean isPartialRider) {
		this.isPartialRider = isPartialRider;
	}

}

package com.bfa.comprehensive.core;

public interface ComprehensiveConstants {
	
	public static double protect_default_emp_rate = 0.75;
	public static double protect_default_semp_rate = 0.65;
	public static int protect_default_ci_length	= 4;
	public static int protect_default_ltc_coverage = 1200;
	public static String protect_default_coverage_duration = "Till Age 65";
	public static double ce_uni_fee_inflation	= 0.03;
	public static double ce_living_exp_inflation	= 0.03;
	public static int dependent_male_default_uni_entry_age	= 21;
	public static int dependent_female_default_uni_entry_age = 18;
	public static int dependent_male_default_uni_coverage_age = 25;
	public static int dependent_female_default_uni_coverage_age	= 22;
	public static int dependent_default_coverage_age = 85;
	public static boolean default_rider = true;
	public static boolean early_ci = false;
	public static String comprehensive_child="Child";
	public static String comprehensive_Male="Male";
	public static String comprehensive_Female="Female";
	public static String employed="Employed";
	public static String selfEmployed="Self-Employed";
	public static int COMPREHENSIVE_HOSPITAL_B2C_PLAN_ID=5;

}


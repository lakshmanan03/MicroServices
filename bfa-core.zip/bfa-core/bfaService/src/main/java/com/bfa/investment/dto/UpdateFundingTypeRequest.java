package com.bfa.investment.dto;

public class UpdateFundingTypeRequest {
	
	private Integer customerPortfolioId;
	private Integer fundingType;
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}
	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	public Integer getFundingType() {
		return fundingType;
	}
	public void setFundingType(Integer fundingType) {
		this.fundingType = fundingType;
	}

	

}

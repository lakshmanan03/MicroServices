/**
 * 
 */
package com.bfa.application.core;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 *  This bean is a generic can be used across any microservice to validate captcha.
 *  
 * @since release_2.12 
 * @author pradheep
 * @see ValidateCaptcha
 *
 */
public final class ValidateCaptchaBean {

	private String captcha;
	
	private String sessionId;
	
	/**
	 * This is set at the runtime during validation , use this flag along with annotation @ValidateCaptcha.
	 */
	@JsonIgnore
	public boolean isValidCaptcha = false;
	
	/**
	 * Look for this flag first and then validate the captcha. 
	 */
	@JsonIgnore
	public boolean isApplicable = false;
	
	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	
}

/**
 * 
 */
package com.bfa.request.entity;

/**
 * @author pradheep.p
 *
 */
public class NewEnquiryRequest {
	
	private String subject;

	private String eventPlan;

	private String email_date;

	private String contact;

	private String contactTime;

	private String category;

	private String email;

	private String description;

	private String name;

	private String dob;

	private String last_name;

	private String gender;

	private String smoker;	
	
	private String key;
	
	private String source;	

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventPlan() {
		return eventPlan;
	}

	public void setEventPlan(String eventPlan) {
		this.eventPlan = eventPlan;
	}

	public String getEmail_date() {
		return email_date;
	}

	public void setEmail_date(String email_date) {
		this.email_date = email_date;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getContactTime() {
		return contactTime;
	}

	public void setContactTime(String contactTime) {
		this.contactTime = contactTime;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSmoker() {
		return smoker;
	}

	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}	

	@Override
	public String toString() {
		return "[subject = " + subject + ", eventPlan = " + eventPlan + ", email_date = " + email_date
				+ ", contact = " + contact + ", contactTime = " + contactTime + ", category = " + category
				+ ", email = " + email + ", description = " + description + ", name = " + name + ", dob = " + dob
				+ ", last_name = " + last_name + ", gender = " + gender + ", smoker = " + smoker 
				+ ", source=" + source + "]";
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
}
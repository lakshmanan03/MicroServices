/**
 * 
 */
package com.bfa.request.processor;

/**
 * @author pradheep.p
 *
 */
public interface PreProcess {
	
	public void before(Object source,Object target);
	
}

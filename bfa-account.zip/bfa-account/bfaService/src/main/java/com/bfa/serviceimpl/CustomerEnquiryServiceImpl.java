package com.bfa.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.service.CustomerEnquiryService;
import com.bfa.servicehelper.MOInvestmentService;
import com.bfa.util.ServiceResponse;

public class CustomerEnquiryServiceImpl implements CustomerEnquiryService {

	@Autowired
	MOInvestmentService moInvestmentService;
	
	@Override
	public ServiceResponse<String> mapCustomerToEnquiry(int customerId, int enquiryId) {

		Boolean status;
		ServiceResponse<String> serviceResponse = new ServiceResponse<>();
		status=moInvestmentService.mapEnquiryToCustomer(customerId, enquiryId);
		if (status) {
			serviceResponse.setSuccess(status);
			serviceResponse.addResponseInfo("message", "Customer mapped to Enquiry");
		}
		else {
			serviceResponse.addErrorInfo("message", "Customer not Mapped to Enquiry");
		}
		return serviceResponse;
	}
	
}

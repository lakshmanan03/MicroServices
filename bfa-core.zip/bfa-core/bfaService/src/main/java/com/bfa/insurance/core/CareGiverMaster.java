/**
 * 
 */
package com.bfa.insurance.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "care_giver_master")
public class CareGiverMaster {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "care_giver_type")
	private String careGiverType;
	
	@Column(name = "care_giver_description")
	private String careGiverDescription;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCareGiverType() {
		return careGiverType;
	}

	public void setCareGiverType(String careGiverType) {
		this.careGiverType = careGiverType;
	}

	public String getCareGiverDescription() {
		return careGiverDescription;
	}

	public void setCareGiverDescription(String careGiverDescription) {
		this.careGiverDescription = careGiverDescription;
	}

}

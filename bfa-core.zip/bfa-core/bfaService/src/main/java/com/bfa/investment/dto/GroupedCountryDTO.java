package com.bfa.investment.dto;

public class GroupedCountryDTO {

    private Integer id;

    private String countryCode;
    private String name;
    private String phoneCode;
    private boolean isCountryBlocked;
    private boolean isVisible;
	

	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneCode() {
		return phoneCode;
	}
	public void setPhoneCode(String phoneCode) {
		this.phoneCode = phoneCode;
	}
	public boolean isCountryBlocked() {
		return isCountryBlocked;
	}
	public void setCountryBlocked(boolean isCountryBlocked) {
		this.isCountryBlocked = isCountryBlocked;
	}
	public boolean isVisible() {
		return isVisible;
	}
	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}
    
}

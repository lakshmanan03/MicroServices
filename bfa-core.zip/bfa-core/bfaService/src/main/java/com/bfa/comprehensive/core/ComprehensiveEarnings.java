/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "income")
public class ComprehensiveEarnings {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	@JsonIgnore
	private Integer id;
	
	@JsonIgnore
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name="employment_type")
	private String employmentType;
	
	@Column(name = "monthly_salary")
	private Double monthlySalary;
	
	@Column(name="monthly_rental_income")
	private Double monthlyRentalIncome;
	
	@Column(name="other_monthly_work_income")
	private Double otherMonthlyWorkIncome;
	
	@Column(name = "other_monthly_income")
	private Double otherMonthlyIncome;
	
	@Column(name = "annual_bonus")
	private Double annualBonus;

	@Column(name = "annual_dividends")
	private Double annualDividends;
	
	@Column(name = "other_annual_income")
	private Double otherAnnualIncome;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public Double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(Double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}

	public Double getOtherMonthlyWorkIncome() {
		return otherMonthlyWorkIncome;
	}

	public void setOtherMonthlyWorkIncome(Double otherMonthlyWorkIncome) {
		this.otherMonthlyWorkIncome = otherMonthlyWorkIncome;
	}

	public Double getOtherMonthlyIncome() {
		return otherMonthlyIncome;
	}

	public void setOtherMonthlyIncome(Double otherMonthlyIncome) {
		this.otherMonthlyIncome = otherMonthlyIncome;
	}

	public Double getAnnualBonus() {
		return annualBonus;
	}

	public void setAnnualBonus(Double annualBonus) {
		this.annualBonus = annualBonus;
	}	

	public Double getMonthlyRentalIncome() {
		return monthlyRentalIncome;
	}

	public void setMonthlyRentalIncome(Double monthlyRentalIncome) {
		this.monthlyRentalIncome = monthlyRentalIncome;
	}

	public Double getAnnualDividends() {
		return annualDividends;
	}

	public void setAnnualDividends(Double annualDividends) {
		this.annualDividends = annualDividends;
	}

	public Double getOtherAnnualIncome() {
		return otherAnnualIncome;
	}

	public void setOtherAnnualIncome(Double otherAnnualIncome) {
		this.otherAnnualIncome = otherAnnualIncome;
	}	
	@Override
	public String toString() {
		return "ComprehensiveEarnings [id=" + id + ", customerId=" + customerId + ", enquiryId=" + enquiryId
				+ ", employmentType=" + employmentType + ", monthlySalary=" + monthlySalary + ", monthlyRentalIncome="
				+ monthlyRentalIncome + ", otherMonthlyWorkIncome=" + otherMonthlyWorkIncome + ", otherMonthlyIncome="
				+ otherMonthlyIncome + ", annualBonus=" + annualBonus + ", annualDividends=" + annualDividends
				+ ", otherAnnualIncome=" + otherAnnualIncome + "]";
	}
	
}

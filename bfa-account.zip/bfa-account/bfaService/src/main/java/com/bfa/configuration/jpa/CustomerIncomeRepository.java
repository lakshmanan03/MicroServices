package com.bfa.configuration.jpa;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bfa.common.entity.CustomerLiabilitiesDetail;
import com.bfa.insurance.core.Income;


public interface CustomerIncomeRepository extends CrudRepository<Income, String> {
	
	Optional<Income>  findByEnquiryId(Integer enquiryId);
	Optional<Income>  findFirstByCustomerId(Integer customerId);

}

/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;

/**
 * @author pradheep.p
 *
 */
public class CleanupBlackListedTokens implements InitializingBean, Runnable {

	@Autowired
	private AccountsDao accountsDAO;

	// Sonar: critical: Cast one of the operands of this multiplication operation to a "long".
	private long timeDelayInMilliSecs = 24 * 60 * 60 * 1000L; // 24 Hour delay 

	@Autowired
	private ScheduledJobRunner scheduledJobRunner;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	private Date getStartDate() {
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		calendar.add(GregorianCalendar.HOUR, 5);
		return calendar.getTime();
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		getLogger().info("Initializing : " + this.getClass().getName() + " Job");
		init();
	}

	private void init() {
		scheduledJobRunner.addScheduledJob(this, getStartDate(), timeDelayInMilliSecs);
	}

	private void cleanUp() {
		try {
			getLogger().info("Running the " + this.getClass().getName() + " Job");
			String hql = "delete from BlacklistToken where ejectTime < current_date()";
			int recordsUpdated = accountsDAO.executeUpdate(hql);
			getLogger().info("Deleted  " + recordsUpdated + " black listed records");
		} catch (Exception err) {
			getLogger().error("Error while cleaning tokens", err);
		}
	}

	@Override
	public void run() {
		cleanUp();
	}

}

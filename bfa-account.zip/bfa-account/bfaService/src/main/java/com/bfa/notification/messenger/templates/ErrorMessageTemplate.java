/**
 * 
 */
package com.bfa.notification.messenger.templates;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * @author pradheep.p
 *
 */
public class ErrorMessageTemplate extends BFATemplate {

	private Exception exception;
	/* (non-Javadoc)
	 * @see com.pyr.templates.PyrTemplate#getFormatString()
	 */
	public ErrorMessageTemplate(Exception err){
		this.exception = err;
	}
	
	@Override
	public String getFormatString() {		
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		this.exception.printStackTrace(pw);
		return sw.toString();
	}

	/* (non-Javadoc)
	 * @see com.pyr.templates.PyrTemplate#getType()
	 */
	@Override
	public int getType() {
		return TemplateType.ERROR_MESSAGE_TEMPLATE;
	}

}

/**
 * 
 */
package com.bfa.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.BFAGrandtedAuthority;
import com.bfa.application.security.SecurityConstants;
import com.bfa.common.JourneyTypeEnum;
import com.bfa.common.ProtectionTypeEnum;
//import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.EnquiryWithProtectionType;
import com.bfa.insurance.core.ProtectionType;
import com.bfa.request.entity.CRMNewEnquiryRequest;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.PublicUtility;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;

public class CRMDataTransformer extends DiscoveryHelper {

	@Autowired
	protected SecurityConstants securityConstants;

	@Autowired
	private BFAHttpClient bfaHttpClient;

	protected Gson gson = new Gson();

	private String appKey = "IMXYlDmP4f4=";

	protected PublicUtility utility = PublicUtility.getInstance(appKey);

	protected void addCategoryAndProtectionType(CRMNewEnquiryRequest crmNewEnquiryRequest,
			EnquiryWithProtectionType enquiryDetailsWithProtection) {
		logger.info("Inside add category and protection type");
		Enquiry enquiryDetails = enquiryDetailsWithProtection.getEnquiryDetails();
		/* Set the journey type before making the CRM call */
		if (enquiryDetails.getType().toLowerCase().equalsIgnoreCase("comprehensive")) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Comprehensive);
		}else if (enquiryDetails.getType().toLowerCase().equalsIgnoreCase("comprehensive-lite")) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Comprehensive_Lite);
		} else if (enquiryDetails.getType().toLowerCase().equalsIgnoreCase("insurance-guided")) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Insurance_Guided);
		} else if (enquiryDetails.getType().toLowerCase().equalsIgnoreCase("insurance-direct")) {
			crmNewEnquiryRequest.setJourneyType(JourneyTypeEnum.Insurance_Direct);
		}
		
		
		/* Set the protection type choosen in the enquiry details */
		ProtectionType protectionType = enquiryDetailsWithProtection.getProtectionType();
		if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("life protection")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Life_Protection);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("critical illness")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Critical_Illness);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("occupational disability")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Occupational_Disability);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("hospital plan")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Hospital_Plan);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("long-term care")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Long_Term_Care);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("child's education fund")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Education_Fund);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("retirement income plan")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.Retirement_Income_Plan);
		} else if (protectionType.getProtectionType().toLowerCase().equalsIgnoreCase("srs approved plan")) {
			crmNewEnquiryRequest.setProtectionType(ProtectionTypeEnum.SRS_Approved_Plans);
		}
	}

	protected EnquiryWithProtectionType getEnquiryAndProtectionData(Integer enquiryId) {
		logger.info(".. Trying to get the enquiry details .. ");
		try {
			// Introduced a sleep to ensure that the enquiry is persisted and we make a call from accounts microservice.
			// This is to avoid synchronization issues. Please dont remove this.
			Thread.currentThread().sleep(4000);
		} catch (InterruptedException e) {			
			logger.error("Error while sleep ",e);
		}
		// -------- Set the headers before the call ------------ //
		HashMap<String, String> customHeaders = new HashMap<String, String>();
		List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
		BFAGrandtedAuthority authority = new BFAGrandtedAuthority("ROLE_SERVICE_CALL");
		BFAGrandtedAuthority authority1 = new BFAGrandtedAuthority("ROLE_USER");
		grantedAuthorities.add(authority);
		grantedAuthorities.add(authority1);
		String securityHeader = loadSecurityHeader(securityConstants.TOKEN_NAME, grantedAuthorities);
		logger.info("Printing the header " + securityHeader);
		customHeaders.put(securityConstants.TOKEN_NAME, securityHeader);
		logger.info("Trying to fetch the details of enquiry " + enquiryId);
		String encryptedEnquiryId = getEnquiryIdWithPadding(enquiryId);
		logger.info("Printing the encrypted enquiry id :" + encryptedEnquiryId);

		// ---------------------------------------------------------//
		// --- Set the base URL --- //
		String apiName = APIConstants.GET_ENQUIRY_DETAILS_WITH_PROTECTION;
		String baseUrl = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE);
		baseUrl = removePortNumbers(baseUrl);
		baseUrl = baseUrl + apiName;
		baseUrl = baseUrl + "?ref=" + encryptedEnquiryId;
		logger.info("Printing the base URL:" + baseUrl);
		// ---------------------------//
		BFAHttpResponse httpResponse = bfaHttpClient.doGetCall(baseUrl, customHeaders, null);
		String enqJson = httpResponse.getResponseBody();
		logger.info("Printing the response :" + enqJson);
		EnquiryWithProtectionType enquiryWithProtectionObj = gson.fromJson(enqJson, EnquiryWithProtectionType.class);
		return enquiryWithProtectionObj;
	}

	private String getEnquiryIdWithPadding(Integer enquiryId) {
		return utility.getStringWithPadding(enquiryId.toString(), ApplicationConstants.DELIMITER);
	}
}

/**
 * 
 */
package com.bfa.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bfa.application.core.CustomerPromo;

/**
 * @author kianann
 *
 */
public interface CustomerPromoRepository extends CrudRepository<CustomerPromo, Integer> {

	CustomerPromo findByCustomerId(Integer customerId);
	
	/**
	 * 
	 * @param customerId
	 * @param promoCodeCategory
	 * @return
	 */
	@Query(value = "select cpc.* from customer_promo_code cpc, promo_code_master pcm where cpc.customer_id = :customerId and cpc.promo_code_id = pcm.id and pcm.category = :promoCodeCategory",
			nativeQuery = true)
	CustomerPromo findByCustomerIdAndPromoCodeCategory(@Param("customerId") Integer customerId, @Param("promoCodeCategory") String promoCodeCategory);
}

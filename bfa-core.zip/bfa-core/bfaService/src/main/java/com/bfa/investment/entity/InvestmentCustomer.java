package com.bfa.investment.entity;

import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.IdentityVerificationStatus;
import com.bfa.insurance.core.Customer;

public class InvestmentCustomer extends Customer {
	@OneToOne
	@JoinColumn(name = "country_of_birth_id")
	private Country countryOfBirth;
	
	@OneToOne
	@JoinColumn(name = "nationality_id")
	private Country nationality;	

	@OneToOne
	@JoinColumn(name = "identity_verification_status_id")
	private IdentityVerificationStatus identityVerificationStatus;
	
	@OneToOne
	@JoinColumn(name = "home_address_id")
	private Address homeAddress;
	
	@OneToOne
	@JoinColumn(name = "mailing_address_id")
	private Address mailingAddress;
	
	@OneToOne
	@JoinColumn(name = "household_id")
	private Address household;
	
	public Country getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(Country countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public Country getNationality() {
		return nationality;
	}

	public void setNationality(Country nationality) {
		this.nationality = nationality;
	}

	public IdentityVerificationStatus getIdentityVerificationStatus() {
		return identityVerificationStatus;
	}

	public void setIdentityVerificationStatus(IdentityVerificationStatus identityVerificationStatus) {
		this.identityVerificationStatus = identityVerificationStatus;
	}

	public Address getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}

	public Address getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(Address mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public Address getHousehold() {
		return household;
	}

	public void setHousehold(Address household) {
		this.household = household;
	}
}

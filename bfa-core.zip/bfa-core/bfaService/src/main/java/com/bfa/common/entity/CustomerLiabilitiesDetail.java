package com.bfa.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vw_customer_asset_details")
public class CustomerLiabilitiesDetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "enquiryId")
	private int enquiryId;
	
	@Column(name = "assetId")
	private int assetId;
	
	@Column(name = "liabilityId")
	private int liabilityId;	
	
	@Column(name = "customerId")
	private int customerId;
	
	@Column(name="cash")
	private double cash;
	
	@Column(name="cpf")
	private double cpf;
	
	@Column(name = "homeProperty")
	private double homeProperty; 
	
	@Column(name = "investmentProperties")
	private double investmentProperties; 
	
	@Column(name = "otherInvestments")
	private double otherInvestments; 
	
	@Column(name = "totalAssets")
	private double totalAssets; 
	
	@Column(name = "otherAssets")
	private double otherAssets; 
	
	@Column(name = "propertyLoan")
	private double propertyLoan; 
	
	@Column(name = "carLoan")
	private double carLoan; 
	
	@Column(name = "otherLoan")
	private double otherLoan; 
	
	@Column(name = "totalLoans")
	private double totalLoans;

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getCash() {
		return cash;
	}

	public void setCash(double cash) {
		this.cash = cash;
	}

	public double getCpf() {
		return cpf;
	}

	public void setCpf(double cpf) {
		this.cpf = cpf;
	}

	public double getHomeProperty() {
		return homeProperty;
	}

	public void setHomeProperty(double homeProperty) {
		this.homeProperty = homeProperty;
	}

	public double getInvestmentProperties() {
		return investmentProperties;
	}

	public void setInvestmentProperties(double investmentProperties) {
		this.investmentProperties = investmentProperties;
	}

	public double getOtherInvestments() {
		return otherInvestments;
	}

	public void setOtherInvestments(double otherInvestments) {
		this.otherInvestments = otherInvestments;
	}

	public double getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(double totalAssets) {
		this.totalAssets = totalAssets;
	}

	public double getPropertyLoan() {
		return propertyLoan;
	}

	public void setPropertyLoan(double propertyLoan) {
		this.propertyLoan = propertyLoan;
	}

	public double getCarLoan() {
		return carLoan;
	}

	public void setCarLoan(double carLoan) {
		this.carLoan = carLoan;
	}

	public double getOtherLoan() {
		return otherLoan;
	}

	public void setOtherLoan(double otherLoan) {
		this.otherLoan = otherLoan;
	}

	public double getTotalLoans() {
		return totalLoans;
	}

	public void setTotalLoans(double totalLoans) {
		this.totalLoans = totalLoans;
	}

	public double getOtherAssets() {
		return otherAssets;
	}

	public void setOtherAssets(double otherAssets) {
		this.otherAssets = otherAssets;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public int getLiabilityId() {
		return liabilityId;
	}

	public void setLiabilityId(int liabilityId) {
		this.liabilityId = liabilityId;
	} 	
	
	

}

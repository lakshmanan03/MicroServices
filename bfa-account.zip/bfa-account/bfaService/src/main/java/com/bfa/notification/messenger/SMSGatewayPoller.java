/**
 * 
 */
package com.bfa.notification.messenger;

import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.AccountsDao;
import com.bfa.serviceimpl.ScheduledJobRunner;

/**
 * @author pradheep.p
 *
 */
public class SMSGatewayPoller implements InitializingBean, Runnable {

	@Autowired
	private ScheduledJobRunner scheduledJobRunner;

	@Autowired
	private AccountsDao accountsDao;

	@Autowired
	private SMSGatewayActivator smsGatewayActivator;

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private String name;

	private long timeDelayInMillis = 1000L * 60 * 5; // 5 Minutes

	@Autowired

	public SMSGatewayPoller() {
		setName("SMS Gateway Poller");
	}

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	public String getGatwayDetails() {
		return accountsDao.getActiveSMSGatewayProvider();
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		configure();
	}

	private void configure() {
		getLogger().info("Scheduling the job :" + this.getClass().getName());
		Date now = new Date();
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(now);
		calendar.set(GregorianCalendar.SECOND, -5);
		Date startTime = calendar.getTime();
		scheduledJobRunner.addScheduledJob(this, startTime, timeDelayInMillis);
		getLogger().info("Starting the scheduled job at " + now);
	}

	@Override
	public void run() {
		getLogger().info(getName() + " : fetching the active SMS gateway provider ");
		// Step 1:
		String activeProvider = getGatwayDetails();
		getLogger().info(activeProvider);
		// Step 2: Set the current provider
		if (!this.smsGatewayActivator.getGatewayProvider().equals(activeProvider)) {
			getLogger().info("Switching the SMS gateway provider from " + smsGatewayActivator.getGatewayProvider()
					+ " to " + activeProvider);
			this.smsGatewayActivator.setGatewayProvider(activeProvider);
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

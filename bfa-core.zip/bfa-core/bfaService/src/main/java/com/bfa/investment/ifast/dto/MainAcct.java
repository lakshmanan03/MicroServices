package com.bfa.investment.ifast.dto;

public class MainAcct
{
    private String bank2Name;

    private String employerAddressCountry;

    private String homeAddressUnit;

    private Tin[] tin;

    private String race;

    private String cpfInvestmentAcctNo;

    private String srsOperator;

    private String countryOfBirth;

    private String employerName;

    private String sourceOfFunds;

    private String usPermanentResident;

    private String passportExpiryDate;

    private String gender;

    private String employerTownName;

    private String counterPartyAccountNumber;

    private String bankAcctName;

    private String occupation;

    private String countryOfIssue;

    private String bankAgreeFlag;

    private String employerAddressZip;

    private String bank2SwiftCode;

    private String bankCode;

    private String telOfficeCountryCode;

    private String identificationType;

    private String telHomeCountryCode;

    private String officeIsUsNo;

    private String hpIsUsNo;

    private String telHpCountryCode;

    private String mailAddressState;

    private String officeNumber;

    private String homeAddress2;

    private String cpfAcctNo;

    private String homeAddress1;

    private String nric;
    
    private String passportNumber;

    private String addressDiffOtherReason;

    private String bankAcctNo;

    private String salaryRange;

    private String mailingAddressOption;

    private String directorOfInvestmentFirm;

    private String bank1SwiftCode;

    private String employerContactNumber;

    private String bank1AcctNo;

    private String cpfAgentBank;

    private String employerState;

    private String nricName;

    private String occupationDescription;

    private String ecddOccupationFlag;

    private String ecddClientDeclaredPepFlag;

    private String mailAddressUnit;

    private String employerAddress1;

    private String homeAddressZip;

    private String homeAddressState;

    private String addressDiffReason;

    private String singaporeTaxResident;

    private String ecddLocationFlag;

    private String mailAddressZip;

    private String employerUnitNumber;

    private String homeAddressCountry;

    private String homeIsUsNo;

    private String accountName;

    private String homeNumber;

    private String nationality;

    private String mailAddress2;

    private String mailAddress1;

    private String bank1Name;

    private String mailAddressCountry;

    private String dob;

    private String employerStreetName;

    private String srsAcctNo;

    private String mobileNumber;

    private String salutation;

    public String getBank2Name ()
    {
        return bank2Name;
    }
    
    

    public String getPassportNumber() {
		return passportNumber;
	}



	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}



	public void setBank2Name (String bank2Name)
    {
        this.bank2Name = bank2Name;
    }

    public String getEmployerAddressCountry ()
    {
        return employerAddressCountry;
    }

    public void setEmployerAddressCountry (String employerAddressCountry)
    {
        this.employerAddressCountry = employerAddressCountry;
    }

    public String getHomeAddressUnit ()
    {
        return homeAddressUnit;
    }

    public void setHomeAddressUnit (String homeAddressUnit)
    {
        this.homeAddressUnit = homeAddressUnit;
    }

    public Tin[] getTin ()
    {
        return tin;
    }

    public void setTin (Tin[] tin)
    {
        this.tin = tin;
    }

    public String getRace ()
    {
        return race;
    }

    public void setRace (String race)
    {
        this.race = race;
    }

    public String getCpfInvestmentAcctNo ()
    {
        return cpfInvestmentAcctNo;
    }

    public void setCpfInvestmentAcctNo (String cpfInvestmentAcctNo)
    {
        this.cpfInvestmentAcctNo = cpfInvestmentAcctNo;
    }

    public String getSrsOperator ()
    {
        return srsOperator;
    }

    public void setSrsOperator (String srsOperator)
    {
        this.srsOperator = srsOperator;
    }

    public String getCountryOfBirth ()
    {
        return countryOfBirth;
    }

    public void setCountryOfBirth (String countryOfBirth)
    {
        this.countryOfBirth = countryOfBirth;
    }

    public String getEmployerName ()
    {
        return employerName;
    }

    public void setEmployerName (String employerName)
    {
        this.employerName = employerName;
    }

    public String getSourceOfFunds ()
    {
        return sourceOfFunds;
    }

    public void setSourceOfFunds (String sourceOfFunds)
    {
        this.sourceOfFunds = sourceOfFunds;
    }

    public String getUsPermanentResident ()
    {
        return usPermanentResident;
    }

    public void setUsPermanentResident (String usPermanentResident)
    {
        this.usPermanentResident = usPermanentResident;
    }

    public String getPassportExpiryDate ()
    {
        return passportExpiryDate;
    }

    public void setPassportExpiryDate (String passportExpiryDate)
    {
        this.passportExpiryDate = passportExpiryDate;
    }

    public String getGender ()
    {
        return gender;
    }

    public void setGender (String gender)
    {
        this.gender = gender;
    }

    public String getEmployerTownName ()
    {
        return employerTownName;
    }

    public void setEmployerTownName (String employerTownName)
    {
        this.employerTownName = employerTownName;
    }

    public String getCounterPartyAccountNumber ()
    {
        return counterPartyAccountNumber;
    }

    public void setCounterPartyAccountNumber (String counterPartyAccountNumber)
    {
        this.counterPartyAccountNumber = counterPartyAccountNumber;
    }

    public String getBankAcctName ()
    {
        return bankAcctName;
    }

    public void setBankAcctName (String bankAcctName)
    {
        this.bankAcctName = bankAcctName;
    }

    public String getOccupation ()
    {
        return occupation;
    }

    public void setOccupation (String occupation)
    {
        this.occupation = occupation;
    }

    public String getCountryOfIssue ()
    {
        return countryOfIssue;
    }

    public void setCountryOfIssue (String countryOfIssue)
    {
        this.countryOfIssue = countryOfIssue;
    }

    public String getBankAgreeFlag ()
    {
        return bankAgreeFlag;
    }

    public void setBankAgreeFlag (String bankAgreeFlag)
    {
        this.bankAgreeFlag = bankAgreeFlag;
    }

    public String getEmployerAddressZip ()
    {
        return employerAddressZip;
    }

    public void setEmployerAddressZip (String employerAddressZip)
    {
        this.employerAddressZip = employerAddressZip;
    }

    public String getBank2SwiftCode ()
    {
        return bank2SwiftCode;
    }

    public void setBank2SwiftCode (String bank2SwiftCode)
    {
        this.bank2SwiftCode = bank2SwiftCode;
    }

    public String getBankCode ()
    {
        return bankCode;
    }

    public void setBankCode (String bankCode)
    {
        this.bankCode = bankCode;
    }

    public String getTelOfficeCountryCode ()
    {
        return telOfficeCountryCode;
    }

    public void setTelOfficeCountryCode (String telOfficeCountryCode)
    {
        this.telOfficeCountryCode = telOfficeCountryCode;
    }

    public String getIdentificationType ()
    {
        return identificationType;
    }

    public void setIdentificationType (String identificationType)
    {
        this.identificationType = identificationType;
    }

    public String getTelHomeCountryCode ()
    {
        return telHomeCountryCode;
    }

    public void setTelHomeCountryCode (String telHomeCountryCode)
    {
        this.telHomeCountryCode = telHomeCountryCode;
    }

    public String getOfficeIsUsNo ()
    {
        return officeIsUsNo;
    }

    public void setOfficeIsUsNo (String officeIsUsNo)
    {
        this.officeIsUsNo = officeIsUsNo;
    }

    public String getHpIsUsNo ()
    {
        return hpIsUsNo;
    }

    public void setHpIsUsNo (String hpIsUsNo)
    {
        this.hpIsUsNo = hpIsUsNo;
    }

    public String getTelHpCountryCode ()
    {
        return telHpCountryCode;
    }

    public void setTelHpCountryCode (String telHpCountryCode)
    {
        this.telHpCountryCode = telHpCountryCode;
    }

    public String getMailAddressState ()
    {
        return mailAddressState;
    }

    public void setMailAddressState (String mailAddressState)
    {
        this.mailAddressState = mailAddressState;
    }

    public String getOfficeNumber ()
    {
        return officeNumber;
    }

    public void setOfficeNumber (String officeNumber)
    {
        this.officeNumber = officeNumber;
    }

    public String getHomeAddress2 ()
    {
        return homeAddress2;
    }

    public void setHomeAddress2 (String homeAddress2)
    {
        this.homeAddress2 = homeAddress2;
    }

    public String getCpfAcctNo ()
    {
        return cpfAcctNo;
    }

    public void setCpfAcctNo (String cpfAcctNo)
    {
        this.cpfAcctNo = cpfAcctNo;
    }

    public String getHomeAddress1 ()
    {
        return homeAddress1;
    }

    public void setHomeAddress1 (String homeAddress1)
    {
        this.homeAddress1 = homeAddress1;
    }

    public String getNric ()
    {
        return nric;
    }

    public void setNric (String nric)
    {
        this.nric = nric;
    }

    public String getAddressDiffOtherReason ()
    {
        return addressDiffOtherReason;
    }

    public void setAddressDiffOtherReason (String addressDiffOtherReason)
    {
        this.addressDiffOtherReason = addressDiffOtherReason;
    }

    public String getBankAcctNo ()
    {
        return bankAcctNo;
    }

    public void setBankAcctNo (String bankAcctNo)
    {
        this.bankAcctNo = bankAcctNo;
    }

    public String getSalaryRange ()
    {
        return salaryRange;
    }

    public void setSalaryRange (String salaryRange)
    {
        this.salaryRange = salaryRange;
    }

    public String getMailingAddressOption ()
    {
        return mailingAddressOption;
    }

    public void setMailingAddressOption (String mailingAddressOption)
    {
        this.mailingAddressOption = mailingAddressOption;
    }

    public String getDirectorOfInvestmentFirm ()
    {
        return directorOfInvestmentFirm;
    }

    public void setDirectorOfInvestmentFirm (String directorOfInvestmentFirm)
    {
        this.directorOfInvestmentFirm = directorOfInvestmentFirm;
    }

    public String getBank1SwiftCode ()
    {
        return bank1SwiftCode;
    }

    public void setBank1SwiftCode (String bank1SwiftCode)
    {
        this.bank1SwiftCode = bank1SwiftCode;
    }

    public String getEmployerContactNumber ()
    {
        return employerContactNumber;
    }

    public void setEmployerContactNumber (String employerContactNumber)
    {
        this.employerContactNumber = employerContactNumber;
    }

    public String getBank1AcctNo ()
    {
        return bank1AcctNo;
    }

    public void setBank1AcctNo (String bank1AcctNo)
    {
        this.bank1AcctNo = bank1AcctNo;
    }

    public String getCpfAgentBank ()
    {
        return cpfAgentBank;
    }

    public void setCpfAgentBank (String cpfAgentBank)
    {
        this.cpfAgentBank = cpfAgentBank;
    }

    public String getEmployerState ()
    {
        return employerState;
    }

    public void setEmployerState (String employerState)
    {
        this.employerState = employerState;
    }

    public String getNricName ()
    {
        return nricName;
    }

    public void setNricName (String nricName)
    {
        this.nricName = nricName;
    }

    public String getOccupationDescription ()
    {
        return occupationDescription;
    }

    public void setOccupationDescription (String occupationDescription)
    {
        this.occupationDescription = occupationDescription;
    }

    public String getEcddOccupationFlag ()
    {
        return ecddOccupationFlag;
    }

    public void setEcddOccupationFlag (String ecddOccupationFlag)
    {
        this.ecddOccupationFlag = ecddOccupationFlag;
    }

    public String getEcddClientDeclaredPepFlag ()
    {
        return ecddClientDeclaredPepFlag;
    }

    public void setEcddClientDeclaredPepFlag (String ecddClientDeclaredPepFlag)
    {
        this.ecddClientDeclaredPepFlag = ecddClientDeclaredPepFlag;
    }

    public String getMailAddressUnit ()
    {
        return mailAddressUnit;
    }

    public void setMailAddressUnit (String mailAddressUnit)
    {
        this.mailAddressUnit = mailAddressUnit;
    }

    public String getEmployerAddress1 ()
    {
        return employerAddress1;
    }

    public void setEmployerAddress1 (String employerAddress1)
    {
        this.employerAddress1 = employerAddress1;
    }

    public String getHomeAddressZip ()
    {
        return homeAddressZip;
    }

    public void setHomeAddressZip (String homeAddressZip)
    {
        this.homeAddressZip = homeAddressZip;
    }

    public String getHomeAddressState ()
    {
        return homeAddressState;
    }

    public void setHomeAddressState (String homeAddressState)
    {
        this.homeAddressState = homeAddressState;
    }

    public String getAddressDiffReason ()
    {
        return addressDiffReason;
    }

    public void setAddressDiffReason (String addressDiffReason)
    {
        this.addressDiffReason = addressDiffReason;
    }

    public String getSingaporeTaxResident ()
    {
        return singaporeTaxResident;
    }

    public void setSingaporeTaxResident (String singaporeTaxResident)
    {
        this.singaporeTaxResident = singaporeTaxResident;
    }

    public String getEcddLocationFlag ()
    {
        return ecddLocationFlag;
    }

    public void setEcddLocationFlag (String ecddLocationFlag)
    {
        this.ecddLocationFlag = ecddLocationFlag;
    }

    public String getMailAddressZip ()
    {
        return mailAddressZip;
    }

    public void setMailAddressZip (String mailAddressZip)
    {
        this.mailAddressZip = mailAddressZip;
    }

    public String getEmployerUnitNumber ()
    {
        return employerUnitNumber;
    }

    public void setEmployerUnitNumber (String employerUnitNumber)
    {
        this.employerUnitNumber = employerUnitNumber;
    }

    public String getHomeAddressCountry ()
    {
        return homeAddressCountry;
    }

    public void setHomeAddressCountry (String homeAddressCountry)
    {
        this.homeAddressCountry = homeAddressCountry;
    }

    public String getHomeIsUsNo ()
    {
        return homeIsUsNo;
    }

    public void setHomeIsUsNo (String homeIsUsNo)
    {
        this.homeIsUsNo = homeIsUsNo;
    }

    public String getAccountName ()
    {
        return accountName;
    }

    public void setAccountName (String accountName)
    {
        this.accountName = accountName;
    }

    public String getHomeNumber ()
    {
        return homeNumber;
    }

    public void setHomeNumber (String homeNumber)
    {
        this.homeNumber = homeNumber;
    }

    public String getNationality ()
    {
        return nationality;
    }

    public void setNationality (String nationality)
    {
        this.nationality = nationality;
    }

    public String getMailAddress2 ()
    {
        return mailAddress2;
    }

    public void setMailAddress2 (String mailAddress2)
    {
        this.mailAddress2 = mailAddress2;
    }

    public String getMailAddress1 ()
    {
        return mailAddress1;
    }

    public void setMailAddress1 (String mailAddress1)
    {
        this.mailAddress1 = mailAddress1;
    }

    public String getBank1Name ()
    {
        return bank1Name;
    }

    public void setBank1Name (String bank1Name)
    {
        this.bank1Name = bank1Name;
    }

    public String getMailAddressCountry ()
    {
        return mailAddressCountry;
    }

    public void setMailAddressCountry (String mailAddressCountry)
    {
        this.mailAddressCountry = mailAddressCountry;
    }

    public String getDob ()
    {
        return dob;
    }

    public void setDob (String dob)
    {
        this.dob = dob;
    }

    public String getEmployerStreetName ()
    {
        return employerStreetName;
    }

    public void setEmployerStreetName (String employerStreetName)
    {
        this.employerStreetName = employerStreetName;
    }

    public String getSrsAcctNo ()
    {
        return srsAcctNo;
    }

    public void setSrsAcctNo (String srsAcctNo)
    {
        this.srsAcctNo = srsAcctNo;
    }

    public String getMobileNumber ()
    {
        return mobileNumber;
    }

    public void setMobileNumber (String mobileNumber)
    {
        this.mobileNumber = mobileNumber;
    }

    public String getSalutation ()
    {
        return salutation;
    }

    public void setSalutation (String salutation)
    {
        this.salutation = salutation;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [bank2Name = "+bank2Name+", employerAddressCountry = "+employerAddressCountry+", homeAddressUnit = "+homeAddressUnit+", tin = "+tin+", race = "+race+", cpfInvestmentAcctNo = "+cpfInvestmentAcctNo+", srsOperator = "+srsOperator+", countryOfBirth = "+countryOfBirth+", employerName = "+employerName+", sourceOfFunds = "+sourceOfFunds+", usPermanentResident = "+usPermanentResident+", passportExpiryDate = "+passportExpiryDate+", gender = "+gender+", employerTownName = "+employerTownName+", counterPartyAccountNumber = "+counterPartyAccountNumber+", bankAcctName = "+bankAcctName+", occupation = "+occupation+", countryOfIssue = "+countryOfIssue+", bankAgreeFlag = "+bankAgreeFlag+", employerAddressZip = "+employerAddressZip+", bank2SwiftCode = "+bank2SwiftCode+", bankCode = "+bankCode+", telOfficeCountryCode = "+telOfficeCountryCode+", identificationType = "+identificationType+", telHomeCountryCode = "+telHomeCountryCode+", officeIsUsNo = "+officeIsUsNo+", hpIsUsNo = "+hpIsUsNo+", telHpCountryCode = "+telHpCountryCode+", mailAddressState = "+mailAddressState+", officeNumber = "+officeNumber+", homeAddress2 = "+homeAddress2+", cpfAcctNo = "+cpfAcctNo+", homeAddress1 = "+homeAddress1+", nric = "+nric+", addressDiffOtherReason = "+addressDiffOtherReason+", bankAcctNo = "+bankAcctNo+", salaryRange = "+salaryRange+", mailingAddressOption = "+mailingAddressOption+", directorOfInvestmentFirm = "+directorOfInvestmentFirm+", bank1SwiftCode = "+bank1SwiftCode+", employerContactNumber = "+employerContactNumber+", bank1AcctNo = "+bank1AcctNo+", cpfAgentBank = "+cpfAgentBank+", employerState = "+employerState+", nricName = "+nricName+", occupationDescription = "+occupationDescription+", ecddOccupationFlag = "+ecddOccupationFlag+", ecddClientDeclaredPepFlag = "+ecddClientDeclaredPepFlag+", mailAddressUnit = "+mailAddressUnit+", employerAddress1 = "+employerAddress1+", homeAddressZip = "+homeAddressZip+", homeAddressState = "+homeAddressState+", addressDiffReason = "+addressDiffReason+", singaporeTaxResident = "+singaporeTaxResident+", ecddLocationFlag = "+ecddLocationFlag+", mailAddressZip = "+mailAddressZip+", employerUnitNumber = "+employerUnitNumber+", homeAddressCountry = "+homeAddressCountry+", homeIsUsNo = "+homeIsUsNo+", accountName = "+accountName+", homeNumber = "+homeNumber+", nationality = "+nationality+", mailAddress2 = "+mailAddress2+", mailAddress1 = "+mailAddress1+", bank1Name = "+bank1Name+", mailAddressCountry = "+mailAddressCountry+", dob = "+dob+", employerStreetName = "+employerStreetName+", srsAcctNo = "+srsAcctNo+", mobileNumber = "+mobileNumber+", salutation = "+salutation+"]";
    }
}
package com.bfa.investment.ifast.dto;

public class AccountRequestDTO {
	
	 private String annualWrapFee;

	    private MainAcct mainAcct;

	    private String accountType;

	    private String isMyInfo;

	    private String annualWrapStockFee;

	    private String wrapFeePaymentMethodIa;

	    private String wrapFeePaymentMethod;

	    public String getAnnualWrapFee ()
	    {
	        return annualWrapFee;
	    }

	    public void setAnnualWrapFee (String annualWrapFee)
	    {
	        this.annualWrapFee = annualWrapFee;
	    }

	    public MainAcct getMainAcct ()
	    {
	        return mainAcct;
	    }

	    public void setMainAcct (MainAcct mainAcct)
	    {
	        this.mainAcct = mainAcct;
	    }

	    public String getAccountType ()
	    {
	        return accountType;
	    }

	    public void setAccountType (String accountType)
	    {
	        this.accountType = accountType;
	    }

	    public String getIsMyInfo ()
	    {
	        return isMyInfo;
	    }

	    public void setIsMyInfo (String isMyInfo)
	    {
	        this.isMyInfo = isMyInfo;
	    }

	    public String getAnnualWrapStockFee ()
	    {
	        return annualWrapStockFee;
	    }

	    public void setAnnualWrapStockFee (String annualWrapStockFee)
	    {
	        this.annualWrapStockFee = annualWrapStockFee;
	    }

	    public String getWrapFeePaymentMethodIa ()
	    {
	        return wrapFeePaymentMethodIa;
	    }

	    public void setWrapFeePaymentMethodIa (String wrapFeePaymentMethodIa)
	    {
	        this.wrapFeePaymentMethodIa = wrapFeePaymentMethodIa;
	    }

	    public String getWrapFeePaymentMethod ()
	    {
	        return wrapFeePaymentMethod;
	    }

	    public void setWrapFeePaymentMethod (String wrapFeePaymentMethod)
	    {
	        this.wrapFeePaymentMethod = wrapFeePaymentMethod;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [annualWrapFee = "+annualWrapFee+", mainAcct = "+mainAcct+", accountType = "+accountType+", isMyInfo = "+isMyInfo+", annualWrapStockFee = "+annualWrapStockFee+", wrapFeePaymentMethodIa = "+wrapFeePaymentMethodIa+", wrapFeePaymentMethod = "+wrapFeePaymentMethod+"]";
	    }
}

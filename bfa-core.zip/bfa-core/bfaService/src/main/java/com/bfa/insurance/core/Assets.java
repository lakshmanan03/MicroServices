/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "assets")
public class Assets implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "id")
	private int id;	
	
	@Column(name = "enquiry_id")
	private int enquiryId;	
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "cash")
	private double cash;
	
	@Column(name = "cpf")
	private double cpf;
	
	@Column(name = "home_property")
	private double homeProperty;
	
	@Column(name = "investment_properties")
	private double investmentProperties;

	@Column(name = "other_investments")
	private double otherInvestments;
	
	@Column(name = "others_assets")
	private double otherAssets;
	
	@Column(name = "total_assets")
	private double totalAssets;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getCash() {
		return cash;
	}

	public void setCash(double cash) {
		this.cash = cash;
	}

	public double getCpf() {
		return cpf;
	}

	public void setCpf(double cpf) {
		this.cpf = cpf;
	}

	public double getHomeProperty() {
		return homeProperty;
	}

	public void setHomeProperty(double homeProperty) {
		this.homeProperty = homeProperty;
	}

	public double getInvestmentProperties() {
		return investmentProperties;
	}

	public void setInvestmentProperties(double investmentProperties) {
		this.investmentProperties = investmentProperties;
	}

	public double getOtherInvestments() {
		return otherInvestments;
	}

	public void setOtherInvestments(double otherInvestments) {
		this.otherInvestments = otherInvestments;
	}

	public double getOtherAssets() {
		return otherAssets;
	}

	public void setOtherAssets(double otherAssets) {
		this.otherAssets = otherAssets;
	}

	public double getTotalAssets() {
		return totalAssets;
	}

	public void setTotalAssets(double totalAssets) {
		this.totalAssets = totalAssets;
	}
	
}

/**
 * 
 */
package com.bfa.dao;

import java.util.List;

import com.bfa.application.exception.DatabaseAccessException;

/**
 * @author pradheep.p
 *
 */
public interface BaseDao<T> {

	public T saveOrUpdateObject(T obj) throws DatabaseAccessException;

	public T saveObject(T obj) throws DatabaseAccessException;

	public List<T> getObjectsById(Class T, String reference, int value) throws DatabaseAccessException;

	public List<T> getObjectsByRef(Class T, String reference, String value) throws DatabaseAccessException;

	public <T> List<T> getObjectsAsList(Class T) throws DatabaseAccessException;

	public List<T> getObjectByHql(String hqlString) throws DatabaseAccessException;

	public List<T> getObjectByHqlAndLimit(String hqlString, int numberOfRecords) throws DatabaseAccessException;

	public List<T> getObjectByHql(String hqlString, String param, String value) throws DatabaseAccessException;
	
	public int executeUpdate(String hqlString);

}

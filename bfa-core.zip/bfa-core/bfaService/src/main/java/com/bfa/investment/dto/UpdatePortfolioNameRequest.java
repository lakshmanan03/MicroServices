package com.bfa.investment.dto;

public class UpdatePortfolioNameRequest {
	private Integer customerPortfolioId;
	private String portfolioName;
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}
	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	
	
}

/**
 * 
 */
package com.bfa.security.twofa.core;

/**
 * @author pradheep
 *
 */
public class TwoFactorValidationRequest {

	private String twoFactorOtpString;

	public String getTwoFactorOtpString() {
		return twoFactorOtpString;
	}

	public void setTwoFactorOtpString(String twoFactorOtpString) {
		this.twoFactorOtpString = twoFactorOtpString;
	}	
}

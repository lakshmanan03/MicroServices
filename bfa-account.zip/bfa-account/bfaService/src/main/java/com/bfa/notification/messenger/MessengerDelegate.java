/**
 * 
 */
package com.bfa.notification.messenger;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.bfa.notification.MessageObject;

/**
 * @author pradheep.p
 *
 */
public class MessengerDelegate implements ApplicationContextAware{
	

	private BFAMessenger emailMessenger;
	
	private SMSMessenger smsMessenger;
	
	private ApplicationContext applicationContext;

	public Object communicateMessage(MessageObject obj,int messageType){
		if(messageType == Messenger.EMAIL_MESSAGE){
			return sendEmailCommunication(obj);
		}
		if(messageType == Messenger.SMS_MESSAGE){
			return sendSMSCommunication(obj);
		}
		if(messageType == Messenger.BOTH){
			sendEmailCommunication(obj);
			sendSMSCommunication(obj);
			return "0";
		}
		return "Invalid Code";
	}
	
	private Object sendEmailCommunication(MessageObject emailObject){
		emailMessenger = (BFAMessenger) this.applicationContext.getBean("emailMessenger");
		return emailMessenger.communicate(emailObject);
	}
	
	private Object sendSMSCommunication(MessageObject emailObject){
		smsMessenger = (SMSMessenger) this.applicationContext.getBean("smsMessenger");
		return smsMessenger.communicate(emailObject);
	}

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {		
		this.applicationContext = context;
	}
}

package com.bfa.application.security;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.security.Key;
import java.util.Base64;

import org.springframework.core.io.ClassPathResource;


public class SecurityConstants implements Serializable{
	
	private static final long serialVersionUID = 1L;

	public static final String TOKEN_NAME = "Authorization";

	public static Key _secret;// MacProvider.generateKey(SignatureAlgorithm.HS256)

	public byte[] secretBytes;

	public String base64SecretBytes;

	// In seconds //
	public static final int timeToLive = 3600;

	public static final int divisor_value = 19;

	public static final String date_format = "SSS HH:mm:ss yyyy-MM-dd";

	public static final String ROLE_USER = "ROLE_USER";

	public static final String ROLE_SIGNED_USER = "ROLE_SIGNED_USER";

	public static final String ROLE_ADMIN_USER = "ROLE_ADMIN";

	public static final int ROLE_SIGNED_USER_ID = 1;

	public static final int ROLE_USER_ID = 2;
	public static final String CUSTOMER_REFERENCE = "customerReference";
	public static final String CUSTOMER_ID_IN_REQUEST = "customerIdInRequest";
	
	public static final String ENQUIRY_ID_IN_REQUEST = "enquiryIdInRequest";
	
	public static final String ROLE_SERVICE_CALL = "SERVICE_CALL";

	public SecurityConstants() {
		// created constructor
	}

	public void assignKey() {
		this._secret = loadKey();
		if (null != _secret) {
			System.out.println(_secret.toString());
			secretBytes = this._secret.getEncoded();
			base64SecretBytes = Base64.getEncoder().encodeToString(secretBytes);
		}
	}

	private Key loadKey() {
		Key keyObject = null;
		ObjectInputStream ois = null;
		try {
			ClassPathResource res = new ClassPathResource("app.key");
			ois = new ObjectInputStream(res.getInputStream());
			keyObject = (Key) ois.readObject();
		} catch (IOException err) {
			err.printStackTrace();
		} catch (ClassNotFoundException exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
			} catch (IOException e) {
				// IO Exception
			}
		}
		return keyObject;
	}
}

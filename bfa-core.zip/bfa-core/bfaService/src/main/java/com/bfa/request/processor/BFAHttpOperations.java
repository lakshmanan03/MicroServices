/**
 * 
 */
package com.bfa.request.processor;

import com.bfa.util.BFAHttpResponse;

/**
 * @author pradheep.p
 *
 */
public interface BFAHttpOperations {
	
	public abstract BFAHttpResponse getPreOpreratedResponse();

	public abstract void setPreOpreratedResponse(BFAHttpResponse httpResponse);
}

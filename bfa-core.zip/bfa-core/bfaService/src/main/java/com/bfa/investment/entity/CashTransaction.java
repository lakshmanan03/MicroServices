/**
 * 
 */
package com.bfa.investment.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.common.entity.OptionItem;
import com.bfa.insurance.core.Customer;

/**
 * @author HCL - 51772803
 * CashTransaction.java Created on Jan 5, 2019 4:36:18 PM by Vimala Shan
 */

@Entity
@Table(name = "cash_account_transaction")
public class CashTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id")
	private Customer customer;

	@Column(name = "contract_no")
	private String contractNo;
	
	@OneToOne
	@JoinColumn(name = "transaction_type_id")
	private OptionItem transactionType;

	@Column(name = "amount")
	private Double amount;

	@OneToOne
	@JoinColumn(name = "currency_id")
	private OptionItem currency;

	@Column(name = "conversion_rate")
	private Double conversionRate;

	@OneToOne
	@JoinColumn(name = "transaction_status_id")
	private OptionItem transactionStatus;

	@Column(name = "account_balance")
	private Double accountBalance;

	@Column(name = "ref_no")
	private String refNo;

	@Column(name = "transaction_created_date")
	private Date transactionCreatedDate;

	@Column(name = "transaction_completed_date")
	private Date transactionCompletedDate;
	
	@Column(name = "last_updated_date")
	private Date lastUpdatedDate;
	
	@OneToOne
	@JoinColumn(name = "payment_method_id")
	private OptionItem paymentMethod;
	
	@OneToOne
	@JoinColumn(name = "customer_portfolio_id")
	private CustomerPortfolio customerPortfolio;
	
    public CustomerPortfolio getCustomerPortfolio() {
		return customerPortfolio;
	}

	public void setCustomerPortfolio(CustomerPortfolio customerPortfolio) {
		this.customerPortfolio = customerPortfolio;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	
	
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public OptionItem getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(OptionItem transactionType) {
		this.transactionType = transactionType;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public OptionItem getCurrency() {
		return currency;
	}

	public void setCurrency(OptionItem currency) {
		this.currency = currency;
	}

	public Double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(Double conversionRate) {
		this.conversionRate = conversionRate;
	}

	public OptionItem getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(OptionItem transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public Double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Date getTransactionCreatedDate() {
		return transactionCreatedDate;
	}

	public void setTransactionCreatedDate(Date transactionCreatedDate) {
		this.transactionCreatedDate = transactionCreatedDate;
	}

	public Date getTransactionCompletedDate() {
		return transactionCompletedDate;
	}

	public void setTransactionCompletedDate(Date transactionCompletedDate) {
		this.transactionCompletedDate = transactionCompletedDate;
	}

	/**
	 * @return the paymentMethod
	 */
	public OptionItem getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(OptionItem paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	
	
}

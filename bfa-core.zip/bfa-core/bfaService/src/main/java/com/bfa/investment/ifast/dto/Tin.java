package com.bfa.investment.ifast.dto;

public class Tin
{
    private String withoutTinReason;

    private String taxResidentCountry;

    private String justification;

    private String tin;

    public String getWithoutTinReason ()
    {
        return withoutTinReason;
    }

    public void setWithoutTinReason (String withoutTinReason)
    {
        this.withoutTinReason = withoutTinReason;
    }

    public String getTaxResidentCountry ()
    {
        return taxResidentCountry;
    }

    public void setTaxResidentCountry (String taxResidentCountry)
    {
        this.taxResidentCountry = taxResidentCountry;
    }

    public String getJustification ()
    {
        return justification;
    }

    public void setJustification (String justification)
    {
        this.justification = justification;
    }

    public String getTin ()
    {
        return tin;
    }

    public void setTin (String tin)
    {
        this.tin = tin;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [withoutTinReason = "+withoutTinReason+", taxResidentCountry = "+taxResidentCountry+", justification = "+justification+", tin = "+tin+"]";
    }
}
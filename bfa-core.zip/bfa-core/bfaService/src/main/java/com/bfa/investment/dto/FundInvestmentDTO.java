package com.bfa.investment.dto;

import java.io.Serializable;

public class FundInvestmentDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String fundName;
	private Double units;
	private Double unitPrice;

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public Double getUnits() {
		return units;
	}

	public void setUnits(Double units) {
		this.units = units;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

}

package com.bfa.service;

import com.bfa.util.ServiceResponse;

public interface CustomerEnquiryService {
	ServiceResponse<String> mapCustomerToEnquiry(int customerId, int enquiryId); 
	
	
}

package com.bfa.investment.dto;

public class IndustryListDTO {
	
		private int id;
		  
		private String industry;
			
		private String ssocId;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getIndustry() {
			return industry;
		}

		public void setIndustry(String industry) {
			this.industry = industry;
		}

		public String getSsocId() {
			return ssocId;
		}

		public void setSsocId(String ssocId) {
			this.ssocId = ssocId;
		}

}

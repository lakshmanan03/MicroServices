package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "sector_type_master")
public class SectorType {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "type")
	private String type;
	
	  @JsonProperty("holdingsCount") 
	  @Column(name = "holdings")
	  private Integer holdings;

	  @JsonProperty("holdingsCount") 
	  public Integer getHoldings() {
		  return holdings; 
	  }
	  
	  public void setHoldings(Integer holdings) { 
		  this.holdings = holdings; 
	  }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}

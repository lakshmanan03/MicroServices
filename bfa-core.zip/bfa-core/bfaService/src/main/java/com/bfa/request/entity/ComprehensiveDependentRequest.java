/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.insurance.core.ComprehensiveDependentMapping;

/**
 * @author gajendrak
 *
 */
public class ComprehensiveDependentRequest {
	
	private List<ComprehensiveDependentMapping> dependentMappingList;
	
	private boolean hasDependents;	
	
	private Integer noOfHouseholdMembers;
	
	private String houseHoldIncome;
	
	private Integer noOfYears;

	public List<ComprehensiveDependentMapping> getDependentMappingList() {
		return dependentMappingList;
	}

	public void setDependentMappingList(List<ComprehensiveDependentMapping> dependentMappingList) {
		this.dependentMappingList = dependentMappingList;
	}
	public boolean isHasDependents() {
		return hasDependents;
	}

	public void setHasDependents(boolean hasDependents) {
		this.hasDependents = hasDependents;
	}
	
	public Integer getNoOfHouseholdMembers() {
		return noOfHouseholdMembers;
	}

	public void setNoOfHouseholdMembers(Integer noOfHouseholdMembers) {
		this.noOfHouseholdMembers = noOfHouseholdMembers;
	}

	public String getHouseHoldIncome() {
		return houseHoldIncome;
	}

	public void setHouseHoldIncome(String houseHoldIncome) {
		this.houseHoldIncome = houseHoldIncome;
	}

	public Integer getNoOfYears() {
		return noOfYears;
	}

	public void setNoOfYears(Integer noOfYears) {
		this.noOfYears = noOfYears;
	}
	
	
	

}

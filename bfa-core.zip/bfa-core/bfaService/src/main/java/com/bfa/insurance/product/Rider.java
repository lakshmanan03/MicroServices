/**
 * 
 */
package com.bfa.insurance.product;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name="rider")
public class Rider {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name="rider_name")
	private String riderName;
	
	@Column(name="rider_type")
	private String riderType;
	
	@JsonIgnore
	@Column(name="last_updated_by")
	private String lastUpdatedBy;
	
	@JsonIgnore
	@Column(name="last_updated_timestamp")
	private Date lastUpdatedTimeStamp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRiderName() {
		return riderName;
	}

	public void setRiderName(String riderName) {
		this.riderName = riderName;
	}	

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getRiderType() {
		return riderType;
	}

	public void setRiderType(String riderType) {
		this.riderType = riderType;
	}
}

package com.bfa.investment.ifast.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class MODPMSTransactionResponse extends DPMSTransactionResponse {
	private Integer transactionId;
	
	private Integer customerPortfolioId;
	
	private Integer customerId;
	
	private boolean isMonthly;
	
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone="UTC")
	private String recordCreatedDate;
	
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone="UTC")
	private String transactionCreatedDate;
	
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone="UTC")
	private String transactionCompletedDate;
	
//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone="UTC")
	private String recordLastUpdatedDate;
	 



	public String getRecordCreatedDate() {
		return recordCreatedDate;
	}

	public void setRecordCreatedDate(String recordCreatedDate) {
		this.recordCreatedDate = recordCreatedDate;
	}

	public String getRecordLastUpdatedDate() {
		return recordLastUpdatedDate;
	}

	public void setRecordLastUpdatedDate(String recordLastUpdatedDate) {
		this.recordLastUpdatedDate = recordLastUpdatedDate;
	}

	public String getTransactionCreatedDate() {
		return transactionCreatedDate;
	}

	public void setTransactionCreatedDate(String transactionCreatedDate) {
		this.transactionCreatedDate = transactionCreatedDate;
	}

	public String getTransactionCompletedDate() {
		return transactionCompletedDate;
	}

	public void setTransactionCompletedDate(String transactionCompletedDate) {
		this.transactionCompletedDate = transactionCompletedDate;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public boolean isMonthly() {
		return isMonthly;
	}

	public void setMonthly(boolean isMonthly) {
		this.isMonthly = isMonthly;
	}

	/**
	 * @return the customerPortfolioId
	 */
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}

	/**
	 * @param customerPortfolioId the customerPortfolioId to set
	 */
	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	
	
}

/**
 * 
 */
package com.bfa.monthlystatements;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.log4j.Logger;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SFTPUtil {
		
	private Logger logger;

	/**
	 * @param host
	 * @param port
	 * @param userName
	 * @param password
	 * @param fileToBeDownload
	 */
	/*
	 * Download monthly statements from SFTP server
	 */
	public InputStream downloadFile(String fileToBeDownload, String userName, String host, String port, String password )  {
		getLogger().info("Files to be downloaded: " + fileToBeDownload);
		getLogger().info("get inside into SFTP util");
		InputStream out = null;
		try {
			JSch jsch = new JSch();
			int portNo = Integer.parseInt(port);
			Session session = jsch.getSession(userName, host, portNo);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			getLogger().info("Establishing Connection...");
			session.connect();
			getLogger().info("Connection established.");
			getLogger().info("Creating SFTP Channel.");
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();
			getLogger().info("SFTP Channel created.");
			out = sftpChannel.get(fileToBeDownload);
			getLogger().info(out.toString());

		} catch (Exception e) {
			getLogger().error("Exception occured while downloadfile in SFTPUtil.downloadFile() for the host=" + host + ":", e);
		}
		return out;
	}
	
	public boolean downloadFileToStore(InputStream is, String downloadFilePath) {
		BufferedInputStream bufferedInputStream = null;
		BufferedOutputStream bufferedOutputStream = null;
		OutputStream outputStream = null;
		try {
				byte[] buffer = new byte[1024];
				bufferedInputStream = new BufferedInputStream(is);
	            File newFile = new File(downloadFilePath);
	            outputStream = new FileOutputStream(newFile);
	            bufferedOutputStream = new BufferedOutputStream(outputStream);
	            int readCount;
	            while ((readCount = bufferedInputStream.read(buffer)) > 0) {
	            	bufferedOutputStream.write(buffer, 0, readCount);
	            }
	            getLogger().info("success");
	            return true;
			} catch(IOException ioException) {
				getLogger().error("Exception occured in downloadFileToStore() while downloading... : "  + downloadFilePath + " : ", ioException);
			} catch(Exception e) {
				getLogger().error("Exception occured while downloading... : "  + downloadFilePath + " : ", e);
			} finally {
				try {
					if(bufferedInputStream != null) {					
							bufferedInputStream.close();					
					}
					if(bufferedOutputStream != null) {
						bufferedOutputStream.close();
					}
					if(outputStream != null) {
						outputStream.close();
					}
				} catch (IOException e) {
					getLogger().error("Exception occured while closing streams: "  + downloadFilePath + " : ", e);
				}
			}
		return false;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
}

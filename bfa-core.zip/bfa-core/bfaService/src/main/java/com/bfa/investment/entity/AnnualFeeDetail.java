package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.bfa.common.entity.OptionItem;

@Entity
@Table(name = "annual_fee_details")
public class AnnualFeeDetail {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "fee_name")
	private String feeName;
	
	@Column(name = "percentage_details")
	private String percentage;
	
	@Column(name = "comment")
	private String comments;
	
	@Column(name = "listing_order")
	private Integer listing_order;
	
	@OneToOne
	@JoinColumn(name = "risk_profile_id")
	private RiskProfile riskProfile;
	
	@OneToOne
	@JoinColumn(name = "portfolio_type")
	private OptionItem portfolioType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFeeName() {
		return feeName;
	}

	public void setFeeName(String feeName) {
		this.feeName = feeName;
	}

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getListing_order() {
		return listing_order;
	}

	public void setListing_order(Integer listing_order) {
		this.listing_order = listing_order;
	}
	
	public OptionItem getPortfolioType() {
		return portfolioType;
	}

	public void setPortfolioType(OptionItem portfolioType) {
		this.portfolioType = portfolioType;
	}
}

package com.bfa.investment.dto;

import java.util.List;

public class RiskAssessmentAnswerDTO {
	
	private int enquiryId;
	
	private List<OptionDTO> answers;
	
	public int getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}
	public List<OptionDTO> getAnswers() {
		return answers;
	}
	public void setAnswers(List<OptionDTO> answers) {
		this.answers = answers;
	}
}

package com.bfa.serviceimpl;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

import com.bfa.common.dto.CustomerEmploymentInformation;
import com.bfa.common.entity.Address;
import com.bfa.common.entity.Country;
import com.bfa.common.entity.CustomerAMLStatus;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.dao.CustomerAMLDao;
import com.bfa.dao.InvestmentAccountDao;
import com.bfa.insurance.core.Customer;
import com.bfa.service.AMLVerificationService;
import com.bfa.servicehelper.URLDirectory;
import com.bfa.util.AMLVerificationServiceResponse;
import com.bfa.util.AMLVerificationStatus;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.PublicUtility;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ArtemisAMLVerificationService implements AMLVerificationService {

	@Autowired
	private Environment env;
	
	@Autowired
	private BFAHttpClient bfaHttpClient;
	
	@Autowired
	InvestmentAccountDao investmentAccountDao;

	@Autowired
	CustomerAMLDao amlDao;

	@Autowired
	ApplicationLoggerBean applicationLoggerBean;

	protected Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}

	public AMLVerificationServiceResponse verify(Integer customerId) {
		getLogger().info("reached ArtemisAMLVerificationService verify");
		Customer customer = investmentAccountDao.getCustomer(customerId);
		if (customer == null) {
			getLogger().info("customer object as null");
			return null;
		}
		AMLVerificationServiceResponse currentAMLStatusResponse = new AMLVerificationServiceResponse();
		try {
			CustomerAMLStatus previousAMLResponse = amlDao.getCustomerAMLStatus(customer.getId());
			if (previousAMLResponse != null) {
				AMLVerificationStatus previousVerificatiomStatus = getAMLVerificationStatus(
						previousAMLResponse.getApprovalStatus());
				if (previousVerificatiomStatus == AMLVerificationStatus.CLEARED
						|| previousVerificatiomStatus == AMLVerificationStatus.REJECTED) {
					currentAMLStatusResponse.setStatus(previousVerificatiomStatus);
				} else {
					if (previousAMLResponse.getCheckStatusURL() != null) {
						currentAMLStatusResponse = doCheckStatus(previousAMLResponse.getCheckStatusURL());
					}
					if (currentAMLStatusResponse != null
							&& currentAMLStatusResponse.getStatus() != previousVerificatiomStatus) {
						Map<String, Object> amlInfo = currentAMLStatusResponse.getAdditionalDetails();
						CustomerAMLStatus amlObj = createCustomerAMLStatus(amlInfo);
						amlObj.setCustomer(customer);
						amlObj.setReferenceId(amlObj.getReferenceId());
						amlDao.saveOrUpdateAMLStatus(amlObj);
					}
				}
			} else {
				currentAMLStatusResponse = doVerify(customer);
				if (currentAMLStatusResponse != null) {
					Map<String, Object> amlInfo = currentAMLStatusResponse.getAdditionalDetails();
					CustomerAMLStatus amlObj = createCustomerAMLStatus(amlInfo);
					amlObj.setCustomer(customer);
					amlDao.saveOrUpdateAMLStatus(amlObj);
				}
			}
		} catch (Exception ex) {
			getLogger().debug("exception caught in verify" + ex);
			getLogger().debug("exception message in verify" + ex.getMessage());
		}
		return currentAMLStatusResponse;
	}

	private CustomerAMLStatus createCustomerAMLStatus(Map<String, Object> amlInfo) {
		CustomerAMLStatus amlObj = new CustomerAMLStatus();
		if (amlInfo.containsKey("approval_status"))
			amlObj.setApprovalStatus(amlInfo.get("approval_status").toString());
		else
			amlObj.setApprovalStatus("REJECTED");
		if (amlInfo.containsKey("status"))
			amlObj.setStatus(amlInfo.get("status").toString());
		if (amlInfo.containsKey("cust_rfr_id"))
			amlObj.setReferenceId(amlInfo.get("cust_rfr_id").toString());
		if (amlInfo.containsKey("check_status_url"))
			amlObj.setCheckStatusURL(amlInfo.get("check_status_url").toString());
		return amlObj;
	}

	private AMLVerificationServiceResponse doCheckStatus(String url) {
		AMLVerificationServiceResponse amlResponse = new AMLVerificationServiceResponse();
		String accessToken = env.getProperty("artemis.accessToken");
		getLogger().info(
				"AML URL: " + url + "\n" +
				"AML TOKEN: " + accessToken
		);
		HashMap<String, String> headers = new HashMap<>();
		headers.put("WEB2PY-USER-TOKEN", accessToken);
		BFAHttpResponse response = bfaHttpClient.doGetCall(url, headers, null);

		if (response != null && response.getResponseBody() != null) {
			try {
				getLogger().info(
						"AML Response: " + response.getResponseBody()
				);
				Gson gson = new Gson();
				Type type = new TypeToken<Map<String, Object>>() {
				}.getType();
				Map<String, Object> resultJson = gson.fromJson(response.getResponseBody(), type);
				if (resultJson != null) {
					if (resultJson.containsKey("approval_status")) {
						String status = resultJson.get("approval_status").toString();
						AMLVerificationStatus verificatiomStatus = getAMLVerificationStatus(status);
						amlResponse.setStatus(verificatiomStatus);
					}
					amlResponse.setAdditionalDetails(resultJson);
				}
			} catch (Exception ex) {
				getLogger().error("exception at doCheckStatus:" + ex);
			}
		}
		else {
			getLogger().info(
					"AML Response is null"
			);
		}
		return amlResponse;
	}


	private AMLVerificationServiceResponse doVerify(Customer customer) {
		getLogger().info("reached doVerify");
		AMLVerificationServiceResponse amlResponse = new AMLVerificationServiceResponse();
		String url = URLDirectory.ArtemisService.individualAPI();
		ArtemisUser user = buildArtemisUserFrom(customer);
		Gson gson = new Gson();
		String userJson = gson.toJson(user);

		String accessToken = env.getProperty("artemis.accessToken");
		HashMap<String, String> headers = new HashMap<>();
		headers.put("WEB2PY-USER-TOKEN", accessToken);
		getLogger().info(
				"AML URL: " + url + "\n" +
				"AML TOKEN: " + accessToken + "\n" +
				"AML Request Body: " + userJson + "\n"
		);
		BFAHttpResponse response = bfaHttpClient.doPostCall(userJson, url, headers, null);

		if (response != null && response.getResponseBody() != null) {
			try {
				getLogger().info(
						"AML Response: " + response.getResponseBody()
				);
				Type type = new TypeToken<Map<String, Object>>() {
				}.getType();
				Map<String, Object> resultJson = gson.fromJson(response.getResponseBody(), type);
				if (resultJson != null) {
					if (resultJson.containsKey("approval_status")) {
						String status = resultJson.get("approval_status").toString();
						AMLVerificationStatus verificatiomStatus = getAMLVerificationStatus(status);
						amlResponse.setStatus(verificatiomStatus);
					}
					amlResponse.setAdditionalDetails(resultJson);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				getLogger().debug("exception caught in doVerify" + ex);
				getLogger().debug("exception message in doVerify" + ex.getMessage());
			}

		}
		else {
			getLogger().info(
					"AML Response is null"
			);
		}
		return amlResponse;
	}

	private AMLVerificationStatus getAMLVerificationStatus(String status) {
		if ("PENDING".equalsIgnoreCase(status)) {
			return AMLVerificationStatus.PENDING;
		} else if ("CLEARED".equalsIgnoreCase(status)) {
			return AMLVerificationStatus.CLEARED;
		} else if ("ACCEPTED".equalsIgnoreCase(status)) {
			return AMLVerificationStatus.ACCEPTED;
		} else if ("REJECTED".equalsIgnoreCase(status)) {
			return AMLVerificationStatus.REJECTED;
		} else {
			return AMLVerificationStatus.REJECTED;
		}
	}

	private ArtemisUser buildArtemisUserFrom(Customer customer) {
		getLogger().info("reached buildArtemisUserFrom");
		String domainName = env.getProperty("artemis.domainName");
		if (domainName == null)
			domainName = "NTUCLINK_UAT";

		String formattedCustomerID = String.format("MO%8s", customer.getId().toString());
		formattedCustomerID = formattedCustomerID.replace(' ', '0');

		ArtemisUser artemisUser = new ArtemisUser();
		try {
			artemisUser.setDomain_name(domainName);
			artemisUser.setCust_rfr_id(formattedCustomerID);
			artemisUser.setFirst_name("");			
			artemisUser.setLast_name(customer.getNricName());
			artemisUser.setTelephone_numbers(customer.getMobileNumber());

			String homeAddress = null;
			if (customer.getHomeAddress() != null) {
				homeAddress = buildAddressString(customer.getHomeAddress());
				artemisUser.setAddresses(homeAddress);
			}

			if (customer.getHomeAddress() != null && customer.getHomeAddress().getCountry() != null) {
				artemisUser.setCountry_of_residence(customer.getHomeAddress().getCountry().getCountry().toUpperCase());
			}
			if (customer.getDateOfBirth() != null) {
				Date dDob = customer.getFormattedDOB();
				String dob = PublicUtility.dateToString(dDob, "dd/MM/yyyy");
				artemisUser.setDate_of_birth(dob);
			}
			artemisUser.setOnboarding_mode("NON FACE-TO-FACE");
			artemisUser.setProduct_service_complexity("SIMPLE");
			artemisUser.setPayment_mode("CREDIT CARD");
			if (customer.getNationalityCode() != null) {
				Country countryDetails = investmentAccountDao.getNationality(customer.getNationalityCode());
				if (countryDetails != null) {
					artemisUser.setNationality(countryDetails.getNationality().toUpperCase());
				}
			}

			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Now use today date.
			c.add(Calendar.DATE, 30);
			String expiryDate = PublicUtility.dateToString(c.getTime(), "dd/MM/yyyy");

			artemisUser.setExpiry_date(expiryDate);

			CustomerEmploymentInformation employerInfo = investmentAccountDao
					.getCustomerEmploymentInformation(customer.getId());
			if (employerInfo != null) {

				if (employerInfo.getCustomerEmploymentDetails() != null
						&& employerInfo.getCustomerEmploymentDetails().getOccupation() != null)
					artemisUser.setSsoc_code(employerInfo.getCustomerEmploymentDetails().getOccupation().getSsocId());
				else
					artemisUser.setSsoc_code("UNKNOWN");

				if (employerInfo.getEmployerDetails() != null
						&& employerInfo.getEmployerDetails().getIndustry() != null)
					artemisUser.setSsic_code(employerInfo.getEmployerDetails().getIndustry().getSsicId());
				else
					artemisUser.setSsic_code("UNKNOWN");
			}
			if (employerInfo != null && employerInfo.getCustomerEmploymentDetails() != null
					&& employerInfo.getCustomerEmploymentDetails().getOccupation() != null) {
				artemisUser.setSsoc_code(employerInfo.getCustomerEmploymentDetails().getOccupation().getSsocId());
			}
		} catch (Exception ex) {
			getLogger().debug("exception caught buildArtemisUserFrom" + ex);
			getLogger().debug("exception message in buildArtemisUserFrom" + ex.getMessage());
		}
		return artemisUser;
	}

	private String buildAddressString(Address address) {
		String addressString = "";
		if (address.getAddressLine1() != null)
			addressString += addressString == "" ? address.getAddressLine1() : ", " + address.getAddressLine1();
		if (address.getAddressLine2() != null)
			addressString += addressString == "" ? address.getAddressLine2() : ", " + address.getAddressLine2();
		if (address.getState() != null)
			addressString += addressString == "" ? address.getState() : ", " + address.getState();
		return addressString;
	}

	@Override
	public AMLVerificationServiceResponse clearVerification(Integer customerId) {
		getLogger().info("reached ArtemisAMLVerificationService verify");
		Customer customer = investmentAccountDao.getCustomer(customerId);
		if (customer == null) {
			getLogger().info("customer object as null");
			return null;
		}

		AMLVerificationServiceResponse currentAMLStatusResponse = new AMLVerificationServiceResponse();
		try {

			CustomerAMLStatus currentAMLResponse = amlDao.getCustomerAMLStatus(customer.getId());
			if (currentAMLResponse != null) {
				AMLVerificationStatus verificationStatus = getAMLVerificationStatus(
						currentAMLResponse.getApprovalStatus());				
					currentAMLResponse.setApprovalStatus("CLEARED");
					currentAMLResponse.setStatus("CLEARED");
					
					amlDao.saveOrUpdateAMLStatus(currentAMLResponse);
					
					currentAMLResponse = amlDao.getCustomerAMLStatus(customer.getId());
					getLogger().debug("Clear Artemis" + currentAMLResponse.getStatus());
				

			}
		} catch (Exception ex) {
			getLogger().debug("exception caught in verify" + ex);
			getLogger().debug("exception message in verify" + ex.getMessage());
		}
		return currentAMLStatusResponse;
	}
}

class ArtemisUser {
	private String domain_name;
	private String cust_rfr_id;
	private String first_name;
	private String last_name;
	private String country_of_residence;
	private String date_of_birth;
	private String onboarding_mode;
	private String product_service_complexity;
	private String payment_mode;
	private String nationality;
	private String expiry_date;
	private String ssic_code;
	private String ssoc_code;
	private String telephone_numbers;
	private String addresses;

	public String getTelephone_numbers() {
		return telephone_numbers;
	}

	public void setTelephone_numbers(String telephone_numbers) {
		this.telephone_numbers = telephone_numbers;
	}

	public String getAddresses() {
		return addresses;
	}

	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}

	public String getDomain_name() {
		return domain_name;
	}

	public void setDomain_name(String domain_name) {
		this.domain_name = domain_name;
	}

	public String getCust_rfr_id() {
		return cust_rfr_id;
	}

	public void setCust_rfr_id(String cust_rfr_id) {
		this.cust_rfr_id = cust_rfr_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getCountry_of_residence() {
		return country_of_residence;
	}

	public void setCountry_of_residence(String country_of_residence) {
		this.country_of_residence = country_of_residence;
	}

	public String getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String getOnboarding_mode() {
		return onboarding_mode;
	}

	public void setOnboarding_mode(String onboarding_mode) {
		this.onboarding_mode = onboarding_mode;
	}

	public String getProduct_service_complexity() {
		return product_service_complexity;
	}

	public void setProduct_service_complexity(String product_service_complexity) {
		this.product_service_complexity = product_service_complexity;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getExpiry_date() {
		return expiry_date;
	}

	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}

	public String getSsic_code() {
		return ssic_code;
	}

	public void setSsic_code(String ssic_code) {
		this.ssic_code = ssic_code;
	}

	public String getSsoc_code() {
		return ssoc_code;
	}

	public void setSsoc_code(String ssoc_code) {
		this.ssoc_code = ssoc_code;
	}

}

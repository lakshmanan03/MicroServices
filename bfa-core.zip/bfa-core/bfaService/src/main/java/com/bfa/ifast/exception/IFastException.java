/**
 * 
 */
package com.bfa.ifast.exception;

/**
 * @author DivakarU
 *
 */
public class IFastException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7359457919614304909L;

	/**
	 * @param exceptionMessage
	 */
	public IFastException(String exceptionMessage) {
		super(exceptionMessage);
	}

}



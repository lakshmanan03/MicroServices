package com.bfa.dao;

import com.bfa.common.entity.CustomerAMLStatus;

public interface CustomerAMLDao {
	CustomerAMLStatus getCustomerAMLStatus(Integer customerId);
	CustomerAMLStatus saveOrUpdateAMLStatus(CustomerAMLStatus amlStatus);
}

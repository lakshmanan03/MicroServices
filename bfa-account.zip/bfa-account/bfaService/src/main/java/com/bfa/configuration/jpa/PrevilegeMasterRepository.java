/**
 * 
 */
package com.bfa.configuration.jpa;

import org.springframework.data.repository.CrudRepository;

import com.bfa.insurance.core.PrevilageMaster;

/**
 * @author pradheep.p
 *
 */
public interface PrevilegeMasterRepository extends CrudRepository<PrevilageMaster, Integer> {

}

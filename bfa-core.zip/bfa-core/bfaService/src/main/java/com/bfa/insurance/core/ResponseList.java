/**
 * 
 */
package com.bfa.insurance.core;

import java.util.Collections;
import java.util.List;

import com.bfa.util.ResponseMessage;
import com.bfa.util.ResponseMessageList;


public class ResponseList extends ResponseMessageList {
	
	private ResponseMessage responseMessage;
	
	private List<Object> objectList = Collections.emptyList();
	
	public ResponseList(){
		
	}
	
	public ResponseList(ResponseMessage defaultResponseMessage){
		this.responseMessage = defaultResponseMessage;
	}
	
	@Override
	public ResponseMessage getResponseMessage() {		
		return this.responseMessage;
	}
	
	@Override
	public List<Object> getObjectList() {		
		return this.objectList;
	}
	
	@Override
	public void setResponseMessage(ResponseMessage responseMessage){
		this.responseMessage = responseMessage;
	}
	
	@Override
	public void setObjectList(List<Object> responseList){
		this.objectList = responseList;
	}

}

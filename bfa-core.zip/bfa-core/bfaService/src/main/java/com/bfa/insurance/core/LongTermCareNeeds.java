/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "long_term_care_needs")
public class LongTermCareNeeds implements Serializable{
	

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "care_giver_type_id")
	private int careGiverTypeId;	
	
	@Column(name = "montly_payout")
	private int monthlyPayout;
	
	@Column(name = "income_payout_duration")
	private String incomePayoutDuration;
	
	@Column(name = "no_of_adls")
	private int noOfAdls;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getCareGiverTypeId() {
		return careGiverTypeId;
	}

	public void setCareGiverTypeId(int careGiverTypeId) {
		this.careGiverTypeId = careGiverTypeId;
	}

	public int getMonthlyPayout() {
		return monthlyPayout;
	}

	public void setMonthlyPayout(int monthlyPayout) {
		this.monthlyPayout = monthlyPayout;
	}

	public String getIncomePayoutDuration() {
		return incomePayoutDuration;
	}

	public void setIncomePayoutDuration(String incomePayoutDuration) {
		this.incomePayoutDuration = incomePayoutDuration;
	}

	public int getNoOfAdls() {
		return noOfAdls;
	}

	public void setNoOfAdls(int noOfAdls) {
		this.noOfAdls = noOfAdls;
	}
}

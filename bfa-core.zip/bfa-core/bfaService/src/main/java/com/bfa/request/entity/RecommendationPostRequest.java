/**
 * 
 */
package com.bfa.request.entity;

import java.io.Serializable;
import java.util.List;

import com.bfa.insurance.core.CriticalIllnessNeeds;
import com.bfa.insurance.core.DependentMapping;

import com.bfa.insurance.core.Enquiry;
import com.bfa.insurance.core.EnquiryProtectionType;
import com.bfa.insurance.core.ExistingInsurance;
import com.bfa.insurance.core.FinancialStatusMapping;
import com.bfa.insurance.core.HospitalizationNeeds;
import com.bfa.insurance.core.LifeProtectionNeeds;
import com.bfa.insurance.core.LongTermCareNeeds;
import com.bfa.insurance.core.OccupationalDisabilityNeeds;
import com.bfa.insurance.core.RetirementIncomePlan;
import com.bfa.insurance.core.SRSApprovedPlans;

/**
 * @author pradheep.p
 *
 */
public class RecommendationPostRequest implements Serializable {	
	

	private static final long serialVersionUID = 1L;

	private Enquiry enquiryData;
	
	private List<EnquiryProtectionType> enquiryProtectionTypeData;
	
	private FinancialStatusMapping financialStatusMapping;
	
	private List<DependentMapping> dependentsData; 
	
	private CriticalIllnessNeeds criticalIllnessNeedsData;
	
	private OccupationalDisabilityNeeds occupationalDisabilityNeeds;
	
	private HospitalizationNeeds hospitalizationNeeds;
	
	private LongTermCareNeeds longTermCareNeeds;
	
	private LifeProtectionNeeds lifeProtectionNeeds;
	
	private List<ExistingInsurance> existingInsuranceList;
	
	private SRSApprovedPlans srsApprovedPlans;
	
	private RetirementIncomePlan retirementIncomePlan;	
	
	private String sessionId;
	

	public Enquiry getEnquiryData() {
		return enquiryData;
	}

	public void setEnquiryData(Enquiry enquiryData) {
		this.enquiryData = enquiryData;
	}

	public CriticalIllnessNeeds getCriticalIllnessNeedsData() {
		return criticalIllnessNeedsData;
	}

	public void setCriticalIllnessNeedsData(CriticalIllnessNeeds criticalIllnessNeedsData) {
		this.criticalIllnessNeedsData = criticalIllnessNeedsData;
	}

	public OccupationalDisabilityNeeds getOccupationalDisabilityNeeds() {
		return occupationalDisabilityNeeds;
	}

	public void setOccupationalDisabilityNeeds(OccupationalDisabilityNeeds occupationalDisabilityNeeds) {
		this.occupationalDisabilityNeeds = occupationalDisabilityNeeds;
	}

	public HospitalizationNeeds getHospitalizationNeeds() {
		return hospitalizationNeeds;
	}

	public void setHospitalizationNeeds(HospitalizationNeeds hospitalizationNeeds) {
		this.hospitalizationNeeds = hospitalizationNeeds;
	}

	public LongTermCareNeeds getLongTermCareNeeds() {
		return longTermCareNeeds;
	}

	public void setLongTermCareNeeds(LongTermCareNeeds longTermCareNeeds) {
		this.longTermCareNeeds = longTermCareNeeds;
	}

	/**
	 * @return the enquiryProtectionTypeData
	 */
	public List<EnquiryProtectionType> getEnquiryProtectionTypeData() {
		return enquiryProtectionTypeData;
	}

	/**
	 * @param enquiryProtectionTypeData the enquiryProtectionTypeData to set
	 */
	public void setEnquiryProtectionTypeData(List<EnquiryProtectionType> enquiryProtectionTypeData) {
		this.enquiryProtectionTypeData = enquiryProtectionTypeData;
	}

	/**
	 * @return the lifeProtectionNeeds
	 */
	public LifeProtectionNeeds getLifeProtectionNeeds() {
		return lifeProtectionNeeds;
	}

	/**
	 * @param lifeProtectionNeeds the lifeProtectionNeeds to set
	 */
	public void setLifeProtectionNeeds(LifeProtectionNeeds lifeProtectionNeeds) {
		this.lifeProtectionNeeds = lifeProtectionNeeds;
	}

	/**
	 * @return the existingInsuranceList
	 */
	public List<ExistingInsurance> getExistingInsuranceList() {
		return existingInsuranceList;
	}

	/**
	 * @param existingInsuranceList the existingInsuranceList to set
	 */
	public void setExistingInsuranceList(List<ExistingInsurance> existingInsuranceList) {
		this.existingInsuranceList = existingInsuranceList;
	}

	public List<DependentMapping> getDependentsData() {
		return dependentsData;
	}

	public void setDependentsData(List<DependentMapping> dependentsData) {
		this.dependentsData = dependentsData;
	}

	public FinancialStatusMapping getFinancialStatusMapping() {
		return financialStatusMapping;
	}

	public void setFinancialStatusMapping(FinancialStatusMapping financialStatusMapping) {
		this.financialStatusMapping = financialStatusMapping;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public SRSApprovedPlans getSrsApprovedPlans() {
		return srsApprovedPlans;
	}

	public void setSrsApprovedPlans(SRSApprovedPlans srsApprovedPlans) {
		this.srsApprovedPlans = srsApprovedPlans;
	}

	public RetirementIncomePlan getRetirementIncomePlan() {
		return retirementIncomePlan;
	}

	public void setRetirementIncomePlan(RetirementIncomePlan retirementIncomePlan) {
		this.retirementIncomePlan = retirementIncomePlan;
	}
	
}

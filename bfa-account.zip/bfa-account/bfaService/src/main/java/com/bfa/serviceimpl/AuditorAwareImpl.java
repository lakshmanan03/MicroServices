/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;

/**
 * @author kianann
 *
 */
public class AuditorAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		System.out.println("IN AuditorAwareImpl");
		return Optional.of("user");
	}

}

/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;

import com.bfa.application.core.EnquiryResponseMessage;
import com.bfa.application.core.PromoCodeRequest;
import com.bfa.application.discovery.DiscoveryHelper;
import com.bfa.application.security.SecurityConstants;
import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.servicehelper.MOServiceHelper;
import com.bfa.util.APIConstants;
import com.bfa.util.ApplicationConstants;
import com.bfa.util.BFAHttpClient;
import com.bfa.util.BFAHttpResponse;
import com.bfa.util.ErrorCodes;
import com.bfa.util.ServiceNames;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * @author kianann
 *
 */
public class EnquiryServiceUpdater extends DiscoveryHelper {

	@Autowired
	private Environment environment;

	@Autowired
	private BFAHttpClient bfaHttpClient;
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private String API_NAME = "/api/createEnquiry";

	@Autowired
	private SecurityConstants securityConstants;

	@Autowired
	@Qualifier(value = "moServiceHelper")
	private MOServiceHelper serviceHelper;

	public EnquiryResponseMessage createEnquiry(PromoCodeRequest promoCodeRequest) {

		setEnvironment(environment);
		String targetURL = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + API_NAME;

		Integer customerId = null;
		if (serviceHelper != null && serviceHelper.getCurrentHttpRequest() != null && serviceHelper
				.getCurrentHttpRequest().getAttribute(securityConstants.CUSTOMER_ID_IN_REQUEST) != null) {
			customerId = Integer.valueOf(serviceHelper.getCurrentHttpRequest()
					.getAttribute(securityConstants.CUSTOMER_ID_IN_REQUEST).toString());
			getLogger().info("Printing customer Id value from createEnquiry() method :" + customerId);
		}
		loadSecurityHeaderForCustomer(securityConstants.TOKEN_NAME, customerId);

		Map<String, Object> createEnquiryJson = new HashMap<>();
		createEnquiryJson.put("sessionId", promoCodeRequest.getSessionId());
		createEnquiryJson.put("promoCodeId", promoCodeRequest.getPromoCodeId());
		createEnquiryJson.put("requestType", promoCodeRequest.getRequestType());

		getLogger().info("Printing the target URL :" + targetURL);
		getLogger().info("Calling account microservice - Request body :" + createEnquiryJson);

		BFAHttpResponse response = bfaHttpClient.doPostCall(new Gson().toJson(createEnquiryJson), targetURL, header,
				null);

		String responseBody = response.getResponseBody();

		Gson gson = new GsonBuilder().serializeNulls().create();
		EnquiryResponseMessage responseMessageList = new EnquiryResponseMessage();
		try {
			responseMessageList = gson.fromJson(responseBody, EnquiryResponseMessage.class);
			if (ErrorCodes.SUCCESSFUL_RESPONSE == responseMessageList.getResponseMessage().getResponseCode()) {
				getLogger().info("Create Enquiry Success!");
				return responseMessageList;
			} else {
				getLogger().warn("Create Enquiry Failure!");
				responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				responseMessageList.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception error) {
			getLogger().error("Error while paring the response ", error);
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
		}

		return responseMessageList;
	}

	public EnquiryResponseMessage createComprehensiveEnquiry(PromoCodeRequest promoCodeRequest) {

		setEnvironment(environment);
		String targetURL = getBaseUrl(ServiceNames.RECOMMENDATIONS_MICROSERVICE);
		targetURL = removePortNumbers(targetURL);
		targetURL = targetURL + APIConstants.CREATE_COMPRE_ENQUIRY;

		Integer customerId = null;
		if (serviceHelper != null && serviceHelper.getCurrentHttpRequest() != null && serviceHelper
				.getCurrentHttpRequest().getAttribute(securityConstants.CUSTOMER_ID_IN_REQUEST) != null) {
			customerId = Integer.valueOf(serviceHelper.getCurrentHttpRequest()
					.getAttribute(securityConstants.CUSTOMER_ID_IN_REQUEST).toString());
			getLogger().info("Printing customer Id value from createEnquiry() method :" + customerId);
		}
		loadSecurityHeaderForCustomer(securityConstants.TOKEN_NAME, customerId);

		Map<String, Object> createEnquiryJson = new HashMap<>();
		createEnquiryJson.put("sessionId", promoCodeRequest.getSessionId());
		createEnquiryJson.put("promoCodeId", promoCodeRequest.getPromoCodeId());
		createEnquiryJson.put("requestType", promoCodeRequest.getRequestType());

		getLogger().info("Printing the target URL :" + targetURL);
		getLogger().info("Calling account microservice - Request body :" + createEnquiryJson);

		BFAHttpResponse response = bfaHttpClient.doPostCall(new Gson().toJson(createEnquiryJson), targetURL, header,
				null);

		String responseBody = response.getResponseBody();

		Gson gson = new GsonBuilder().serializeNulls().create();
		EnquiryResponseMessage responseMessageList = new EnquiryResponseMessage();
		try {
			responseMessageList = gson.fromJson(responseBody, EnquiryResponseMessage.class);
			if (ErrorCodes.SUCCESSFUL_RESPONSE == responseMessageList.getResponseMessage().getResponseCode()) {
				getLogger().info("Create Enquiry Success!");
				return responseMessageList;
			} else {
				getLogger().warn("Create Enquiry Failure!");
				responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
				responseMessageList.getResponseMessage()
						.setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception error) {
			getLogger().error("Error while paring the response ", error);
			responseMessageList.getResponseMessage().setResponseCode(ErrorCodes.INTERNAL_SERVER_ERROR);
			responseMessageList.getResponseMessage().setResponseDescription(ApplicationConstants.INTERNAL_SERVER_ERROR);
		}

		return responseMessageList;
	}

	private Logger getLogger() {
		return applicationLoggerBean.getLogBean(this.getClass());
	}
}

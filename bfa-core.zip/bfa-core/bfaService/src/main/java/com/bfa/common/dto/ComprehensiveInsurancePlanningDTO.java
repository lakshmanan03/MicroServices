/**
 * 
 */
package com.bfa.common.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class ComprehensiveInsurancePlanningDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private Integer id;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private Integer customerId;

	private Integer enquiryId;

	private Boolean haveHospitalPlan;

	private Integer haveCPFDependentsProtectionScheme;

	private Double lifeProtectionAmount;
	
	private Integer haveHDBHomeProtectionScheme;
	
	private Double homeProtectionCoverageAmount;

	private Double otherLifeProtectionCoverageAmount;

	private Double criticalIllnessCoverageAmount;

	private Double disabilityIncomeCoverageAmount;

	private Integer haveLongTermElderShield;

	private Integer longTermElderShieldAmount;
	
	private Boolean isDefaultLifeProtectionAmount;
	
	private Integer haveHospitalPlanWithRider;
	
	private Double otherLongTermCareInsuranceAmount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Double getCriticalIllnessCoverageAmount() {
		return criticalIllnessCoverageAmount;
	}

	public void setCriticalIllnessCoverageAmount(Double criticalIllnessCoverageAmount) {
		this.criticalIllnessCoverageAmount = criticalIllnessCoverageAmount;
	}

	public Double getDisabilityIncomeCoverageAmount() {
		return disabilityIncomeCoverageAmount;
	}

	public void setDisabilityIncomeCoverageAmount(Double disabilityIncomeCoverageAmount) {
		this.disabilityIncomeCoverageAmount = disabilityIncomeCoverageAmount;
	}

	public Integer getHaveCPFDependentsProtectionScheme() {
		return haveCPFDependentsProtectionScheme;
	}

	public void setHaveCPFDependentsProtectionScheme(Integer haveCPFDependentsProtectionScheme) {
		this.haveCPFDependentsProtectionScheme = haveCPFDependentsProtectionScheme;
	}

	public Integer getHaveHDBHomeProtectionScheme() {
		return haveHDBHomeProtectionScheme;
	}

	public void setHaveHDBHomeProtectionScheme(Integer haveHDBHomeProtectionScheme) {
		this.haveHDBHomeProtectionScheme = haveHDBHomeProtectionScheme;
	}

	public Integer getHaveLongTermElderShield() {
		return haveLongTermElderShield;
	}

	public void setHaveLongTermElderShield(Integer haveLongTermElderShield) {
		this.haveLongTermElderShield = haveLongTermElderShield;
	}

	public Integer getLongTermElderShieldAmount() {
		return longTermElderShieldAmount;
	}

	public void setLongTermElderShieldAmount(Integer longTermElderShieldAmount) {
		this.longTermElderShieldAmount = longTermElderShieldAmount;
	}

	public Double getHomeProtectionCoverageAmount() {
		return homeProtectionCoverageAmount;
	}

	public void setHomeProtectionCoverageAmount(Double homeProtectionCoverageAmount) {
		this.homeProtectionCoverageAmount = homeProtectionCoverageAmount;
	}

	public Double getOtherLifeProtectionCoverageAmount() {
		return otherLifeProtectionCoverageAmount;
	}

	public void setOtherLifeProtectionCoverageAmount(Double otherLifeProtectionCoverageAmount) {
		this.otherLifeProtectionCoverageAmount = otherLifeProtectionCoverageAmount;
	}

	public Double getLifeProtectionAmount() {
		return lifeProtectionAmount;
	}

	public void setLifeProtectionAmount(Double lifeProtectionAmount) {
		this.lifeProtectionAmount = lifeProtectionAmount;
	}

	public Boolean isHaveHospitalPlan() {
		return haveHospitalPlan;
	}

	public void setHaveHospitalPlan(Boolean haveHospitalPlan) {
		this.haveHospitalPlan = haveHospitalPlan;
	}

	public Boolean getIsDefaultLifeProtectionAmount() {
		return isDefaultLifeProtectionAmount;
	}

	public void setIsDefaultLifeProtectionAmount(Boolean isDefaultLifeProtectionAmount) {
		this.isDefaultLifeProtectionAmount = isDefaultLifeProtectionAmount;
	}

	public Integer getHaveHospitalPlanWithRider() {
		return haveHospitalPlanWithRider;
	}

	public void setHaveHospitalPlanWithRider(Integer haveHospitalPlanWithRider) {
		this.haveHospitalPlanWithRider = haveHospitalPlanWithRider;
	}

	public Double getOtherLongTermCareInsuranceAmount() {
		return otherLongTermCareInsuranceAmount;
	}

	public void setOtherLongTermCareInsuranceAmount(Double otherLongTermCareInsuranceAmount) {
		this.otherLongTermCareInsuranceAmount = otherLongTermCareInsuranceAmount;
	}

	

}

package com.bfa.investment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "risk_score_matrix")
public class RiskScore {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "risk_ability_score")
	private int riskAbilityScore;
	
	@Column(name = "risk_score_factor_type_id")
	private int riskScoreFactorId;
	
	@Column(name = "risk_willingness_score")
	private int riskWillingnessScore;
	
	@OneToOne
	@JoinColumn(name = "risk_profile_master_id")
	private RiskProfile riskProfile;
	
	@OneToOne
	@JoinColumn(name = "alternate_risk_profile_id")
	private RiskProfile alternateRiskProfile;
	
	

	@Column(name = "description")
	private String htmlDesc;
	
	
	
	public RiskProfile getAlternateRiskProfile() {
		return alternateRiskProfile;
	}

	public void setAlternateRiskProfile(RiskProfile alternateRiskProfile) {
		this.alternateRiskProfile = alternateRiskProfile;
	}

	public int getRiskScoreFactorId() {
		return riskScoreFactorId;
	}

	public void setRiskScoreFactorId(int riskScoreFactorId) {
		this.riskScoreFactorId = riskScoreFactorId;
	}

	public String getHtmlDesc() {
		return htmlDesc;
	}

	public void setHtmlDesc(String htmlDesc) {
		this.htmlDesc = htmlDesc;
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getRiskAbilityScore() {
		return riskAbilityScore;
	}


	public void setRiskAbilityScore(int riskAbilityScore) {
		this.riskAbilityScore = riskAbilityScore;
	}


	public int getRiskWillingnessScore() {
		return riskWillingnessScore;
	}


	public void setRiskWillingnessScore(int riskWillingnessScore) {
		this.riskWillingnessScore = riskWillingnessScore;
	}


	public RiskProfile getRiskProfile() {
		return riskProfile;
	}


	public void setRiskProfile(RiskProfile riskProfile) {
		this.riskProfile = riskProfile;
	}
	
	
}

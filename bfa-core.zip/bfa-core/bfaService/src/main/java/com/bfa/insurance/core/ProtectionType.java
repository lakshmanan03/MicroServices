/**
* 
 */
package com.bfa.insurance.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "protection_type_master")
public class ProtectionType {
	
	@Id
	@GeneratedValue
	@Column(name = "id")
	private int protectionTypeId;

	@Column(name = "protection_type")
	private String protectionType;

	@Column(name = "protection_type_description")
	private String protectionDesc;
	
	@JsonIgnore
	@Column(name="journey_type")
	private String journeyType;

	public String getProtectionDesc() {
		return protectionDesc;
	}

	public void setProtectionDesc(String protectionDesc) {
		this.protectionDesc = protectionDesc;
	}

	public String getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(String protectionType) {
		this.protectionType = protectionType;
	}

	public int getProtectionTypeId() {
		return this.protectionTypeId;
	}

	public void setProtectionTypeId(int protectionTypeId) {
		this.protectionTypeId = protectionTypeId;
	}

	public String getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

}

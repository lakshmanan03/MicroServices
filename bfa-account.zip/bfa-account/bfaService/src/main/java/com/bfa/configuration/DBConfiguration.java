package com.bfa.configuration;

import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.bfa.servicehelper.URLDirectory;
import com.bfa.util.PublicUtility;

@Configuration
@EnableTransactionManagement
@EntityScan({"com.bfa.insurance.core","com.bfa.application.core", "com.bfa.investment.entity", "com.bfa.common.entity", "com.bfa.investment.ifast.entity","com.bfa.comprehensive.core"})
@EnableJpaRepositories(basePackages = "com.bfa.configuration.jpa", entityManagerFactoryRef="entityManagerFactory")
@DependsOn("applicationLoggerBean")
public class DBConfiguration {

	@Autowired
    private Environment env;

	private String appKey = "IMXYlDmP4f4=";
	
	private PublicUtility utility = PublicUtility.getInstance(appKey);
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}
	
	@Bean	
	public LocalSessionFactoryBean sessionFactory() {
		
		getLogger().info("Profile detected from Environment: " + PublicUtility.getActiveProfile(env));
		URLDirectory.initialize(env);
		
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(new String[] { "com.bfa.insurance.core","com.bfa.application.core", "com.bfa.investment.entity", "com.bfa.common.entity", "com.bfa.investment.ifast.entity","com.bfa.comprehensive.core"});
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean	
	public BasicDataSource dataSource() {
		BasicDataSource dataSource = new BasicDataSource();
		System.out.println(env.getProperty("jdbc.url")+"+================++++++");
		System.out.println(env.getProperty("jdbc.driverClassName")+"+================++++++");
		System.out.println(env.getProperty("jdbc.user")+"+================++++++");
		System.out.println(env.getProperty("jdbc.password")+"+================++++++");
		getLogger().info("--------------------------------------------------------------");
		getLogger().info("Printing the driver class name :" + env.getProperty("jdbc.driverClassName"));
		getLogger().info("--------------------------------------------------------------");
		dataSource.setDriverClassName(env.getProperty("jdbc.driverClassName"));
		System.out.println(env.getProperty("test")+" added new ==================================");
		dataSource.setUrl(env.getProperty("jdbc.url"));
		System.out.println(env.getProperty("jdbc.password")+" Password for connectivity");
		if(env.getProperty("jdbc.user") != null){
		dataSource.setUsername(env.getProperty("jdbc.user"));
		}
		if(env.getProperty("jdbc.password") != null){
		dataSource.setPassword(utility.DecryptText(env.getProperty("jdbc.password")));
		System.out.println(utility.DecryptText(env.getProperty("jdbc.password"))+"d=====");
		}		
		getLogger().info("Data Source " + dataSource.toString());
		dataSource.setTestWhileIdle(true);
		dataSource.setValidationQuery("select 1");	
		// -- Load test issues fix -- //
		dataSource.setMaxActive(-1);
		dataSource.setInitialSize(3);
		dataSource.setMaxIdle(10);		
		dataSource.setMinIdle(3);
		dataSource.setMinEvictableIdleTimeMillis(10000);
		dataSource.setNumTestsPerEvictionRun(10);
		dataSource.setTimeBetweenEvictionRunsMillis(60000);
		//----------------------------//
		return dataSource;
	}

	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
		properties.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
		properties.put("hibernate.format_sql", env.getProperty("hibernate.format_sql"));
		properties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
		return properties;
	}

	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory s) {
		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(s);
		return txManager;
	}
	
	@Bean(name="entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
	    HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	    vendorAdapter.setGenerateDdl(false);
	    LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
	    factory.setJpaProperties(hibernateProperties());
	    factory.setJpaVendorAdapter(vendorAdapter);	    
	    factory.setPackagesToScan("com.bfa.insurance.core","com.bfa.application.core", "com.bfa.investment.entity", "com.bfa.common.entity", "com.bfa.investment.ifast.entity","com.bfa.comprehensive.core");
	    factory.setDataSource(dataSource());
	    return factory;
	}	
}
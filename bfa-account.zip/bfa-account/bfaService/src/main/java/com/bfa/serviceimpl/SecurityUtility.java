/**
 * 
 */
package com.bfa.serviceimpl;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.DigestException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.exception.BfaException;

public class SecurityUtility {

	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;

	private Logger getLogger() {
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}	

	protected String hashSHA512(String input) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] messageDigest = md.digest(input.getBytes());
			BigInteger no = new BigInteger(1, messageDigest);
			String hashtext = no.toString(16);
			while (hashtext.length() < 32) {
				hashtext = "0" + hashtext;
			}
			return hashtext;
		} catch (NoSuchAlgorithmException err) {
			getLogger().error("Error while encrypting data " + input, err);
		}
		return null;
	}

	protected String decrypt(String stringToDecrypt, String keyString) throws Exception{
		byte[] cipherData = Base64.getDecoder().decode(stringToDecrypt);
		byte[] saltData = Arrays.copyOfRange(cipherData, 8, 16);

		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			getLogger().error("NoSuchAlgorithmException: ", e);
		}
		byte[][] keyAndIV = null;
		SecretKeySpec key = null;
		IvParameterSpec iv = null;
		try {
			keyAndIV = GenerateKeyAndIV(32, 16, 1, saltData, keyString.getBytes(StandardCharsets.UTF_8), md5);
			key = new SecretKeySpec(keyAndIV[0], "AES");
			iv = new IvParameterSpec(keyAndIV[1]);
		} catch (Exception e) {
			getLogger().error("Exception: ", e);
		}

		byte[] encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
		Cipher aesCBC = null;
		try {
			aesCBC = Cipher.getInstance("AES/CBC/PKCS5Padding");
		} catch (NoSuchAlgorithmException err) {
			getLogger().error("NoSuchAlgorithmException while decrypting data ", err);
		} catch (NoSuchPaddingException err) {
			getLogger().error("NoSuchPaddingException while decrypting data ", err);
		}
		try {
			if (aesCBC != null) {
				aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
			}
		} catch (InvalidKeyException err) {
			getLogger().error("Error while decrypting data ", err);
		} catch (InvalidAlgorithmParameterException err) {
			getLogger().error("InvalidAlgorithmParameterException while decrypting data ", err);
		}
		byte[] decryptedData = null;
		try {
			if (aesCBC != null) {
				decryptedData = aesCBC.doFinal(encrypted);
			}
		} catch (IllegalBlockSizeException err) {
			getLogger().error("Error while decrypting data ", err);
		} catch (BadPaddingException err) {
			getLogger().error("BadPaddingException while decrypting data ", err);
		}
		if(decryptedData == null){
			// throw new RuntimeException("Unable to decrypt the password : Check the key used!")
			throw new BfaException("Unable to decrypt the password : Check the key used!");
		}
		
		String decryptedText = new String(decryptedData, StandardCharsets.UTF_8);
		getLogger().debug(decryptedText);
		return decryptedText;
	}

	private byte[][] GenerateKeyAndIV(int keyLength, int ivLength, int iterations, byte[] salt, byte[] password,
			MessageDigest md) {

		int digestLength = md.getDigestLength();
		int requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
		byte[] generatedData = new byte[requiredLength];
		int generatedLength = 0;

		try {
			md.reset();
			// Repeat process until sufficient data has been generated
			while (generatedLength < keyLength + ivLength) {
				// Digest data (last digest if available, password data, salt if
				// available)
				if (generatedLength > 0)
					md.update(generatedData, generatedLength - digestLength, digestLength);
				md.update(password);
				if (salt != null)
					md.update(salt, 0, 8);
				md.digest(generatedData, generatedLength, digestLength);
				// additional rounds
				for (int i = 1; i < iterations; i++) {
					md.update(generatedData, generatedLength, digestLength);
					md.digest(generatedData, generatedLength, digestLength);
				}
				generatedLength += digestLength;
			}

			// Copy key and IV into separate byte arrays
			byte[][] result = new byte[2][];
			result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
			if (ivLength > 0)
				result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);

			return result;

		} catch (DigestException e) {
			//throw new RuntimeException(e)
			throw new BfaException("DigestException: " + e);

		} finally {
			// Clean out temporary data
			Arrays.fill(generatedData, (byte) 0);
		}
	}
}

/**
 * 
 */
package com.bfa.request.entity;

import java.util.List;

import com.bfa.common.dto.ComprehensiveAssetsDTO;
import com.bfa.common.dto.ComprehensiveDownOnLuckDTO;
import com.bfa.common.dto.ComprehensiveEarningsDTO;
import com.bfa.common.dto.ComprehensiveLiabilitiesDTO;
import com.bfa.common.dto.ComprehensiveRegularSavingsDTO;
import com.bfa.common.dto.ComprehensiveSpendingDTO;

public class ComprehensiveFinancialEnquiryPostResponse {
	
	ComprehensiveEarningsDTO comprehensiveEarnings;
	
	private List<ComprehensiveRegularSavingsDTO> comprehensiveRegularSavingsList;
	
	ComprehensiveDownOnLuckDTO comprehensiveDownOnLuckDTO;
	
	ComprehensiveSpendingDTO comprehensiveSpendingDTO;
	
	ComprehensiveAssetsDTO comprehensiveAssetsDTO;
	
	ComprehensiveLiabilitiesDTO comprehensiveLiabilitiesDTO;

	public ComprehensiveLiabilitiesDTO getComprehensiveLiabilitiesDTO() {
		return comprehensiveLiabilitiesDTO;
	}

	public void setComprehensiveLiabilitiesDTO(ComprehensiveLiabilitiesDTO comprehensiveLiabilitiesDTO) {
		this.comprehensiveLiabilitiesDTO = comprehensiveLiabilitiesDTO;
	}

	public ComprehensiveAssetsDTO getComprehensiveAssetsDTO() {
		return comprehensiveAssetsDTO;
	}

	public void setComprehensiveAssetsDTO(ComprehensiveAssetsDTO comprehensiveAssetsDTO) {
		this.comprehensiveAssetsDTO = comprehensiveAssetsDTO;
	}

	public ComprehensiveSpendingDTO getComprehensiveSpendingDTO() {
		return comprehensiveSpendingDTO;
	}

	public void setComprehensiveSpendingDTO(ComprehensiveSpendingDTO comprehensiveSpendingDTO) {
		this.comprehensiveSpendingDTO = comprehensiveSpendingDTO;
	}

	public ComprehensiveDownOnLuckDTO getComprehensiveDownOnLuckDTO() {
		return comprehensiveDownOnLuckDTO;
	}

	public void setComprehensiveDownOnLuckDTO(ComprehensiveDownOnLuckDTO comprehensiveDownOnLuckDTO) {
		this.comprehensiveDownOnLuckDTO = comprehensiveDownOnLuckDTO;
	}

	public ComprehensiveEarningsDTO getComprehensiveEarnings() {
		return comprehensiveEarnings;
	}

	public void setComprehensiveEarnings(ComprehensiveEarningsDTO comprehensiveEarnings) {
		this.comprehensiveEarnings = comprehensiveEarnings;
	}

	public List<ComprehensiveRegularSavingsDTO> getComprehensiveRegularSavingsList() {
		return comprehensiveRegularSavingsList;
	}

	public void setComprehensiveRegularSavingsList(List<ComprehensiveRegularSavingsDTO> comprehensiveRegularSavingsList) {
		this.comprehensiveRegularSavingsList = comprehensiveRegularSavingsList;
	}

	

}

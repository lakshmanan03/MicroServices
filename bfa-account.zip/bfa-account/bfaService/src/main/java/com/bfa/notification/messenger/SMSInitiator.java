/**
 * 
 */
package com.bfa.notification.messenger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.bfa.configuration.ApplicationLoggerBean;
import com.bfa.notification.messenger.templates.OTPSMSTemplate;
import com.bfa.notification.messenger.templates.SMSDetails;
import com.bfa.notification.messenger.templates.SMSMessageObject;

/**
 * @author pradheep.p
 *
 */
public class SMSInitiator implements Runnable {

	private SMSDetails smsDetails;
	
	@Autowired
	private MessengerDelegate messengerDelegate;
	
	@Autowired
	private ApplicationLoggerBean applicationLoggerBean;
	
	private Logger getLogger(){
		return this.applicationLoggerBean.getLogBean(this.getClass());
	}
	
	@Override
	public void run() {
		getLogger().info("Sending a OTP message to the user ");
		
		String countryCode = getSmsDetails().getCountryCode();
		String otp = getSmsDetails().getOTP();
		String contactNumber = getSmsDetails().getContactNumber();
		
		getLogger().info("Printing the country code " + countryCode);
		getLogger().info("Printing the OTP " + otp);
		getLogger().info("Contact Number :" + contactNumber);
		
		if(countryCode.equals(0) || countryCode == null ){		
			getLogger().error("Cannot send SMS country code is not available");
			return;
		}
		if( otp == null || otp.isEmpty()){
			getLogger().error("Cannot send the SMS , OTP string is not available");
			return;
		}
		if(contactNumber == null || contactNumber.isEmpty()){
			getLogger().error("Cannot send the SMS , contact number is empty");
			return;
		}
		OTPSMSTemplate otpSMSTemplate = new OTPSMSTemplate(otp);
		SMSMessageObject messageObj = new SMSMessageObject(otpSMSTemplate.getFormatString());
		messageObj.setDestinationCountryCode(countryCode.toString());
		messageObj.setContactNumber(contactNumber);
		messageObj.setUnicode(false);
		messageObj.setResend(getSmsDetails().isResend());
		
		messengerDelegate.communicateMessage(messageObj, Messenger.SMS_MESSAGE);
	}

	public SMSDetails getSmsDetails() {
		return smsDetails;
	}

	public void setSmsDetails(SMSDetails smsDetails) {
		this.smsDetails = smsDetails;
	}

}

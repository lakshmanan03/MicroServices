package com.bfa.admin.dto;

import java.util.List;

public class AdminSearchResponse {

	private List<CustomerOverviewDTO> customerOverview;
	private Integer dataCount;
	public List<CustomerOverviewDTO> getCustomerOverview() {
		return customerOverview;
	}
	public void setCustomerOverview(List<CustomerOverviewDTO> customerOverview) {
		this.customerOverview = customerOverview;
	}
	public Integer getDataCount() {
		return dataCount;
	}
	public void setDataCount(Integer dataCount) {
		this.dataCount = dataCount;
	}
	
}


/**
 * 
 */
package com.bfa.comprehensive.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comprehensive_retirement_lump_sum")
public class ComprehensiveRetirementLumpSum {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "enquiry_id")
	private Integer enquiryId;
	
	@Column(name = "maturity_amount")
	private Integer maturityAmount;
	
	@Column(name = "maturity_year")
	private Integer maturityYear;
		
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="retirement_planning_id", nullable = false)
	ComprehensiveRetirementPlanning comprehensiveRetirementPlanning;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public Integer getMaturityAmount() {
		return maturityAmount;
	}

	public void setMaturityAmount(Integer maturityAmount) {
		this.maturityAmount = maturityAmount;
	}

	public Integer getMaturityYear() {
		return maturityYear;
	}

	public void setMaturityYear(Integer maturityYear) {
		this.maturityYear = maturityYear;
	}

	public ComprehensiveRetirementPlanning getComprehensiveRetirementPlanning() {
		return comprehensiveRetirementPlanning;
	}

	public void setComprehensiveRetirementPlanning(ComprehensiveRetirementPlanning comprehensiveRetirementPlanning) {
		this.comprehensiveRetirementPlanning = comprehensiveRetirementPlanning;
	}
}

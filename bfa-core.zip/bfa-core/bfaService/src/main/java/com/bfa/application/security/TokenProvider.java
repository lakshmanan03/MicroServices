package com.bfa.application.security;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.util.BFALoggerBean;
import com.bfa.util.PublicUtility;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class TokenProvider  {
	
	@Autowired
	private SecurityConstants constants;
	
	private String appKey = "IMXYlDmP4f4=";

	private PublicUtility utility = PublicUtility.getInstance(appKey);	

	private static final Logger log = Logger.getLogger(TokenProvider.class);

	public String getTokenString(String principal,Collection<? extends GrantedAuthority> grantedAuthorities){

		log.info(" **************************** ");
		log.info("get inside the getTokenString(): ");
		
		Iterator iter = grantedAuthorities.iterator();
		String roles="";
		while(iter.hasNext()){
			GrantedAuthority authority = (GrantedAuthority) iter.next();			
			roles = roles + authority.getAuthority() + ",";
		}
		if("-1".equals(principal)){
			principal = encryptCustomerId(-1);
		}
		System.out.println("Role:" + roles);
		String jwtToken = Jwts.builder().setSubject(principal)
        .claim("roles", roles).setIssuedAt(new Date()).setIssuer(SecurityConstants.TOKEN_NAME).setExpiration(getExpiryTimeForDelay(constants.timeToLive))
        .signWith(SignatureAlgorithm.HS256,constants.base64SecretBytes).compact();
		return jwtToken;
	}
	
	public String getTokenString(String id, String principal,Collection<? extends GrantedAuthority> grantedAuthorities){
		Iterator iter = grantedAuthorities.iterator();
		String roles="";
		while(iter.hasNext()){
			GrantedAuthority authority = (GrantedAuthority) iter.next();			
			roles = roles + authority.getAuthority() + ",";
		}
		return Jwts.builder().setSubject(principal).setId(id)
        .claim("roles", roles).setIssuedAt(new Date()).setIssuer(SecurityConstants.TOKEN_NAME).setExpiration(getExpiryTimeForDelay(constants.timeToLive))
        .signWith(SignatureAlgorithm.HS256,constants.base64SecretBytes).compact();		
	}
	
	public String getTokenStringV2(Integer customerId, Collection<? extends GrantedAuthority> grantedAuthorities) {
		Iterator iter = grantedAuthorities.iterator();
		String roles = "";
		while (iter.hasNext()) {
			GrantedAuthority authority = (GrantedAuthority) iter.next();
			roles = roles + authority.getAuthority() + ",";
		}
		String customerRef = encryptCustomerId(customerId);
		System.out.println("Role:" + roles);
		String jwtToken = Jwts.builder().setSubject(customerRef).claim("roles", roles).setIssuedAt(new Date())
				.setIssuer(SecurityConstants.TOKEN_NAME).setExpiration(getExpiryTimeForDelay(constants.timeToLive))
				.signWith(SignatureAlgorithm.HS256, constants.base64SecretBytes).compact();
		return jwtToken;
	}
	
	private String encryptCustomerId(Integer customerId) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(SecurityConstants.date_format);
		StringBuffer buffer = new StringBuffer();
		buffer.append(customerId);
		buffer.append("###");
		buffer.append(sdf.format(date));
		System.out.println(buffer);
		return utility.EncryptText(buffer.toString());
	}
	
	private Date getExpiryTimeForDelay(int seconds){
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		calendar.add(GregorianCalendar.SECOND, seconds);		
		return calendar.getTime();
	}
		
}
/**
 * 
 */
package com.bfa.notification.messenger.templates;

import com.bfa.notification.MessageObject;

/**
 * @author pradheep.p
 *
 */
public class SMSMessageObject extends MessageObject {
	
	private String contactNumber;
	
	private boolean isUnicode = false;
	
	private String destinationCountryCode;
	
	private boolean isResend;

	public SMSMessageObject(String args) {
		setBodyOfMessage(args);
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public boolean isUnicode() {
		return isUnicode;
	}

	public void setUnicode(boolean isUnicode) {
		this.isUnicode = isUnicode;
	}

	public String getDestinationCountryCode() {
		return destinationCountryCode;
	}

	public void setDestinationCountryCode(String destinationCountryCode) {
		this.destinationCountryCode = destinationCountryCode;
	}

	public boolean isResend() {
		return isResend;
	}

	public void setResend(boolean isResend) {
		this.isResend = isResend;
	}
	
}

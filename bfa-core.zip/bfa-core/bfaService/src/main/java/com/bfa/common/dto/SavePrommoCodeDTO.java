package com.bfa.common.dto;

public class SavePrommoCodeDTO {
	
	private Integer enquiryId;

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

}


package com.bfa.insurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.bfa.configuration.AccountServiceConfiguration;

@SpringBootApplication
@Import(AccountServiceConfiguration.class)
public class AccountsMain {
	
	public static void main(String[] args) {
		//System.setProperty("spring.config.name", "application-local");
		SpringApplication.run(AccountsMain.class, args);
	}
}


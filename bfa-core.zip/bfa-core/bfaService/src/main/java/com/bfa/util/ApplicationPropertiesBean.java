/**
 * 
 */
package com.bfa.util;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;

/**
 * This class loads the application properties file outside the WAR file 
 * From a tomcat folder.
 * @author pradheep.p
 *
 */
public class ApplicationPropertiesBean implements InitializingBean {	

	private Properties properties = new Properties();	

	public void afterPropertiesSet() throws Exception {
	/*	Resource resource = new ClassPathResource("bfa_core.properties")		
		loadProperties(resource.getInputStream())*/
	}

	private void loadProperties(InputStream inputStream) {				
		try {			
			Reader reader = new InputStreamReader(inputStream, "UTF-8");
			try {				
				properties.load(reader);				
			} finally {
				reader.close();
			}
		} catch (Throwable e) {
			throw new RuntimeException("Unable to read property file: ", e);
		}
	}
	
	public Properties getApplicationProperties(){
		return properties;
	}

}

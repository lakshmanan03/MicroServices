/**
 * 
 */
package com.bfa.common.entity;

/**
 * BFA-1233 This is to provide the response between services to know if the
 * security token is still valid or black listed.
 * 
 * @author pradheep.p
 *
 */
public class TokenValidityResponse {	
	
	private String reason;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	
}

package com.bfa.investment.dto;

public class OccupationListDTO {

    private int id;
  
    private String occupation;
    
    private String ssocCode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getSsocCode() {
		return ssocCode;
	}

	public void setSsocCode(String ssocCode) {
		this.ssocCode = ssocCode;
	}

	
}

package com.bfa.servicehelper;

import com.bfa.util.APIResponse;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class MOServiceResponse {
	private String responseBody;
	
	private Integer responseCode;
	
	private Exception exception;
	
	private boolean success;
	
	private String errorMessage;
	
	
	
	
	public Integer getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseBody() {
		return responseBody;
	}
	
	public void setResponseBody(String response) {
		this.responseBody = response;
	}
	public Exception getException() {
		return exception;
	}
	public void setException(Exception exception) {
		this.exception = exception;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public <T> T getResponseAsObject(Class<T> classOfT) {
		if (getResponseBody() != null) {
			Gson gson = new Gson();
			return gson.fromJson(getResponseBody(), classOfT);
		}
		else {
			return null;
		}
	}
	
	public <T> APIResponse<T> parseAbstractResponse(TypeToken type) {
		if (getResponseBody() != null) {
		    return new GsonBuilder()
		            .create()
		            .fromJson(getResponseBody(), type.getType());
		}
		else {
			return null;
		}

	}
	
}

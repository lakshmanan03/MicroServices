package com.bfa.insurance.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "hospital_class_master")	
public class HospitalClassMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "hospital_class")
	private String hospitalClass;
	
	@Column(name = "hospital_class_description")
	private String hospitalClassDescription;
	

	@Column(name = "hospital_type")
	private String hospitalType;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHospitalClass() {
		return hospitalClass;
	}

	public void setHospitalClass(String hospitalClass) {
		this.hospitalClass = hospitalClass;
	}
	public String getHospitalClassDescription() {
		return hospitalClassDescription;
	}

	public void setHospitalClassDescription(String hospitalClassDescription) {
		this.hospitalClassDescription = hospitalClassDescription;
	}

	public String getHospitalType() {

		return hospitalType;
	}

	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;

	}

}

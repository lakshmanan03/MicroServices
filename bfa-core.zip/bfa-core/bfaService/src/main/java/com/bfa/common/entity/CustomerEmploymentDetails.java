package com.bfa.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "customer_employment_details")
public class CustomerEmploymentDetails {
	
	@Id
	@Column(name = "customer_id")
	private Integer customerId;
	
	@Column(name = "employment_status_id")
	private Integer employmentStatusId;
	
	@Column(name = "unemployed_reason")
	private String unemployedReason;
	
	@OneToOne
	@JoinColumn(name = "occupation_id")
	private Occupation occupation;
	
	@Column(name = "other_occupation")
	private String otherOccupation;
	
	@Column(name = "employer_id")
	private Integer employerId;
	
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public Integer getEmploymentStatusId() {
		return employmentStatusId;
	}
	public void setEmploymentStatusId(Integer employmentStatusId) {
		this.employmentStatusId = employmentStatusId;
	}
	public String getUnemployedReason() {
		return unemployedReason;
	}
	public void setUnemployedReason(String umemployedReason) {
		this.unemployedReason = umemployedReason;
	}

	public String getOtherOccupation() {
		return otherOccupation;
	}
	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}
	public Occupation getOccupation() {
		return occupation;
	}
	public void setOccupation(Occupation occupation) {
		this.occupation = occupation;
	}
	public Integer getEmployerId() {
		return employerId;
	}
	public void setEmployerId(Integer employerId) {
		this.employerId = employerId;
	}
	
	
		
}

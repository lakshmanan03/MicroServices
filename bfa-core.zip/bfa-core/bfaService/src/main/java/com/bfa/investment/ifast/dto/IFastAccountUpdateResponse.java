package com.bfa.investment.ifast.dto;

public class IFastAccountUpdateResponse {

	private String counterPartyAccountNumber;
	private String refno;
	private String accountType;
	private String status;
	private MainAcct mainAcct;
	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}
	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}
	public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public MainAcct getMainAcct() {
		return mainAcct;
	}
	public void setMainAcct(MainAcct mainAcct) {
		this.mainAcct = mainAcct;
	}
	@Override
	public String toString() {
		return "IFastAccountUpdateResponse [counterPartyAccountNumber=" + counterPartyAccountNumber + ", refno=" + refno
				+ ", accountType=" + accountType + ", status=" + status + ", mainAcct=" + mainAcct + "]";
	}
	
	
}

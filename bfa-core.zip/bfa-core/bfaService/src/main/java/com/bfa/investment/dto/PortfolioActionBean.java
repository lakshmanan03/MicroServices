package com.bfa.investment.dto;

/**
 * 
 * @author Johnny Israel
 *
 */
public class PortfolioActionBean {

	private String portfolioStatus;
	
	private boolean portfolioLoaded;
	
	private boolean transactionStatus;
	
	private boolean rspUserAccountLevel;
	
	private boolean showDelete;
	
	private boolean showInvest;
	
	private boolean showTopup;
	
	private boolean showWithdrawPvToBa;
	
	private boolean showWithdrawPvToCa;
	
	private boolean showWithdrawCaToBa;
	
	private boolean showWithdrawPvToSRS;
	
	private boolean processMonthly;
	
	private boolean processAwaitingFundTransaction;

	/**
	 * @return the portfolioStatus
	 */
	public String getPortfolioStatus() {
		return portfolioStatus;
	}

	/**
	 * @param portfolioStatus the portfolioStatus to set
	 */
	public void setPortfolioStatus(String portfolioStatus) {
		this.portfolioStatus = portfolioStatus;
	}

	/**
	 * @return the portfolioLoaded
	 */
	public boolean isPortfolioLoaded() {
		return portfolioLoaded;
	}

	/**
	 * @param portfolioLoaded the portfolioLoaded to set
	 */
	public void setPortfolioLoaded(boolean portfolioLoaded) {
		this.portfolioLoaded = portfolioLoaded;
	}

	/**
	 * @return the transactionStatus
	 */
	public boolean isTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public void setTransactionStatus(boolean transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * @return the rspUserAccountLevel
	 */
	public boolean isRspUserAccountLevel() {
		return rspUserAccountLevel;
	}

	/**
	 * @param rspUserAccountLevel the rspUserAccountLevel to set
	 */
	public void setRspUserAccountLevel(boolean rspUserAccountLevel) {
		this.rspUserAccountLevel = rspUserAccountLevel;
	}

	/**
	 * @return the showDelete
	 */
	public boolean isShowDelete() {
		return showDelete;
	}

	/**
	 * @param showDelete the showDelete to set
	 */
	public void setShowDelete(boolean showDelete) {
		this.showDelete = showDelete;
	}

	/**
	 * @return the showInvest
	 */
	public boolean isShowInvest() {
		return showInvest;
	}

	/**
	 * @param showInvest the showInvest to set
	 */
	public void setShowInvest(boolean showInvest) {
		this.showInvest = showInvest;
	}

	/**
	 * @return the showTopup
	 */
	public boolean isShowTopup() {
		return showTopup;
	}

	/**
	 * @param showTopup the showTopup to set
	 */
	public void setShowTopup(boolean showTopup) {
		this.showTopup = showTopup;
	}

	/**
	 * @return the showWithdrawPvToBa
	 */
	public boolean isShowWithdrawPvToBa() {
		return showWithdrawPvToBa;
	}

	/**
	 * @param showWithdrawPvToBa the showWithdrawPvToBa to set
	 */
	public void setShowWithdrawPvToBa(boolean showWithdrawPvToBa) {
		this.showWithdrawPvToBa = showWithdrawPvToBa;
	}

	/**
	 * @return the showWithdrawPvToCa
	 */
	public boolean isShowWithdrawPvToCa() {
		return showWithdrawPvToCa;
	}

	/**
	 * @param showWithdrawPvToCa the showWithdrawPvToCa to set
	 */
	public void setShowWithdrawPvToCa(boolean showWithdrawPvToCa) {
		this.showWithdrawPvToCa = showWithdrawPvToCa;
	}

	/**
	 * @return the showWithdrawCaToBa
	 */
	public boolean isShowWithdrawCaToBa() {
		return showWithdrawCaToBa;
	}

	/**
	 * @param showWithdrawCaToBa the showWithdrawCaToBa to set
	 */
	public void setShowWithdrawCaToBa(boolean showWithdrawCaToBa) {
		this.showWithdrawCaToBa = showWithdrawCaToBa;
	}
	
	public boolean isShowWithdrawPvToSRS() {
		return showWithdrawPvToSRS;
	}

	public void setShowWithdrawPvToSRS(boolean showWithdrawPvToSRS) {
		this.showWithdrawPvToSRS = showWithdrawPvToSRS;
	}

	/**
	 * @return the processMonthly
	 */
	public boolean isProcessMonthly() {
		return processMonthly;
	}

	/**
	 * @param processMonthly the processMonthly to set
	 */
	public void setProcessMonthly(boolean processMonthly) {
		this.processMonthly = processMonthly;
	}

	/**
	 * @return the processAwaitingFundTransaction
	 */
	public boolean isProcessAwaitingFundTransaction() {
		return processAwaitingFundTransaction;
	}

	/**
	 * @param processAwaitingFundTransaction the processAwaitingFundTransaction to set
	 */
	public void setProcessAwaitingFundTransaction(boolean processAwaitingFundTransaction) {
		this.processAwaitingFundTransaction = processAwaitingFundTransaction;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return String.format(
				"PortfolioActionBean [portfolioStatus=%s, portfolioLoaded=%s, transactionStatus=%s, rspUserAccountLevel=%s, showDelete=%s, showInvest=%s, showTopup=%s, showWithdrawPvToBa=%s, showWithdrawPvToCa=%s, showWithdrawCaToBa=%s, processMonthly=%s, processAwaitingFundTransaction=%s]",
				portfolioStatus, portfolioLoaded, transactionStatus, rspUserAccountLevel, showDelete, showInvest,
				showTopup, showWithdrawPvToBa, showWithdrawPvToCa, showWithdrawCaToBa, processMonthly,
				processAwaitingFundTransaction);
	}
	
}


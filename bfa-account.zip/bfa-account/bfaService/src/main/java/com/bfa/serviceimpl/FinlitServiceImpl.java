/**
 * 
 */
package com.bfa.serviceimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;

import com.bfa.application.core.security.FinlitAccessCode;
import com.bfa.application.core.security.FinlitAuthenticationRequest;
import com.bfa.application.exception.CustomerNotFoundException;
import com.bfa.application.security.BFAUserDetailsService;
import com.bfa.application.security.SecurityInfo;
import com.bfa.application.security.TokenProvider;
import com.bfa.common.entity.BFAGrantedAuthority;
import com.bfa.dao.AccountsDao;
import com.bfa.daoimpl.FinlitDAOImpl;
import com.bfa.insurance.core.Customer;
import com.bfa.insurance.core.CustomerPrevilege;
import com.bfa.insurance.core.PrevilageMaster;
import com.bfa.insurance.core.SessionDetails;
import com.bfa.service.FinlitService;
import com.bfa.util.ResponseMessageList;

/**
 * @author pradheep
 *
 */
public class FinlitServiceImpl extends DefaultServiceImpl implements FinlitService {		

	@Autowired
	private BFAUserDetailsService bfaUserDetailsService;
	
	@Autowired
	private TokenProvider tokenProvider;
	
	List<PrevilageMaster> privileges = null;	
	
	@Autowired
	private FinlitDAOImpl finlitDAO;
	
	@Autowired
	private AccountsDao accountsDAO;
	
	private String getUniqueSessionId() {
		return UUID.randomUUID().toString();		
	}
	
	public SessionDetails saveSessionDetails(String sessionId, HttpServletRequest request) {
		SessionDetails sessionDetails = getSessionDetails(request);
		sessionDetails.setSessionId(sessionId);
		getLogger().info("Saving session details " + sessionDetails.toString());
		try {
			return (SessionDetails) finlitDAO.saveOrUpdateObject(sessionDetails);
		} catch (Exception err) {
			getLogger().error("Error while updating session details ", err);
		}
		return null;
	}
	

	/**
	 * This method compares the given access code in the database and returns if
	 * that is present and valid.
	 */
	@Override
	public boolean isValidAccessCode(String accessCode) {
		List<FinlitAccessCode> accessCodeList = finlitDAO.isValidAccessCode(accessCode);
		if (null == accessCodeList || accessCodeList.isEmpty()) {
			getLogger().info("No matching records found for : " + accessCode);
			return false;
		}
		getLogger().info("Found :" + accessCodeList.size() + " records");
		return true;
	}

	/**
	 * Assign the special previleges to the customer with specific access codes.
	 */
	@Override
	public void assignFinlitRolesForCustomer(List<PrevilageMaster> privileges,Integer customerId) throws CustomerNotFoundException {
		getLogger().info("Assign the roles to the customer :" + customerId);
		if(customerId == -1){
			throw new CustomerNotFoundException("Internal server error - Customer not found ");
		}
		List<Integer> existingPrivileges = accountsDAO.getExistingPrivileges(customerId);
		StringBuffer rolesAssigned = new StringBuffer();
		Iterator<PrevilageMaster> iter = privileges.iterator();
			while (iter.hasNext()) {
				PrevilageMaster previlageMaster = iter.next();
				rolesAssigned.append(previlageMaster.getPrvilegeName() + " ");
				if(!existingPrivileges.contains(previlageMaster.getPrevilegeId())) {
					CustomerPrevilege customerPrevilege = new CustomerPrevilege();
					customerPrevilege.setCustomerId(customerId);
					customerPrevilege.setPrevilegetId(previlageMaster.getPrevilegeId());
					getLogger().info("Assigning the privilege :" + previlageMaster.getPrevilegeId()
							+ " to customer id: " + customerId);
					finlitDAO.saveObject(customerPrevilege);
				} else {
					getLogger().info("Role (" + previlageMaster.getPrevilegeId() + ") already provided to the customer "
							+ customerId);
				}
			}
				
		getLogger().info("Completed assigning the roles " + rolesAssigned + " to customer :" + customerId);		
	}	
	
	

	@Override
	public boolean validateInputs(FinlitAuthenticationRequest request) throws IllegalArgumentException {
		getLogger().info("Validating the finlit authentication request");
		String email = request.getEmail();
		String mobile = request.getMobile();
		String accessCode = request.getAccessCode();
		
		if (!StringUtils.isNotEmpty(email) && !StringUtils.isNotEmpty(mobile)) {
			throw new IllegalArgumentException("Email address or Mobile number cannot be empty");
		}
		if (!StringUtils.isNotEmpty(request.getPassword())) {
			throw new IllegalArgumentException("Password cannot be empty");
		}
		if (!StringUtils.isNotEmpty(request.getSessionId())) {
			throw new IllegalArgumentException("Session id cannot be empty");
		}
		if (!StringUtils.isNotEmpty(accessCode)) {
			throw new IllegalArgumentException("Access code cannot be null or empty");
		}
		return true;		
	}
	
	@Override
	public void provideJWTTokenAndSessionDetails(String email, String mobileNumber,
			ResponseMessageList responseMessageList, HttpServletRequest servletRequest) {		
		try {
			getLogger().info("Add JWT token for the user:" + email + " Mobile Number:" + mobileNumber);
			CustomerDetails customerDetails = getCustomerDetails(email, mobileNumber);
			List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
			for (String authority : customerDetails.authorities) {
				BFAGrantedAuthority bfaGrantedAuthority = new BFAGrantedAuthority(authority);
				grantedAuthorities.add(bfaGrantedAuthority);
			}
			Integer customerId = customerDetails.customerId;
			String jwtToken = tokenProvider.getTokenStringV2(customerId, grantedAuthorities);
			String sessionId = getUniqueSessionId();
			getLogger().info("Session id: " + sessionId);
			saveSessionDetails(sessionId, servletRequest);			
			String customerIdEnc = utility.EncryptText(String.valueOf(customerDetails.customerId));
			SecurityInfo securityInfo = new SecurityInfo(jwtToken, sessionId, customerIdEnc);
			List<Object> tokenList = new ArrayList<Object>();
			tokenList.add(securityInfo);
			responseMessageList.setObjectList(tokenList);
		} catch (Exception err) {
			getLogger().error("Error while adding the jwt token details", err);
		}
	}	

	@Override
	public List<PrevilageMaster> getRobo3LiteRolesByCode(String accessCode) {
		return finlitDAO.getRobo3LiteRolesByCode(accessCode);
	}
	
	private CustomerDetails getCustomerDetails(String email, String mobileNumber) {		
		Customer customerObj = null;
		if (StringUtils.isNotEmpty(email)) {
			getLogger().info("Fetching user details by email: " + email);			
			List<Customer> customers = accountsDAO.getCustomerByEmail(email);
			if(!customers.isEmpty()){				
			customerObj = (Customer) customers.get(0);			
			}
		} else if (StringUtils.isNotEmpty(mobileNumber)) {			
			List<Customer> customers = accountsDAO.getCustomerByMobile(mobileNumber);
			if(!customers.isEmpty()){				
			customerObj = (Customer)customers.get(0);			
			}
		}
		Integer customerId = customerObj.getId();		
		List<String> roles = accountsDAO.getPrevilegesForCustomer(customerId);
		CustomerDetails custDetails = new CustomerDetails(customerId, roles);
		return custDetails;
	}
	
	class CustomerDetails {
		public Integer customerId;
		public List<String> authorities;

		public CustomerDetails(Integer customerId, List<String> authorities) {
			this.customerId = customerId;
			this.authorities = authorities;
		}
	}
}

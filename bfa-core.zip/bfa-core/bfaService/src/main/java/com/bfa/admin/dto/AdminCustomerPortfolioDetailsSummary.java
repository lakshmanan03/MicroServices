package com.bfa.admin.dto;

import java.util.Date;
import java.util.List;

import com.bfa.common.entity.CustomerAssessmentDetails;
import com.bfa.insurance.core.Assets;
import com.bfa.insurance.core.Income;
import com.bfa.insurance.core.Liabilities;
import com.bfa.investment.entity.CustomerInvestmentObjective;

public class AdminCustomerPortfolioDetailsSummary {
	
	private String productName;
	private Double totalReturns;
	private Double yearlyReturns;
	private Double totalInvested;
	private Double currentValue;
	private CustomerInvestmentObjective investmentObjective;
	private Income income;
	private Liabilities liabilities;
	private Assets assets;
	private String investemntSource;
	private String ifastReferenceNumber;
	private List<CustomerAssessmentDetails> customerAssessmentDetails;
	private Integer customerPortfolioId;
	private Double cashAccountBalance;
	private String portfolioType;
	private int riskTypeId;
	private String riskProfileType;
	private String createdDate;
	private String lastUpdatedTimeStamp;
	private String currentPortfolioStatus;
	private String portfolioCategory;
	
	
	public String getRiskProfileType() {
		return riskProfileType;
	}
	public void setRiskProfileType(String riskProfileType) {
		this.riskProfileType = riskProfileType;
	}
	public int getRiskTypeId() {
		return riskTypeId;
	}
	public void setRiskTypeId(int riskTypeId) {
		this.riskTypeId = riskTypeId;
	}
	
	public String getPortfolioType() {
		return portfolioType;
	}
	public void setPortfolioType(String portfolioType) {
		this.portfolioType = portfolioType;
	}
	public Double getCashAccountBalance() {
		return cashAccountBalance;
	}
	public void setCashAccountBalance(Double cashAccountBalance) {
		this.cashAccountBalance = cashAccountBalance;
	}
	public Integer getCustomerPortfolioId() {
		return customerPortfolioId;
	}
	public void setCustomerPortfolioId(Integer customerPortfolioId) {
		this.customerPortfolioId = customerPortfolioId;
	}
	public String getIfastReferenceNumber() {
		return ifastReferenceNumber;
	}
	public void setIfastReferenceNumber(String ifastReferenceNumber) {
		this.ifastReferenceNumber = ifastReferenceNumber;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getTotalReturns() {
		return totalReturns;
	}
	public void setTotalReturns(Double totalReturns) {
		this.totalReturns = totalReturns;
	}
	public Double getYearlyReturns() {
		return yearlyReturns;
	}
	public void setYearlyReturns(Double yearlyReturns) {
		this.yearlyReturns = yearlyReturns;
	}
	public Double getTotalInvested() {
		return totalInvested;
	}
	public void setTotalInvested(Double totalInvested) {
		this.totalInvested = totalInvested;
	}
	public Double getCurrentValue() {
		return currentValue;
	}
	public void setCurrentValue(Double currentValue) {
		this.currentValue = currentValue;
	}
	public CustomerInvestmentObjective getInvestmentObjective() {
		return investmentObjective;
	}
	public void setInvestmentObjective(CustomerInvestmentObjective investmentObjective) {
		this.investmentObjective = investmentObjective;
	}
	public Income getIncome() {
		return income;
	}
	public void setIncome(Income income) {
		this.income = income;
	}
	public Liabilities getLiabilities() {
		return liabilities;
	}
	public void setLiabilities(Liabilities liabilities) {
		this.liabilities = liabilities;
	}
	public Assets getAssets() {
		return assets;
	}
	public void setAssets(Assets assets) {
		this.assets = assets;
	}
	public String getInvestemntSource() {
		return investemntSource;
	}
	public void setInvestemntSource(String investemntSource) {
		this.investemntSource = investemntSource;
	}
	public List<CustomerAssessmentDetails> getCustomerAssessmentDetails() {
		return customerAssessmentDetails;
	}
	public void setCustomerAssessmentDetails(List<CustomerAssessmentDetails> customerAssessmentDetails) {
		this.customerAssessmentDetails = customerAssessmentDetails;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}
	public void setLastUpdatedTimeStamp(String lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}
	public String getCurrentPortfolioStatus() {
		return currentPortfolioStatus;
	}
	public void setCurrentPortfolioStatus(String currentPortfolioStatus) {
		this.currentPortfolioStatus = currentPortfolioStatus;
	}
	public String getPortfolioCategory() {
		return portfolioCategory;
	}
	public void setPortfolioCategory(String portfolioCategory) {
		this.portfolioCategory = portfolioCategory;
	}
	

}

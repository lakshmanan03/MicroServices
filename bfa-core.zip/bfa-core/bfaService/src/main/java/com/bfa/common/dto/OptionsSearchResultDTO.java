package com.bfa.common.dto;

import com.bfa.common.entity.Country;
import com.bfa.common.entity.Industry;
import com.bfa.common.entity.Occupation;
import com.bfa.common.entity.OptionItem;
import com.bfa.investment.dto.NationalityDTO;

public class OptionsSearchResultDTO {
	
	private Country country;
	private NationalityDTO nationality;
	private Occupation occupation;
	private Industry industry;
	private OptionItem houseHoldRange;
	
	
	
	
	
	public OptionItem getHouseHoldRange() {
		return houseHoldRange;
	}
	public void setHouseHoldRange(OptionItem houseHoldRange) {
		this.houseHoldRange = houseHoldRange;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	public NationalityDTO getNationality() {
		return nationality;
	}
	public void setNationality(NationalityDTO nationality) {
		this.nationality = nationality;
	}
	public Occupation getOccupation() {
		return occupation;
	}
	public void setOccupation(Occupation occupation) {
		this.occupation = occupation;
	}
	public Industry getIndustry() {
		return industry;
	}
	public void setIndustry(Industry industry) {
		this.industry = industry;
	}
	
	
}

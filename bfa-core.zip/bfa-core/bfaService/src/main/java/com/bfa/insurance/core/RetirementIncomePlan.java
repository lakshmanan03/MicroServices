/**
 * 
 */
package com.bfa.insurance.core;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradheep.p
 *
 */
@Entity
@Table(name = "retirement_income_plan")
public class RetirementIncomePlan implements Serializable{
	

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "enquiry_id")
	private int enquiryId;
	
	@Column(name = "customer_id")
	private int customerId;
	
	@Column(name = "retirement_income")
	private double retirementIncome;
	
	@Column(name = "payout_start_age")
	private int payoutStartAge;	
	
	@Column(name = "payout_duration")
	private String payoutDuration;
	
	@Column(name="payout_feature")
	private String payoutFeature;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getRetirementIncome() {
		return retirementIncome;
	}

	public void setRetirementIncome(double retirementIncome) {
		this.retirementIncome = retirementIncome;
	}

	public int getPayoutStartAge() {
		return payoutStartAge;
	}

	public void setPayoutStartAge(int payoutStartAge) {
		this.payoutStartAge = payoutStartAge;
	}

	public String getPayoutDuration() {
		return payoutDuration;
	}

	public void setPayoutDuration(String payoutDuration) {
		this.payoutDuration = payoutDuration;
	}

	public String getPayoutFeature() {
		return payoutFeature;
	}

	public void setPayoutFeature(String payoutFeature) {
		this.payoutFeature = payoutFeature;
	}
}

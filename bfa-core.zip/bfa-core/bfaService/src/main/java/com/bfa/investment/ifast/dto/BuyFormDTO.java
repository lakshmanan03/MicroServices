package com.bfa.investment.ifast.dto;

public class BuyFormDTO implements IFastRequestObject{
	private String portfolioId;//
	private String refno ;
	private String trustId;
	private String paymentMode;
	
	
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(String portfolioId) {
		this.portfolioId = portfolioId;
	}
	public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getTrustId() {
		return trustId;
	}
	public void setTrustId(String trustId) {
		this.trustId = trustId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BuyFormDTO [portfolioId=");
		builder.append(portfolioId);
		builder.append(", refno=");
		builder.append(refno);
		builder.append(", trustId=");
		builder.append(trustId);
		builder.append(", paymentMode=");
		builder.append(paymentMode);
		builder.append("]");
		return builder.toString();
	}
	@Override
	public String getReferenceNumber() {
		return this.refno;
	}
}

/**
 * 
 */
package com.bfa.request.processor;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author pradheep.p
 *
 */
public abstract class FailureHandler implements Runnable {
	
	@Autowired
	public QueueProcessorController queueProcessorController;
	
	private Object sourceObj;

	public Object getSource() {
		return sourceObj;
	}

	public void setSource(Object source) {
		this.sourceObj = source;
	}
	
	public void handle(){
		ProcessorCommand command = (ProcessorCommand) getSource();
		int failureCount = command.failureCount;
		command.failureCount = failureCount + 1;
		command.timeDelayForReschedule = 5000;		
		queueProcessorController.addJobToQueue(command);		
		System.out.println("command failed :" + command.getCommandName() + "- Job failed to update job : " + command.uniqueKey + "Failure count:" + command.failureCount);
	}

}

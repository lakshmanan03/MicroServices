package com.bfa.investment.ifast.dto;

import java.io.Serializable;

/**
 * @author VimalaS
 *
 */
public class MultiplePortfolioAccCreationDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String refno;
	private String counterPartyAccountNumber;
	public String getRefno() {
		return refno;
	}
	public void setRefno(String refno) {
		this.refno = refno;
	}
	public String getCounterPartyAccountNumber() {
		return counterPartyAccountNumber;
	}
	public void setCounterPartyAccountNumber(String counterPartyAccountNumber) {
		this.counterPartyAccountNumber = counterPartyAccountNumber;
	}

}

import React, { Component } from 'react'


class OrderComponent extends Component {


    

        render (){
            return (
            <div ><h2 style={style}> Order placed for {window.localStorage.getItem('item')}

            </h2>

            <h4 style={style1}>kindly pay the amount of {window.localStorage.getItem('amount')} while it is delivered</h4>
            </div>
            );

        }
  
}

const style = {
    color: 'green',
    margin: '10px'
}

const style1 = {
    color: 'red',
    margin: '5px'
}
export default OrderComponent;